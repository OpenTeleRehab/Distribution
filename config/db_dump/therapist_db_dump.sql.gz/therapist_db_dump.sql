-- MySQL dump 10.13  Distrib 8.3.0, for Linux (x86_64)
--
-- Host: localhost    Database: therapist_service
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activities`
--

DROP TABLE IF EXISTS `activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activities` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `treatment_plan_id` int NOT NULL,
  `week` int NOT NULL,
  `day` int NOT NULL,
  `activity_id` int NOT NULL,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sets` tinyint DEFAULT NULL,
  `reps` tinyint DEFAULT NULL,
  `additional_information` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=180 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activities`
--

LOCK TABLES `activities` WRITE;
/*!40000 ALTER TABLE `activities` DISABLE KEYS */;
INSERT INTO `activities` VALUES (1,1,1,1,3,'exercise',NULL,NULL,NULL),(2,1,1,1,2,'exercise',NULL,NULL,NULL),(3,1,1,1,1,'material',NULL,NULL,NULL),(4,1,1,1,15,'questionnaire',NULL,NULL,NULL),(5,6,1,6,1,'exercise',NULL,NULL,NULL),(6,6,1,6,4,'exercise',NULL,NULL,NULL),(7,6,1,5,32,'exercise',NULL,NULL,NULL),(8,6,1,5,1,'exercise',NULL,NULL,NULL),(9,6,1,5,3,'exercise',NULL,NULL,NULL),(10,6,1,4,29,'exercise',NULL,NULL,NULL),(11,6,1,4,31,'exercise',NULL,NULL,NULL),(12,6,1,4,32,'exercise',NULL,NULL,NULL),(13,8,1,5,3,'exercise',NULL,NULL,NULL),(14,8,1,3,4,'exercise',NULL,NULL,NULL),(15,8,1,2,3,'exercise',NULL,NULL,NULL),(16,8,1,2,1,'material',NULL,NULL,NULL),(17,8,1,2,15,'questionnaire',NULL,NULL,NULL),(18,9,1,5,4,'exercise',NULL,NULL,NULL),(19,9,1,5,2,'exercise',NULL,NULL,NULL),(20,9,1,5,29,'exercise',NULL,NULL,NULL),(21,9,1,4,33,'exercise',NULL,NULL,NULL),(22,9,1,4,32,'exercise',NULL,NULL,NULL),(23,9,1,3,15,'questionnaire',NULL,NULL,NULL),(24,9,1,2,3,'exercise',NULL,NULL,NULL),(25,9,1,2,1,'exercise',NULL,NULL,NULL),(26,9,1,1,2,'exercise',NULL,NULL,NULL),(27,9,1,1,4,'exercise',NULL,NULL,NULL),(28,9,1,1,31,'exercise',NULL,NULL,NULL),(29,10,1,7,29,'exercise',NULL,NULL,NULL),(30,10,1,7,32,'exercise',NULL,NULL,NULL),(31,10,1,6,2,'exercise',NULL,NULL,NULL),(32,10,1,6,31,'exercise',NULL,NULL,NULL),(33,10,1,5,1,'material',NULL,NULL,NULL),(34,10,1,4,33,'exercise',NULL,NULL,NULL),(35,10,1,4,32,'exercise',NULL,NULL,NULL),(36,10,1,3,1,'exercise',NULL,NULL,NULL),(37,10,1,3,3,'exercise',NULL,NULL,NULL),(38,10,1,2,29,'exercise',NULL,NULL,NULL),(39,10,1,2,31,'exercise',NULL,NULL,NULL),(40,10,1,1,2,'exercise',NULL,NULL,NULL),(41,10,1,1,4,'exercise',NULL,NULL,NULL),(42,11,1,7,32,'exercise',NULL,NULL,NULL),(43,11,1,6,3,'exercise',NULL,NULL,NULL),(44,11,1,5,1,'exercise',NULL,NULL,NULL),(45,11,1,4,31,'exercise',NULL,NULL,NULL),(46,11,1,3,29,'exercise',NULL,NULL,NULL),(47,11,1,2,4,'exercise',NULL,NULL,NULL),(48,11,1,1,2,'exercise',NULL,NULL,NULL),(49,12,1,1,3,'exercise',NULL,NULL,NULL),(50,12,1,7,31,'exercise',NULL,NULL,NULL),(51,12,1,6,31,'exercise',NULL,NULL,NULL),(52,12,1,5,31,'exercise',NULL,NULL,NULL),(53,12,1,4,31,'exercise',NULL,NULL,NULL),(54,12,1,3,31,'exercise',NULL,NULL,NULL),(55,12,1,2,31,'exercise',NULL,NULL,NULL),(58,14,1,1,2,'exercise',NULL,NULL,NULL),(59,15,1,1,2,'exercise',NULL,NULL,NULL),(60,15,1,1,4,'exercise',NULL,NULL,NULL),(61,15,1,1,1,'material',NULL,NULL,NULL),(62,15,1,1,15,'questionnaire',NULL,NULL,NULL),(63,16,1,3,2,'exercise',NULL,NULL,NULL),(64,16,1,3,4,'exercise',NULL,NULL,NULL),(65,16,1,3,1,'material',NULL,NULL,NULL),(66,16,1,2,2,'exercise',NULL,NULL,NULL),(67,16,1,2,4,'exercise',NULL,NULL,NULL),(68,16,1,2,1,'material',NULL,NULL,NULL),(69,18,2,1,29,'exercise',NULL,NULL,NULL),(70,18,2,3,29,'exercise',NULL,NULL,NULL),(71,18,2,5,29,'exercise',NULL,NULL,NULL),(72,18,1,3,29,'exercise',NULL,NULL,NULL),(73,18,1,5,29,'exercise',NULL,NULL,NULL),(74,18,1,1,29,'exercise',NULL,NULL,NULL),(75,17,1,2,1,'material',NULL,NULL,NULL),(76,17,1,2,15,'questionnaire',NULL,NULL,NULL),(77,17,1,1,2,'exercise',NULL,NULL,NULL),(78,17,1,1,124,'exercise',NULL,NULL,NULL),(79,17,2,4,1,'material',NULL,NULL,NULL),(80,19,1,7,1,'material',NULL,NULL,NULL),(81,19,1,7,24,'material',NULL,NULL,NULL),(82,20,1,3,2,'exercise',NULL,NULL,NULL),(83,21,1,2,57,'questionnaire',NULL,NULL,NULL),(84,21,1,2,58,'questionnaire',NULL,NULL,NULL),(85,21,1,1,4,'exercise',NULL,NULL,NULL),(86,21,1,1,1,'material',NULL,NULL,NULL),(87,23,1,2,2,'exercise',NULL,NULL,NULL),(88,23,1,2,29,'exercise',NULL,NULL,NULL),(89,23,1,2,33,'exercise',NULL,NULL,NULL),(90,23,1,3,2,'exercise',NULL,NULL,NULL),(91,23,1,3,29,'exercise',NULL,NULL,NULL),(92,23,1,3,33,'exercise',NULL,NULL,NULL),(93,23,1,4,2,'exercise',NULL,NULL,NULL),(94,23,1,4,29,'exercise',NULL,NULL,NULL),(95,23,1,4,33,'exercise',NULL,NULL,NULL),(96,23,1,5,2,'exercise',NULL,NULL,NULL),(97,23,1,5,29,'exercise',NULL,NULL,NULL),(98,23,1,5,33,'exercise',NULL,NULL,NULL),(99,23,1,6,2,'exercise',NULL,NULL,NULL),(100,23,1,6,29,'exercise',NULL,NULL,NULL),(101,23,1,6,33,'exercise',NULL,NULL,NULL),(102,23,1,7,2,'exercise',NULL,NULL,NULL),(103,23,1,7,29,'exercise',NULL,NULL,NULL),(104,23,1,7,33,'exercise',NULL,NULL,NULL),(105,23,1,1,2,'exercise',NULL,NULL,NULL),(106,23,1,1,29,'exercise',NULL,NULL,NULL),(107,23,1,1,33,'exercise',NULL,NULL,NULL),(108,24,1,1,2,'exercise',NULL,NULL,NULL),(110,26,1,1,2,'exercise',NULL,NULL,NULL),(111,26,1,1,33,'exercise',NULL,NULL,NULL),(112,26,1,1,15,'questionnaire',NULL,NULL,NULL),(113,28,1,1,2,'exercise',NULL,NULL,NULL),(114,29,1,2,2,'exercise',NULL,NULL,NULL),(115,29,1,2,33,'material',NULL,NULL,NULL),(116,31,1,2,4,'exercise',NULL,NULL,NULL),(117,31,1,2,155,'exercise',NULL,NULL,NULL),(118,31,1,2,43,'material',NULL,NULL,NULL),(119,31,1,2,15,'questionnaire',NULL,NULL,NULL),(120,31,1,3,4,'exercise',NULL,NULL,NULL),(121,31,1,3,155,'exercise',NULL,NULL,NULL),(122,31,1,3,43,'material',NULL,NULL,NULL),(123,31,1,3,15,'questionnaire',NULL,NULL,NULL),(124,31,1,4,4,'exercise',NULL,NULL,NULL),(125,31,1,4,155,'exercise',NULL,NULL,NULL),(126,31,1,4,43,'material',NULL,NULL,NULL),(127,31,1,4,15,'questionnaire',NULL,NULL,NULL),(128,31,1,5,4,'exercise',NULL,NULL,NULL),(129,31,1,5,155,'exercise',NULL,NULL,NULL),(130,31,1,5,43,'material',NULL,NULL,NULL),(131,31,1,5,15,'questionnaire',NULL,NULL,NULL),(132,31,1,6,4,'exercise',NULL,NULL,NULL),(133,31,1,6,155,'exercise',NULL,NULL,NULL),(134,31,1,6,43,'material',NULL,NULL,NULL),(135,31,1,6,15,'questionnaire',NULL,NULL,NULL),(136,31,1,7,4,'exercise',NULL,NULL,NULL),(137,31,1,7,155,'exercise',NULL,NULL,NULL),(138,31,1,7,43,'material',NULL,NULL,NULL),(139,31,1,7,15,'questionnaire',NULL,NULL,NULL),(140,31,1,1,4,'exercise',NULL,NULL,NULL),(141,31,1,1,155,'exercise',NULL,NULL,NULL),(142,31,1,1,43,'material',NULL,NULL,NULL),(143,31,1,1,15,'questionnaire',NULL,NULL,NULL),(144,32,1,2,152,'exercise',NULL,NULL,NULL),(145,32,1,2,15,'questionnaire',NULL,NULL,NULL),(146,32,1,1,152,'exercise',NULL,NULL,NULL),(147,32,1,1,15,'questionnaire',NULL,NULL,NULL),(148,33,1,1,2,'exercise',NULL,NULL,NULL),(149,32,1,4,2,'exercise',4,10,'test'),(150,32,1,3,2,'exercise',1,1,'Less advanced: 1. Decrease the distance to the cup. More advanced: 1. Increase the distance to the cup. 2. Increase the amount of wrist extension.'),(151,32,1,5,80,'questionnaire',NULL,NULL,NULL),(152,34,1,1,2,'exercise',NULL,NULL,NULL),(153,34,1,1,4,'exercise',NULL,NULL,NULL),(154,34,1,1,29,'exercise',NULL,NULL,NULL),(155,35,1,2,2,'exercise',4,10,NULL),(156,35,1,4,2,'exercise',4,10,NULL),(157,35,1,6,2,'exercise',4,10,NULL),(158,35,1,1,2,'exercise',NULL,NULL,NULL),(159,36,2,1,1,'exercise',3,10,NULL),(160,36,2,4,1,'exercise',3,10,NULL),(161,36,3,1,1,'exercise',3,10,NULL),(162,36,3,4,1,'exercise',3,10,NULL),(163,36,4,1,1,'exercise',3,10,NULL),(164,36,4,4,1,'exercise',3,10,NULL),(165,36,5,1,1,'exercise',3,10,NULL),(166,36,5,4,1,'exercise',3,10,NULL),(167,36,6,1,1,'exercise',3,10,NULL),(168,36,6,4,1,'exercise',3,10,NULL),(169,36,1,1,1,'exercise',NULL,NULL,NULL),(172,36,1,2,15,'questionnaire',NULL,NULL,NULL),(173,36,1,3,4,'exercise',NULL,NULL,NULL),(174,36,1,4,96,'questionnaire',NULL,NULL,NULL),(175,37,1,2,195,'exercise',NULL,NULL,NULL),(176,37,1,1,2,'exercise',NULL,NULL,NULL),(177,39,1,1,215,'exercise',NULL,NULL,NULL),(178,39,1,1,70,'material',NULL,NULL,NULL),(179,39,1,1,107,'questionnaire',NULL,NULL,NULL);
/*!40000 ALTER TABLE `activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `messages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `patient_id` int NOT NULL,
  `message` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `therapist_id` int NOT NULL,
  `sent_at` timestamp NULL DEFAULT NULL,
  `draft` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
INSERT INTO `messages` VALUES (1,247,'Hello, Jeff. This is a test message from HI.',156,'2022-12-22 01:42:37',NULL,'2022-12-22 01:42:37','2022-12-22 01:42:37'),(2,247,'Hello Jeff',156,'2022-12-23 08:03:44',NULL,'2022-12-23 08:03:44','2022-12-23 08:03:44'),(3,247,'Hello Jeff. This is from Phearoth',156,'2022-12-23 08:12:17',NULL,'2022-12-23 08:12:17','2022-12-23 08:12:17'),(5,247,'This is a draft message aksjlfjslfdjdsfalsf',156,NULL,1,'2022-12-23 08:24:24','2022-12-23 08:24:24'),(11,248,'hello',237,'2023-02-03 03:51:30',NULL,'2023-02-03 03:51:30','2023-02-03 03:51:30'),(12,248,'Hello',237,'2023-02-03 03:52:01',NULL,'2023-02-03 03:52:01','2023-02-03 03:52:01'),(13,248,'Hello',237,'2023-02-03 03:52:03',NULL,'2023-02-03 03:52:03','2023-02-03 03:52:03'),(14,248,'Hello',237,'2023-02-03 03:52:17',NULL,'2023-02-03 03:52:17','2023-02-03 03:52:17'),(15,248,'Hello',237,'2023-02-03 03:52:22',NULL,'2023-02-03 03:52:22','2023-02-03 03:52:22'),(35,238,'Hello',190,'2023-02-03 04:13:03',NULL,'2023-01-28 04:13:03','2023-02-03 04:13:03'),(36,238,'Hello',190,'2023-02-03 04:13:10',NULL,'2023-01-28 04:13:10','2023-02-03 04:13:10'),(37,238,'Hello',190,'2023-02-03 04:14:08',NULL,'2023-01-28 04:14:08','2023-02-03 04:14:08'),(38,238,'Hello',190,'2023-02-03 04:14:10',NULL,'2023-01-28 04:14:10','2023-02-03 04:14:10'),(39,238,'Hell',190,'2023-02-03 04:14:11',NULL,'2023-01-28 04:14:11','2023-02-03 04:14:11'),(40,238,'Hello Test',190,'2023-02-03 04:14:51',NULL,'2023-01-28 04:14:51','2023-02-03 04:14:51'),(41,238,'Hello New 1',190,'2023-02-03 04:15:07',NULL,'2023-01-28 04:15:07','2023-02-03 04:15:07'),(42,238,'Hello',190,'2023-02-03 04:17:27',NULL,'2023-02-03 04:17:27','2023-02-03 04:17:27'),(43,238,'Hello',190,'2023-02-03 04:17:47',NULL,'2023-02-03 04:17:47','2023-02-03 04:17:47'),(44,238,'Hello',190,'2023-02-03 04:17:49',NULL,'2023-02-03 04:17:49','2023-02-03 04:17:49'),(45,238,'Hello',190,'2023-02-03 04:17:51',NULL,'2023-02-03 04:17:51','2023-02-03 04:17:51'),(46,238,'Hello',190,'2023-02-03 04:17:53',NULL,'2023-02-03 04:17:53','2023-02-03 04:17:53'),(52,249,'this is testmessage',190,'2023-02-03 04:21:15',NULL,'2023-02-03 04:21:15','2023-02-03 04:21:15'),(53,249,'testing message',190,NULL,1,'2023-02-03 04:26:58','2023-02-03 04:26:58'),(54,238,'trstrrrrrr\\',190,'2023-02-03 04:28:35',NULL,'2023-02-03 04:28:35','2023-02-03 04:28:35'),(55,221,'jjjjj',190,'2023-02-06 09:45:02',NULL,'2023-02-06 09:45:02','2023-02-06 09:45:02');
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2020_11_19_032757_add_columns_to_users_table',2),(5,'2020_12_02_042131_create_treatment_plans_table',3),(6,'2020_12_04_045801_alter_identity_in_users_table',4),(7,'2020_12_07_073645_add_status_to_treatment_plans_table',5),(8,'2020_12_22_015700_create_activities_table',6),(9,'2021_01_22_065944_alter_exercises_in_activities_table',7),(10,'2021_02_04_081012_alter_activities_table',8),(11,'2021_02_08_080356_add_total_of_weeks_to_treatment_plans_table',9),(12,'2021_02_22_082335_add_chat_columns_to_users_table',10),(13,'2021_03_01_045226_create_goals_table',11),(14,'2021_03_17_034127_add_created_by_column_to_treatment_plans_table',11),(15,'2021_03_26_062815_add_last_login_to_users_table',12),(16,'2021_04_21_014651_adjust_tables_for_preset_treatment',13),(17,'2021_05_04_091524_create_notifications_table',14),(18,'2021_06_01_083527_add_show_guidance_to_users_table',15),(19,'2022_07_05_082142_add_columns_in_activities_table',16),(20,'2022_12_15_043631_create_messages_table',17),(21,'2024_07_03_025512_create_transfers_table',17),(22,'2024_11_08_150512_add_columns_to_users_table',18),(23,'2024_11_19_172323_create_activity_log_table',18),(24,'2024_12_06_150512_add_columns_to_activity_log_table',18);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint unsigned NOT NULL,
  `data` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES ('0200e5b3-54fa-4e28-afb9-878a02234090','App\\Notifications\\NewPatient','App\\Models\\User',55,'{\"patient_first_name\":\"Save\",\"patient_last_name\":\"ChannaSave\"}',NULL,'2021-05-24 03:54:41','2021-05-24 03:54:41'),('03811de5-3399-4b85-92b3-821ce05e8744','App\\Notifications\\NewPatient','App\\Models\\User',56,'{\"patient_first_name\":\"Bon\",\"patient_last_name\":\"Channa\"}',NULL,'2021-05-06 09:13:18','2021-05-06 09:13:18'),('04084ff8-4eaa-492a-a830-0762f3976402','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Darith\",\"patient_last_name\":\"Dara\"}',NULL,'2021-05-19 00:01:15','2021-05-19 00:01:15'),('0482df9f-1db7-4276-a11c-9f4b91e2f212','App\\Notifications\\NewPatient','App\\Models\\User',56,'{\"patient_first_name\":\"test\",\"patient_last_name\":\"Test\"}',NULL,'2021-05-06 10:06:20','2021-05-06 10:06:20'),('0b735c02-7c50-482a-93db-b6e78e13db6e','App\\Notifications\\NewPatient','App\\Models\\User',51,'{\"patient_first_name\":\"Save\",\"patient_last_name\":\"ChannaSave\"}',NULL,'2021-06-08 03:53:13','2021-06-08 03:53:13'),('0b83072b-5003-4901-879b-eada9386a202','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Na\",\"patient_last_name\":\"Kanitha\"}',NULL,'2021-05-06 09:47:30','2021-05-06 09:47:30'),('0bbe10b7-5fe0-4114-9167-a534368ef4bb','App\\Notifications\\NewPatient','App\\Models\\User',55,'{\"patient_first_name\":\"test\",\"patient_last_name\":\"Test\"}',NULL,'2021-05-06 10:06:20','2021-05-06 10:06:20'),('0d4b3bd6-6cf3-40c6-b2ad-567346bd60ce','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Chan\",\"patient_last_name\":\"Soda\"}',NULL,'2021-05-31 09:19:01','2021-05-31 09:19:01'),('116b2893-f630-4a64-802e-aea3468e1ffb','App\\Notifications\\NewPatient','App\\Models\\User',55,'{\"patient_first_name\":\"new\",\"patient_last_name\":\"patient\"}',NULL,'2021-05-06 06:59:12','2021-05-06 06:59:12'),('13e58dd0-ce4f-41c4-9e00-24c3a67731c4','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Thorn\",\"patient_last_name\":\"Lisa\"}',NULL,'2021-07-09 09:37:11','2021-07-09 09:37:11'),('1409c47b-6351-45fb-9e83-6fd92917563d','App\\Notifications\\NewPatient','App\\Models\\User',55,'{\"patient_first_name\":\"Bon\",\"patient_last_name\":\"Channa\"}',NULL,'2021-05-06 07:49:59','2021-05-06 07:49:59'),('163408f0-3d18-41dc-9254-8e2d4948342c','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Chan\",\"patient_last_name\":\"Soda\"}',NULL,'2021-05-31 09:18:22','2021-05-31 09:18:22'),('16c23f84-48fc-403d-a2d3-2c072237a218','App\\Notifications\\NewPatient','App\\Models\\User',55,'{\"patient_first_name\":\"Bon\",\"patient_last_name\":\"Channa\"}',NULL,'2021-05-06 09:13:51','2021-05-06 09:13:51'),('19c98669-2be8-4cdf-a8e4-6844e3c93785','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Thorn\",\"patient_last_name\":\"Lisa\"}',NULL,'2021-07-01 09:00:23','2021-07-01 09:00:23'),('1a7abaea-7fa4-4c99-9630-bf5d92609739','App\\Notifications\\NewPatient','App\\Models\\User',55,'{\"patient_first_name\":\"Bon\",\"patient_last_name\":\"Channa\"}',NULL,'2021-05-06 09:04:33','2021-05-06 09:04:33'),('20518465-d054-4427-9e5d-0de67e2e0900','App\\Notifications\\NewPatient','App\\Models\\User',153,'{\"patient_first_name\":\"Leng\",\"patient_last_name\":\"Sovanthy\"}',NULL,'2021-06-22 08:23:18','2021-06-22 08:23:18'),('2098f796-ad40-4190-b2c4-ac4e4f7a8729','App\\Notifications\\NewPatient','App\\Models\\User',55,'{\"patient_first_name\":\"Na\",\"patient_last_name\":\"Kanitha\"}',NULL,'2021-05-06 09:56:35','2021-05-06 09:56:35'),('22c068ce-5211-4431-ba36-f0fd64ea1d49','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Kan\",\"patient_last_name\":\"Jeny\"}',NULL,'2021-06-07 08:10:33','2021-06-07 08:10:33'),('24426208-57fb-447b-8467-f75ce9d06375','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Sun\",\"patient_last_name\":\"Lina\"}',NULL,'2021-06-08 08:15:52','2021-06-08 08:15:52'),('252b829c-4b49-4402-831e-66230ae40970','App\\Notifications\\NewPatient','App\\Models\\User',55,'{\"patient_first_name\":\"Bon\",\"patient_last_name\":\"Channa\"}',NULL,'2021-05-06 07:24:59','2021-05-06 07:24:59'),('269d7aa4-4740-40d4-97cd-07e2366d1ec6','App\\Notifications\\NewPatient','App\\Models\\User',184,'{\"patient_first_name\":\"Lysa\",\"patient_last_name\":\"Thorn\"}',NULL,'2022-08-17 09:49:45','2022-08-17 09:49:45'),('27868078-dfb0-4481-b5e5-5e2e2b027385','App\\Notifications\\NewPatient','App\\Models\\User',60,'{\"patient_first_name\":\"KH\",\"patient_last_name\":\"Patient\"}',NULL,'2021-09-29 07:09:52','2021-09-29 07:09:52'),('2c34592d-0829-4a3b-a63b-b439d6caa26c','App\\Notifications\\NewPatient','App\\Models\\User',55,'{\"patient_first_name\":\"Bon\",\"patient_last_name\":\"Channa\"}',NULL,'2021-05-06 09:18:25','2021-05-06 09:18:25'),('2c34bd6e-eb98-4885-91f5-019606a32019','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Patient\",\"patient_last_name\":\"Test\"}',NULL,'2021-05-06 09:15:57','2021-05-06 09:15:57'),('2ff65d67-41ff-4f53-a0dd-83f138bd4c7e','App\\Notifications\\NewPatient','App\\Models\\User',56,'{\"patient_first_name\":\"Bon\",\"patient_last_name\":\"Channa\"}',NULL,'2021-05-06 08:56:05','2021-05-06 08:56:05'),('308eaea1-7523-4b8d-b7e7-bff85ed69a31','App\\Notifications\\NewPatient','App\\Models\\User',55,'{\"patient_first_name\":\"Bon\",\"patient_last_name\":\"Channa\"}',NULL,'2021-05-06 07:21:08','2021-05-06 07:21:08'),('363d68c0-b16d-46f6-a2fe-4848ebe4f1f8','App\\Notifications\\NewPatient','App\\Models\\User',55,'{\"patient_first_name\":\"Na\",\"patient_last_name\":\"Kanitha\"}',NULL,'2021-05-06 09:25:51','2021-05-06 09:25:51'),('38c09396-ba73-4c16-9f1c-7c0fc3759fa6','App\\Notifications\\NewPatient','App\\Models\\User',161,'{\"patient_first_name\":\"Na\",\"patient_last_name\":\"Da\"}',NULL,'2024-05-23 07:56:31','2024-05-23 07:56:31'),('392224c2-c98c-45c5-8b86-203dd4a255d2','App\\Notifications\\NewPatient','App\\Models\\User',55,'{\"patient_first_name\":\"Bon\",\"patient_last_name\":\"Channa\"}',NULL,'2021-05-06 07:19:40','2021-05-06 07:19:40'),('39eee372-6417-4760-8253-fabb6ff53853','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Patient\",\"patient_last_name\":\"Test\"}',NULL,'2021-05-06 04:54:21','2021-05-06 04:54:21'),('3a1429da-9f21-4b06-a2a8-f737ddb2deaa','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Lysa\",\"patient_last_name\":\"Lysa Testing\"}',NULL,'2021-05-31 09:32:11','2021-05-31 09:32:11'),('3acb4f82-80e2-4d51-bb5e-34f9a573d018','App\\Notifications\\NewPatient','App\\Models\\User',161,'{\"patient_first_name\":\"Patient_001\",\"patient_last_name\":\"Tester\"}',NULL,'2024-11-07 16:19:12','2024-11-07 16:19:12'),('3ed3f225-e6f6-4f43-8b93-0eec065deb73','App\\Notifications\\NewPatient','App\\Models\\User',141,'{\"patient_first_name\":\"Ku\",\"patient_last_name\":\"Kari\"}',NULL,'2021-06-15 04:52:52','2021-06-15 04:52:52'),('42975eba-819b-4981-b9fc-b37171a03bf4','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Leng\",\"patient_last_name\":\"Sovanthy\"}',NULL,'2021-06-22 07:37:17','2021-06-22 07:37:17'),('432b002a-18f3-412f-ba67-ee559bf2bc83','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Thorn\",\"patient_last_name\":\"Lisa\"}',NULL,'2021-07-09 09:39:42','2021-07-09 09:39:42'),('446a385a-4dca-45c9-960d-6ec9db21bafb','App\\Notifications\\NewPatient','App\\Models\\User',55,'{\"patient_first_name\":\"Bon\",\"patient_last_name\":\"Channa\"}',NULL,'2021-05-06 07:20:40','2021-05-06 07:20:40'),('476375a9-3255-45c3-b3dc-c1b32833a87b','App\\Notifications\\NewPatient','App\\Models\\User',51,'{\"patient_first_name\":\"Lysa\",\"patient_last_name\":\"Lysa Testing\"}',NULL,'2021-05-24 04:14:01','2021-05-24 04:14:01'),('4a10262a-90d7-474c-ab86-d4089f25c999','App\\Notifications\\NewPatient','App\\Models\\User',55,'{\"patient_first_name\":\"Bon\",\"patient_last_name\":\"Channa\"}',NULL,'2021-05-06 09:11:53','2021-05-06 09:11:53'),('4bc5592b-fe05-4a3b-9bf0-54378097f9ac','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Patient\",\"patient_last_name\":\"Test\"}',NULL,'2021-05-06 05:05:51','2021-05-06 05:05:51'),('4d45ccab-a4ed-4c7e-b53a-b2476df656f7','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Thorn\",\"patient_last_name\":\"Lisa\"}',NULL,'2021-07-01 09:03:51','2021-07-01 09:03:51'),('4e073633-c4e6-4410-b12d-30d36f9dc11a','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Darith\",\"patient_last_name\":\"Dara\"}',NULL,'2021-05-10 07:22:51','2021-05-10 07:22:51'),('4f2d3ec7-dc27-4eed-858c-9dc34662e5df','App\\Notifications\\NewPatient','App\\Models\\User',55,'{\"patient_first_name\":\"Bon\",\"patient_last_name\":\"Channa\"}',NULL,'2021-05-06 09:18:01','2021-05-06 09:18:01'),('4f799039-1c89-4b05-857c-12602e07964f','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Kita\",\"patient_last_name\":\"Jeny\"}',NULL,'2021-05-28 08:22:08','2021-05-28 08:22:08'),('50133320-6fe9-4ffa-8780-b4b23ce15a8e','App\\Notifications\\NewPatient','App\\Models\\User',55,'{\"patient_first_name\":\"Bon\",\"patient_last_name\":\"Channa\"}',NULL,'2021-05-06 09:04:01','2021-05-06 09:04:01'),('50516320-faac-46cb-8643-135bc8c4b7cc','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Patient\",\"patient_last_name\":\"Test\"}',NULL,'2021-05-06 09:17:04','2021-05-06 09:17:04'),('50dd6a81-7358-4761-8a1a-aaca99a60690','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Kita\",\"patient_last_name\":\"Jeny\"}',NULL,'2021-05-28 09:00:53','2021-05-28 09:00:53'),('50ed34a9-9823-4167-a2a4-3f75da1c05a3','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Kan\",\"patient_last_name\":\"Jeny\"}',NULL,'2021-06-22 09:18:25','2021-06-22 09:18:25'),('54ecced8-98e9-429a-b1a5-6ae896ee0b26','App\\Notifications\\NewPatient','App\\Models\\User',55,'{\"patient_first_name\":\"Bon\",\"patient_last_name\":\"Channa\"}',NULL,'2021-05-06 07:52:07','2021-05-06 07:52:07'),('551dcea8-8a7d-49eb-ac3d-f1b7d742ac93','App\\Notifications\\NewPatient','App\\Models\\User',51,'{\"patient_first_name\":\"new\",\"patient_last_name\":\"patient\"}',NULL,'2021-05-06 06:59:12','2021-05-06 06:59:12'),('58184657-8bf5-4d97-a97b-7e6082a79fa7','App\\Notifications\\NewPatient','App\\Models\\User',56,'{\"patient_first_name\":\"Bon\",\"patient_last_name\":\"Channa\"}',NULL,'2021-05-06 08:58:41','2021-05-06 08:58:41'),('59e980f4-dbfe-48b0-8879-e500a96fbb75','App\\Notifications\\NewPatient','App\\Models\\User',156,'{\"patient_first_name\":\"1\",\"patient_last_name\":\"1\"}',NULL,'2022-08-19 03:11:16','2022-08-19 03:11:16'),('5c6972f2-cea6-4b48-9230-43f06630b369','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Kan\",\"patient_last_name\":\"Jeny\"}',NULL,'2021-06-02 08:25:03','2021-06-02 08:25:03'),('5c85faca-1160-46b7-b2fb-6b8c530dd3c9','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Sok\",\"patient_last_name\":\"Thida\"}',NULL,'2021-05-10 07:07:15','2021-05-10 07:07:15'),('5e143298-08a8-4071-be2d-11f6ca633881','App\\Notifications\\NewPatient','App\\Models\\User',56,'{\"patient_first_name\":\"Bon\",\"patient_last_name\":\"Channa\"}',NULL,'2021-05-06 09:12:23','2021-05-06 09:12:23'),('5e14a1f7-8e6d-4c9f-aae7-1a84096b2f33','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Patient\",\"patient_last_name\":\"Test\"}',NULL,'2021-05-06 04:58:53','2021-05-06 04:58:53'),('607a426a-93d6-4f93-8744-e8d58ad9ebb4','App\\Notifications\\NewPatient','App\\Models\\User',156,'{\"patient_first_name\":\"ka\",\"patient_last_name\":\"kaka\"}',NULL,'2021-06-28 08:38:32','2021-06-28 08:38:32'),('668bcc3b-a5d3-41a1-9364-717cf69ae2a6','App\\Notifications\\NewPatient','App\\Models\\User',51,'{\"patient_first_name\":\"Secondary\",\"patient_last_name\":\"Test\"}',NULL,'2021-05-06 06:56:02','2021-05-06 06:56:02'),('6c4f2073-1d00-4d16-9465-659239f85837','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Na\",\"patient_last_name\":\"Kanitha\"}',NULL,'2021-05-06 09:47:02','2021-05-06 09:47:02'),('71198e91-598e-4b11-a130-5942863b0daf','App\\Notifications\\NewPatient','App\\Models\\User',184,'{\"patient_first_name\":\"New3\",\"patient_last_name\":\"Test\"}',NULL,'2022-08-19 01:26:13','2022-08-19 01:26:13'),('73d7c730-8232-485b-a02a-0b792e9469f7','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Kan\",\"patient_last_name\":\"Jeny\"}',NULL,'2021-06-04 03:22:57','2021-06-04 03:22:57'),('740992e8-0005-4c5d-85b8-b578bc78dd34','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Kan\",\"patient_last_name\":\"Jeny\"}',NULL,'2021-06-02 08:23:06','2021-06-02 08:23:06'),('760b1eda-68b2-4632-888b-e72ae78dad85','App\\Notifications\\NewPatient','App\\Models\\User',51,'{\"patient_first_name\":\"Save\",\"patient_last_name\":\"ChannaSave\"}',NULL,'2021-05-06 06:58:50','2021-05-06 06:58:50'),('79d2475f-b41a-4f77-93a9-65ae8ef1a64f','App\\Notifications\\NewPatient','App\\Models\\User',56,'{\"patient_first_name\":\"Bon\",\"patient_last_name\":\"Channa\"}',NULL,'2021-05-06 08:57:23','2021-05-06 08:57:23'),('7bc6b3e9-a941-44e2-a23f-19eb5e61b8cd','App\\Notifications\\NewPatient','App\\Models\\User',56,'{\"patient_first_name\":\"Bon\",\"patient_last_name\":\"Channa\"}',NULL,'2021-05-06 08:59:13','2021-05-06 08:59:13'),('7c9c1867-5459-43f3-ab8f-fb934eba5673','App\\Notifications\\NewPatient','App\\Models\\User',56,'{\"patient_first_name\":\"Bon\",\"patient_last_name\":\"Channa\"}',NULL,'2021-05-06 08:59:36','2021-05-06 08:59:36'),('7df88e0f-9051-4b48-ae82-7cbcc3efa10c','App\\Notifications\\NewPatient','App\\Models\\User',55,'{\"patient_first_name\":\"Bon\",\"patient_last_name\":\"Channa\"}',NULL,'2021-05-06 09:05:53','2021-05-06 09:05:53'),('7e1fed59-dcc5-45fa-9332-babbc8a45075','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Na\",\"patient_last_name\":\"Kanitha\"}',NULL,'2021-05-06 09:48:08','2021-05-06 09:48:08'),('80534ac4-329c-4085-b563-18a5bf890467','App\\Notifications\\NewPatient','App\\Models\\User',61,'{\"patient_first_name\":\"Lysa\",\"patient_last_name\":\"Lysa Testing\"}',NULL,'2021-06-11 04:08:39','2021-06-11 04:08:39'),('81bf3fa6-5a69-4fe5-9586-c1482a9e28e3','App\\Notifications\\NewPatient','App\\Models\\User',61,'{\"patient_first_name\":\"Thorn\",\"patient_last_name\":\"Lisa\"}',NULL,'2021-06-15 02:44:37','2021-06-15 02:44:37'),('81fe616a-5d78-408c-9f50-30fddb7c78a4','App\\Notifications\\NewPatient','App\\Models\\User',55,'{\"patient_first_name\":\"Bon\",\"patient_last_name\":\"Channa\"}',NULL,'2021-05-06 09:11:26','2021-05-06 09:11:26'),('8343a25c-a36a-48b0-b709-7bee98a4dca1','App\\Notifications\\NewPatient','App\\Models\\User',51,'{\"patient_first_name\":\"User\",\"patient_last_name\":\"Tet\"}',NULL,'2021-05-06 07:21:01','2021-05-06 07:21:01'),('83d9c82f-ff10-4083-ac5d-b5119382f76b','App\\Notifications\\NewPatient','App\\Models\\User',237,'{\"patient_first_name\":\"Sun\",\"patient_last_name\":\"Lina\"}',NULL,'2022-12-26 07:28:45','2022-12-26 07:28:45'),('8511576f-2897-470b-baf5-d4b9ec36f47e','App\\Notifications\\NewPatient','App\\Models\\User',60,'{\"patient_first_name\":\"Patient\",\"patient_last_name\":\"A\"}',NULL,'2021-05-06 05:02:16','2021-05-06 05:02:16'),('8672a06c-896d-4288-9c62-a107139c7a11','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Kan\",\"patient_last_name\":\"Jeny\"}',NULL,'2021-06-22 09:17:50','2021-06-22 09:17:50'),('88cd1ef5-732e-48ef-ba48-bf76d95e385a','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Sun\",\"patient_last_name\":\"Lina\"}',NULL,'2021-06-15 02:49:40','2021-06-15 02:49:40'),('8a0ca222-1ec1-44b4-b978-87e586ac5154','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Sun\",\"patient_last_name\":\"Lina\"}',NULL,'2021-05-28 04:23:11','2021-05-28 04:23:11'),('8cd9190c-dd03-41cd-9533-610b6a6f0cf0','App\\Notifications\\NewPatient','App\\Models\\User',56,'{\"patient_first_name\":\"Patient\",\"patient_last_name\":\"A\"}',NULL,'2021-05-10 07:11:22','2021-05-10 07:11:22'),('8df360ad-4b50-467f-93f0-b23bbbd3affa','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Sok\",\"patient_last_name\":\"Thida\"}',NULL,'2021-05-10 07:07:14','2021-05-10 07:07:14'),('8eed4538-bce5-4421-a4ef-5d7519b14558','App\\Notifications\\NewPatient','App\\Models\\User',159,'{\"patient_first_name\":\"audit\",\"patient_last_name\":\"test\"}',NULL,'2025-03-25 01:49:23','2025-03-25 01:49:23'),('92335f05-8d18-4c33-84b1-6ead46941248','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Thorn\",\"patient_last_name\":\"Lisa\"}',NULL,'2021-07-12 01:22:07','2021-07-12 01:22:07'),('94bc27de-ecdb-4de8-af4c-8c35b46e577c','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Kan\",\"patient_last_name\":\"Jeny\"}',NULL,'2021-06-22 09:20:04','2021-06-22 09:20:04'),('957f7c3b-662f-4203-8cc3-d7e67279f454','App\\Notifications\\NewPatient','App\\Models\\User',51,'{\"patient_first_name\":\"Secondary\",\"patient_last_name\":\"Test\"}',NULL,'2021-05-06 06:58:11','2021-05-06 06:58:11'),('9a50f074-82d3-4eb0-90cb-8296810bb298','App\\Notifications\\NewPatient','App\\Models\\User',55,'{\"patient_first_name\":\"Bon\",\"patient_last_name\":\"Channa\"}',NULL,'2021-05-06 04:52:51','2021-05-06 04:52:51'),('9aa53561-5264-4fbe-b7f7-a48489e5074b','App\\Notifications\\NewPatient','App\\Models\\User',55,'{\"patient_first_name\":\"Na\",\"patient_last_name\":\"Kanitha\"}',NULL,'2021-05-06 09:20:59','2021-05-06 09:20:59'),('9d8faa7a-d482-4c43-a49a-3c143a6a9f21','App\\Notifications\\NewPatient','App\\Models\\User',184,'{\"patient_first_name\":\"New\",\"patient_last_name\":\"Test\"}',NULL,'2022-08-19 01:17:24','2022-08-19 01:17:24'),('9ead0f16-bff3-48b1-9d7c-b6a83115ca93','App\\Notifications\\NewPatient','App\\Models\\User',55,'{\"patient_first_name\":\"Bon\",\"patient_last_name\":\"Channa\"}',NULL,'2021-05-06 07:25:31','2021-05-06 07:25:31'),('a0a9081e-9104-4e62-970f-c718aa8f1ff4','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Sun\",\"patient_last_name\":\"Lina\"}',NULL,'2021-06-11 02:30:43','2021-06-11 02:30:43'),('a3a98ef2-07ab-4e92-b13a-efd146be195f','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Kan\",\"patient_last_name\":\"Jeny\"}',NULL,'2021-06-03 02:12:15','2021-06-03 02:12:15'),('a4ca2f3e-4e21-4f07-9271-59222fd14a69','App\\Notifications\\NewPatient','App\\Models\\User',56,'{\"patient_first_name\":\"Patient\",\"patient_last_name\":\"Test\"}',NULL,'2021-05-06 09:15:44','2021-05-06 09:15:44'),('acc5ae07-1851-4b51-b526-5338d07f8060','App\\Notifications\\NewPatient','App\\Models\\User',60,'{\"patient_first_name\":\"Patient\",\"patient_last_name\":\"A\"}',NULL,'2021-05-11 01:41:26','2021-05-11 01:41:26'),('acf98b70-0cb8-444e-8b19-d80798093983','App\\Notifications\\NewPatient','App\\Models\\User',161,'{\"patient_first_name\":\"Patient_002\",\"patient_last_name\":\"Tester\"}',NULL,'2024-11-07 16:20:03','2024-11-07 16:20:03'),('ada30686-c2c4-4a56-858b-99cffbcd3c28','App\\Notifications\\NewPatient','App\\Models\\User',56,'{\"patient_first_name\":\"Bon\",\"patient_last_name\":\"Channa\"}',NULL,'2021-05-06 09:14:21','2021-05-06 09:14:21'),('af641bc3-e5ef-4394-adbe-ba8d2765691e','App\\Notifications\\NewPatient','App\\Models\\User',56,'{\"patient_first_name\":\"Patient\",\"patient_last_name\":\"Test\"}',NULL,'2021-05-06 09:15:16','2021-05-06 09:15:16'),('afae8e44-b6af-40df-b0fb-694cdde754f8','App\\Notifications\\NewPatient','App\\Models\\User',159,'{\"patient_first_name\":\"Thorn\",\"patient_last_name\":\"Lisa\"}',NULL,'2021-07-12 01:37:38','2021-07-12 01:37:38'),('afc211ce-098d-4a1f-99f9-de205ef74395','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Thorn\",\"patient_last_name\":\"Lisa\"}',NULL,'2021-07-12 01:27:39','2021-07-12 01:27:39'),('b0247ec5-de7d-4760-8d5e-bbcec2a38af4','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Darith\",\"patient_last_name\":\"Dara\"}',NULL,'2021-05-18 23:52:25','2021-05-18 23:52:25'),('b1fe491f-068d-4eda-b3a2-e5946f0f9a44','App\\Notifications\\NewPatient','App\\Models\\User',156,'{\"patient_first_name\":\"Ny\",\"patient_last_name\":\"Na\"}',NULL,'2021-06-28 09:49:44','2021-06-28 09:49:44'),('b30ab75d-0c61-4a3a-a1b1-aacd0e8a5f7e','App\\Notifications\\NewPatient','App\\Models\\User',55,'{\"patient_first_name\":\"Bon\",\"patient_last_name\":\"Channa\"}',NULL,'2021-05-06 09:02:58','2021-05-06 09:02:58'),('b7983b65-35a0-4989-ae84-e1464aeb662b','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Thorn\",\"patient_last_name\":\"Lisa\"}',NULL,'2021-07-01 08:37:12','2021-07-01 08:37:12'),('b976b33b-3e45-446d-ad6d-ea8796639489','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Thorn\",\"patient_last_name\":\"Lysa\"}',NULL,'2021-06-22 09:17:15','2021-06-22 09:17:15'),('b9b88642-831d-438f-8729-677f9125e9af','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Kan\",\"patient_last_name\":\"Jeny\"}',NULL,'2021-06-22 09:17:30','2021-06-22 09:17:30'),('ba626318-d065-43bd-a395-d87469e603a0','App\\Notifications\\NewPatient','App\\Models\\User',55,'{\"patient_first_name\":\"Bon\",\"patient_last_name\":\"Channa\"}',NULL,'2021-05-06 07:49:07','2021-05-06 07:49:07'),('bd4db578-be0d-43ad-aa05-d5df9f46165e','App\\Notifications\\NewPatient','App\\Models\\User',60,'{\"patient_first_name\":\"Patient\",\"patient_last_name\":\"A\"}',NULL,'2021-05-10 06:38:49','2021-05-10 06:38:49'),('bfb229b9-269b-468e-9424-3b17a57388a6','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Ngeth\",\"patient_last_name\":\"Chanthorn\"}',NULL,'2021-06-21 08:58:46','2021-06-21 08:58:46'),('c5624fc2-0743-4581-b038-e230a58e3afb','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Ni\",\"patient_last_name\":\"Soka\"}',NULL,'2021-06-30 01:07:13','2021-06-30 01:07:13'),('c5aacdf6-6d9d-426c-9a32-3800b51feba9','App\\Notifications\\NewPatient','App\\Models\\User',153,'{\"patient_first_name\":\"Leng\",\"patient_last_name\":\"Sovanthy\"}',NULL,'2021-06-22 08:24:01','2021-06-22 08:24:01'),('c716d461-6d96-45bd-879c-c6c89857a063','App\\Notifications\\NewPatient','App\\Models\\User',253,'{\"patient_first_name\":\"Patient_002\",\"patient_last_name\":\"Tester\"}',NULL,'2024-11-07 16:20:04','2024-11-07 16:20:04'),('c77abd3f-8584-423a-98ae-7c2b4f1a69ff','App\\Notifications\\NewPatient','App\\Models\\User',184,'{\"patient_first_name\":\"Lysa\",\"patient_last_name\":\"Thorn\"}',NULL,'2022-08-17 09:49:44','2022-08-17 09:49:44'),('ca8826ab-2503-4d20-9545-e8119022b8cc','App\\Notifications\\NewPatient','App\\Models\\User',55,'{\"patient_first_name\":\"Bon\",\"patient_last_name\":\"Channa\"}',NULL,'2021-05-06 07:18:22','2021-05-06 07:18:22'),('cc401bfd-8ba4-44ae-878d-579ddb7b1d4e','App\\Notifications\\NewPatient','App\\Models\\User',254,'{\"patient_first_name\":\"001\",\"patient_last_name\":\"001\"}',NULL,'2024-10-07 08:46:37','2024-10-07 08:46:37'),('cd28cc48-d453-45e4-9ec8-7767ed025427','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Sun\",\"patient_last_name\":\"Lina\"}',NULL,'2021-06-11 08:35:52','2021-06-11 08:35:52'),('cd6282b5-230f-4211-a683-ae44c2bd9821','App\\Notifications\\NewPatient','App\\Models\\User',156,'{\"patient_first_name\":\"Sun\",\"patient_last_name\":\"Lina\"}',NULL,'2022-12-26 04:55:17','2022-12-26 04:55:17'),('cf9cc018-3ea4-437b-a2d4-37d9517922f8','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Sun\",\"patient_last_name\":\"Lina\"}',NULL,'2021-05-28 04:15:07','2021-05-28 04:15:07'),('d3807f66-d580-406d-bf1c-7b4b3554d0d0','App\\Notifications\\NewPatient','App\\Models\\User',184,'{\"patient_first_name\":\"Lysa\",\"patient_last_name\":\"test1\"}',NULL,'2022-08-11 02:16:04','2022-08-11 02:16:04'),('d66043b9-17f3-4b5c-833a-aaf64c2197f7','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"ka\",\"patient_last_name\":\"kaka\"}',NULL,'2021-07-01 06:57:11','2021-07-01 06:57:11'),('d84165ad-8168-4abd-9c90-1315f0353686','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Kan\",\"patient_last_name\":\"Jeny\"}',NULL,'2021-06-04 08:55:53','2021-06-04 08:55:53'),('d93abf62-b5c2-4d85-a6db-99660bd744fe','App\\Notifications\\NewPatient','App\\Models\\User',51,'{\"patient_first_name\":\"Bon\",\"patient_last_name\":\"Channa\"}',NULL,'2021-05-06 09:11:11','2021-05-06 09:11:11'),('da34127d-3202-4dbd-ad3b-818bed857a12','App\\Notifications\\NewPatient','App\\Models\\User',55,'{\"patient_first_name\":\"Na\",\"patient_last_name\":\"Kanitha\"}',NULL,'2021-05-06 09:19:42','2021-05-06 09:19:42'),('e3435a61-37e2-4114-b5df-c7bb85549713','App\\Notifications\\NewPatient','App\\Models\\User',153,'{\"patient_first_name\":\"Leng\",\"patient_last_name\":\"Sovanthy\"}',NULL,'2021-06-22 08:25:52','2021-06-22 08:25:52'),('e54e47c1-1072-4dbd-944a-42d6c3c328ff','App\\Notifications\\NewPatient','App\\Models\\User',55,'{\"patient_first_name\":\"Na\",\"patient_last_name\":\"Kanitha\"}',NULL,'2021-05-06 09:28:05','2021-05-06 09:28:05'),('e8404c52-7670-4a3d-82d2-dce44ad2e271','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"sun\",\"patient_last_name\":\"lina\"}',NULL,'2021-06-11 08:05:14','2021-06-11 08:05:14'),('eadb876e-14c3-452d-a60c-b652f84de88b','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Lysa\",\"patient_last_name\":\"Thorn\"}',NULL,'2021-10-14 01:34:10','2021-10-14 01:34:10'),('ec142d2d-caaf-440a-813f-9fb9419b9792','App\\Notifications\\NewPatient','App\\Models\\User',55,'{\"patient_first_name\":\"Na\",\"patient_last_name\":\"Kanitha\"}',NULL,'2021-05-06 09:30:35','2021-05-06 09:30:35'),('ec187dc0-e013-4af5-b51f-6ccd66e99644','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Patient\",\"patient_last_name\":\"Test\"}',NULL,'2021-05-06 04:54:51','2021-05-06 04:54:51'),('ed984acc-7b93-4368-9b41-47b450e13f34','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Sun\",\"patient_last_name\":\"Lina\"}',NULL,'2021-06-07 08:35:25','2021-06-07 08:35:25'),('eeb6fb5e-1433-450f-9337-98478e809f65','App\\Notifications\\NewPatient','App\\Models\\User',55,'{\"patient_first_name\":\"Bon\",\"patient_last_name\":\"Channa\"}',NULL,'2021-05-06 09:06:38','2021-05-06 09:06:38'),('f02aed66-a868-4038-8a19-392ddf63c0e1','App\\Notifications\\NewPatient','App\\Models\\User',56,'{\"patient_first_name\":\"Bon\",\"patient_last_name\":\"Channa\"}',NULL,'2021-05-06 08:50:20','2021-05-06 08:50:20'),('f03c12b6-53c1-4684-9ff8-faa89cec74ab','App\\Notifications\\NewPatient','App\\Models\\User',55,'{\"patient_first_name\":\"Na\",\"patient_last_name\":\"Kanitha\"}',NULL,'2021-05-06 09:55:02','2021-05-06 09:55:02'),('f119b685-484c-4cc1-a10f-e819dd483336','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Thorn\",\"patient_last_name\":\"Lisa\"}',NULL,'2021-07-09 09:19:34','2021-07-09 09:19:34'),('f4a2c8f7-4a1a-4d72-9312-8d87092f336e','App\\Notifications\\NewPatient','App\\Models\\User',184,'{\"patient_first_name\":\"New2\",\"patient_last_name\":\"Test\"}',NULL,'2022-08-19 01:20:36','2022-08-19 01:20:36'),('f5bfc04a-4d01-431c-ae71-7fef8ca1ada9','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Na\",\"patient_last_name\":\"Kanitha\"}',NULL,'2021-05-06 09:44:46','2021-05-06 09:44:46'),('f67da4ef-628b-48ca-9130-b40b4c46482d','App\\Notifications\\NewPatient','App\\Models\\User',56,'{\"patient_first_name\":\"Bon\",\"patient_last_name\":\"Channa\"}',NULL,'2021-05-06 09:18:26','2021-05-06 09:18:26'),('f9bd0540-6544-4cfd-85ff-e11131ff9a40','App\\Notifications\\NewPatient','App\\Models\\User',253,'{\"patient_first_name\":\"Demo\",\"patient_last_name\":\"Patient\"}',NULL,'2025-02-20 04:04:08','2025-02-20 04:04:08'),('fb0e5d2d-8f54-441d-b139-003202be8464','App\\Notifications\\NewPatient','App\\Models\\User',55,'{\"patient_first_name\":\"Bon\",\"patient_last_name\":\"Channa\"}',NULL,'2021-05-06 09:03:31','2021-05-06 09:03:31'),('fb73e9f0-61f4-4770-96a4-d95b9b0931ea','App\\Notifications\\NewPatient','App\\Models\\User',56,'{\"patient_first_name\":\"Bon\",\"patient_last_name\":\"Channa\"}',NULL,'2021-05-06 09:03:32','2021-05-06 09:03:32'),('fd5ec7fb-126e-473d-83a1-af6f6c352a0c','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Patient\",\"patient_last_name\":\"Test\"}',NULL,'2021-05-06 05:06:24','2021-05-06 05:06:24'),('fe96b449-8148-4582-891b-8630c0e97187','App\\Notifications\\NewPatient','App\\Models\\User',59,'{\"patient_first_name\":\"Jacobs\",\"patient_last_name\":\"Martin\"}',NULL,'2021-06-02 14:08:47','2021-06-02 14:08:47'),('ffbeb870-d485-44a2-a6fc-480e232eae7f','App\\Notifications\\NewPatient','App\\Models\\User',54,'{\"patient_first_name\":\"Sun\",\"patient_last_name\":\"Lina\"}',NULL,'2021-06-15 02:52:43','2021-06-15 02:52:43');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transfers`
--

DROP TABLE IF EXISTS `transfers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transfers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `patient_id` int unsigned NOT NULL,
  `from_therapist_id` int unsigned NOT NULL,
  `to_therapist_id` int unsigned NOT NULL,
  `clinic_id` int unsigned NOT NULL,
  `therapist_type` enum('lead','supplementary') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('invited','declined') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transfers`
--

LOCK TABLES `transfers` WRITE;
/*!40000 ALTER TABLE `transfers` DISABLE KEYS */;
INSERT INTO `transfers` VALUES (4,262,253,252,42,'lead','declined','2024-10-07 02:01:06','2024-10-07 02:02:11'),(5,262,253,254,42,'lead','declined','2024-10-07 02:03:27','2024-10-07 08:47:55'),(6,265,255,256,42,'lead','declined','2024-10-07 02:44:37','2025-03-25 04:05:34'),(7,262,253,254,42,'supplementary','declined','2024-10-07 08:46:37','2024-10-07 08:47:52'),(8,269,257,161,42,'supplementary','invited','2024-11-07 16:19:14','2024-11-07 16:19:14'),(9,270,257,161,42,'supplementary','invited','2024-11-07 16:20:05','2024-11-07 16:20:05'),(10,270,257,253,42,'supplementary','declined','2024-11-07 16:20:05','2025-02-20 04:07:24'),(12,264,253,257,42,'lead','declined','2025-02-20 04:15:46','2025-02-20 04:19:39'),(16,269,257,253,42,'lead','declined','2025-02-20 07:49:56','2025-02-20 07:52:15'),(17,273,257,159,42,'supplementary','invited','2025-03-25 01:49:26','2025-03-25 01:49:26'),(18,274,257,159,42,'lead','invited','2025-03-25 04:16:43','2025-03-25 04:16:43');
/*!40000 ALTER TABLE `transfers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `treatment_plans`
--

DROP TABLE IF EXISTS `treatment_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `treatment_plans` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `total_of_weeks` smallint NOT NULL DEFAULT '1',
  `created_by` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `treatment_plans`
--

LOCK TABLES `treatment_plans` WRITE;
/*!40000 ALTER TABLE `treatment_plans` DISABLE KEYS */;
INSERT INTO `treatment_plans` VALUES (1,'cerebal pasly','2021-04-13 09:44:44','2021-04-13 09:44:44',2,6),(2,'Cerebral Palsy','2021-04-13 11:01:05','2021-04-13 11:01:05',1,3),(3,'Low back pain','2021-04-13 12:44:04','2021-04-13 12:44:04',1,5),(4,'tổn thương tủy sống cổ ASIAD C5','2021-04-14 07:40:11','2021-04-14 07:40:11',1,9),(5,'Bại não liệt 1/2 người phải','2021-04-14 07:40:27','2021-04-14 07:40:27',1,11),(6,'Prothèse de genou','2021-04-14 13:24:02','2021-04-14 13:24:02',2,23),(7,'Neurologie','2021-04-14 13:37:21','2021-04-14 13:37:21',1,23),(8,'Chấn thương cột sống t11/12','2021-04-15 08:24:17','2021-04-15 08:24:17',1,29),(9,'tăng huyết áp','2021-04-16 07:49:56','2021-04-16 07:49:56',1,40),(10,'đau tay mỏi gối','2021-04-16 07:55:48','2021-04-16 07:55:48',1,40),(11,'đau mỏi tay chân','2021-04-16 08:02:16','2021-04-16 08:02:16',1,40),(12,'Đau 2 khớp gối','2021-04-16 08:05:44','2021-04-16 08:05:44',1,39),(13,'Viêm khớp gối phải','2021-04-16 08:20:13','2021-04-16 08:20:13',1,34),(14,'Đột quỵ','2021-04-16 09:10:13','2021-04-16 09:14:32',1,49),(23,'Template for Stroke','2021-05-27 04:32:24','2021-05-27 04:32:24',1,91),(30,'template 1','2021-10-14 09:37:07','2021-10-14 09:37:07',1,179),(38,'TAP 001','2024-11-07 16:21:41','2024-11-07 16:21:41',1,257),(39,'test preset 1','2025-03-25 03:46:35','2025-04-01 03:30:34',1,257);
/*!40000 ALTER TABLE `treatment_plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `first_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `clinic_id` int NOT NULL,
  `country_id` int NOT NULL,
  `limit_patient` int NOT NULL,
  `language_id` int DEFAULT NULL,
  `profession_id` int DEFAULT NULL,
  `identity` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `chat_user_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `chat_password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `chat_rooms` json DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  `show_guidance` tinyint(1) NOT NULL DEFAULT '0',
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dial_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_identity_unique` (`identity`)
) ENGINE=InnoDB AUTO_INCREMENT=263 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (195,'hi_backend',NULL,NULL,NULL,'2022-10-31 07:45:25','2022-10-31 07:45:25','DO NOT DELETE!','DO NOT DELETE!',0,0,0,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,0,NULL,NULL),(262,'therapist@we.co',NULL,NULL,NULL,'2025-04-04 08:17:45','2025-04-04 08:18:24','Portal','Therapist',42,16,35,1,10,'T00010016004200262',1,'gzNT5AjcbcucixHeG','7658bb97fff52ade4fa7f260bd002947c1f9d09cce145d7a59c4b69ab4adb308',NULL,NULL,0,'85512222333','855');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-04  8:40:47
