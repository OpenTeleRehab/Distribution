-- MySQL dump 10.13  Distrib 8.3.0, for Linux (x86_64)
--
-- Host: localhost    Database: keycloak
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ADMIN_EVENT_ENTITY`
--

DROP TABLE IF EXISTS `ADMIN_EVENT_ENTITY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ADMIN_EVENT_ENTITY` (
  `ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ADMIN_EVENT_TIME` bigint DEFAULT NULL,
  `REALM_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `OPERATION_TYPE` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `AUTH_REALM_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `AUTH_CLIENT_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `AUTH_USER_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `IP_ADDRESS` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `RESOURCE_PATH` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `REPRESENTATION` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `ERROR` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `RESOURCE_TYPE` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IDX_ADMIN_EVENT_TIME` (`REALM_ID`,`ADMIN_EVENT_TIME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ADMIN_EVENT_ENTITY`
--

LOCK TABLES `ADMIN_EVENT_ENTITY` WRITE;
/*!40000 ALTER TABLE `ADMIN_EVENT_ENTITY` DISABLE KEYS */;
INSERT INTO `ADMIN_EVENT_ENTITY` VALUES ('016b5e9b-4cde-4fe8-b401-f2068bc970f5',1604570104272,'sts','CREATE','master','d3bacc5c-ac4e-41ab-abb9-3d79878ddcdc','1d46a5b9-3e17-42ab-a8bd-c2d1c4700e84','10.10.2.198','users/1c225af7-8324-4dfb-9495-0cf032fb0cf0',NULL,NULL,'USER'),('2cc36aa4-0cbe-46ab-9a8e-b86c8fa3736d',1604570088941,'sts','UPDATE','master','d3bacc5c-ac4e-41ab-abb9-3d79878ddcdc','1d46a5b9-3e17-42ab-a8bd-c2d1c4700e84','10.10.2.198',NULL,NULL,NULL,'REALM'),('903f8ac7-c796-4519-9795-cbeb753713f3',1604570108569,'sts','ACTION','master','d3bacc5c-ac4e-41ab-abb9-3d79878ddcdc','1d46a5b9-3e17-42ab-a8bd-c2d1c4700e84','10.10.2.198','users/1c225af7-8324-4dfb-9495-0cf032fb0cf0/reset-password',NULL,NULL,'USER'),('b8d919e0-2605-4e30-84e5-e9d5251bf0cc',1604570126898,'sts','UPDATE','master','d3bacc5c-ac4e-41ab-abb9-3d79878ddcdc','1d46a5b9-3e17-42ab-a8bd-c2d1c4700e84','10.10.2.198','users/1c225af7-8324-4dfb-9495-0cf032fb0cf0',NULL,NULL,'USER'),('dbc25493-08e4-42e3-9768-47137e296abc',1604571553655,'Hi','UPDATE','master','d3bacc5c-ac4e-41ab-abb9-3d79878ddcdc','1d46a5b9-3e17-42ab-a8bd-c2d1c4700e84','10.10.2.198','events/config',NULL,NULL,'REALM'),('f0e48e4a-8224-4673-bf23-0054591216a5',1604573006266,'Hi','ACTION','master','d3bacc5c-ac4e-41ab-abb9-3d79878ddcdc','1d46a5b9-3e17-42ab-a8bd-c2d1c4700e84','10.10.2.198','users/5a3b4694-3690-4bcd-8f39-9b1fecff1dd1/reset-password',NULL,NULL,'USER');
/*!40000 ALTER TABLE `ADMIN_EVENT_ENTITY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ASSOCIATED_POLICY`
--

DROP TABLE IF EXISTS `ASSOCIATED_POLICY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ASSOCIATED_POLICY` (
  `POLICY_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ASSOCIATED_POLICY_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`POLICY_ID`,`ASSOCIATED_POLICY_ID`),
  KEY `IDX_ASSOC_POL_ASSOC_POL_ID` (`ASSOCIATED_POLICY_ID`),
  CONSTRAINT `FK_FRSR5S213XCX4WNKOG82SSRFY` FOREIGN KEY (`ASSOCIATED_POLICY_ID`) REFERENCES `RESOURCE_SERVER_POLICY` (`ID`),
  CONSTRAINT `FK_FRSRPAS14XCX4WNKOG82SSRFY` FOREIGN KEY (`POLICY_ID`) REFERENCES `RESOURCE_SERVER_POLICY` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ASSOCIATED_POLICY`
--

LOCK TABLES `ASSOCIATED_POLICY` WRITE;
/*!40000 ALTER TABLE `ASSOCIATED_POLICY` DISABLE KEYS */;
/*!40000 ALTER TABLE `ASSOCIATED_POLICY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AUTHENTICATION_EXECUTION`
--

DROP TABLE IF EXISTS `AUTHENTICATION_EXECUTION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AUTHENTICATION_EXECUTION` (
  `ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ALIAS` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `AUTHENTICATOR` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REALM_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `FLOW_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REQUIREMENT` int DEFAULT NULL,
  `PRIORITY` int DEFAULT NULL,
  `AUTHENTICATOR_FLOW` bit(1) NOT NULL DEFAULT b'0',
  `AUTH_FLOW_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `AUTH_CONFIG` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IDX_AUTH_EXEC_REALM_FLOW` (`REALM_ID`,`FLOW_ID`),
  KEY `IDX_AUTH_EXEC_FLOW` (`FLOW_ID`),
  CONSTRAINT `FK_AUTH_EXEC_FLOW` FOREIGN KEY (`FLOW_ID`) REFERENCES `AUTHENTICATION_FLOW` (`ID`),
  CONSTRAINT `FK_AUTH_EXEC_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AUTHENTICATION_EXECUTION`
--

LOCK TABLES `AUTHENTICATION_EXECUTION` WRITE;
/*!40000 ALTER TABLE `AUTHENTICATION_EXECUTION` DISABLE KEYS */;
INSERT INTO `AUTHENTICATION_EXECUTION` VALUES ('004e036f-e472-443b-a8f3-0e8eb71e6fb3',NULL,NULL,'hi-therapist','381480b9-5311-43cb-bbb6-cbd1c44c4e69',0,20,_binary '','11c7425e-05d7-431c-a835-b8fd8945e5c3',NULL),('00dac3f8-391e-4a7d-accb-8bd6a7cc45f2',NULL,'registration-password-action','master','cf5915e8-1958-4cbf-9bde-f615e94014bf',0,50,_binary '\0',NULL,NULL),('011355b5-1a0f-412d-8222-d7d5b697cb69',NULL,NULL,'hi','ae018a83-f046-4f72-a595-7dda233529fb',2,30,_binary '','9ef7f41f-1978-4e27-8b62-9da623029b6c',NULL),('012dfc1f-886f-4aab-9ad3-bc2cce30b80a',NULL,'identity-provider-redirector','hi','ae018a83-f046-4f72-a595-7dda233529fb',2,25,_binary '\0',NULL,NULL),('02103c26-c9bb-4ec1-af35-8ce611586f04',NULL,'identity-provider-redirector','master','ee278adf-b54d-43a7-9f7b-6d371cb01118',2,25,_binary '\0',NULL,NULL),('0996ec3d-6d48-4cad-a3bf-d767770830ad',NULL,'auth-username-password-form','hi-library','9d07c829-6cb9-4bca-bd67-20b1b2ec9b87',0,10,_binary '\0',NULL,NULL),('0a68b303-6257-4594-88a6-d9dbfdeebfd0',NULL,'client-jwt','hi-library','5bcee621-2824-45ef-83b0-33ce018959d4',2,20,_binary '\0',NULL,NULL),('0b23392b-5250-4d22-9b74-228cfb7d4c0e',NULL,'reset-password','master','876af1ff-ec2a-4357-ad20-b097e1a30b66',0,30,_binary '\0',NULL,NULL),('0bfae157-d013-45cb-9903-3bb222a3a7ed',NULL,'registration-recaptcha-action','hi','ec122629-f387-4f71-825d-fd9fd3149c73',3,60,_binary '\0',NULL,NULL),('0cb5a5dc-6a1b-4c14-85b0-7e38b7a2da9a',NULL,NULL,'hi-library','f0d372ae-f37d-4efb-8475-dbd954d44656',2,20,_binary '','cb534180-3d27-42a3-8eb7-369f884a8bcc',NULL),('0f545fde-4ee1-42e4-a96f-d0ca2fef1f95',NULL,NULL,'master','6a73c2d6-c611-4bf4-a014-3d9b1b1b31e6',0,20,_binary '','cb904f1a-ad0e-4830-bedc-9e9cd9b5b472',NULL),('0fc5ccee-7c92-471c-bb77-c4f92edcd37e',NULL,'registration-user-creation','master','cf5915e8-1958-4cbf-9bde-f615e94014bf',0,20,_binary '\0',NULL,NULL),('113818fb-0c57-4bf6-b7f0-453d940150bf',NULL,'idp-create-user-if-unique','hi','544d16fc-0363-45d5-9173-89099bbd7571',2,10,_binary '\0',NULL,'e1707e38-1fbd-4209-824a-bd6d2188c080'),('1309f5f9-0936-4ae8-9fa5-1b6ab566451a',NULL,'conditional-user-configured','hi','8a03cb9f-85e2-4bce-a4e9-9716217676f8',0,10,_binary '\0',NULL,NULL),('138c9190-450e-4778-bc9b-545e6853ea5e',NULL,'reset-otp','hi-therapist','d5dda600-11a8-4f35-8f53-3799a5c0f120',0,20,_binary '\0',NULL,NULL),('13a69283-cf47-4278-8843-250edaca8a72',NULL,'reset-credentials-choose-user','hi','8384ed04-ad56-46db-a2d5-1975c859d74e',0,10,_binary '\0',NULL,NULL),('14633e9c-3e23-4287-8f6b-2640be77646c',NULL,'conditional-user-configured','hi','2588125a-ef9c-4eeb-b854-99694e02760f',0,10,_binary '\0',NULL,NULL),('15fdee26-6db0-4f1f-a5c7-9cb409e3f34c',NULL,'auth-username-password-form','hi','9ef7f41f-1978-4e27-8b62-9da623029b6c',0,10,_binary '\0',NULL,NULL),('16514f17-7344-4961-a400-8d471fae3baf',NULL,NULL,'hi','9ef7f41f-1978-4e27-8b62-9da623029b6c',1,20,_binary '','186f0e91-2213-4a1a-bc0e-a1fe7bbe067b',NULL),('1964bc20-7392-4848-bb00-9caf8e7ce5e7',NULL,'direct-grant-validate-otp','master','eaf3fdb4-bbe8-4191-b770-c0dd3a2153b1',0,20,_binary '\0',NULL,NULL),('1bb18894-8957-4b52-9610-9aac43451984',NULL,NULL,'hi','544d16fc-0363-45d5-9173-89099bbd7571',2,20,_binary '','6be39391-44b5-4815-be88-9459bbb6f2f7',NULL),('1dde5831-4646-4953-8e6e-d59ad0badbad',NULL,'direct-grant-validate-password','hi','9ec99d3d-749a-454b-bac4-423b2a7d105f',0,20,_binary '\0',NULL,NULL),('1ec64747-5c5a-4074-96e4-84be9762bbd6',NULL,'idp-review-profile','hi-therapist','1d21a5a6-c602-41c1-8a61-c21360530fc6',0,10,_binary '\0',NULL,'611b6f51-9c1e-4365-9cfc-4deb2d03bbfd'),('234b84dd-bfb2-4c1e-aedb-863f86e95abe',NULL,'docker-http-basic-authenticator','hi','e5a56b25-198b-4b22-8ef5-1b0e26727f69',0,10,_binary '\0',NULL,NULL),('25364354-d296-4117-8585-66d0e24758eb',NULL,'idp-create-user-if-unique','hi-therapist','d847ada6-88ba-4612-9bc1-f9393916df2f',2,10,_binary '\0',NULL,'aa1fb027-3540-4ba9-bc74-1a658c7f7726'),('25acfc4d-bab0-47bd-a9fa-87c5dc922800',NULL,NULL,'master','ee278adf-b54d-43a7-9f7b-6d371cb01118',2,30,_binary '','1f18e563-3c74-44ca-b041-01644c63ffe6',NULL),('25e7c6b2-9339-4054-8561-b01820f3c82c',NULL,'auth-spnego','hi-library','e6130d4d-117d-4a54-b478-ec24dfbc929a',3,20,_binary '\0',NULL,NULL),('28341a7e-ab00-415d-9efd-caa57d3b22ad',NULL,'client-x509','hi-therapist','90d64ec7-2b2a-4a6b-8127-27c35439bd01',2,40,_binary '\0',NULL,NULL),('2bcccccf-c07c-4f1e-9db8-07ecc2f0dba2',NULL,'conditional-user-configured','master','2509b8fd-ee35-498f-be87-3ea689711117',0,10,_binary '\0',NULL,NULL),('2c065e4d-36fc-4e25-8a9d-7107ac03d5ed',NULL,'registration-page-form','hi-therapist','ee6e3d97-68b0-4771-a840-ad02eb747500',0,10,_binary '','fcc49b59-6a2d-49ef-8bac-7678c41819a7',NULL),('2c8ab7e6-3018-4afd-9021-be6835cbc543',NULL,'auth-otp-form','hi','2588125a-ef9c-4eeb-b854-99694e02760f',0,20,_binary '\0',NULL,NULL),('2de13115-1d02-4031-b48b-105cd382500f',NULL,'registration-user-creation','hi-therapist','fcc49b59-6a2d-49ef-8bac-7678c41819a7',0,20,_binary '\0',NULL,NULL),('2e23dd96-64bf-4bd2-81e1-a348e25528cf',NULL,'client-secret','hi','ca153fff-2c91-4dcd-9ffc-88d44bc1973f',2,10,_binary '\0',NULL,NULL),('2ffcbcb6-d1bc-485c-b1e6-0bf9d5ff6151',NULL,NULL,'hi-therapist','11c7425e-05d7-431c-a835-b8fd8945e5c3',2,20,_binary '','57aa92f1-2eec-4c96-ac9f-b7a57661d8ff',NULL),('325a15ef-dfb7-4173-a3fb-e1ce0cee67c8',NULL,NULL,'hi-therapist','1d21a5a6-c602-41c1-8a61-c21360530fc6',0,20,_binary '','d847ada6-88ba-4612-9bc1-f9393916df2f',NULL),('3292e130-583a-45ab-88d3-06655f3a4844',NULL,'idp-create-user-if-unique','hi-library','f0d372ae-f37d-4efb-8475-dbd954d44656',2,10,_binary '\0',NULL,'1654fec2-b7f6-4048-b52d-45e781367119'),('3310fb11-ecc8-4646-ae6c-e8fc9f1888b2',NULL,NULL,'hi','c72ed562-95ad-48fe-98ef-b1110fea119c',0,20,_binary '','544d16fc-0363-45d5-9173-89099bbd7571',NULL),('378ba571-64af-43e6-8736-fe08ae0a7dc9',NULL,NULL,'hi-therapist','e9a9c744-015c-437b-b1c7-68677d4e9bda',2,30,_binary '','06e0bc58-e534-49fb-9108-9a63b2c33111',NULL),('38905433-40b2-43d1-ba07-5f6ac8b215df',NULL,'conditional-user-configured','master','eaf3fdb4-bbe8-4191-b770-c0dd3a2153b1',0,10,_binary '\0',NULL,NULL),('3b5ff384-cba2-44c4-a12b-bc507a1fa2f2',NULL,'direct-grant-validate-otp','hi-therapist','84534266-9d8d-4093-a1ac-a101ffb8eaa0',0,20,_binary '\0',NULL,NULL),('3b8c488e-696b-430d-8a8f-cb025b3c0d59',NULL,'idp-review-profile','hi-library','a2b67129-6c56-46ed-bca6-55279c9d9de0',0,10,_binary '\0',NULL,'00d298c5-f948-4567-a483-78094ceface6'),('3b9966e6-04f9-4157-b8ac-c8cdb147e1f6',NULL,'registration-page-form','hi-library','718d46e1-350c-4c81-ad21-9164565e4128',0,10,_binary '','7c8a2afc-0061-4463-a7d4-c4227cc942ca',NULL),('3e8a8c37-b50d-4f95-9132-301903ab2159',NULL,NULL,'hi-library','cb534180-3d27-42a3-8eb7-369f884a8bcc',0,20,_binary '','73c57080-0c08-4e87-b0ad-6cd4d18b7dc6',NULL),('3eb4736a-197f-4d25-9526-b215dd21ef2d',NULL,NULL,'hi-therapist','06e0bc58-e534-49fb-9108-9a63b2c33111',1,20,_binary '','cb06f712-73e6-47a8-aac1-59308af226fb',NULL),('4091064f-5f9f-47f0-b46d-99c0600b3337',NULL,NULL,'hi-therapist','57aa92f1-2eec-4c96-ac9f-b7a57661d8ff',1,20,_binary '','d065e5d3-c40e-4f38-8d77-1f7d1da1cb6f',NULL),('4443292d-6e98-4e0a-8c44-4d875ff9c651',NULL,'idp-email-verification','hi-library','73c57080-0c08-4e87-b0ad-6cd4d18b7dc6',2,10,_binary '\0',NULL,NULL),('45d42d38-2007-4ae5-956b-1e98ced40dd1',NULL,'auth-otp-form','hi-therapist','d065e5d3-c40e-4f38-8d77-1f7d1da1cb6f',0,20,_binary '\0',NULL,NULL),('4654c530-463d-4300-9dd1-907671c52a7e',NULL,'registration-recaptcha-action','hi-library','7c8a2afc-0061-4463-a7d4-c4227cc942ca',3,60,_binary '\0',NULL,NULL),('4690c47e-d652-46cb-afe9-86cbf6f4a82a',NULL,'docker-http-basic-authenticator','hi-therapist','4ca37c19-ca79-40ab-b914-e458b06637f7',0,10,_binary '\0',NULL,NULL),('4691b007-39bd-459e-8011-eb063b3250a1',NULL,'identity-provider-redirector','hi','34b5d5d8-d3ef-4e9b-a253-df8b4115a21a',2,25,_binary '\0',NULL,NULL),('4811ae31-15cb-4ce9-8d2a-f2ce596274c9',NULL,'reset-credentials-choose-user','hi-library','7458dff4-fe52-4c2e-9ef5-4f7e10e9784b',0,10,_binary '\0',NULL,NULL),('4867c16c-f891-46c8-939d-64cff884e6c1',NULL,NULL,'hi-library','73c57080-0c08-4e87-b0ad-6cd4d18b7dc6',2,20,_binary '','2ff51d6a-d54d-41d7-845e-5151e8b21ed4',NULL),('486b32dc-3615-4493-9e21-664027cbe828',NULL,'registration-password-action','hi-library','7c8a2afc-0061-4463-a7d4-c4227cc942ca',0,50,_binary '\0',NULL,NULL),('49d20262-08ec-48d9-b148-1fe92341ad9f',NULL,'auth-cookie','hi','ae018a83-f046-4f72-a595-7dda233529fb',2,10,_binary '\0',NULL,NULL),('4dfba714-59b4-49c2-a64f-fe85cb1aa6a9',NULL,NULL,'hi-library','e6130d4d-117d-4a54-b478-ec24dfbc929a',2,30,_binary '','9d07c829-6cb9-4bca-bd67-20b1b2ec9b87',NULL),('4e3b3b6b-d467-4153-922e-1f315802301b',NULL,NULL,'hi','97241df8-358a-47c4-af54-ff59780d9393',1,20,_binary '','92eeafef-daaf-4853-9f65-4de6f368292f',NULL),('4e92445f-1671-4c35-b1bb-802736d0bd69',NULL,'idp-email-verification','master','049a78ae-2987-4d23-85f8-48cedde8c844',2,10,_binary '\0',NULL,NULL),('526800e2-7bc3-48ab-9b78-2c789419c067',NULL,NULL,'hi-therapist','d847ada6-88ba-4612-9bc1-f9393916df2f',2,20,_binary '','381480b9-5311-43cb-bbb6-cbd1c44c4e69',NULL),('5362f901-15c0-4008-8b86-ee6006b19f61',NULL,NULL,'hi','9ec99d3d-749a-454b-bac4-423b2a7d105f',1,30,_binary '','8a03cb9f-85e2-4bce-a4e9-9716217676f8',NULL),('53a9bcd0-387a-47c7-a921-a7e877f18eb8',NULL,'idp-username-password-form','hi-therapist','57aa92f1-2eec-4c96-ac9f-b7a57661d8ff',0,10,_binary '\0',NULL,NULL),('54572c50-1f82-46ca-8d50-2520973bb1a3',NULL,'idp-email-verification','hi','11ccc413-eb3a-4dde-a38d-f86f87ffb8a2',2,10,_binary '\0',NULL,NULL),('549a9fa8-8a89-4a03-873a-15fd1b2ffc50',NULL,'idp-confirm-link','hi','6be39391-44b5-4815-be88-9459bbb6f2f7',0,10,_binary '\0',NULL,NULL),('55d92e7e-efb6-444c-a2c0-511240f61a68',NULL,'reset-password','hi-therapist','ed3234cf-40bd-408b-a242-109a6009389c',0,30,_binary '\0',NULL,NULL),('56cb44f8-47c4-4c3d-9d12-e87cc0bb96a6',NULL,NULL,'hi-library','a2b67129-6c56-46ed-bca6-55279c9d9de0',0,20,_binary '','f0d372ae-f37d-4efb-8475-dbd954d44656',NULL),('56f41db4-f2f0-4be9-baab-fe4bb4bd4b41',NULL,'docker-http-basic-authenticator','hi-library','1cce3557-13cf-4bb4-a39d-0548fdf71394',0,10,_binary '\0',NULL,NULL),('5d628e7b-3f06-4350-bc51-075faf95acd3',NULL,'auth-spnego','hi','34b5d5d8-d3ef-4e9b-a253-df8b4115a21a',3,20,_binary '\0',NULL,NULL),('5ea20b22-0f6b-4bea-bec6-06af98a205e5',NULL,'conditional-user-configured','master','bc850286-bc31-40ce-acf4-21a59577a444',0,10,_binary '\0',NULL,NULL),('61d359af-7bd1-4314-92dd-d2e32bf1957a',NULL,'registration-user-creation','hi','ec122629-f387-4f71-825d-fd9fd3149c73',0,20,_binary '\0',NULL,NULL),('63155508-b0bd-4563-bbc2-97137c67ef4a',NULL,'client-jwt','master','762d0690-3bea-4566-8e75-9e97d6b30cbf',2,20,_binary '\0',NULL,NULL),('647b4ba9-33ac-4be9-a13f-4c9b82d04575',NULL,'conditional-user-configured','hi','ff1fc8a4-8da4-4a77-b6b6-4a4adea21dad',0,10,_binary '\0',NULL,NULL),('66d764fe-a4e3-4f22-9e63-88958fc89dfc',NULL,'reset-password','hi','8384ed04-ad56-46db-a2d5-1975c859d74e',0,30,_binary '\0',NULL,NULL),('67cf5c50-9f4d-41af-929d-97b1b3e16fc8',NULL,NULL,'hi','34b5d5d8-d3ef-4e9b-a253-df8b4115a21a',2,30,_binary '','97241df8-358a-47c4-af54-ff59780d9393',NULL),('6884fd54-233c-428b-b4c5-c911ea1f9af6',NULL,'conditional-user-configured','master','da7e0b99-d528-4969-a877-433f8226c120',0,10,_binary '\0',NULL,NULL),('6a2f268d-2b72-4836-bf27-d207bf1c0af3',NULL,'reset-password','hi-library','7458dff4-fe52-4c2e-9ef5-4f7e10e9784b',0,30,_binary '\0',NULL,NULL),('6ac94bc6-bf3a-41e2-b360-67a0eb1586d4',NULL,'direct-grant-validate-username','master','7413e1f5-671c-4f99-a8ec-9a3df8f83b1b',0,10,_binary '\0',NULL,NULL),('6efc2ad3-5189-4a7c-89f4-7185a211ad79',NULL,'auth-username-password-form','hi','97241df8-358a-47c4-af54-ff59780d9393',0,10,_binary '\0',NULL,NULL),('6ff13d09-3490-404e-a704-67abfe571371',NULL,'auth-otp-form','hi','92eeafef-daaf-4853-9f65-4de6f368292f',0,20,_binary '\0',NULL,NULL),('7471a6a0-5b91-4e4c-87dd-9060a042ca2e',NULL,NULL,'hi-library','9d07c829-6cb9-4bca-bd67-20b1b2ec9b87',1,20,_binary '','4bf17e57-129e-4d29-bb48-ca5a9898f576',NULL),('7544f9db-8078-4a36-906d-6af187c8addc',NULL,'auth-cookie','hi-library','e6130d4d-117d-4a54-b478-ec24dfbc929a',2,10,_binary '\0',NULL,NULL),('775a6860-33d5-4a1d-8584-904171cad699',NULL,'direct-grant-validate-password','master','7413e1f5-671c-4f99-a8ec-9a3df8f83b1b',0,20,_binary '\0',NULL,NULL),('79fd0070-7905-4d95-ae5b-17516744d0a8',NULL,'idp-username-password-form','hi-library','2ff51d6a-d54d-41d7-845e-5151e8b21ed4',0,10,_binary '\0',NULL,NULL),('805e1c42-d87f-4509-8944-aba0abd5bb37',NULL,'reset-otp','hi','ff1fc8a4-8da4-4a77-b6b6-4a4adea21dad',0,20,_binary '\0',NULL,NULL),('809d42d8-2361-4e4c-bb80-68514eeb55e1',NULL,'auth-otp-form','hi-therapist','cb06f712-73e6-47a8-aac1-59308af226fb',0,20,_binary '\0',NULL,NULL),('81ad09da-708d-482b-a07f-7de1290488b0',NULL,'idp-username-password-form','hi','3be1f7d5-306d-4d09-9ba6-bdf996dbc474',0,10,_binary '\0',NULL,NULL),('8551d06f-563a-4f16-b9df-bd8054b219ce',NULL,'idp-create-user-if-unique','master','cb904f1a-ad0e-4830-bedc-9e9cd9b5b472',2,10,_binary '\0',NULL,'57a40d88-80fd-4716-8b49-2e82dcf12da7'),('8a5db072-f739-43bf-a851-4e5c2efa39b2',NULL,'client-secret','hi-library','5bcee621-2824-45ef-83b0-33ce018959d4',2,10,_binary '\0',NULL,NULL),('8bf832c6-68d9-4066-845d-b3850829b281',NULL,NULL,'master','7413e1f5-671c-4f99-a8ec-9a3df8f83b1b',1,30,_binary '','eaf3fdb4-bbe8-4191-b770-c0dd3a2153b1',NULL),('8c5c090a-8246-4360-80c3-93228975fd1e',NULL,'reset-credential-email','master','876af1ff-ec2a-4357-ad20-b097e1a30b66',0,20,_binary '\0',NULL,NULL),('8ee21be3-29eb-44b9-ac64-03b84712fe37',NULL,NULL,'hi','8384ed04-ad56-46db-a2d5-1975c859d74e',1,40,_binary '','ff1fc8a4-8da4-4a77-b6b6-4a4adea21dad',NULL),('907f3c83-bd94-4418-b38b-93c1b602f44b',NULL,'conditional-user-configured','hi-library','4bf17e57-129e-4d29-bb48-ca5a9898f576',0,10,_binary '\0',NULL,NULL),('90a178ef-54c5-4dc9-bf9d-d9768db087d1',NULL,'client-secret','hi-therapist','90d64ec7-2b2a-4a6b-8127-27c35439bd01',2,10,_binary '\0',NULL,NULL),('914ec489-c3a8-4ba8-8892-34591df070d9',NULL,'docker-http-basic-authenticator','master','4e530eef-6f34-4750-8712-8460b81579f5',0,10,_binary '\0',NULL,NULL),('925cbd24-f72f-4248-aec4-b303ca5db94b',NULL,'auth-username-password-form','hi-therapist','06e0bc58-e534-49fb-9108-9a63b2c33111',0,10,_binary '\0',NULL,NULL),('93351b1a-b32e-4b89-9f59-f0b1aaa2794f',NULL,'idp-review-profile','hi','c72ed562-95ad-48fe-98ef-b1110fea119c',0,10,_binary '\0',NULL,'a492e4d8-eca5-4ed9-89fd-f7abac77189b'),('960a9353-aa93-49bb-a00f-c9a45dd37ac1',NULL,NULL,'hi','3be1f7d5-306d-4d09-9ba6-bdf996dbc474',1,20,_binary '','2588125a-ef9c-4eeb-b854-99694e02760f',NULL),('97e8e590-6af7-46f4-b91f-6644e49bd331',NULL,'registration-user-creation','hi-library','7c8a2afc-0061-4463-a7d4-c4227cc942ca',0,20,_binary '\0',NULL,NULL),('9a19eed2-235c-40b0-a2e6-0754ecba93e5',NULL,'conditional-user-configured','hi-therapist','cb06f712-73e6-47a8-aac1-59308af226fb',0,10,_binary '\0',NULL,NULL),('9ae4ba9e-67dc-49bd-9795-3ebeffd12f32',NULL,'client-x509','hi','ca153fff-2c91-4dcd-9ffc-88d44bc1973f',2,40,_binary '\0',NULL,NULL),('9d8e1fe9-2894-4e04-9b0e-247ea970c20c',NULL,'conditional-user-configured','hi-therapist','84534266-9d8d-4093-a1ac-a101ffb8eaa0',0,10,_binary '\0',NULL,NULL),('9fbaa3e6-39c7-4437-8a64-7744aa618487',NULL,'client-secret','master','762d0690-3bea-4566-8e75-9e97d6b30cbf',2,10,_binary '\0',NULL,NULL),('a02df292-d5b0-4aa2-ab40-d2cfef51bc73',NULL,'conditional-user-configured','hi-library','25e7d1fe-b75a-44af-8d87-6d2e4acff5c7',0,10,_binary '\0',NULL,NULL),('a2bbf77e-8aca-418f-8a44-c99ac9d1c977',NULL,'auth-otp-form','master','2509b8fd-ee35-498f-be87-3ea689711117',0,20,_binary '\0',NULL,NULL),('a345e047-9c3c-48c2-a732-f6c133385c12',NULL,'auth-otp-form','hi-library','25e7d1fe-b75a-44af-8d87-6d2e4acff5c7',0,20,_binary '\0',NULL,NULL),('a3a9efad-8d9f-4e7d-8dae-18465c91ead7',NULL,'auth-otp-form','hi','186f0e91-2213-4a1a-bc0e-a1fe7bbe067b',0,20,_binary '\0',NULL,NULL),('a3dc629d-41e4-4268-a2a2-856e30828763',NULL,'auth-spnego','hi','ae018a83-f046-4f72-a595-7dda233529fb',3,20,_binary '\0',NULL,NULL),('a41d8045-ed8c-40f5-b220-e2e7adb5a5a6',NULL,'idp-confirm-link','hi-therapist','381480b9-5311-43cb-bbb6-cbd1c44c4e69',0,10,_binary '\0',NULL,NULL),('a7b29a93-a618-4050-b099-2dcf4d952130',NULL,'http-basic-authenticator','hi','b63db777-5422-4a46-8ff8-39decb284ec5',0,10,_binary '\0',NULL,NULL),('a8702edd-e400-4de1-9d60-ff1e37b6e147',NULL,NULL,'hi-therapist','ed3234cf-40bd-408b-a242-109a6009389c',1,40,_binary '','d5dda600-11a8-4f35-8f53-3799a5c0f120',NULL),('aa213cb6-f199-471a-8fe3-e53182f7cb7d',NULL,'reset-credentials-choose-user','hi-therapist','ed3234cf-40bd-408b-a242-109a6009389c',0,10,_binary '\0',NULL,NULL),('ab51cba3-230f-4975-9367-6682fb6ac1f7',NULL,'reset-credentials-choose-user','master','876af1ff-ec2a-4357-ad20-b097e1a30b66',0,10,_binary '\0',NULL,NULL),('ac656f92-3241-4cbc-8ccb-483b01cf90c6',NULL,'direct-grant-validate-otp','hi-library','9a23af0c-2aac-4d49-869c-e99c220ddfab',0,20,_binary '\0',NULL,NULL),('ac8e6bc8-e17e-4114-a537-5868a2c0913a',NULL,'conditional-user-configured','hi-therapist','d5dda600-11a8-4f35-8f53-3799a5c0f120',0,10,_binary '\0',NULL,NULL),('acbf4f19-0d76-498e-b911-fe17a222ecbf',NULL,NULL,'hi-library','7458dff4-fe52-4c2e-9ef5-4f7e10e9784b',1,40,_binary '','fa49b5d5-f727-434d-b842-dd27f92826af',NULL),('b03f4639-e37a-4d8f-8610-305f06f76245',NULL,'direct-grant-validate-username','hi','9ec99d3d-749a-454b-bac4-423b2a7d105f',0,10,_binary '\0',NULL,NULL),('b0477910-b89f-4887-a9c5-f19ec0f0e956',NULL,'conditional-user-configured','hi','186f0e91-2213-4a1a-bc0e-a1fe7bbe067b',0,10,_binary '\0',NULL,NULL),('b25ec6ce-858f-402b-a920-b67f575a1ad9',NULL,'auth-spnego','hi-therapist','e9a9c744-015c-437b-b1c7-68677d4e9bda',3,20,_binary '\0',NULL,NULL),('b52dc92d-79bc-4de5-a70d-e80e659ed98b',NULL,'direct-grant-validate-otp','hi','8a03cb9f-85e2-4bce-a4e9-9716217676f8',0,20,_binary '\0',NULL,NULL),('b5fb0ca3-4fb7-4325-9b33-1b7aa4f01151',NULL,NULL,'hi-library','2ff51d6a-d54d-41d7-845e-5151e8b21ed4',1,20,_binary '','25e7d1fe-b75a-44af-8d87-6d2e4acff5c7',NULL),('b66fed63-8c79-43a2-a987-8f94a44bf1ee',NULL,'idp-confirm-link','master','9d1df98a-7cce-4635-b176-34d8ffbe8c6d',0,10,_binary '\0',NULL,NULL),('b7c8c3fb-e5fb-42e3-b2fa-f0995a521a48',NULL,NULL,'hi-therapist','84461f65-53f7-4dd0-b2fc-a22189b67668',1,30,_binary '','84534266-9d8d-4093-a1ac-a101ffb8eaa0',NULL),('baec5c27-81a6-48b5-8e4d-5466112364fc',NULL,'direct-grant-validate-username','hi-library','3ea3ddb8-d400-4492-9336-af24f413ea93',0,10,_binary '\0',NULL,NULL),('bb44e2ad-2bb1-402d-8a8d-0f8f734aabcd',NULL,'registration-password-action','hi','ec122629-f387-4f71-825d-fd9fd3149c73',0,50,_binary '\0',NULL,NULL),('bbd45ced-7eb9-4851-9019-289edbc1ac28',NULL,'reset-credential-email','hi-therapist','ed3234cf-40bd-408b-a242-109a6009389c',0,20,_binary '\0',NULL,NULL),('bbef9a01-339e-4c1e-9aaf-4c921a28221a',NULL,'client-jwt','hi-therapist','90d64ec7-2b2a-4a6b-8127-27c35439bd01',2,20,_binary '\0',NULL,NULL),('bf38a0b4-0438-4c96-96f1-63ef11642b1c',NULL,'auth-cookie','hi','34b5d5d8-d3ef-4e9b-a253-df8b4115a21a',2,10,_binary '\0',NULL,NULL),('c0b6c2a1-83d2-4487-b7f6-8eb459eaba36',NULL,'auth-otp-form','hi-library','4bf17e57-129e-4d29-bb48-ca5a9898f576',0,20,_binary '\0',NULL,NULL),('c1d84e94-7004-451b-bc31-40c17d2d2b2e',NULL,NULL,'hi','11ccc413-eb3a-4dde-a38d-f86f87ffb8a2',2,20,_binary '','3be1f7d5-306d-4d09-9ba6-bdf996dbc474',NULL),('c23fcbfa-7625-4d56-ac6e-ff80d7969bc2',NULL,'client-x509','master','762d0690-3bea-4566-8e75-9e97d6b30cbf',2,40,_binary '\0',NULL,NULL),('c441ec3b-fa13-4848-83f5-ac92c12443f5',NULL,'client-secret-jwt','hi-library','5bcee621-2824-45ef-83b0-33ce018959d4',2,30,_binary '\0',NULL,NULL),('c4bb0462-622d-40d1-b228-9d8e7bde9642',NULL,'http-basic-authenticator','hi-library','5c843bba-4d55-48b1-a329-fb56de629645',0,10,_binary '\0',NULL,NULL),('c4cba688-1789-4176-9bec-4ea806183c07',NULL,'conditional-user-configured','hi-therapist','d065e5d3-c40e-4f38-8d77-1f7d1da1cb6f',0,10,_binary '\0',NULL,NULL),('c56f7b13-c0fe-40c4-b488-f7f98626be41',NULL,'idp-email-verification','hi-therapist','11c7425e-05d7-431c-a835-b8fd8945e5c3',2,10,_binary '\0',NULL,NULL),('c7106c9d-4460-4739-b421-7d807e7caa67',NULL,NULL,'master','049a78ae-2987-4d23-85f8-48cedde8c844',2,20,_binary '','e874f2b0-b618-4add-bee8-ee66147bd6cf',NULL),('c82bd3ff-5312-4410-812a-fa977f58e555',NULL,'http-basic-authenticator','hi-therapist','cd5ea2ec-4605-482c-b0fb-a4500dab8657',0,10,_binary '\0',NULL,NULL),('cbfaa9a6-eb88-49ca-a61b-5e6caeeb463f',NULL,'client-secret-jwt','hi','ca153fff-2c91-4dcd-9ffc-88d44bc1973f',2,30,_binary '\0',NULL,NULL),('cbfbaa72-b3c9-4570-acfe-9c8941a01085',NULL,NULL,'hi','6be39391-44b5-4815-be88-9459bbb6f2f7',0,20,_binary '','11ccc413-eb3a-4dde-a38d-f86f87ffb8a2',NULL),('cc837c53-dac9-44f9-97bb-87b402c84ebd',NULL,'client-x509','hi-library','5bcee621-2824-45ef-83b0-33ce018959d4',2,40,_binary '\0',NULL,NULL),('cd3ecef2-bfee-4cd7-9f90-acf5af1d3510',NULL,'auth-cookie','hi-therapist','e9a9c744-015c-437b-b1c7-68677d4e9bda',2,10,_binary '\0',NULL,NULL),('cfa8db7d-2fd2-4591-b65d-0b4b487b5b29',NULL,'client-secret-jwt','master','762d0690-3bea-4566-8e75-9e97d6b30cbf',2,30,_binary '\0',NULL,NULL),('d96b971a-3089-4b12-9618-81253eb23708',NULL,'conditional-user-configured','hi-library','9a23af0c-2aac-4d49-869c-e99c220ddfab',0,10,_binary '\0',NULL,NULL),('dd4b2695-dc88-4335-8f4a-fe33007bef24',NULL,NULL,'master','9d1df98a-7cce-4635-b176-34d8ffbe8c6d',0,20,_binary '','049a78ae-2987-4d23-85f8-48cedde8c844',NULL),('de9d5366-0760-4edc-8b77-2c1e0f94c520',NULL,'http-basic-authenticator','master','105d5726-fbba-494f-84db-f0db8d7c9139',0,10,_binary '\0',NULL,NULL),('e147c1c5-23fc-441b-bbde-e0317a9623b9',NULL,'idp-review-profile','master','6a73c2d6-c611-4bf4-a014-3d9b1b1b31e6',0,10,_binary '\0',NULL,'3f9610f7-ba0e-42a2-9f2b-9afc7dcf619e'),('e1ca68ab-e11c-47b7-afee-5d0166a73a2c',NULL,'reset-credential-email','hi','8384ed04-ad56-46db-a2d5-1975c859d74e',0,20,_binary '\0',NULL,NULL),('e20212c4-f72f-48a0-9f05-29ea9adf4b5d',NULL,'auth-username-password-form','master','1f18e563-3c74-44ca-b041-01644c63ffe6',0,10,_binary '\0',NULL,NULL),('ea0e6c9c-5816-434c-ae07-f53e804742b2',NULL,'auth-otp-form','master','da7e0b99-d528-4969-a877-433f8226c120',0,20,_binary '\0',NULL,NULL),('ebe1a771-ba02-44a5-babb-53b2252d078e',NULL,'identity-provider-redirector','hi-library','e6130d4d-117d-4a54-b478-ec24dfbc929a',2,25,_binary '\0',NULL,NULL),('ecd59f33-cb03-4c51-bece-d36dd51d8132',NULL,'registration-recaptcha-action','hi-therapist','fcc49b59-6a2d-49ef-8bac-7678c41819a7',3,60,_binary '\0',NULL,NULL),('ee86c0ae-e440-4768-9466-442dbc41a5f6',NULL,NULL,'master','cb904f1a-ad0e-4830-bedc-9e9cd9b5b472',2,20,_binary '','9d1df98a-7cce-4635-b176-34d8ffbe8c6d',NULL),('ef988e22-1851-40f6-806a-9948c619ab61',NULL,'auth-cookie','master','ee278adf-b54d-43a7-9f7b-6d371cb01118',2,10,_binary '\0',NULL,NULL),('efa0abd6-e0a3-4762-864d-66bd40b5eab9',NULL,'direct-grant-validate-password','hi-library','3ea3ddb8-d400-4492-9336-af24f413ea93',0,20,_binary '\0',NULL,NULL),('f0340d7f-1eaa-4a10-8827-e43841891f44',NULL,'reset-otp','master','bc850286-bc31-40ce-acf4-21a59577a444',0,20,_binary '\0',NULL,NULL),('f19a8fc8-0cb4-4ad1-b298-9728311f09d5',NULL,'conditional-user-configured','hi-library','fa49b5d5-f727-434d-b842-dd27f92826af',0,10,_binary '\0',NULL,NULL),('f1dc7889-03fb-4a8b-bb25-d5337a51e38f',NULL,NULL,'master','e874f2b0-b618-4add-bee8-ee66147bd6cf',1,20,_binary '','2509b8fd-ee35-498f-be87-3ea689711117',NULL),('f2bf051c-3852-4e46-a9bf-026d401d5f48',NULL,'registration-page-form','master','4029cddf-3047-4fce-b502-9e705e02b175',0,10,_binary '','cf5915e8-1958-4cbf-9bde-f615e94014bf',NULL),('f491b885-61db-4f37-bfe6-85a5a442ca39',NULL,'client-jwt','hi','ca153fff-2c91-4dcd-9ffc-88d44bc1973f',2,20,_binary '\0',NULL,NULL),('f4de84f8-67fe-4a36-a516-9f72d4dbe7fb',NULL,'reset-credential-email','hi-library','7458dff4-fe52-4c2e-9ef5-4f7e10e9784b',0,20,_binary '\0',NULL,NULL),('f7015e33-9f74-4cdf-bdb0-b62c140df184',NULL,NULL,'master','1f18e563-3c74-44ca-b041-01644c63ffe6',1,20,_binary '','da7e0b99-d528-4969-a877-433f8226c120',NULL),('f92abf60-58c9-49e1-8a98-86668cdb1880',NULL,NULL,'hi-library','3ea3ddb8-d400-4492-9336-af24f413ea93',1,30,_binary '','9a23af0c-2aac-4d49-869c-e99c220ddfab',NULL),('f9655fd8-4c8f-4f8d-a651-776af712a63a',NULL,'identity-provider-redirector','hi-therapist','e9a9c744-015c-437b-b1c7-68677d4e9bda',2,25,_binary '\0',NULL,NULL),('f9b64f9f-0fb9-4b74-8695-d5be4d0b1824',NULL,'direct-grant-validate-password','hi-therapist','84461f65-53f7-4dd0-b2fc-a22189b67668',0,20,_binary '\0',NULL,NULL),('fa03ba3a-25c2-4e56-9430-6e10b688b9b2',NULL,'direct-grant-validate-username','hi-therapist','84461f65-53f7-4dd0-b2fc-a22189b67668',0,10,_binary '\0',NULL,NULL),('fac6f872-5463-41f4-8d3b-7d4e7c1e3250',NULL,'conditional-user-configured','hi','92eeafef-daaf-4853-9f65-4de6f368292f',0,10,_binary '\0',NULL,NULL),('fb381376-5e9a-4995-b63b-4329435ac5d9',NULL,NULL,'master','876af1ff-ec2a-4357-ad20-b097e1a30b66',1,40,_binary '','bc850286-bc31-40ce-acf4-21a59577a444',NULL),('fb3bc75f-c1a8-4245-8617-7b8b26adc9d8',NULL,'registration-recaptcha-action','master','cf5915e8-1958-4cbf-9bde-f615e94014bf',3,60,_binary '\0',NULL,NULL),('fc261693-f925-4e87-8859-6cf943dba068',NULL,'reset-otp','hi-library','fa49b5d5-f727-434d-b842-dd27f92826af',0,20,_binary '\0',NULL,NULL),('fc460ca6-4a33-40ce-8e89-6e6926f9d7a8',NULL,'client-secret-jwt','hi-therapist','90d64ec7-2b2a-4a6b-8127-27c35439bd01',2,30,_binary '\0',NULL,NULL),('fd475ac9-ccfc-4e58-98a0-1b699e1bbf07',NULL,'idp-confirm-link','hi-library','cb534180-3d27-42a3-8eb7-369f884a8bcc',0,10,_binary '\0',NULL,NULL),('fe60a72b-8996-4838-a33f-c0fe490840ef',NULL,'idp-username-password-form','master','e874f2b0-b618-4add-bee8-ee66147bd6cf',0,10,_binary '\0',NULL,NULL),('fe8fb4f5-aa10-41dd-9de0-6b7c08cb550c',NULL,'registration-page-form','hi','22a7a6b6-61a2-4ef0-944d-0e00c5ce4c21',0,10,_binary '','ec122629-f387-4f71-825d-fd9fd3149c73',NULL),('febf0604-47fd-4fe6-aec1-fe0c4cd91ad3',NULL,'registration-password-action','hi-therapist','fcc49b59-6a2d-49ef-8bac-7678c41819a7',0,50,_binary '\0',NULL,NULL),('ffc3aab7-9775-40b4-bfd2-083c8767e60a',NULL,'auth-spnego','master','ee278adf-b54d-43a7-9f7b-6d371cb01118',3,20,_binary '\0',NULL,NULL);
/*!40000 ALTER TABLE `AUTHENTICATION_EXECUTION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AUTHENTICATION_FLOW`
--

DROP TABLE IF EXISTS `AUTHENTICATION_FLOW`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AUTHENTICATION_FLOW` (
  `ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ALIAS` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DESCRIPTION` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `REALM_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PROVIDER_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'basic-flow',
  `TOP_LEVEL` bit(1) NOT NULL DEFAULT b'0',
  `BUILT_IN` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`ID`),
  KEY `IDX_AUTH_FLOW_REALM` (`REALM_ID`),
  CONSTRAINT `FK_AUTH_FLOW_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AUTHENTICATION_FLOW`
--

LOCK TABLES `AUTHENTICATION_FLOW` WRITE;
/*!40000 ALTER TABLE `AUTHENTICATION_FLOW` DISABLE KEYS */;
INSERT INTO `AUTHENTICATION_FLOW` VALUES ('049a78ae-2987-4d23-85f8-48cedde8c844','Account verification options','Method with which to verity the existing account','master','basic-flow',_binary '\0',_binary ''),('06e0bc58-e534-49fb-9108-9a63b2c33111','forms','Username, password, otp and other auth forms.','hi-therapist','basic-flow',_binary '\0',_binary ''),('105d5726-fbba-494f-84db-f0db8d7c9139','saml ecp','SAML ECP Profile Authentication Flow','master','basic-flow',_binary '',_binary ''),('11c7425e-05d7-431c-a835-b8fd8945e5c3','Account verification options','Method with which to verity the existing account','hi-therapist','basic-flow',_binary '\0',_binary ''),('11ccc413-eb3a-4dde-a38d-f86f87ffb8a2','Account verification options','Method with which to verity the existing account','hi','basic-flow',_binary '\0',_binary ''),('186f0e91-2213-4a1a-bc0e-a1fe7bbe067b','Custom browser Browser - Conditional OTP','Flow to determine if the OTP is required for the authentication','hi','basic-flow',_binary '\0',_binary '\0'),('1cce3557-13cf-4bb4-a39d-0548fdf71394','docker auth','Used by Docker clients to authenticate against the IDP','hi-library','basic-flow',_binary '',_binary ''),('1d21a5a6-c602-41c1-8a61-c21360530fc6','first broker login','Actions taken after first broker login with identity provider account, which is not yet linked to any Keycloak account','hi-therapist','basic-flow',_binary '',_binary ''),('1f18e563-3c74-44ca-b041-01644c63ffe6','forms','Username, password, otp and other auth forms.','master','basic-flow',_binary '\0',_binary ''),('22a7a6b6-61a2-4ef0-944d-0e00c5ce4c21','registration','registration flow','hi','basic-flow',_binary '',_binary ''),('2509b8fd-ee35-498f-be87-3ea689711117','First broker login - Conditional OTP','Flow to determine if the OTP is required for the authentication','master','basic-flow',_binary '\0',_binary ''),('2588125a-ef9c-4eeb-b854-99694e02760f','First broker login - Conditional OTP','Flow to determine if the OTP is required for the authentication','hi','basic-flow',_binary '\0',_binary ''),('25e7d1fe-b75a-44af-8d87-6d2e4acff5c7','First broker login - Conditional OTP','Flow to determine if the OTP is required for the authentication','hi-library','basic-flow',_binary '\0',_binary ''),('2ff51d6a-d54d-41d7-845e-5151e8b21ed4','Verify Existing Account by Re-authentication','Reauthentication of existing account','hi-library','basic-flow',_binary '\0',_binary ''),('34b5d5d8-d3ef-4e9b-a253-df8b4115a21a','browser','browser based authentication','hi','basic-flow',_binary '',_binary ''),('381480b9-5311-43cb-bbb6-cbd1c44c4e69','Handle Existing Account','Handle what to do if there is existing account with same email/username like authenticated identity provider','hi-therapist','basic-flow',_binary '\0',_binary ''),('3be1f7d5-306d-4d09-9ba6-bdf996dbc474','Verify Existing Account by Re-authentication','Reauthentication of existing account','hi','basic-flow',_binary '\0',_binary ''),('3ea3ddb8-d400-4492-9336-af24f413ea93','direct grant','OpenID Connect Resource Owner Grant','hi-library','basic-flow',_binary '',_binary ''),('4029cddf-3047-4fce-b502-9e705e02b175','registration','registration flow','master','basic-flow',_binary '',_binary ''),('4bf17e57-129e-4d29-bb48-ca5a9898f576','Browser - Conditional OTP','Flow to determine if the OTP is required for the authentication','hi-library','basic-flow',_binary '\0',_binary ''),('4ca37c19-ca79-40ab-b914-e458b06637f7','docker auth','Used by Docker clients to authenticate against the IDP','hi-therapist','basic-flow',_binary '',_binary ''),('4e530eef-6f34-4750-8712-8460b81579f5','docker auth','Used by Docker clients to authenticate against the IDP','master','basic-flow',_binary '',_binary ''),('544d16fc-0363-45d5-9173-89099bbd7571','User creation or linking','Flow for the existing/non-existing user alternatives','hi','basic-flow',_binary '\0',_binary ''),('57aa92f1-2eec-4c96-ac9f-b7a57661d8ff','Verify Existing Account by Re-authentication','Reauthentication of existing account','hi-therapist','basic-flow',_binary '\0',_binary ''),('5bcee621-2824-45ef-83b0-33ce018959d4','clients','Base authentication for clients','hi-library','client-flow',_binary '',_binary ''),('5c843bba-4d55-48b1-a329-fb56de629645','saml ecp','SAML ECP Profile Authentication Flow','hi-library','basic-flow',_binary '',_binary ''),('6a73c2d6-c611-4bf4-a014-3d9b1b1b31e6','first broker login','Actions taken after first broker login with identity provider account, which is not yet linked to any Keycloak account','master','basic-flow',_binary '',_binary ''),('6be39391-44b5-4815-be88-9459bbb6f2f7','Handle Existing Account','Handle what to do if there is existing account with same email/username like authenticated identity provider','hi','basic-flow',_binary '\0',_binary ''),('718d46e1-350c-4c81-ad21-9164565e4128','registration','registration flow','hi-library','basic-flow',_binary '',_binary ''),('73c57080-0c08-4e87-b0ad-6cd4d18b7dc6','Account verification options','Method with which to verity the existing account','hi-library','basic-flow',_binary '\0',_binary ''),('7413e1f5-671c-4f99-a8ec-9a3df8f83b1b','direct grant','OpenID Connect Resource Owner Grant','master','basic-flow',_binary '',_binary ''),('7458dff4-fe52-4c2e-9ef5-4f7e10e9784b','reset credentials','Reset credentials for a user if they forgot their password or something','hi-library','basic-flow',_binary '',_binary ''),('762d0690-3bea-4566-8e75-9e97d6b30cbf','clients','Base authentication for clients','master','client-flow',_binary '',_binary ''),('7c8a2afc-0061-4463-a7d4-c4227cc942ca','registration form','registration form','hi-library','form-flow',_binary '\0',_binary ''),('8384ed04-ad56-46db-a2d5-1975c859d74e','reset credentials','Reset credentials for a user if they forgot their password or something','hi','basic-flow',_binary '',_binary ''),('84461f65-53f7-4dd0-b2fc-a22189b67668','direct grant','OpenID Connect Resource Owner Grant','hi-therapist','basic-flow',_binary '',_binary ''),('84534266-9d8d-4093-a1ac-a101ffb8eaa0','Direct Grant - Conditional OTP','Flow to determine if the OTP is required for the authentication','hi-therapist','basic-flow',_binary '\0',_binary ''),('876af1ff-ec2a-4357-ad20-b097e1a30b66','reset credentials','Reset credentials for a user if they forgot their password or something','master','basic-flow',_binary '',_binary ''),('8a03cb9f-85e2-4bce-a4e9-9716217676f8','Direct Grant - Conditional OTP','Flow to determine if the OTP is required for the authentication','hi','basic-flow',_binary '\0',_binary ''),('90d64ec7-2b2a-4a6b-8127-27c35439bd01','clients','Base authentication for clients','hi-therapist','client-flow',_binary '',_binary ''),('92eeafef-daaf-4853-9f65-4de6f368292f','Browser - Conditional OTP','Flow to determine if the OTP is required for the authentication','hi','basic-flow',_binary '\0',_binary ''),('97241df8-358a-47c4-af54-ff59780d9393','forms','Username, password, otp and other auth forms.','hi','basic-flow',_binary '\0',_binary ''),('9a23af0c-2aac-4d49-869c-e99c220ddfab','Direct Grant - Conditional OTP','Flow to determine if the OTP is required for the authentication','hi-library','basic-flow',_binary '\0',_binary ''),('9d07c829-6cb9-4bca-bd67-20b1b2ec9b87','forms','Username, password, otp and other auth forms.','hi-library','basic-flow',_binary '\0',_binary ''),('9d1df98a-7cce-4635-b176-34d8ffbe8c6d','Handle Existing Account','Handle what to do if there is existing account with same email/username like authenticated identity provider','master','basic-flow',_binary '\0',_binary ''),('9ec99d3d-749a-454b-bac4-423b2a7d105f','direct grant','OpenID Connect Resource Owner Grant','hi','basic-flow',_binary '',_binary ''),('9ef7f41f-1978-4e27-8b62-9da623029b6c','Custom browser forms','Username, password, otp and other auth forms.','hi','basic-flow',_binary '\0',_binary '\0'),('a2b67129-6c56-46ed-bca6-55279c9d9de0','first broker login','Actions taken after first broker login with identity provider account, which is not yet linked to any Keycloak account','hi-library','basic-flow',_binary '',_binary ''),('ae018a83-f046-4f72-a595-7dda233529fb','Custom browser','browser based authentication','hi','basic-flow',_binary '',_binary '\0'),('b63db777-5422-4a46-8ff8-39decb284ec5','saml ecp','SAML ECP Profile Authentication Flow','hi','basic-flow',_binary '',_binary ''),('bc850286-bc31-40ce-acf4-21a59577a444','Reset - Conditional OTP','Flow to determine if the OTP should be reset or not. Set to REQUIRED to force.','master','basic-flow',_binary '\0',_binary ''),('c72ed562-95ad-48fe-98ef-b1110fea119c','first broker login','Actions taken after first broker login with identity provider account, which is not yet linked to any Keycloak account','hi','basic-flow',_binary '',_binary ''),('ca153fff-2c91-4dcd-9ffc-88d44bc1973f','clients','Base authentication for clients','hi','client-flow',_binary '',_binary ''),('cb06f712-73e6-47a8-aac1-59308af226fb','Browser - Conditional OTP','Flow to determine if the OTP is required for the authentication','hi-therapist','basic-flow',_binary '\0',_binary ''),('cb534180-3d27-42a3-8eb7-369f884a8bcc','Handle Existing Account','Handle what to do if there is existing account with same email/username like authenticated identity provider','hi-library','basic-flow',_binary '\0',_binary ''),('cb904f1a-ad0e-4830-bedc-9e9cd9b5b472','User creation or linking','Flow for the existing/non-existing user alternatives','master','basic-flow',_binary '\0',_binary ''),('cd5ea2ec-4605-482c-b0fb-a4500dab8657','saml ecp','SAML ECP Profile Authentication Flow','hi-therapist','basic-flow',_binary '',_binary ''),('cf5915e8-1958-4cbf-9bde-f615e94014bf','registration form','registration form','master','form-flow',_binary '\0',_binary ''),('d065e5d3-c40e-4f38-8d77-1f7d1da1cb6f','First broker login - Conditional OTP','Flow to determine if the OTP is required for the authentication','hi-therapist','basic-flow',_binary '\0',_binary ''),('d5dda600-11a8-4f35-8f53-3799a5c0f120','Reset - Conditional OTP','Flow to determine if the OTP should be reset or not. Set to REQUIRED to force.','hi-therapist','basic-flow',_binary '\0',_binary ''),('d847ada6-88ba-4612-9bc1-f9393916df2f','User creation or linking','Flow for the existing/non-existing user alternatives','hi-therapist','basic-flow',_binary '\0',_binary ''),('da7e0b99-d528-4969-a877-433f8226c120','Browser - Conditional OTP','Flow to determine if the OTP is required for the authentication','master','basic-flow',_binary '\0',_binary ''),('e5a56b25-198b-4b22-8ef5-1b0e26727f69','docker auth','Used by Docker clients to authenticate against the IDP','hi','basic-flow',_binary '',_binary ''),('e6130d4d-117d-4a54-b478-ec24dfbc929a','browser','browser based authentication','hi-library','basic-flow',_binary '',_binary ''),('e874f2b0-b618-4add-bee8-ee66147bd6cf','Verify Existing Account by Re-authentication','Reauthentication of existing account','master','basic-flow',_binary '\0',_binary ''),('e9a9c744-015c-437b-b1c7-68677d4e9bda','browser','browser based authentication','hi-therapist','basic-flow',_binary '',_binary ''),('eaf3fdb4-bbe8-4191-b770-c0dd3a2153b1','Direct Grant - Conditional OTP','Flow to determine if the OTP is required for the authentication','master','basic-flow',_binary '\0',_binary ''),('ec122629-f387-4f71-825d-fd9fd3149c73','registration form','registration form','hi','form-flow',_binary '\0',_binary ''),('ed3234cf-40bd-408b-a242-109a6009389c','reset credentials','Reset credentials for a user if they forgot their password or something','hi-therapist','basic-flow',_binary '',_binary ''),('ee278adf-b54d-43a7-9f7b-6d371cb01118','browser','browser based authentication','master','basic-flow',_binary '',_binary ''),('ee6e3d97-68b0-4771-a840-ad02eb747500','registration','registration flow','hi-therapist','basic-flow',_binary '',_binary ''),('f0d372ae-f37d-4efb-8475-dbd954d44656','User creation or linking','Flow for the existing/non-existing user alternatives','hi-library','basic-flow',_binary '\0',_binary ''),('fa49b5d5-f727-434d-b842-dd27f92826af','Reset - Conditional OTP','Flow to determine if the OTP should be reset or not. Set to REQUIRED to force.','hi-library','basic-flow',_binary '\0',_binary ''),('fcc49b59-6a2d-49ef-8bac-7678c41819a7','registration form','registration form','hi-therapist','form-flow',_binary '\0',_binary ''),('ff1fc8a4-8da4-4a77-b6b6-4a4adea21dad','Reset - Conditional OTP','Flow to determine if the OTP should be reset or not. Set to REQUIRED to force.','hi','basic-flow',_binary '\0',_binary '');
/*!40000 ALTER TABLE `AUTHENTICATION_FLOW` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AUTHENTICATOR_CONFIG`
--

DROP TABLE IF EXISTS `AUTHENTICATOR_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AUTHENTICATOR_CONFIG` (
  `ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ALIAS` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REALM_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IDX_AUTH_CONFIG_REALM` (`REALM_ID`),
  CONSTRAINT `FK_AUTH_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AUTHENTICATOR_CONFIG`
--

LOCK TABLES `AUTHENTICATOR_CONFIG` WRITE;
/*!40000 ALTER TABLE `AUTHENTICATOR_CONFIG` DISABLE KEYS */;
INSERT INTO `AUTHENTICATOR_CONFIG` VALUES ('00d298c5-f948-4567-a483-78094ceface6','review profile config','hi-library'),('1654fec2-b7f6-4048-b52d-45e781367119','create unique user config','hi-library'),('3f9610f7-ba0e-42a2-9f2b-9afc7dcf619e','review profile config','master'),('57a40d88-80fd-4716-8b49-2e82dcf12da7','create unique user config','master'),('611b6f51-9c1e-4365-9cfc-4deb2d03bbfd','review profile config','hi-therapist'),('a492e4d8-eca5-4ed9-89fd-f7abac77189b','review profile config','hi'),('aa1fb027-3540-4ba9-bc74-1a658c7f7726','create unique user config','hi-therapist'),('e1707e38-1fbd-4209-824a-bd6d2188c080','create unique user config','hi');
/*!40000 ALTER TABLE `AUTHENTICATOR_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AUTHENTICATOR_CONFIG_ENTRY`
--

DROP TABLE IF EXISTS `AUTHENTICATOR_CONFIG_ENTRY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AUTHENTICATOR_CONFIG_ENTRY` (
  `AUTHENTICATOR_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`AUTHENTICATOR_ID`,`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AUTHENTICATOR_CONFIG_ENTRY`
--

LOCK TABLES `AUTHENTICATOR_CONFIG_ENTRY` WRITE;
/*!40000 ALTER TABLE `AUTHENTICATOR_CONFIG_ENTRY` DISABLE KEYS */;
INSERT INTO `AUTHENTICATOR_CONFIG_ENTRY` VALUES ('00d298c5-f948-4567-a483-78094ceface6','missing','update.profile.on.first.login'),('1654fec2-b7f6-4048-b52d-45e781367119','false','require.password.update.after.registration'),('3f9610f7-ba0e-42a2-9f2b-9afc7dcf619e','missing','update.profile.on.first.login'),('57a40d88-80fd-4716-8b49-2e82dcf12da7','false','require.password.update.after.registration'),('611b6f51-9c1e-4365-9cfc-4deb2d03bbfd','missing','update.profile.on.first.login'),('a492e4d8-eca5-4ed9-89fd-f7abac77189b','missing','update.profile.on.first.login'),('aa1fb027-3540-4ba9-bc74-1a658c7f7726','false','require.password.update.after.registration'),('e1707e38-1fbd-4209-824a-bd6d2188c080','false','require.password.update.after.registration');
/*!40000 ALTER TABLE `AUTHENTICATOR_CONFIG_ENTRY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BROKER_LINK`
--

DROP TABLE IF EXISTS `BROKER_LINK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BROKER_LINK` (
  `IDENTITY_PROVIDER` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `STORAGE_PROVIDER_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REALM_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `BROKER_USER_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `BROKER_USERNAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TOKEN` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `USER_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`IDENTITY_PROVIDER`,`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BROKER_LINK`
--

LOCK TABLES `BROKER_LINK` WRITE;
/*!40000 ALTER TABLE `BROKER_LINK` DISABLE KEYS */;
/*!40000 ALTER TABLE `BROKER_LINK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENT`
--

DROP TABLE IF EXISTS `CLIENT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CLIENT` (
  `ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ENABLED` bit(1) NOT NULL DEFAULT b'0',
  `FULL_SCOPE_ALLOWED` bit(1) NOT NULL DEFAULT b'0',
  `CLIENT_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `NOT_BEFORE` int DEFAULT NULL,
  `PUBLIC_CLIENT` bit(1) NOT NULL DEFAULT b'0',
  `SECRET` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `BASE_URL` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `BEARER_ONLY` bit(1) NOT NULL DEFAULT b'0',
  `MANAGEMENT_URL` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SURROGATE_AUTH_REQUIRED` bit(1) NOT NULL DEFAULT b'0',
  `REALM_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PROTOCOL` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `NODE_REREG_TIMEOUT` int DEFAULT '0',
  `FRONTCHANNEL_LOGOUT` bit(1) NOT NULL DEFAULT b'0',
  `CONSENT_REQUIRED` bit(1) NOT NULL DEFAULT b'0',
  `NAME` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `SERVICE_ACCOUNTS_ENABLED` bit(1) NOT NULL DEFAULT b'0',
  `CLIENT_AUTHENTICATOR_TYPE` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ROOT_URL` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DESCRIPTION` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `REGISTRATION_TOKEN` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `STANDARD_FLOW_ENABLED` bit(1) NOT NULL DEFAULT b'1',
  `IMPLICIT_FLOW_ENABLED` bit(1) NOT NULL DEFAULT b'0',
  `DIRECT_ACCESS_GRANTS_ENABLED` bit(1) NOT NULL DEFAULT b'0',
  `ALWAYS_DISPLAY_IN_CONSOLE` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_B71CJLBENV945RB6GCON438AT` (`REALM_ID`,`CLIENT_ID`),
  KEY `IDX_CLIENT_ID` (`CLIENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENT`
--

LOCK TABLES `CLIENT` WRITE;
/*!40000 ALTER TABLE `CLIENT` DISABLE KEYS */;
INSERT INTO `CLIENT` VALUES ('0ae8de67-23f4-49b2-8672-75bb2dedc900',_binary '',_binary '\0','realm-management',0,_binary '\0','7bc0881d-a9b8-4a72-9788-10bf40ba0b4b',NULL,_binary '',NULL,_binary '\0','hi-library','openid-connect',0,_binary '\0',_binary '\0','${client_realm-management}',_binary '\0','client-secret',NULL,NULL,NULL,_binary '',_binary '\0',_binary '\0',_binary '\0'),('1472daaa-5420-4b1f-bfb2-f184f16a8320',_binary '',_binary '','hi_backend',0,_binary '\0','xSDl105v261UnZXu25pEwQ0h7tnjnVGm','',_binary '\0','',_binary '\0','hi-therapist','openid-connect',-1,_binary '\0',_binary '\0','',_binary '\0','client-secret','','',NULL,_binary '',_binary '\0',_binary '',_binary '\0'),('188df32b-7999-4ebb-9c06-f0087380f68d',_binary '',_binary '\0','admin-cli',0,_binary '','66799f6a-14be-4e6a-9476-de3c60ee374d',NULL,_binary '\0',NULL,_binary '\0','hi-library','openid-connect',0,_binary '\0',_binary '\0','${client_admin-cli}',_binary '\0','client-secret',NULL,NULL,NULL,_binary '\0',_binary '\0',_binary '',_binary '\0'),('1d1424ea-24c6-4434-b5e5-8e96e26f3255',_binary '',_binary '\0','account-console',0,_binary '','b4cd3059-afc3-47cb-98fa-47409c4e274c','/realms/hi-library/account/',_binary '\0',NULL,_binary '\0','hi-library','openid-connect',0,_binary '\0',_binary '\0','${client_account-console}',_binary '\0','client-secret','${authBaseUrl}',NULL,NULL,_binary '',_binary '\0',_binary '\0',_binary '\0'),('2410b91c-be58-4f3c-a4ae-83cd998c8f6c',_binary '',_binary '','hi-realm',0,_binary '\0','f1ff3748-0295-4c2b-90d0-6aadbe3c5c53',NULL,_binary '',NULL,_binary '\0','master',NULL,0,_binary '\0',_binary '\0','hi Realm',_binary '\0','client-secret',NULL,NULL,NULL,_binary '',_binary '\0',_binary '\0',_binary '\0'),('30febc11-32fa-4349-a4db-a46a33775ab2',_binary '',_binary '','hi_frontend',0,_binary '',NULL,'',_binary '\0','',_binary '\0','hi-therapist','openid-connect',-1,_binary '\0',_binary '\0','',_binary '\0','client-secret','','',NULL,_binary '',_binary '',_binary '',_binary '\0'),('3d7c0f55-4d00-4eb7-92fc-2ac879eba8fe',_binary '',_binary '\0','admin-cli',0,_binary '','21dfdcab-5f9d-41e4-a9ac-b3b321113f12',NULL,_binary '\0',NULL,_binary '\0','hi','openid-connect',0,_binary '\0',_binary '\0','${client_admin-cli}',_binary '\0','client-secret',NULL,NULL,NULL,_binary '\0',_binary '\0',_binary '',_binary '\0'),('434a5435-9f56-4ed6-9649-1946ac15cbfc',_binary '',_binary '\0','broker',0,_binary '\0','e39efd1d-4776-44fb-935c-fa1ff15ac140',NULL,_binary '\0',NULL,_binary '\0','master','openid-connect',0,_binary '\0',_binary '\0','${client_broker}',_binary '\0','client-secret',NULL,NULL,NULL,_binary '',_binary '\0',_binary '\0',_binary '\0'),('558bc5ae-068f-4e0b-b70a-170b730aa137',_binary '',_binary '','hi_frontend',0,_binary '',NULL,'',_binary '\0','',_binary '\0','hi','openid-connect',-1,_binary '\0',_binary '\0','',_binary '\0','client-secret','','',NULL,_binary '',_binary '',_binary '',_binary '\0'),('55c52d92-7f2e-40b2-8cef-35e558d2c72b',_binary '',_binary '\0','account',0,_binary '\0','08353cd8-cd11-4ee1-a1ce-0e4da8943b29','/realms/hi/account/',_binary '\0',NULL,_binary '\0','hi','openid-connect',0,_binary '\0',_binary '\0','${client_account}',_binary '\0','client-secret','${authBaseUrl}',NULL,NULL,_binary '',_binary '\0',_binary '\0',_binary '\0'),('59b01532-686c-41a7-a818-8cd64adb99f5',_binary '',_binary '','master-realm',0,_binary '\0','6f39d04e-02f0-4031-aa81-dfec731772b9',NULL,_binary '',NULL,_binary '\0','master',NULL,0,_binary '\0',_binary '\0','master Realm',_binary '\0','client-secret',NULL,NULL,NULL,_binary '',_binary '\0',_binary '\0',_binary '\0'),('5ac1fbef-dc0d-437e-bdfb-6d0c0d467dc0',_binary '',_binary '\0','security-admin-console',0,_binary '','fada1ec9-a256-4306-a5c9-17fc40cae6f3','/admin/hi-library/console/',_binary '\0',NULL,_binary '\0','hi-library','openid-connect',0,_binary '\0',_binary '\0','${client_security-admin-console}',_binary '\0','client-secret','${authAdminUrl}',NULL,NULL,_binary '',_binary '\0',_binary '\0',_binary '\0'),('5cef529c-ec43-419f-a198-7ce0e7ba6eb3',_binary '',_binary '\0','admin-cli',0,_binary '','aff142f0-1f79-45c0-8cd7-09939a763988',NULL,_binary '\0',NULL,_binary '\0','hi-therapist','openid-connect',0,_binary '\0',_binary '\0','${client_admin-cli}',_binary '\0','client-secret',NULL,NULL,NULL,_binary '\0',_binary '\0',_binary '',_binary '\0'),('620c09d1-5d44-4bda-959f-82ff964b0f98',_binary '',_binary '','hi_frontend',0,_binary '',NULL,'',_binary '\0','',_binary '\0','hi-library','openid-connect',-1,_binary '\0',_binary '\0','',_binary '\0','client-secret','','',NULL,_binary '',_binary '\0',_binary '',_binary '\0'),('63f568e6-51bc-4bbe-9fb4-1dcf570d09a4',_binary '',_binary '\0','account-console',0,_binary '','**********','/realms/Hi/account/',_binary '\0',NULL,_binary '\0','hi-therapist','openid-connect',0,_binary '\0',_binary '\0','${client_account-console}',_binary '\0','client-secret','${authBaseUrl}',NULL,NULL,_binary '',_binary '\0',_binary '\0',_binary '\0'),('78044321-1410-42bf-9489-f89303e77e5a',_binary '',_binary '\0','broker',0,_binary '\0','063799bc-3def-4e97-b65d-c32116ff8fe4',NULL,_binary '\0',NULL,_binary '\0','hi-therapist','openid-connect',0,_binary '\0',_binary '\0','${client_broker}',_binary '\0','client-secret',NULL,NULL,NULL,_binary '',_binary '\0',_binary '\0',_binary '\0'),('89d22c6b-7a3a-406a-8635-049ea85abb55',_binary '',_binary '\0','account',0,_binary '\0','d51d6c89-cd73-4148-8b29-6822ed24b087','/realms/hi-therapist/account/',_binary '\0',NULL,_binary '\0','hi-therapist','openid-connect',0,_binary '\0',_binary '\0','${client_account}',_binary '\0','client-secret','${authBaseUrl}',NULL,NULL,_binary '',_binary '\0',_binary '\0',_binary '\0'),('a3a37b6f-21f9-49da-8561-1b850d20cba5',_binary '',_binary '\0','account-console',0,_binary '','41bf923e-1022-44e3-bd80-58aa3d921046','/realms/master/account/',_binary '\0',NULL,_binary '\0','master','openid-connect',0,_binary '\0',_binary '\0','${client_account-console}',_binary '\0','client-secret','${authBaseUrl}',NULL,NULL,_binary '',_binary '\0',_binary '\0',_binary '\0'),('a70bea3e-e035-439e-a52a-b15206b54b29',_binary '',_binary '\0','account',0,_binary '\0','68de0f28-71e3-437c-aad7-9e3b3c2dcebf','/realms/master/account/',_binary '\0',NULL,_binary '\0','master','openid-connect',0,_binary '\0',_binary '\0','${client_account}',_binary '\0','client-secret','${authBaseUrl}',NULL,NULL,_binary '',_binary '\0',_binary '\0',_binary '\0'),('a970fd62-9f34-451b-9ea3-38ca7fdc3260',_binary '',_binary '\0','admin-cli',0,_binary '','843ec52c-dd74-496a-a20a-acdaa04ee822',NULL,_binary '\0',NULL,_binary '\0','master','openid-connect',0,_binary '\0',_binary '\0','${client_admin-cli}',_binary '\0','client-secret',NULL,NULL,NULL,_binary '\0',_binary '\0',_binary '',_binary '\0'),('ac8a7f4f-fefc-4a43-bc0f-b42078184dc5',_binary '',_binary '\0','broker',0,_binary '\0','731fb85b-96e7-4e09-856e-99b9dd84aeac',NULL,_binary '\0',NULL,_binary '\0','hi','openid-connect',0,_binary '\0',_binary '\0','${client_broker}',_binary '\0','client-secret',NULL,NULL,NULL,_binary '',_binary '\0',_binary '\0',_binary '\0'),('af07419a-9fdd-48f8-bb86-98deababeb5d',_binary '',_binary '\0','account-console',0,_binary '','**********','/realms/hi/account/',_binary '\0',NULL,_binary '\0','hi','openid-connect',0,_binary '\0',_binary '\0','${client_account-console}',_binary '\0','client-secret','${authBaseUrl}',NULL,NULL,_binary '',_binary '\0',_binary '\0',_binary '\0'),('b3fea689-45c7-4c2b-96ef-b389a0355159',_binary '',_binary '\0','broker',0,_binary '\0','77c81f09-b399-458e-9e56-d85d4dd0d7ad',NULL,_binary '\0',NULL,_binary '\0','hi-library','openid-connect',0,_binary '\0',_binary '\0','${client_broker}',_binary '\0','client-secret',NULL,NULL,NULL,_binary '',_binary '\0',_binary '\0',_binary '\0'),('cb884845-e614-4c6e-9508-6fd6ae87fd60',_binary '',_binary '\0','security-admin-console',0,_binary '','cf0e1594-7b8c-4545-adaa-5f3eca0c72f4','/admin/hi-therapist/console/',_binary '\0',NULL,_binary '\0','hi-therapist','openid-connect',0,_binary '\0',_binary '\0','${client_security-admin-console}',_binary '\0','client-secret','${authAdminUrl}',NULL,NULL,_binary '',_binary '\0',_binary '\0',_binary '\0'),('cea71342-d5fb-4873-b97d-21ac890e6c72',_binary '',_binary '','hi-library-realm',0,_binary '\0','ea93ef7f-94aa-4b9b-a749-b4a612d0248f',NULL,_binary '',NULL,_binary '\0','master',NULL,0,_binary '\0',_binary '\0','hi-library Realm',_binary '\0','client-secret',NULL,NULL,NULL,_binary '',_binary '\0',_binary '\0',_binary '\0'),('d3bacc5c-ac4e-41ab-abb9-3d79878ddcdc',_binary '',_binary '\0','security-admin-console',0,_binary '','320b5267-9a1c-430c-8478-4f2ada407b24','/admin/master/console/',_binary '\0',NULL,_binary '\0','master','openid-connect',0,_binary '\0',_binary '\0','${client_security-admin-console}',_binary '\0','client-secret','${authAdminUrl}',NULL,NULL,_binary '',_binary '\0',_binary '\0',_binary '\0'),('d84f18c2-b355-4a93-893b-a886e0b8fcf2',_binary '',_binary '\0','security-admin-console',0,_binary '','8707dedd-625d-4099-a36b-95df6ca51d37','/admin/hi/console/',_binary '\0',NULL,_binary '\0','hi','openid-connect',0,_binary '\0',_binary '\0','${client_security-admin-console}',_binary '\0','client-secret','${authAdminUrl}',NULL,NULL,_binary '',_binary '\0',_binary '\0',_binary '\0'),('da8a1c0e-1290-4e3d-988f-7ff967de07d8',_binary '',_binary '','hi_backend',0,_binary '\0','TJwS15l3vFcqHF6n7823AlYfjnOAacVz','',_binary '\0','',_binary '\0','hi','openid-connect',-1,_binary '\0',_binary '\0','',_binary '\0','client-secret','','',NULL,_binary '',_binary '\0',_binary '',_binary '\0'),('dd77b2d7-5ee9-4a5d-a25a-eb152157fb4c',_binary '',_binary '\0','account',0,_binary '\0','4f88396e-5c65-45b9-a329-5137d8f7cf2c','/realms/hi-library/account/',_binary '\0',NULL,_binary '\0','hi-library','openid-connect',0,_binary '\0',_binary '\0','${client_account}',_binary '\0','client-secret','${authBaseUrl}',NULL,NULL,_binary '',_binary '\0',_binary '\0',_binary '\0'),('e233b1cf-3455-4e60-9488-ec12dfa884d2',_binary '',_binary '','hi_backend',0,_binary '\0','gCHfjvcpQzqgKkDhHryWdOWYpIj4ZKqd','',_binary '\0','',_binary '\0','hi-library','openid-connect',-1,_binary '\0',_binary '\0','',_binary '\0','client-secret','','',NULL,_binary '',_binary '\0',_binary '',_binary '\0'),('e7c18adf-18b9-48fc-92a0-698f43736bcd',_binary '',_binary '','hi-therapist-realm',0,_binary '\0','e7fad4aa-563c-4d46-8ea4-16f233d4ae85',NULL,_binary '',NULL,_binary '\0','master',NULL,0,_binary '\0',_binary '\0','hi-therapist Realm',_binary '\0','client-secret',NULL,NULL,NULL,_binary '',_binary '\0',_binary '\0',_binary '\0'),('ead46d75-3ebd-458d-8d9a-8df75b027507',_binary '',_binary '\0','realm-management',0,_binary '\0','5592d083-43c1-4adb-b7fe-65ac897d00db',NULL,_binary '',NULL,_binary '\0','hi-therapist','openid-connect',0,_binary '\0',_binary '\0','${client_realm-management}',_binary '\0','client-secret',NULL,NULL,NULL,_binary '',_binary '\0',_binary '\0',_binary '\0'),('eec28897-b54a-4d82-9488-f454e28d01ea',_binary '',_binary '\0','realm-management',0,_binary '\0','f35211d5-0e24-4823-abb9-02a5820a2ac0',NULL,_binary '',NULL,_binary '\0','hi','openid-connect',0,_binary '\0',_binary '\0','${client_realm-management}',_binary '\0','client-secret',NULL,NULL,NULL,_binary '',_binary '\0',_binary '\0',_binary '\0');
/*!40000 ALTER TABLE `CLIENT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENT_ATTRIBUTES`
--

DROP TABLE IF EXISTS `CLIENT_ATTRIBUTES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CLIENT_ATTRIBUTES` (
  `CLIENT_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  PRIMARY KEY (`CLIENT_ID`,`NAME`),
  KEY `IDX_CLIENT_ATT_BY_NAME_VALUE` (`NAME`,`VALUE`(255)),
  CONSTRAINT `FK3C47C64BEACCA966` FOREIGN KEY (`CLIENT_ID`) REFERENCES `CLIENT` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENT_ATTRIBUTES`
--

LOCK TABLES `CLIENT_ATTRIBUTES` WRITE;
/*!40000 ALTER TABLE `CLIENT_ATTRIBUTES` DISABLE KEYS */;
INSERT INTO `CLIENT_ATTRIBUTES` VALUES ('1472daaa-5420-4b1f-bfb2-f184f16a8320','backchannel.logout.revoke.offline.tokens','false'),('1472daaa-5420-4b1f-bfb2-f184f16a8320','backchannel.logout.session.required','true'),('1472daaa-5420-4b1f-bfb2-f184f16a8320','client.secret.creation.time','1743666418'),('1472daaa-5420-4b1f-bfb2-f184f16a8320','display.on.consent.screen','false'),('1472daaa-5420-4b1f-bfb2-f184f16a8320','exclude.session.state.from.auth.response','false'),('1472daaa-5420-4b1f-bfb2-f184f16a8320','oauth2.device.authorization.grant.enabled','false'),('1472daaa-5420-4b1f-bfb2-f184f16a8320','oidc.ciba.grant.enabled','false'),('1472daaa-5420-4b1f-bfb2-f184f16a8320','post.logout.redirect.uris','+'),('1472daaa-5420-4b1f-bfb2-f184f16a8320','saml_force_name_id_format','false'),('1472daaa-5420-4b1f-bfb2-f184f16a8320','saml.assertion.signature','false'),('1472daaa-5420-4b1f-bfb2-f184f16a8320','saml.authnstatement','false'),('1472daaa-5420-4b1f-bfb2-f184f16a8320','saml.client.signature','false'),('1472daaa-5420-4b1f-bfb2-f184f16a8320','saml.encrypt','false'),('1472daaa-5420-4b1f-bfb2-f184f16a8320','saml.force.post.binding','false'),('1472daaa-5420-4b1f-bfb2-f184f16a8320','saml.multivalued.roles','false'),('1472daaa-5420-4b1f-bfb2-f184f16a8320','saml.onetimeuse.condition','false'),('1472daaa-5420-4b1f-bfb2-f184f16a8320','saml.server.signature','false'),('1472daaa-5420-4b1f-bfb2-f184f16a8320','saml.server.signature.keyinfo.ext','false'),('1472daaa-5420-4b1f-bfb2-f184f16a8320','tls.client.certificate.bound.access.tokens','false'),('1d1424ea-24c6-4434-b5e5-8e96e26f3255','pkce.code.challenge.method','S256'),('1d1424ea-24c6-4434-b5e5-8e96e26f3255','post.logout.redirect.uris','+'),('30febc11-32fa-4349-a4db-a46a33775ab2','backchannel.logout.revoke.offline.tokens','false'),('30febc11-32fa-4349-a4db-a46a33775ab2','backchannel.logout.session.required','true'),('30febc11-32fa-4349-a4db-a46a33775ab2','display.on.consent.screen','false'),('30febc11-32fa-4349-a4db-a46a33775ab2','exclude.session.state.from.auth.response','false'),('30febc11-32fa-4349-a4db-a46a33775ab2','oauth2.device.authorization.grant.enabled','false'),('30febc11-32fa-4349-a4db-a46a33775ab2','oidc.ciba.grant.enabled','false'),('30febc11-32fa-4349-a4db-a46a33775ab2','post.logout.redirect.uris','+'),('30febc11-32fa-4349-a4db-a46a33775ab2','saml_force_name_id_format','false'),('30febc11-32fa-4349-a4db-a46a33775ab2','saml.assertion.signature','false'),('30febc11-32fa-4349-a4db-a46a33775ab2','saml.authnstatement','false'),('30febc11-32fa-4349-a4db-a46a33775ab2','saml.client.signature','false'),('30febc11-32fa-4349-a4db-a46a33775ab2','saml.encrypt','false'),('30febc11-32fa-4349-a4db-a46a33775ab2','saml.force.post.binding','false'),('30febc11-32fa-4349-a4db-a46a33775ab2','saml.multivalued.roles','false'),('30febc11-32fa-4349-a4db-a46a33775ab2','saml.onetimeuse.condition','false'),('30febc11-32fa-4349-a4db-a46a33775ab2','saml.server.signature','false'),('30febc11-32fa-4349-a4db-a46a33775ab2','saml.server.signature.keyinfo.ext','false'),('30febc11-32fa-4349-a4db-a46a33775ab2','tls.client.certificate.bound.access.tokens','false'),('558bc5ae-068f-4e0b-b70a-170b730aa137','access.token.lifespan',NULL),('558bc5ae-068f-4e0b-b70a-170b730aa137','backchannel.logout.revoke.offline.tokens','false'),('558bc5ae-068f-4e0b-b70a-170b730aa137','backchannel.logout.session.required','true'),('558bc5ae-068f-4e0b-b70a-170b730aa137','display.on.consent.screen','false'),('558bc5ae-068f-4e0b-b70a-170b730aa137','exclude.session.state.from.auth.response','false'),('558bc5ae-068f-4e0b-b70a-170b730aa137','oauth2.device.authorization.grant.enabled','false'),('558bc5ae-068f-4e0b-b70a-170b730aa137','oidc.ciba.grant.enabled','false'),('558bc5ae-068f-4e0b-b70a-170b730aa137','post.logout.redirect.uris','+'),('558bc5ae-068f-4e0b-b70a-170b730aa137','saml_force_name_id_format','false'),('558bc5ae-068f-4e0b-b70a-170b730aa137','saml.assertion.signature','false'),('558bc5ae-068f-4e0b-b70a-170b730aa137','saml.authnstatement','false'),('558bc5ae-068f-4e0b-b70a-170b730aa137','saml.client.signature','false'),('558bc5ae-068f-4e0b-b70a-170b730aa137','saml.encrypt','false'),('558bc5ae-068f-4e0b-b70a-170b730aa137','saml.force.post.binding','false'),('558bc5ae-068f-4e0b-b70a-170b730aa137','saml.multivalued.roles','false'),('558bc5ae-068f-4e0b-b70a-170b730aa137','saml.onetimeuse.condition','false'),('558bc5ae-068f-4e0b-b70a-170b730aa137','saml.server.signature','false'),('558bc5ae-068f-4e0b-b70a-170b730aa137','saml.server.signature.keyinfo.ext','false'),('558bc5ae-068f-4e0b-b70a-170b730aa137','tls.client.certificate.bound.access.tokens','false'),('55c52d92-7f2e-40b2-8cef-35e558d2c72b','access.token.lifespan',NULL),('55c52d92-7f2e-40b2-8cef-35e558d2c72b','display.on.consent.screen','false'),('55c52d92-7f2e-40b2-8cef-35e558d2c72b','exclude.session.state.from.auth.response','false'),('55c52d92-7f2e-40b2-8cef-35e558d2c72b','post.logout.redirect.uris','+'),('55c52d92-7f2e-40b2-8cef-35e558d2c72b','saml_force_name_id_format','false'),('55c52d92-7f2e-40b2-8cef-35e558d2c72b','saml.assertion.signature','false'),('55c52d92-7f2e-40b2-8cef-35e558d2c72b','saml.authnstatement','false'),('55c52d92-7f2e-40b2-8cef-35e558d2c72b','saml.client.signature','false'),('55c52d92-7f2e-40b2-8cef-35e558d2c72b','saml.encrypt','false'),('55c52d92-7f2e-40b2-8cef-35e558d2c72b','saml.force.post.binding','false'),('55c52d92-7f2e-40b2-8cef-35e558d2c72b','saml.multivalued.roles','false'),('55c52d92-7f2e-40b2-8cef-35e558d2c72b','saml.onetimeuse.condition','false'),('55c52d92-7f2e-40b2-8cef-35e558d2c72b','saml.server.signature','false'),('55c52d92-7f2e-40b2-8cef-35e558d2c72b','saml.server.signature.keyinfo.ext','false'),('55c52d92-7f2e-40b2-8cef-35e558d2c72b','tls.client.certificate.bound.access.tokens','false'),('5ac1fbef-dc0d-437e-bdfb-6d0c0d467dc0','pkce.code.challenge.method','S256'),('5ac1fbef-dc0d-437e-bdfb-6d0c0d467dc0','post.logout.redirect.uris','+'),('620c09d1-5d44-4bda-959f-82ff964b0f98','backchannel.logout.revoke.offline.tokens','false'),('620c09d1-5d44-4bda-959f-82ff964b0f98','backchannel.logout.session.required','true'),('620c09d1-5d44-4bda-959f-82ff964b0f98','display.on.consent.screen','false'),('620c09d1-5d44-4bda-959f-82ff964b0f98','exclude.session.state.from.auth.response','false'),('620c09d1-5d44-4bda-959f-82ff964b0f98','oauth2.device.authorization.grant.enabled','false'),('620c09d1-5d44-4bda-959f-82ff964b0f98','oidc.ciba.grant.enabled','false'),('620c09d1-5d44-4bda-959f-82ff964b0f98','post.logout.redirect.uris','+'),('620c09d1-5d44-4bda-959f-82ff964b0f98','saml_force_name_id_format','false'),('620c09d1-5d44-4bda-959f-82ff964b0f98','saml.assertion.signature','false'),('620c09d1-5d44-4bda-959f-82ff964b0f98','saml.authnstatement','false'),('620c09d1-5d44-4bda-959f-82ff964b0f98','saml.client.signature','false'),('620c09d1-5d44-4bda-959f-82ff964b0f98','saml.encrypt','false'),('620c09d1-5d44-4bda-959f-82ff964b0f98','saml.force.post.binding','false'),('620c09d1-5d44-4bda-959f-82ff964b0f98','saml.multivalued.roles','false'),('620c09d1-5d44-4bda-959f-82ff964b0f98','saml.onetimeuse.condition','false'),('620c09d1-5d44-4bda-959f-82ff964b0f98','saml.server.signature','false'),('620c09d1-5d44-4bda-959f-82ff964b0f98','saml.server.signature.keyinfo.ext','false'),('620c09d1-5d44-4bda-959f-82ff964b0f98','tls.client.certificate.bound.access.tokens','false'),('63f568e6-51bc-4bbe-9fb4-1dcf570d09a4','display.on.consent.screen','false'),('63f568e6-51bc-4bbe-9fb4-1dcf570d09a4','exclude.session.state.from.auth.response','false'),('63f568e6-51bc-4bbe-9fb4-1dcf570d09a4','pkce.code.challenge.method','S256'),('63f568e6-51bc-4bbe-9fb4-1dcf570d09a4','post.logout.redirect.uris','+'),('63f568e6-51bc-4bbe-9fb4-1dcf570d09a4','saml_force_name_id_format','false'),('63f568e6-51bc-4bbe-9fb4-1dcf570d09a4','saml.assertion.signature','false'),('63f568e6-51bc-4bbe-9fb4-1dcf570d09a4','saml.authnstatement','false'),('63f568e6-51bc-4bbe-9fb4-1dcf570d09a4','saml.client.signature','false'),('63f568e6-51bc-4bbe-9fb4-1dcf570d09a4','saml.encrypt','false'),('63f568e6-51bc-4bbe-9fb4-1dcf570d09a4','saml.force.post.binding','false'),('63f568e6-51bc-4bbe-9fb4-1dcf570d09a4','saml.multivalued.roles','false'),('63f568e6-51bc-4bbe-9fb4-1dcf570d09a4','saml.onetimeuse.condition','false'),('63f568e6-51bc-4bbe-9fb4-1dcf570d09a4','saml.server.signature','false'),('63f568e6-51bc-4bbe-9fb4-1dcf570d09a4','saml.server.signature.keyinfo.ext','false'),('63f568e6-51bc-4bbe-9fb4-1dcf570d09a4','tls.client.certificate.bound.access.tokens','false'),('89d22c6b-7a3a-406a-8635-049ea85abb55','display.on.consent.screen','false'),('89d22c6b-7a3a-406a-8635-049ea85abb55','exclude.session.state.from.auth.response','false'),('89d22c6b-7a3a-406a-8635-049ea85abb55','post.logout.redirect.uris','+'),('89d22c6b-7a3a-406a-8635-049ea85abb55','saml_force_name_id_format','false'),('89d22c6b-7a3a-406a-8635-049ea85abb55','saml.assertion.signature','false'),('89d22c6b-7a3a-406a-8635-049ea85abb55','saml.authnstatement','false'),('89d22c6b-7a3a-406a-8635-049ea85abb55','saml.client.signature','false'),('89d22c6b-7a3a-406a-8635-049ea85abb55','saml.encrypt','false'),('89d22c6b-7a3a-406a-8635-049ea85abb55','saml.force.post.binding','false'),('89d22c6b-7a3a-406a-8635-049ea85abb55','saml.multivalued.roles','false'),('89d22c6b-7a3a-406a-8635-049ea85abb55','saml.onetimeuse.condition','false'),('89d22c6b-7a3a-406a-8635-049ea85abb55','saml.server.signature','false'),('89d22c6b-7a3a-406a-8635-049ea85abb55','saml.server.signature.keyinfo.ext','false'),('89d22c6b-7a3a-406a-8635-049ea85abb55','tls.client.certificate.bound.access.tokens','false'),('a3a37b6f-21f9-49da-8561-1b850d20cba5','pkce.code.challenge.method','S256'),('a3a37b6f-21f9-49da-8561-1b850d20cba5','post.logout.redirect.uris','+'),('a70bea3e-e035-439e-a52a-b15206b54b29','post.logout.redirect.uris','+'),('af07419a-9fdd-48f8-bb86-98deababeb5d','display.on.consent.screen','false'),('af07419a-9fdd-48f8-bb86-98deababeb5d','exclude.session.state.from.auth.response','false'),('af07419a-9fdd-48f8-bb86-98deababeb5d','pkce.code.challenge.method','S256'),('af07419a-9fdd-48f8-bb86-98deababeb5d','post.logout.redirect.uris','+'),('af07419a-9fdd-48f8-bb86-98deababeb5d','saml_force_name_id_format','false'),('af07419a-9fdd-48f8-bb86-98deababeb5d','saml.assertion.signature','false'),('af07419a-9fdd-48f8-bb86-98deababeb5d','saml.authnstatement','false'),('af07419a-9fdd-48f8-bb86-98deababeb5d','saml.client.signature','false'),('af07419a-9fdd-48f8-bb86-98deababeb5d','saml.encrypt','false'),('af07419a-9fdd-48f8-bb86-98deababeb5d','saml.force.post.binding','false'),('af07419a-9fdd-48f8-bb86-98deababeb5d','saml.multivalued.roles','false'),('af07419a-9fdd-48f8-bb86-98deababeb5d','saml.onetimeuse.condition','false'),('af07419a-9fdd-48f8-bb86-98deababeb5d','saml.server.signature','false'),('af07419a-9fdd-48f8-bb86-98deababeb5d','saml.server.signature.keyinfo.ext','false'),('af07419a-9fdd-48f8-bb86-98deababeb5d','tls.client.certificate.bound.access.tokens','false'),('cb884845-e614-4c6e-9508-6fd6ae87fd60','pkce.code.challenge.method','S256'),('cb884845-e614-4c6e-9508-6fd6ae87fd60','post.logout.redirect.uris','+'),('d3bacc5c-ac4e-41ab-abb9-3d79878ddcdc','pkce.code.challenge.method','S256'),('d3bacc5c-ac4e-41ab-abb9-3d79878ddcdc','post.logout.redirect.uris','+'),('d84f18c2-b355-4a93-893b-a886e0b8fcf2','pkce.code.challenge.method','S256'),('d84f18c2-b355-4a93-893b-a886e0b8fcf2','post.logout.redirect.uris','+'),('da8a1c0e-1290-4e3d-988f-7ff967de07d8','backchannel.logout.revoke.offline.tokens','false'),('da8a1c0e-1290-4e3d-988f-7ff967de07d8','backchannel.logout.session.required','true'),('da8a1c0e-1290-4e3d-988f-7ff967de07d8','client.secret.creation.time','1743666256'),('da8a1c0e-1290-4e3d-988f-7ff967de07d8','display.on.consent.screen','false'),('da8a1c0e-1290-4e3d-988f-7ff967de07d8','exclude.session.state.from.auth.response','false'),('da8a1c0e-1290-4e3d-988f-7ff967de07d8','oauth2.device.authorization.grant.enabled','false'),('da8a1c0e-1290-4e3d-988f-7ff967de07d8','oidc.ciba.grant.enabled','false'),('da8a1c0e-1290-4e3d-988f-7ff967de07d8','post.logout.redirect.uris','+'),('da8a1c0e-1290-4e3d-988f-7ff967de07d8','saml_force_name_id_format','false'),('da8a1c0e-1290-4e3d-988f-7ff967de07d8','saml.assertion.signature','false'),('da8a1c0e-1290-4e3d-988f-7ff967de07d8','saml.authnstatement','false'),('da8a1c0e-1290-4e3d-988f-7ff967de07d8','saml.client.signature','false'),('da8a1c0e-1290-4e3d-988f-7ff967de07d8','saml.encrypt','false'),('da8a1c0e-1290-4e3d-988f-7ff967de07d8','saml.force.post.binding','false'),('da8a1c0e-1290-4e3d-988f-7ff967de07d8','saml.multivalued.roles','false'),('da8a1c0e-1290-4e3d-988f-7ff967de07d8','saml.onetimeuse.condition','false'),('da8a1c0e-1290-4e3d-988f-7ff967de07d8','saml.server.signature','false'),('da8a1c0e-1290-4e3d-988f-7ff967de07d8','saml.server.signature.keyinfo.ext','false'),('da8a1c0e-1290-4e3d-988f-7ff967de07d8','tls.client.certificate.bound.access.tokens','false'),('dd77b2d7-5ee9-4a5d-a25a-eb152157fb4c','post.logout.redirect.uris','+'),('e233b1cf-3455-4e60-9488-ec12dfa884d2','backchannel.logout.revoke.offline.tokens','false'),('e233b1cf-3455-4e60-9488-ec12dfa884d2','backchannel.logout.session.required','true'),('e233b1cf-3455-4e60-9488-ec12dfa884d2','client.secret.creation.time','1743753902'),('e233b1cf-3455-4e60-9488-ec12dfa884d2','display.on.consent.screen','false'),('e233b1cf-3455-4e60-9488-ec12dfa884d2','exclude.session.state.from.auth.response','false'),('e233b1cf-3455-4e60-9488-ec12dfa884d2','oauth2.device.authorization.grant.enabled','false'),('e233b1cf-3455-4e60-9488-ec12dfa884d2','oidc.ciba.grant.enabled','false'),('e233b1cf-3455-4e60-9488-ec12dfa884d2','post.logout.redirect.uris','+'),('e233b1cf-3455-4e60-9488-ec12dfa884d2','saml_force_name_id_format','false'),('e233b1cf-3455-4e60-9488-ec12dfa884d2','saml.assertion.signature','false'),('e233b1cf-3455-4e60-9488-ec12dfa884d2','saml.authnstatement','false'),('e233b1cf-3455-4e60-9488-ec12dfa884d2','saml.client.signature','false'),('e233b1cf-3455-4e60-9488-ec12dfa884d2','saml.encrypt','false'),('e233b1cf-3455-4e60-9488-ec12dfa884d2','saml.force.post.binding','false'),('e233b1cf-3455-4e60-9488-ec12dfa884d2','saml.multivalued.roles','false'),('e233b1cf-3455-4e60-9488-ec12dfa884d2','saml.onetimeuse.condition','false'),('e233b1cf-3455-4e60-9488-ec12dfa884d2','saml.server.signature','false'),('e233b1cf-3455-4e60-9488-ec12dfa884d2','saml.server.signature.keyinfo.ext','false'),('e233b1cf-3455-4e60-9488-ec12dfa884d2','tls.client.certificate.bound.access.tokens','false');
/*!40000 ALTER TABLE `CLIENT_ATTRIBUTES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENT_AUTH_FLOW_BINDINGS`
--

DROP TABLE IF EXISTS `CLIENT_AUTH_FLOW_BINDINGS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CLIENT_AUTH_FLOW_BINDINGS` (
  `CLIENT_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `FLOW_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `BINDING_NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`CLIENT_ID`,`BINDING_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENT_AUTH_FLOW_BINDINGS`
--

LOCK TABLES `CLIENT_AUTH_FLOW_BINDINGS` WRITE;
/*!40000 ALTER TABLE `CLIENT_AUTH_FLOW_BINDINGS` DISABLE KEYS */;
/*!40000 ALTER TABLE `CLIENT_AUTH_FLOW_BINDINGS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENT_INITIAL_ACCESS`
--

DROP TABLE IF EXISTS `CLIENT_INITIAL_ACCESS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CLIENT_INITIAL_ACCESS` (
  `ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `REALM_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `TIMESTAMP` int DEFAULT NULL,
  `EXPIRATION` int DEFAULT NULL,
  `COUNT` int DEFAULT NULL,
  `REMAINING_COUNT` int DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IDX_CLIENT_INIT_ACC_REALM` (`REALM_ID`),
  CONSTRAINT `FK_CLIENT_INIT_ACC_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENT_INITIAL_ACCESS`
--

LOCK TABLES `CLIENT_INITIAL_ACCESS` WRITE;
/*!40000 ALTER TABLE `CLIENT_INITIAL_ACCESS` DISABLE KEYS */;
/*!40000 ALTER TABLE `CLIENT_INITIAL_ACCESS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENT_NODE_REGISTRATIONS`
--

DROP TABLE IF EXISTS `CLIENT_NODE_REGISTRATIONS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CLIENT_NODE_REGISTRATIONS` (
  `CLIENT_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` int DEFAULT NULL,
  `NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`CLIENT_ID`,`NAME`),
  CONSTRAINT `FK4129723BA992F594` FOREIGN KEY (`CLIENT_ID`) REFERENCES `CLIENT` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENT_NODE_REGISTRATIONS`
--

LOCK TABLES `CLIENT_NODE_REGISTRATIONS` WRITE;
/*!40000 ALTER TABLE `CLIENT_NODE_REGISTRATIONS` DISABLE KEYS */;
/*!40000 ALTER TABLE `CLIENT_NODE_REGISTRATIONS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENT_SCOPE`
--

DROP TABLE IF EXISTS `CLIENT_SCOPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CLIENT_SCOPE` (
  `ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REALM_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DESCRIPTION` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `PROTOCOL` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_CLI_SCOPE` (`REALM_ID`,`NAME`),
  KEY `IDX_REALM_CLSCOPE` (`REALM_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENT_SCOPE`
--

LOCK TABLES `CLIENT_SCOPE` WRITE;
/*!40000 ALTER TABLE `CLIENT_SCOPE` DISABLE KEYS */;
INSERT INTO `CLIENT_SCOPE` VALUES ('01bd005a-2d2b-4826-9f76-953fcaf6d1bd','acr','hi','OpenID Connect scope for add acr (authentication context class reference) to the token','openid-connect'),('04f47a6c-8d2b-415f-be78-80d855e614a8','address','hi','OpenID Connect built-in scope: address','openid-connect'),('0d783cca-c3a4-4d95-ab32-82551105367e','roles','hi-therapist','OpenID Connect scope for add user roles to the access token','openid-connect'),('0ea1d4c1-d78e-433a-9a43-d31c1c298deb','email','master','OpenID Connect built-in scope: email','openid-connect'),('176332ca-d883-4329-a9d4-68884a7c275e','web-origins','hi','OpenID Connect scope for add allowed web origins to the access token','openid-connect'),('20d24c08-4287-49c0-9e96-23b74cb9dde4','basic','hi','OpenID Connect scope for add all basic claims to the token','openid-connect'),('275e4568-19f1-4016-8db4-c60a6daa0ab4','profile','master','OpenID Connect built-in scope: profile','openid-connect'),('2a8bc487-583c-43dc-8d29-1ad0950d438b','profile','hi-library','OpenID Connect built-in scope: profile','openid-connect'),('32a3853a-b88f-4676-a8ff-36e7f9b1ec44','acr','hi-therapist','OpenID Connect scope for add acr (authentication context class reference) to the token','openid-connect'),('356d3968-262b-4bee-8d44-0d93e880b01a','web-origins','hi-library','OpenID Connect scope for add allowed web origins to the access token','openid-connect'),('3617b695-9239-4d20-9271-32aa00a4825a','profile','hi','OpenID Connect built-in scope: profile','openid-connect'),('4072c001-f7e7-4fa4-9f9f-0f099a308dfe','phone','hi-library','OpenID Connect built-in scope: phone','openid-connect'),('414975ff-f904-4ab5-b84c-ce90b092c83a','address','master','OpenID Connect built-in scope: address','openid-connect'),('41cca0ba-533b-45a7-99c1-8b4ecf149f06','roles','hi-library','OpenID Connect scope for add user roles to the access token','openid-connect'),('433a8036-5c4d-4675-a59e-2ac046db7713','web-origins','hi-therapist','OpenID Connect scope for add allowed web origins to the access token','openid-connect'),('46172ddf-6ae6-4156-8d29-27e64cc13377','acr','hi-library','OpenID Connect scope for add acr (authentication context class reference) to the token','openid-connect'),('467375c3-0f8a-490f-b105-0bb44c15a518','address','hi-therapist','OpenID Connect built-in scope: address','openid-connect'),('4d7db1a2-1bb6-4104-801b-ea18bd31d25e','address','hi-library','OpenID Connect built-in scope: address','openid-connect'),('5331ff23-6ff5-4b10-9ac9-0c413fe89907','phone','master','OpenID Connect built-in scope: phone','openid-connect'),('5753f684-aa1d-4cc0-88aa-98a2f0cab3af','email','hi','OpenID Connect built-in scope: email','openid-connect'),('63210a8a-0008-4908-a26e-c374667cf2ea','profile','hi-therapist','OpenID Connect built-in scope: profile','openid-connect'),('6c42b94b-4d9d-47e4-b334-74526eba766b','acr','master','OpenID Connect scope for add acr (authentication context class reference) to the token','openid-connect'),('6ec5000c-e317-4360-8f97-2f3545494994','basic','hi-library','OpenID Connect scope for add all basic claims to the token','openid-connect'),('76bd20ff-2540-4fb2-b91f-f1b9ec78c9d0','role_list','hi','SAML role list','saml'),('77249e04-e2d2-4031-9667-8786a866947c','email','hi-library','OpenID Connect built-in scope: email','openid-connect'),('7f8eb3f6-36a3-4334-926c-7e7a067a96ad','offline_access','hi-therapist','OpenID Connect built-in scope: offline_access','openid-connect'),('80525d8c-f22c-4adc-a0de-adf5ebf8a6bb','basic','hi-therapist','OpenID Connect scope for add all basic claims to the token','openid-connect'),('8c3bdc03-95db-4a61-833f-d816bc6d702c','phone','hi-therapist','OpenID Connect built-in scope: phone','openid-connect'),('8cf5052c-143d-4034-a453-71443d4c683c','basic','master','OpenID Connect scope for add all basic claims to the token','openid-connect'),('90332860-b400-4df0-b3a0-5ddee0d59319','phone','hi','OpenID Connect built-in scope: phone','openid-connect'),('91926bc4-0204-43c3-a034-67e94de06f80','roles','hi','OpenID Connect scope for add user roles to the access token','openid-connect'),('9ecc4599-6324-4ab5-a7a2-67e68b1af5f2','web-origins','master','OpenID Connect scope for add allowed web origins to the access token','openid-connect'),('bcb19857-2acf-43ed-9480-b1975fa5f33c','role_list','master','SAML role list','saml'),('c32f9638-55d0-4d5a-a3fb-feb682bc420c','microprofile-jwt','hi-library','Microprofile - JWT built-in scope','openid-connect'),('c860f1d3-2172-40b1-9ce2-84911e6a17a9','role_list','hi-library','SAML role list','saml'),('db8690d5-98eb-4b33-8165-cb295c69b3d2','microprofile-jwt','master','Microprofile - JWT built-in scope','openid-connect'),('e22978cc-f9ed-428f-90c6-383ee84fb000','offline_access','master','OpenID Connect built-in scope: offline_access','openid-connect'),('e7c2df73-1988-4b3e-b971-24cd27bb2a0f','offline_access','hi','OpenID Connect built-in scope: offline_access','openid-connect'),('ee7ace46-13d6-42c2-9718-1c0cbd9418a8','microprofile-jwt','hi','Microprofile - JWT built-in scope','openid-connect'),('f070e008-1bf3-4354-9566-af729276ee3e','email','hi-therapist','OpenID Connect built-in scope: email','openid-connect'),('f72905ec-d315-4c68-89dd-14d42907cf3e','roles','master','OpenID Connect scope for add user roles to the access token','openid-connect'),('f8b8a1e5-c804-4695-b5b1-35c66ddbabee','microprofile-jwt','hi-therapist','Microprofile - JWT built-in scope','openid-connect'),('fb50c6e7-5a41-49e1-a6d1-933d23ad0663','offline_access','hi-library','OpenID Connect built-in scope: offline_access','openid-connect'),('fedf7ec0-e80f-4336-a9b1-17e8bf4c7b71','role_list','hi-therapist','SAML role list','saml');
/*!40000 ALTER TABLE `CLIENT_SCOPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENT_SCOPE_ATTRIBUTES`
--

DROP TABLE IF EXISTS `CLIENT_SCOPE_ATTRIBUTES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CLIENT_SCOPE_ATTRIBUTES` (
  `SCOPE_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`SCOPE_ID`,`NAME`),
  KEY `IDX_CLSCOPE_ATTRS` (`SCOPE_ID`),
  CONSTRAINT `FK_CL_SCOPE_ATTR_SCOPE` FOREIGN KEY (`SCOPE_ID`) REFERENCES `CLIENT_SCOPE` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENT_SCOPE_ATTRIBUTES`
--

LOCK TABLES `CLIENT_SCOPE_ATTRIBUTES` WRITE;
/*!40000 ALTER TABLE `CLIENT_SCOPE_ATTRIBUTES` DISABLE KEYS */;
INSERT INTO `CLIENT_SCOPE_ATTRIBUTES` VALUES ('01bd005a-2d2b-4826-9f76-953fcaf6d1bd','false','display.on.consent.screen'),('01bd005a-2d2b-4826-9f76-953fcaf6d1bd','false','include.in.token.scope'),('04f47a6c-8d2b-415f-be78-80d855e614a8','${addressScopeConsentText}','consent.screen.text'),('04f47a6c-8d2b-415f-be78-80d855e614a8','true','display.on.consent.screen'),('04f47a6c-8d2b-415f-be78-80d855e614a8','true','include.in.token.scope'),('0d783cca-c3a4-4d95-ab32-82551105367e','${rolesScopeConsentText}','consent.screen.text'),('0d783cca-c3a4-4d95-ab32-82551105367e','true','display.on.consent.screen'),('0d783cca-c3a4-4d95-ab32-82551105367e','false','include.in.token.scope'),('0ea1d4c1-d78e-433a-9a43-d31c1c298deb','${emailScopeConsentText}','consent.screen.text'),('0ea1d4c1-d78e-433a-9a43-d31c1c298deb','true','display.on.consent.screen'),('0ea1d4c1-d78e-433a-9a43-d31c1c298deb','true','include.in.token.scope'),('176332ca-d883-4329-a9d4-68884a7c275e','','consent.screen.text'),('176332ca-d883-4329-a9d4-68884a7c275e','false','display.on.consent.screen'),('176332ca-d883-4329-a9d4-68884a7c275e','false','include.in.token.scope'),('20d24c08-4287-49c0-9e96-23b74cb9dde4','false','display.on.consent.screen'),('20d24c08-4287-49c0-9e96-23b74cb9dde4','false','include.in.token.scope'),('275e4568-19f1-4016-8db4-c60a6daa0ab4','${profileScopeConsentText}','consent.screen.text'),('275e4568-19f1-4016-8db4-c60a6daa0ab4','true','display.on.consent.screen'),('275e4568-19f1-4016-8db4-c60a6daa0ab4','true','include.in.token.scope'),('2a8bc487-583c-43dc-8d29-1ad0950d438b','${profileScopeConsentText}','consent.screen.text'),('2a8bc487-583c-43dc-8d29-1ad0950d438b','true','display.on.consent.screen'),('2a8bc487-583c-43dc-8d29-1ad0950d438b','true','include.in.token.scope'),('32a3853a-b88f-4676-a8ff-36e7f9b1ec44','false','display.on.consent.screen'),('32a3853a-b88f-4676-a8ff-36e7f9b1ec44','false','include.in.token.scope'),('356d3968-262b-4bee-8d44-0d93e880b01a','','consent.screen.text'),('356d3968-262b-4bee-8d44-0d93e880b01a','false','display.on.consent.screen'),('356d3968-262b-4bee-8d44-0d93e880b01a','false','include.in.token.scope'),('3617b695-9239-4d20-9271-32aa00a4825a','${profileScopeConsentText}','consent.screen.text'),('3617b695-9239-4d20-9271-32aa00a4825a','true','display.on.consent.screen'),('3617b695-9239-4d20-9271-32aa00a4825a','true','include.in.token.scope'),('4072c001-f7e7-4fa4-9f9f-0f099a308dfe','${phoneScopeConsentText}','consent.screen.text'),('4072c001-f7e7-4fa4-9f9f-0f099a308dfe','true','display.on.consent.screen'),('4072c001-f7e7-4fa4-9f9f-0f099a308dfe','true','include.in.token.scope'),('414975ff-f904-4ab5-b84c-ce90b092c83a','${addressScopeConsentText}','consent.screen.text'),('414975ff-f904-4ab5-b84c-ce90b092c83a','true','display.on.consent.screen'),('414975ff-f904-4ab5-b84c-ce90b092c83a','true','include.in.token.scope'),('41cca0ba-533b-45a7-99c1-8b4ecf149f06','${rolesScopeConsentText}','consent.screen.text'),('41cca0ba-533b-45a7-99c1-8b4ecf149f06','true','display.on.consent.screen'),('41cca0ba-533b-45a7-99c1-8b4ecf149f06','false','include.in.token.scope'),('433a8036-5c4d-4675-a59e-2ac046db7713','','consent.screen.text'),('433a8036-5c4d-4675-a59e-2ac046db7713','false','display.on.consent.screen'),('433a8036-5c4d-4675-a59e-2ac046db7713','false','include.in.token.scope'),('46172ddf-6ae6-4156-8d29-27e64cc13377','false','display.on.consent.screen'),('46172ddf-6ae6-4156-8d29-27e64cc13377','false','include.in.token.scope'),('467375c3-0f8a-490f-b105-0bb44c15a518','${addressScopeConsentText}','consent.screen.text'),('467375c3-0f8a-490f-b105-0bb44c15a518','true','display.on.consent.screen'),('467375c3-0f8a-490f-b105-0bb44c15a518','true','include.in.token.scope'),('4d7db1a2-1bb6-4104-801b-ea18bd31d25e','${addressScopeConsentText}','consent.screen.text'),('4d7db1a2-1bb6-4104-801b-ea18bd31d25e','true','display.on.consent.screen'),('4d7db1a2-1bb6-4104-801b-ea18bd31d25e','true','include.in.token.scope'),('5331ff23-6ff5-4b10-9ac9-0c413fe89907','${phoneScopeConsentText}','consent.screen.text'),('5331ff23-6ff5-4b10-9ac9-0c413fe89907','true','display.on.consent.screen'),('5331ff23-6ff5-4b10-9ac9-0c413fe89907','true','include.in.token.scope'),('5753f684-aa1d-4cc0-88aa-98a2f0cab3af','${emailScopeConsentText}','consent.screen.text'),('5753f684-aa1d-4cc0-88aa-98a2f0cab3af','true','display.on.consent.screen'),('5753f684-aa1d-4cc0-88aa-98a2f0cab3af','true','include.in.token.scope'),('63210a8a-0008-4908-a26e-c374667cf2ea','${profileScopeConsentText}','consent.screen.text'),('63210a8a-0008-4908-a26e-c374667cf2ea','true','display.on.consent.screen'),('63210a8a-0008-4908-a26e-c374667cf2ea','true','include.in.token.scope'),('6c42b94b-4d9d-47e4-b334-74526eba766b','false','display.on.consent.screen'),('6c42b94b-4d9d-47e4-b334-74526eba766b','false','include.in.token.scope'),('6ec5000c-e317-4360-8f97-2f3545494994','false','display.on.consent.screen'),('6ec5000c-e317-4360-8f97-2f3545494994','false','include.in.token.scope'),('76bd20ff-2540-4fb2-b91f-f1b9ec78c9d0','${samlRoleListScopeConsentText}','consent.screen.text'),('76bd20ff-2540-4fb2-b91f-f1b9ec78c9d0','true','display.on.consent.screen'),('77249e04-e2d2-4031-9667-8786a866947c','${emailScopeConsentText}','consent.screen.text'),('77249e04-e2d2-4031-9667-8786a866947c','true','display.on.consent.screen'),('77249e04-e2d2-4031-9667-8786a866947c','true','include.in.token.scope'),('7f8eb3f6-36a3-4334-926c-7e7a067a96ad','${offlineAccessScopeConsentText}','consent.screen.text'),('7f8eb3f6-36a3-4334-926c-7e7a067a96ad','true','display.on.consent.screen'),('80525d8c-f22c-4adc-a0de-adf5ebf8a6bb','false','display.on.consent.screen'),('80525d8c-f22c-4adc-a0de-adf5ebf8a6bb','false','include.in.token.scope'),('8c3bdc03-95db-4a61-833f-d816bc6d702c','${phoneScopeConsentText}','consent.screen.text'),('8c3bdc03-95db-4a61-833f-d816bc6d702c','true','display.on.consent.screen'),('8c3bdc03-95db-4a61-833f-d816bc6d702c','true','include.in.token.scope'),('8cf5052c-143d-4034-a453-71443d4c683c','false','display.on.consent.screen'),('8cf5052c-143d-4034-a453-71443d4c683c','false','include.in.token.scope'),('90332860-b400-4df0-b3a0-5ddee0d59319','${phoneScopeConsentText}','consent.screen.text'),('90332860-b400-4df0-b3a0-5ddee0d59319','true','display.on.consent.screen'),('90332860-b400-4df0-b3a0-5ddee0d59319','true','include.in.token.scope'),('91926bc4-0204-43c3-a034-67e94de06f80','${rolesScopeConsentText}','consent.screen.text'),('91926bc4-0204-43c3-a034-67e94de06f80','true','display.on.consent.screen'),('91926bc4-0204-43c3-a034-67e94de06f80','false','include.in.token.scope'),('9ecc4599-6324-4ab5-a7a2-67e68b1af5f2','','consent.screen.text'),('9ecc4599-6324-4ab5-a7a2-67e68b1af5f2','false','display.on.consent.screen'),('9ecc4599-6324-4ab5-a7a2-67e68b1af5f2','false','include.in.token.scope'),('bcb19857-2acf-43ed-9480-b1975fa5f33c','${samlRoleListScopeConsentText}','consent.screen.text'),('bcb19857-2acf-43ed-9480-b1975fa5f33c','true','display.on.consent.screen'),('c32f9638-55d0-4d5a-a3fb-feb682bc420c','false','display.on.consent.screen'),('c32f9638-55d0-4d5a-a3fb-feb682bc420c','true','include.in.token.scope'),('c860f1d3-2172-40b1-9ce2-84911e6a17a9','${samlRoleListScopeConsentText}','consent.screen.text'),('c860f1d3-2172-40b1-9ce2-84911e6a17a9','true','display.on.consent.screen'),('db8690d5-98eb-4b33-8165-cb295c69b3d2','false','display.on.consent.screen'),('db8690d5-98eb-4b33-8165-cb295c69b3d2','true','include.in.token.scope'),('e22978cc-f9ed-428f-90c6-383ee84fb000','${offlineAccessScopeConsentText}','consent.screen.text'),('e22978cc-f9ed-428f-90c6-383ee84fb000','true','display.on.consent.screen'),('e7c2df73-1988-4b3e-b971-24cd27bb2a0f','${offlineAccessScopeConsentText}','consent.screen.text'),('e7c2df73-1988-4b3e-b971-24cd27bb2a0f','true','display.on.consent.screen'),('ee7ace46-13d6-42c2-9718-1c0cbd9418a8','false','display.on.consent.screen'),('ee7ace46-13d6-42c2-9718-1c0cbd9418a8','true','include.in.token.scope'),('f070e008-1bf3-4354-9566-af729276ee3e','${emailScopeConsentText}','consent.screen.text'),('f070e008-1bf3-4354-9566-af729276ee3e','true','display.on.consent.screen'),('f070e008-1bf3-4354-9566-af729276ee3e','true','include.in.token.scope'),('f72905ec-d315-4c68-89dd-14d42907cf3e','${rolesScopeConsentText}','consent.screen.text'),('f72905ec-d315-4c68-89dd-14d42907cf3e','true','display.on.consent.screen'),('f72905ec-d315-4c68-89dd-14d42907cf3e','false','include.in.token.scope'),('f8b8a1e5-c804-4695-b5b1-35c66ddbabee','false','display.on.consent.screen'),('f8b8a1e5-c804-4695-b5b1-35c66ddbabee','true','include.in.token.scope'),('fb50c6e7-5a41-49e1-a6d1-933d23ad0663','${offlineAccessScopeConsentText}','consent.screen.text'),('fb50c6e7-5a41-49e1-a6d1-933d23ad0663','true','display.on.consent.screen'),('fedf7ec0-e80f-4336-a9b1-17e8bf4c7b71','${samlRoleListScopeConsentText}','consent.screen.text'),('fedf7ec0-e80f-4336-a9b1-17e8bf4c7b71','true','display.on.consent.screen');
/*!40000 ALTER TABLE `CLIENT_SCOPE_ATTRIBUTES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENT_SCOPE_CLIENT`
--

DROP TABLE IF EXISTS `CLIENT_SCOPE_CLIENT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CLIENT_SCOPE_CLIENT` (
  `CLIENT_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `SCOPE_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `DEFAULT_SCOPE` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`CLIENT_ID`,`SCOPE_ID`),
  KEY `IDX_CLSCOPE_CL` (`CLIENT_ID`),
  KEY `IDX_CL_CLSCOPE` (`SCOPE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENT_SCOPE_CLIENT`
--

LOCK TABLES `CLIENT_SCOPE_CLIENT` WRITE;
/*!40000 ALTER TABLE `CLIENT_SCOPE_CLIENT` DISABLE KEYS */;
INSERT INTO `CLIENT_SCOPE_CLIENT` VALUES ('0ae8de67-23f4-49b2-8672-75bb2dedc900','2a8bc487-583c-43dc-8d29-1ad0950d438b',_binary ''),('0ae8de67-23f4-49b2-8672-75bb2dedc900','356d3968-262b-4bee-8d44-0d93e880b01a',_binary ''),('0ae8de67-23f4-49b2-8672-75bb2dedc900','4072c001-f7e7-4fa4-9f9f-0f099a308dfe',_binary '\0'),('0ae8de67-23f4-49b2-8672-75bb2dedc900','41cca0ba-533b-45a7-99c1-8b4ecf149f06',_binary ''),('0ae8de67-23f4-49b2-8672-75bb2dedc900','4d7db1a2-1bb6-4104-801b-ea18bd31d25e',_binary '\0'),('0ae8de67-23f4-49b2-8672-75bb2dedc900','77249e04-e2d2-4031-9667-8786a866947c',_binary ''),('0ae8de67-23f4-49b2-8672-75bb2dedc900','c32f9638-55d0-4d5a-a3fb-feb682bc420c',_binary '\0'),('0ae8de67-23f4-49b2-8672-75bb2dedc900','c860f1d3-2172-40b1-9ce2-84911e6a17a9',_binary ''),('0ae8de67-23f4-49b2-8672-75bb2dedc900','fb50c6e7-5a41-49e1-a6d1-933d23ad0663',_binary '\0'),('1472daaa-5420-4b1f-bfb2-f184f16a8320','0d783cca-c3a4-4d95-ab32-82551105367e',_binary ''),('1472daaa-5420-4b1f-bfb2-f184f16a8320','433a8036-5c4d-4675-a59e-2ac046db7713',_binary ''),('1472daaa-5420-4b1f-bfb2-f184f16a8320','467375c3-0f8a-490f-b105-0bb44c15a518',_binary '\0'),('1472daaa-5420-4b1f-bfb2-f184f16a8320','63210a8a-0008-4908-a26e-c374667cf2ea',_binary ''),('1472daaa-5420-4b1f-bfb2-f184f16a8320','7f8eb3f6-36a3-4334-926c-7e7a067a96ad',_binary '\0'),('1472daaa-5420-4b1f-bfb2-f184f16a8320','80525d8c-f22c-4adc-a0de-adf5ebf8a6bb',_binary ''),('1472daaa-5420-4b1f-bfb2-f184f16a8320','8c3bdc03-95db-4a61-833f-d816bc6d702c',_binary '\0'),('1472daaa-5420-4b1f-bfb2-f184f16a8320','f070e008-1bf3-4354-9566-af729276ee3e',_binary ''),('1472daaa-5420-4b1f-bfb2-f184f16a8320','f8b8a1e5-c804-4695-b5b1-35c66ddbabee',_binary '\0'),('1472daaa-5420-4b1f-bfb2-f184f16a8320','fedf7ec0-e80f-4336-a9b1-17e8bf4c7b71',_binary ''),('188df32b-7999-4ebb-9c06-f0087380f68d','2a8bc487-583c-43dc-8d29-1ad0950d438b',_binary ''),('188df32b-7999-4ebb-9c06-f0087380f68d','356d3968-262b-4bee-8d44-0d93e880b01a',_binary ''),('188df32b-7999-4ebb-9c06-f0087380f68d','4072c001-f7e7-4fa4-9f9f-0f099a308dfe',_binary '\0'),('188df32b-7999-4ebb-9c06-f0087380f68d','41cca0ba-533b-45a7-99c1-8b4ecf149f06',_binary ''),('188df32b-7999-4ebb-9c06-f0087380f68d','4d7db1a2-1bb6-4104-801b-ea18bd31d25e',_binary '\0'),('188df32b-7999-4ebb-9c06-f0087380f68d','6ec5000c-e317-4360-8f97-2f3545494994',_binary ''),('188df32b-7999-4ebb-9c06-f0087380f68d','77249e04-e2d2-4031-9667-8786a866947c',_binary ''),('188df32b-7999-4ebb-9c06-f0087380f68d','c32f9638-55d0-4d5a-a3fb-feb682bc420c',_binary '\0'),('188df32b-7999-4ebb-9c06-f0087380f68d','c860f1d3-2172-40b1-9ce2-84911e6a17a9',_binary ''),('188df32b-7999-4ebb-9c06-f0087380f68d','fb50c6e7-5a41-49e1-a6d1-933d23ad0663',_binary '\0'),('1d1424ea-24c6-4434-b5e5-8e96e26f3255','2a8bc487-583c-43dc-8d29-1ad0950d438b',_binary ''),('1d1424ea-24c6-4434-b5e5-8e96e26f3255','356d3968-262b-4bee-8d44-0d93e880b01a',_binary ''),('1d1424ea-24c6-4434-b5e5-8e96e26f3255','4072c001-f7e7-4fa4-9f9f-0f099a308dfe',_binary '\0'),('1d1424ea-24c6-4434-b5e5-8e96e26f3255','41cca0ba-533b-45a7-99c1-8b4ecf149f06',_binary ''),('1d1424ea-24c6-4434-b5e5-8e96e26f3255','4d7db1a2-1bb6-4104-801b-ea18bd31d25e',_binary '\0'),('1d1424ea-24c6-4434-b5e5-8e96e26f3255','6ec5000c-e317-4360-8f97-2f3545494994',_binary ''),('1d1424ea-24c6-4434-b5e5-8e96e26f3255','77249e04-e2d2-4031-9667-8786a866947c',_binary ''),('1d1424ea-24c6-4434-b5e5-8e96e26f3255','c32f9638-55d0-4d5a-a3fb-feb682bc420c',_binary '\0'),('1d1424ea-24c6-4434-b5e5-8e96e26f3255','c860f1d3-2172-40b1-9ce2-84911e6a17a9',_binary ''),('1d1424ea-24c6-4434-b5e5-8e96e26f3255','fb50c6e7-5a41-49e1-a6d1-933d23ad0663',_binary '\0'),('2410b91c-be58-4f3c-a4ae-83cd998c8f6c','0ea1d4c1-d78e-433a-9a43-d31c1c298deb',_binary ''),('2410b91c-be58-4f3c-a4ae-83cd998c8f6c','275e4568-19f1-4016-8db4-c60a6daa0ab4',_binary ''),('2410b91c-be58-4f3c-a4ae-83cd998c8f6c','414975ff-f904-4ab5-b84c-ce90b092c83a',_binary '\0'),('2410b91c-be58-4f3c-a4ae-83cd998c8f6c','5331ff23-6ff5-4b10-9ac9-0c413fe89907',_binary '\0'),('2410b91c-be58-4f3c-a4ae-83cd998c8f6c','9ecc4599-6324-4ab5-a7a2-67e68b1af5f2',_binary ''),('2410b91c-be58-4f3c-a4ae-83cd998c8f6c','bcb19857-2acf-43ed-9480-b1975fa5f33c',_binary ''),('2410b91c-be58-4f3c-a4ae-83cd998c8f6c','db8690d5-98eb-4b33-8165-cb295c69b3d2',_binary '\0'),('2410b91c-be58-4f3c-a4ae-83cd998c8f6c','e22978cc-f9ed-428f-90c6-383ee84fb000',_binary '\0'),('2410b91c-be58-4f3c-a4ae-83cd998c8f6c','f72905ec-d315-4c68-89dd-14d42907cf3e',_binary ''),('30febc11-32fa-4349-a4db-a46a33775ab2','0d783cca-c3a4-4d95-ab32-82551105367e',_binary ''),('30febc11-32fa-4349-a4db-a46a33775ab2','433a8036-5c4d-4675-a59e-2ac046db7713',_binary ''),('30febc11-32fa-4349-a4db-a46a33775ab2','467375c3-0f8a-490f-b105-0bb44c15a518',_binary '\0'),('30febc11-32fa-4349-a4db-a46a33775ab2','63210a8a-0008-4908-a26e-c374667cf2ea',_binary ''),('30febc11-32fa-4349-a4db-a46a33775ab2','7f8eb3f6-36a3-4334-926c-7e7a067a96ad',_binary '\0'),('30febc11-32fa-4349-a4db-a46a33775ab2','80525d8c-f22c-4adc-a0de-adf5ebf8a6bb',_binary ''),('30febc11-32fa-4349-a4db-a46a33775ab2','8c3bdc03-95db-4a61-833f-d816bc6d702c',_binary '\0'),('30febc11-32fa-4349-a4db-a46a33775ab2','f070e008-1bf3-4354-9566-af729276ee3e',_binary ''),('30febc11-32fa-4349-a4db-a46a33775ab2','f8b8a1e5-c804-4695-b5b1-35c66ddbabee',_binary '\0'),('30febc11-32fa-4349-a4db-a46a33775ab2','fedf7ec0-e80f-4336-a9b1-17e8bf4c7b71',_binary ''),('3d7c0f55-4d00-4eb7-92fc-2ac879eba8fe','04f47a6c-8d2b-415f-be78-80d855e614a8',_binary '\0'),('3d7c0f55-4d00-4eb7-92fc-2ac879eba8fe','176332ca-d883-4329-a9d4-68884a7c275e',_binary ''),('3d7c0f55-4d00-4eb7-92fc-2ac879eba8fe','20d24c08-4287-49c0-9e96-23b74cb9dde4',_binary ''),('3d7c0f55-4d00-4eb7-92fc-2ac879eba8fe','3617b695-9239-4d20-9271-32aa00a4825a',_binary ''),('3d7c0f55-4d00-4eb7-92fc-2ac879eba8fe','5753f684-aa1d-4cc0-88aa-98a2f0cab3af',_binary ''),('3d7c0f55-4d00-4eb7-92fc-2ac879eba8fe','76bd20ff-2540-4fb2-b91f-f1b9ec78c9d0',_binary ''),('3d7c0f55-4d00-4eb7-92fc-2ac879eba8fe','90332860-b400-4df0-b3a0-5ddee0d59319',_binary '\0'),('3d7c0f55-4d00-4eb7-92fc-2ac879eba8fe','91926bc4-0204-43c3-a034-67e94de06f80',_binary ''),('3d7c0f55-4d00-4eb7-92fc-2ac879eba8fe','e7c2df73-1988-4b3e-b971-24cd27bb2a0f',_binary '\0'),('3d7c0f55-4d00-4eb7-92fc-2ac879eba8fe','ee7ace46-13d6-42c2-9718-1c0cbd9418a8',_binary '\0'),('434a5435-9f56-4ed6-9649-1946ac15cbfc','0ea1d4c1-d78e-433a-9a43-d31c1c298deb',_binary ''),('434a5435-9f56-4ed6-9649-1946ac15cbfc','275e4568-19f1-4016-8db4-c60a6daa0ab4',_binary ''),('434a5435-9f56-4ed6-9649-1946ac15cbfc','414975ff-f904-4ab5-b84c-ce90b092c83a',_binary '\0'),('434a5435-9f56-4ed6-9649-1946ac15cbfc','5331ff23-6ff5-4b10-9ac9-0c413fe89907',_binary '\0'),('434a5435-9f56-4ed6-9649-1946ac15cbfc','8cf5052c-143d-4034-a453-71443d4c683c',_binary ''),('434a5435-9f56-4ed6-9649-1946ac15cbfc','9ecc4599-6324-4ab5-a7a2-67e68b1af5f2',_binary ''),('434a5435-9f56-4ed6-9649-1946ac15cbfc','bcb19857-2acf-43ed-9480-b1975fa5f33c',_binary ''),('434a5435-9f56-4ed6-9649-1946ac15cbfc','db8690d5-98eb-4b33-8165-cb295c69b3d2',_binary '\0'),('434a5435-9f56-4ed6-9649-1946ac15cbfc','e22978cc-f9ed-428f-90c6-383ee84fb000',_binary '\0'),('434a5435-9f56-4ed6-9649-1946ac15cbfc','f72905ec-d315-4c68-89dd-14d42907cf3e',_binary ''),('558bc5ae-068f-4e0b-b70a-170b730aa137','04f47a6c-8d2b-415f-be78-80d855e614a8',_binary '\0'),('558bc5ae-068f-4e0b-b70a-170b730aa137','176332ca-d883-4329-a9d4-68884a7c275e',_binary ''),('558bc5ae-068f-4e0b-b70a-170b730aa137','20d24c08-4287-49c0-9e96-23b74cb9dde4',_binary ''),('558bc5ae-068f-4e0b-b70a-170b730aa137','3617b695-9239-4d20-9271-32aa00a4825a',_binary ''),('558bc5ae-068f-4e0b-b70a-170b730aa137','5753f684-aa1d-4cc0-88aa-98a2f0cab3af',_binary ''),('558bc5ae-068f-4e0b-b70a-170b730aa137','76bd20ff-2540-4fb2-b91f-f1b9ec78c9d0',_binary ''),('558bc5ae-068f-4e0b-b70a-170b730aa137','90332860-b400-4df0-b3a0-5ddee0d59319',_binary '\0'),('558bc5ae-068f-4e0b-b70a-170b730aa137','91926bc4-0204-43c3-a034-67e94de06f80',_binary ''),('558bc5ae-068f-4e0b-b70a-170b730aa137','e7c2df73-1988-4b3e-b971-24cd27bb2a0f',_binary '\0'),('558bc5ae-068f-4e0b-b70a-170b730aa137','ee7ace46-13d6-42c2-9718-1c0cbd9418a8',_binary '\0'),('55c52d92-7f2e-40b2-8cef-35e558d2c72b','04f47a6c-8d2b-415f-be78-80d855e614a8',_binary '\0'),('55c52d92-7f2e-40b2-8cef-35e558d2c72b','176332ca-d883-4329-a9d4-68884a7c275e',_binary ''),('55c52d92-7f2e-40b2-8cef-35e558d2c72b','20d24c08-4287-49c0-9e96-23b74cb9dde4',_binary ''),('55c52d92-7f2e-40b2-8cef-35e558d2c72b','3617b695-9239-4d20-9271-32aa00a4825a',_binary ''),('55c52d92-7f2e-40b2-8cef-35e558d2c72b','5753f684-aa1d-4cc0-88aa-98a2f0cab3af',_binary ''),('55c52d92-7f2e-40b2-8cef-35e558d2c72b','76bd20ff-2540-4fb2-b91f-f1b9ec78c9d0',_binary ''),('55c52d92-7f2e-40b2-8cef-35e558d2c72b','90332860-b400-4df0-b3a0-5ddee0d59319',_binary '\0'),('55c52d92-7f2e-40b2-8cef-35e558d2c72b','91926bc4-0204-43c3-a034-67e94de06f80',_binary ''),('55c52d92-7f2e-40b2-8cef-35e558d2c72b','e7c2df73-1988-4b3e-b971-24cd27bb2a0f',_binary '\0'),('55c52d92-7f2e-40b2-8cef-35e558d2c72b','ee7ace46-13d6-42c2-9718-1c0cbd9418a8',_binary '\0'),('59b01532-686c-41a7-a818-8cd64adb99f5','0ea1d4c1-d78e-433a-9a43-d31c1c298deb',_binary ''),('59b01532-686c-41a7-a818-8cd64adb99f5','275e4568-19f1-4016-8db4-c60a6daa0ab4',_binary ''),('59b01532-686c-41a7-a818-8cd64adb99f5','414975ff-f904-4ab5-b84c-ce90b092c83a',_binary '\0'),('59b01532-686c-41a7-a818-8cd64adb99f5','5331ff23-6ff5-4b10-9ac9-0c413fe89907',_binary '\0'),('59b01532-686c-41a7-a818-8cd64adb99f5','9ecc4599-6324-4ab5-a7a2-67e68b1af5f2',_binary ''),('59b01532-686c-41a7-a818-8cd64adb99f5','bcb19857-2acf-43ed-9480-b1975fa5f33c',_binary ''),('59b01532-686c-41a7-a818-8cd64adb99f5','db8690d5-98eb-4b33-8165-cb295c69b3d2',_binary '\0'),('59b01532-686c-41a7-a818-8cd64adb99f5','e22978cc-f9ed-428f-90c6-383ee84fb000',_binary '\0'),('59b01532-686c-41a7-a818-8cd64adb99f5','f72905ec-d315-4c68-89dd-14d42907cf3e',_binary ''),('5ac1fbef-dc0d-437e-bdfb-6d0c0d467dc0','2a8bc487-583c-43dc-8d29-1ad0950d438b',_binary ''),('5ac1fbef-dc0d-437e-bdfb-6d0c0d467dc0','356d3968-262b-4bee-8d44-0d93e880b01a',_binary ''),('5ac1fbef-dc0d-437e-bdfb-6d0c0d467dc0','4072c001-f7e7-4fa4-9f9f-0f099a308dfe',_binary '\0'),('5ac1fbef-dc0d-437e-bdfb-6d0c0d467dc0','41cca0ba-533b-45a7-99c1-8b4ecf149f06',_binary ''),('5ac1fbef-dc0d-437e-bdfb-6d0c0d467dc0','4d7db1a2-1bb6-4104-801b-ea18bd31d25e',_binary '\0'),('5ac1fbef-dc0d-437e-bdfb-6d0c0d467dc0','6ec5000c-e317-4360-8f97-2f3545494994',_binary ''),('5ac1fbef-dc0d-437e-bdfb-6d0c0d467dc0','77249e04-e2d2-4031-9667-8786a866947c',_binary ''),('5ac1fbef-dc0d-437e-bdfb-6d0c0d467dc0','c32f9638-55d0-4d5a-a3fb-feb682bc420c',_binary '\0'),('5ac1fbef-dc0d-437e-bdfb-6d0c0d467dc0','c860f1d3-2172-40b1-9ce2-84911e6a17a9',_binary ''),('5ac1fbef-dc0d-437e-bdfb-6d0c0d467dc0','fb50c6e7-5a41-49e1-a6d1-933d23ad0663',_binary '\0'),('5cef529c-ec43-419f-a198-7ce0e7ba6eb3','0d783cca-c3a4-4d95-ab32-82551105367e',_binary ''),('5cef529c-ec43-419f-a198-7ce0e7ba6eb3','433a8036-5c4d-4675-a59e-2ac046db7713',_binary ''),('5cef529c-ec43-419f-a198-7ce0e7ba6eb3','467375c3-0f8a-490f-b105-0bb44c15a518',_binary '\0'),('5cef529c-ec43-419f-a198-7ce0e7ba6eb3','63210a8a-0008-4908-a26e-c374667cf2ea',_binary ''),('5cef529c-ec43-419f-a198-7ce0e7ba6eb3','7f8eb3f6-36a3-4334-926c-7e7a067a96ad',_binary '\0'),('5cef529c-ec43-419f-a198-7ce0e7ba6eb3','80525d8c-f22c-4adc-a0de-adf5ebf8a6bb',_binary ''),('5cef529c-ec43-419f-a198-7ce0e7ba6eb3','8c3bdc03-95db-4a61-833f-d816bc6d702c',_binary '\0'),('5cef529c-ec43-419f-a198-7ce0e7ba6eb3','f070e008-1bf3-4354-9566-af729276ee3e',_binary ''),('5cef529c-ec43-419f-a198-7ce0e7ba6eb3','f8b8a1e5-c804-4695-b5b1-35c66ddbabee',_binary '\0'),('5cef529c-ec43-419f-a198-7ce0e7ba6eb3','fedf7ec0-e80f-4336-a9b1-17e8bf4c7b71',_binary ''),('620c09d1-5d44-4bda-959f-82ff964b0f98','2a8bc487-583c-43dc-8d29-1ad0950d438b',_binary ''),('620c09d1-5d44-4bda-959f-82ff964b0f98','356d3968-262b-4bee-8d44-0d93e880b01a',_binary ''),('620c09d1-5d44-4bda-959f-82ff964b0f98','4072c001-f7e7-4fa4-9f9f-0f099a308dfe',_binary '\0'),('620c09d1-5d44-4bda-959f-82ff964b0f98','41cca0ba-533b-45a7-99c1-8b4ecf149f06',_binary ''),('620c09d1-5d44-4bda-959f-82ff964b0f98','4d7db1a2-1bb6-4104-801b-ea18bd31d25e',_binary '\0'),('620c09d1-5d44-4bda-959f-82ff964b0f98','6ec5000c-e317-4360-8f97-2f3545494994',_binary ''),('620c09d1-5d44-4bda-959f-82ff964b0f98','77249e04-e2d2-4031-9667-8786a866947c',_binary ''),('620c09d1-5d44-4bda-959f-82ff964b0f98','c32f9638-55d0-4d5a-a3fb-feb682bc420c',_binary '\0'),('620c09d1-5d44-4bda-959f-82ff964b0f98','c860f1d3-2172-40b1-9ce2-84911e6a17a9',_binary ''),('620c09d1-5d44-4bda-959f-82ff964b0f98','fb50c6e7-5a41-49e1-a6d1-933d23ad0663',_binary '\0'),('63f568e6-51bc-4bbe-9fb4-1dcf570d09a4','0d783cca-c3a4-4d95-ab32-82551105367e',_binary ''),('63f568e6-51bc-4bbe-9fb4-1dcf570d09a4','433a8036-5c4d-4675-a59e-2ac046db7713',_binary ''),('63f568e6-51bc-4bbe-9fb4-1dcf570d09a4','467375c3-0f8a-490f-b105-0bb44c15a518',_binary '\0'),('63f568e6-51bc-4bbe-9fb4-1dcf570d09a4','63210a8a-0008-4908-a26e-c374667cf2ea',_binary ''),('63f568e6-51bc-4bbe-9fb4-1dcf570d09a4','7f8eb3f6-36a3-4334-926c-7e7a067a96ad',_binary '\0'),('63f568e6-51bc-4bbe-9fb4-1dcf570d09a4','80525d8c-f22c-4adc-a0de-adf5ebf8a6bb',_binary ''),('63f568e6-51bc-4bbe-9fb4-1dcf570d09a4','8c3bdc03-95db-4a61-833f-d816bc6d702c',_binary '\0'),('63f568e6-51bc-4bbe-9fb4-1dcf570d09a4','f070e008-1bf3-4354-9566-af729276ee3e',_binary ''),('63f568e6-51bc-4bbe-9fb4-1dcf570d09a4','f8b8a1e5-c804-4695-b5b1-35c66ddbabee',_binary '\0'),('63f568e6-51bc-4bbe-9fb4-1dcf570d09a4','fedf7ec0-e80f-4336-a9b1-17e8bf4c7b71',_binary ''),('78044321-1410-42bf-9489-f89303e77e5a','0d783cca-c3a4-4d95-ab32-82551105367e',_binary ''),('78044321-1410-42bf-9489-f89303e77e5a','433a8036-5c4d-4675-a59e-2ac046db7713',_binary ''),('78044321-1410-42bf-9489-f89303e77e5a','467375c3-0f8a-490f-b105-0bb44c15a518',_binary '\0'),('78044321-1410-42bf-9489-f89303e77e5a','63210a8a-0008-4908-a26e-c374667cf2ea',_binary ''),('78044321-1410-42bf-9489-f89303e77e5a','7f8eb3f6-36a3-4334-926c-7e7a067a96ad',_binary '\0'),('78044321-1410-42bf-9489-f89303e77e5a','80525d8c-f22c-4adc-a0de-adf5ebf8a6bb',_binary ''),('78044321-1410-42bf-9489-f89303e77e5a','8c3bdc03-95db-4a61-833f-d816bc6d702c',_binary '\0'),('78044321-1410-42bf-9489-f89303e77e5a','f070e008-1bf3-4354-9566-af729276ee3e',_binary ''),('78044321-1410-42bf-9489-f89303e77e5a','f8b8a1e5-c804-4695-b5b1-35c66ddbabee',_binary '\0'),('78044321-1410-42bf-9489-f89303e77e5a','fedf7ec0-e80f-4336-a9b1-17e8bf4c7b71',_binary ''),('89d22c6b-7a3a-406a-8635-049ea85abb55','0d783cca-c3a4-4d95-ab32-82551105367e',_binary ''),('89d22c6b-7a3a-406a-8635-049ea85abb55','433a8036-5c4d-4675-a59e-2ac046db7713',_binary ''),('89d22c6b-7a3a-406a-8635-049ea85abb55','467375c3-0f8a-490f-b105-0bb44c15a518',_binary '\0'),('89d22c6b-7a3a-406a-8635-049ea85abb55','63210a8a-0008-4908-a26e-c374667cf2ea',_binary ''),('89d22c6b-7a3a-406a-8635-049ea85abb55','7f8eb3f6-36a3-4334-926c-7e7a067a96ad',_binary '\0'),('89d22c6b-7a3a-406a-8635-049ea85abb55','80525d8c-f22c-4adc-a0de-adf5ebf8a6bb',_binary ''),('89d22c6b-7a3a-406a-8635-049ea85abb55','8c3bdc03-95db-4a61-833f-d816bc6d702c',_binary '\0'),('89d22c6b-7a3a-406a-8635-049ea85abb55','f070e008-1bf3-4354-9566-af729276ee3e',_binary ''),('89d22c6b-7a3a-406a-8635-049ea85abb55','f8b8a1e5-c804-4695-b5b1-35c66ddbabee',_binary '\0'),('89d22c6b-7a3a-406a-8635-049ea85abb55','fedf7ec0-e80f-4336-a9b1-17e8bf4c7b71',_binary ''),('a3a37b6f-21f9-49da-8561-1b850d20cba5','0ea1d4c1-d78e-433a-9a43-d31c1c298deb',_binary ''),('a3a37b6f-21f9-49da-8561-1b850d20cba5','275e4568-19f1-4016-8db4-c60a6daa0ab4',_binary ''),('a3a37b6f-21f9-49da-8561-1b850d20cba5','414975ff-f904-4ab5-b84c-ce90b092c83a',_binary '\0'),('a3a37b6f-21f9-49da-8561-1b850d20cba5','5331ff23-6ff5-4b10-9ac9-0c413fe89907',_binary '\0'),('a3a37b6f-21f9-49da-8561-1b850d20cba5','8cf5052c-143d-4034-a453-71443d4c683c',_binary ''),('a3a37b6f-21f9-49da-8561-1b850d20cba5','9ecc4599-6324-4ab5-a7a2-67e68b1af5f2',_binary ''),('a3a37b6f-21f9-49da-8561-1b850d20cba5','bcb19857-2acf-43ed-9480-b1975fa5f33c',_binary ''),('a3a37b6f-21f9-49da-8561-1b850d20cba5','db8690d5-98eb-4b33-8165-cb295c69b3d2',_binary '\0'),('a3a37b6f-21f9-49da-8561-1b850d20cba5','e22978cc-f9ed-428f-90c6-383ee84fb000',_binary '\0'),('a3a37b6f-21f9-49da-8561-1b850d20cba5','f72905ec-d315-4c68-89dd-14d42907cf3e',_binary ''),('a70bea3e-e035-439e-a52a-b15206b54b29','0ea1d4c1-d78e-433a-9a43-d31c1c298deb',_binary ''),('a70bea3e-e035-439e-a52a-b15206b54b29','275e4568-19f1-4016-8db4-c60a6daa0ab4',_binary ''),('a70bea3e-e035-439e-a52a-b15206b54b29','414975ff-f904-4ab5-b84c-ce90b092c83a',_binary '\0'),('a70bea3e-e035-439e-a52a-b15206b54b29','5331ff23-6ff5-4b10-9ac9-0c413fe89907',_binary '\0'),('a70bea3e-e035-439e-a52a-b15206b54b29','8cf5052c-143d-4034-a453-71443d4c683c',_binary ''),('a70bea3e-e035-439e-a52a-b15206b54b29','9ecc4599-6324-4ab5-a7a2-67e68b1af5f2',_binary ''),('a70bea3e-e035-439e-a52a-b15206b54b29','bcb19857-2acf-43ed-9480-b1975fa5f33c',_binary ''),('a70bea3e-e035-439e-a52a-b15206b54b29','db8690d5-98eb-4b33-8165-cb295c69b3d2',_binary '\0'),('a70bea3e-e035-439e-a52a-b15206b54b29','e22978cc-f9ed-428f-90c6-383ee84fb000',_binary '\0'),('a70bea3e-e035-439e-a52a-b15206b54b29','f72905ec-d315-4c68-89dd-14d42907cf3e',_binary ''),('a970fd62-9f34-451b-9ea3-38ca7fdc3260','0ea1d4c1-d78e-433a-9a43-d31c1c298deb',_binary ''),('a970fd62-9f34-451b-9ea3-38ca7fdc3260','275e4568-19f1-4016-8db4-c60a6daa0ab4',_binary ''),('a970fd62-9f34-451b-9ea3-38ca7fdc3260','414975ff-f904-4ab5-b84c-ce90b092c83a',_binary '\0'),('a970fd62-9f34-451b-9ea3-38ca7fdc3260','5331ff23-6ff5-4b10-9ac9-0c413fe89907',_binary '\0'),('a970fd62-9f34-451b-9ea3-38ca7fdc3260','8cf5052c-143d-4034-a453-71443d4c683c',_binary ''),('a970fd62-9f34-451b-9ea3-38ca7fdc3260','9ecc4599-6324-4ab5-a7a2-67e68b1af5f2',_binary ''),('a970fd62-9f34-451b-9ea3-38ca7fdc3260','bcb19857-2acf-43ed-9480-b1975fa5f33c',_binary ''),('a970fd62-9f34-451b-9ea3-38ca7fdc3260','db8690d5-98eb-4b33-8165-cb295c69b3d2',_binary '\0'),('a970fd62-9f34-451b-9ea3-38ca7fdc3260','e22978cc-f9ed-428f-90c6-383ee84fb000',_binary '\0'),('a970fd62-9f34-451b-9ea3-38ca7fdc3260','f72905ec-d315-4c68-89dd-14d42907cf3e',_binary ''),('ac8a7f4f-fefc-4a43-bc0f-b42078184dc5','04f47a6c-8d2b-415f-be78-80d855e614a8',_binary '\0'),('ac8a7f4f-fefc-4a43-bc0f-b42078184dc5','176332ca-d883-4329-a9d4-68884a7c275e',_binary ''),('ac8a7f4f-fefc-4a43-bc0f-b42078184dc5','20d24c08-4287-49c0-9e96-23b74cb9dde4',_binary ''),('ac8a7f4f-fefc-4a43-bc0f-b42078184dc5','3617b695-9239-4d20-9271-32aa00a4825a',_binary ''),('ac8a7f4f-fefc-4a43-bc0f-b42078184dc5','5753f684-aa1d-4cc0-88aa-98a2f0cab3af',_binary ''),('ac8a7f4f-fefc-4a43-bc0f-b42078184dc5','76bd20ff-2540-4fb2-b91f-f1b9ec78c9d0',_binary ''),('ac8a7f4f-fefc-4a43-bc0f-b42078184dc5','90332860-b400-4df0-b3a0-5ddee0d59319',_binary '\0'),('ac8a7f4f-fefc-4a43-bc0f-b42078184dc5','91926bc4-0204-43c3-a034-67e94de06f80',_binary ''),('ac8a7f4f-fefc-4a43-bc0f-b42078184dc5','e7c2df73-1988-4b3e-b971-24cd27bb2a0f',_binary '\0'),('ac8a7f4f-fefc-4a43-bc0f-b42078184dc5','ee7ace46-13d6-42c2-9718-1c0cbd9418a8',_binary '\0'),('af07419a-9fdd-48f8-bb86-98deababeb5d','04f47a6c-8d2b-415f-be78-80d855e614a8',_binary '\0'),('af07419a-9fdd-48f8-bb86-98deababeb5d','176332ca-d883-4329-a9d4-68884a7c275e',_binary ''),('af07419a-9fdd-48f8-bb86-98deababeb5d','20d24c08-4287-49c0-9e96-23b74cb9dde4',_binary ''),('af07419a-9fdd-48f8-bb86-98deababeb5d','3617b695-9239-4d20-9271-32aa00a4825a',_binary ''),('af07419a-9fdd-48f8-bb86-98deababeb5d','5753f684-aa1d-4cc0-88aa-98a2f0cab3af',_binary ''),('af07419a-9fdd-48f8-bb86-98deababeb5d','76bd20ff-2540-4fb2-b91f-f1b9ec78c9d0',_binary ''),('af07419a-9fdd-48f8-bb86-98deababeb5d','90332860-b400-4df0-b3a0-5ddee0d59319',_binary '\0'),('af07419a-9fdd-48f8-bb86-98deababeb5d','91926bc4-0204-43c3-a034-67e94de06f80',_binary ''),('af07419a-9fdd-48f8-bb86-98deababeb5d','e7c2df73-1988-4b3e-b971-24cd27bb2a0f',_binary '\0'),('af07419a-9fdd-48f8-bb86-98deababeb5d','ee7ace46-13d6-42c2-9718-1c0cbd9418a8',_binary '\0'),('b3fea689-45c7-4c2b-96ef-b389a0355159','2a8bc487-583c-43dc-8d29-1ad0950d438b',_binary ''),('b3fea689-45c7-4c2b-96ef-b389a0355159','356d3968-262b-4bee-8d44-0d93e880b01a',_binary ''),('b3fea689-45c7-4c2b-96ef-b389a0355159','4072c001-f7e7-4fa4-9f9f-0f099a308dfe',_binary '\0'),('b3fea689-45c7-4c2b-96ef-b389a0355159','41cca0ba-533b-45a7-99c1-8b4ecf149f06',_binary ''),('b3fea689-45c7-4c2b-96ef-b389a0355159','4d7db1a2-1bb6-4104-801b-ea18bd31d25e',_binary '\0'),('b3fea689-45c7-4c2b-96ef-b389a0355159','6ec5000c-e317-4360-8f97-2f3545494994',_binary ''),('b3fea689-45c7-4c2b-96ef-b389a0355159','77249e04-e2d2-4031-9667-8786a866947c',_binary ''),('b3fea689-45c7-4c2b-96ef-b389a0355159','c32f9638-55d0-4d5a-a3fb-feb682bc420c',_binary '\0'),('b3fea689-45c7-4c2b-96ef-b389a0355159','c860f1d3-2172-40b1-9ce2-84911e6a17a9',_binary ''),('b3fea689-45c7-4c2b-96ef-b389a0355159','fb50c6e7-5a41-49e1-a6d1-933d23ad0663',_binary '\0'),('cb884845-e614-4c6e-9508-6fd6ae87fd60','0d783cca-c3a4-4d95-ab32-82551105367e',_binary ''),('cb884845-e614-4c6e-9508-6fd6ae87fd60','433a8036-5c4d-4675-a59e-2ac046db7713',_binary ''),('cb884845-e614-4c6e-9508-6fd6ae87fd60','467375c3-0f8a-490f-b105-0bb44c15a518',_binary '\0'),('cb884845-e614-4c6e-9508-6fd6ae87fd60','63210a8a-0008-4908-a26e-c374667cf2ea',_binary ''),('cb884845-e614-4c6e-9508-6fd6ae87fd60','7f8eb3f6-36a3-4334-926c-7e7a067a96ad',_binary '\0'),('cb884845-e614-4c6e-9508-6fd6ae87fd60','80525d8c-f22c-4adc-a0de-adf5ebf8a6bb',_binary ''),('cb884845-e614-4c6e-9508-6fd6ae87fd60','8c3bdc03-95db-4a61-833f-d816bc6d702c',_binary '\0'),('cb884845-e614-4c6e-9508-6fd6ae87fd60','f070e008-1bf3-4354-9566-af729276ee3e',_binary ''),('cb884845-e614-4c6e-9508-6fd6ae87fd60','f8b8a1e5-c804-4695-b5b1-35c66ddbabee',_binary '\0'),('cb884845-e614-4c6e-9508-6fd6ae87fd60','fedf7ec0-e80f-4336-a9b1-17e8bf4c7b71',_binary ''),('cea71342-d5fb-4873-b97d-21ac890e6c72','0ea1d4c1-d78e-433a-9a43-d31c1c298deb',_binary ''),('cea71342-d5fb-4873-b97d-21ac890e6c72','275e4568-19f1-4016-8db4-c60a6daa0ab4',_binary ''),('cea71342-d5fb-4873-b97d-21ac890e6c72','414975ff-f904-4ab5-b84c-ce90b092c83a',_binary '\0'),('cea71342-d5fb-4873-b97d-21ac890e6c72','5331ff23-6ff5-4b10-9ac9-0c413fe89907',_binary '\0'),('cea71342-d5fb-4873-b97d-21ac890e6c72','9ecc4599-6324-4ab5-a7a2-67e68b1af5f2',_binary ''),('cea71342-d5fb-4873-b97d-21ac890e6c72','bcb19857-2acf-43ed-9480-b1975fa5f33c',_binary ''),('cea71342-d5fb-4873-b97d-21ac890e6c72','db8690d5-98eb-4b33-8165-cb295c69b3d2',_binary '\0'),('cea71342-d5fb-4873-b97d-21ac890e6c72','e22978cc-f9ed-428f-90c6-383ee84fb000',_binary '\0'),('cea71342-d5fb-4873-b97d-21ac890e6c72','f72905ec-d315-4c68-89dd-14d42907cf3e',_binary ''),('d3bacc5c-ac4e-41ab-abb9-3d79878ddcdc','0ea1d4c1-d78e-433a-9a43-d31c1c298deb',_binary ''),('d3bacc5c-ac4e-41ab-abb9-3d79878ddcdc','275e4568-19f1-4016-8db4-c60a6daa0ab4',_binary ''),('d3bacc5c-ac4e-41ab-abb9-3d79878ddcdc','414975ff-f904-4ab5-b84c-ce90b092c83a',_binary '\0'),('d3bacc5c-ac4e-41ab-abb9-3d79878ddcdc','5331ff23-6ff5-4b10-9ac9-0c413fe89907',_binary '\0'),('d3bacc5c-ac4e-41ab-abb9-3d79878ddcdc','8cf5052c-143d-4034-a453-71443d4c683c',_binary ''),('d3bacc5c-ac4e-41ab-abb9-3d79878ddcdc','9ecc4599-6324-4ab5-a7a2-67e68b1af5f2',_binary ''),('d3bacc5c-ac4e-41ab-abb9-3d79878ddcdc','bcb19857-2acf-43ed-9480-b1975fa5f33c',_binary ''),('d3bacc5c-ac4e-41ab-abb9-3d79878ddcdc','db8690d5-98eb-4b33-8165-cb295c69b3d2',_binary '\0'),('d3bacc5c-ac4e-41ab-abb9-3d79878ddcdc','e22978cc-f9ed-428f-90c6-383ee84fb000',_binary '\0'),('d3bacc5c-ac4e-41ab-abb9-3d79878ddcdc','f72905ec-d315-4c68-89dd-14d42907cf3e',_binary ''),('d84f18c2-b355-4a93-893b-a886e0b8fcf2','04f47a6c-8d2b-415f-be78-80d855e614a8',_binary '\0'),('d84f18c2-b355-4a93-893b-a886e0b8fcf2','176332ca-d883-4329-a9d4-68884a7c275e',_binary ''),('d84f18c2-b355-4a93-893b-a886e0b8fcf2','20d24c08-4287-49c0-9e96-23b74cb9dde4',_binary ''),('d84f18c2-b355-4a93-893b-a886e0b8fcf2','3617b695-9239-4d20-9271-32aa00a4825a',_binary ''),('d84f18c2-b355-4a93-893b-a886e0b8fcf2','5753f684-aa1d-4cc0-88aa-98a2f0cab3af',_binary ''),('d84f18c2-b355-4a93-893b-a886e0b8fcf2','76bd20ff-2540-4fb2-b91f-f1b9ec78c9d0',_binary ''),('d84f18c2-b355-4a93-893b-a886e0b8fcf2','90332860-b400-4df0-b3a0-5ddee0d59319',_binary '\0'),('d84f18c2-b355-4a93-893b-a886e0b8fcf2','91926bc4-0204-43c3-a034-67e94de06f80',_binary ''),('d84f18c2-b355-4a93-893b-a886e0b8fcf2','e7c2df73-1988-4b3e-b971-24cd27bb2a0f',_binary '\0'),('d84f18c2-b355-4a93-893b-a886e0b8fcf2','ee7ace46-13d6-42c2-9718-1c0cbd9418a8',_binary '\0'),('da8a1c0e-1290-4e3d-988f-7ff967de07d8','04f47a6c-8d2b-415f-be78-80d855e614a8',_binary '\0'),('da8a1c0e-1290-4e3d-988f-7ff967de07d8','176332ca-d883-4329-a9d4-68884a7c275e',_binary ''),('da8a1c0e-1290-4e3d-988f-7ff967de07d8','20d24c08-4287-49c0-9e96-23b74cb9dde4',_binary ''),('da8a1c0e-1290-4e3d-988f-7ff967de07d8','3617b695-9239-4d20-9271-32aa00a4825a',_binary ''),('da8a1c0e-1290-4e3d-988f-7ff967de07d8','5753f684-aa1d-4cc0-88aa-98a2f0cab3af',_binary ''),('da8a1c0e-1290-4e3d-988f-7ff967de07d8','76bd20ff-2540-4fb2-b91f-f1b9ec78c9d0',_binary ''),('da8a1c0e-1290-4e3d-988f-7ff967de07d8','90332860-b400-4df0-b3a0-5ddee0d59319',_binary '\0'),('da8a1c0e-1290-4e3d-988f-7ff967de07d8','91926bc4-0204-43c3-a034-67e94de06f80',_binary ''),('da8a1c0e-1290-4e3d-988f-7ff967de07d8','e7c2df73-1988-4b3e-b971-24cd27bb2a0f',_binary '\0'),('da8a1c0e-1290-4e3d-988f-7ff967de07d8','ee7ace46-13d6-42c2-9718-1c0cbd9418a8',_binary '\0'),('dd77b2d7-5ee9-4a5d-a25a-eb152157fb4c','2a8bc487-583c-43dc-8d29-1ad0950d438b',_binary ''),('dd77b2d7-5ee9-4a5d-a25a-eb152157fb4c','356d3968-262b-4bee-8d44-0d93e880b01a',_binary ''),('dd77b2d7-5ee9-4a5d-a25a-eb152157fb4c','4072c001-f7e7-4fa4-9f9f-0f099a308dfe',_binary '\0'),('dd77b2d7-5ee9-4a5d-a25a-eb152157fb4c','41cca0ba-533b-45a7-99c1-8b4ecf149f06',_binary ''),('dd77b2d7-5ee9-4a5d-a25a-eb152157fb4c','4d7db1a2-1bb6-4104-801b-ea18bd31d25e',_binary '\0'),('dd77b2d7-5ee9-4a5d-a25a-eb152157fb4c','6ec5000c-e317-4360-8f97-2f3545494994',_binary ''),('dd77b2d7-5ee9-4a5d-a25a-eb152157fb4c','77249e04-e2d2-4031-9667-8786a866947c',_binary ''),('dd77b2d7-5ee9-4a5d-a25a-eb152157fb4c','c32f9638-55d0-4d5a-a3fb-feb682bc420c',_binary '\0'),('dd77b2d7-5ee9-4a5d-a25a-eb152157fb4c','c860f1d3-2172-40b1-9ce2-84911e6a17a9',_binary ''),('dd77b2d7-5ee9-4a5d-a25a-eb152157fb4c','fb50c6e7-5a41-49e1-a6d1-933d23ad0663',_binary '\0'),('e233b1cf-3455-4e60-9488-ec12dfa884d2','2a8bc487-583c-43dc-8d29-1ad0950d438b',_binary ''),('e233b1cf-3455-4e60-9488-ec12dfa884d2','356d3968-262b-4bee-8d44-0d93e880b01a',_binary ''),('e233b1cf-3455-4e60-9488-ec12dfa884d2','4072c001-f7e7-4fa4-9f9f-0f099a308dfe',_binary '\0'),('e233b1cf-3455-4e60-9488-ec12dfa884d2','41cca0ba-533b-45a7-99c1-8b4ecf149f06',_binary ''),('e233b1cf-3455-4e60-9488-ec12dfa884d2','4d7db1a2-1bb6-4104-801b-ea18bd31d25e',_binary '\0'),('e233b1cf-3455-4e60-9488-ec12dfa884d2','6ec5000c-e317-4360-8f97-2f3545494994',_binary ''),('e233b1cf-3455-4e60-9488-ec12dfa884d2','77249e04-e2d2-4031-9667-8786a866947c',_binary ''),('e233b1cf-3455-4e60-9488-ec12dfa884d2','c32f9638-55d0-4d5a-a3fb-feb682bc420c',_binary '\0'),('e233b1cf-3455-4e60-9488-ec12dfa884d2','c860f1d3-2172-40b1-9ce2-84911e6a17a9',_binary ''),('e233b1cf-3455-4e60-9488-ec12dfa884d2','fb50c6e7-5a41-49e1-a6d1-933d23ad0663',_binary '\0'),('e7c18adf-18b9-48fc-92a0-698f43736bcd','0ea1d4c1-d78e-433a-9a43-d31c1c298deb',_binary ''),('e7c18adf-18b9-48fc-92a0-698f43736bcd','275e4568-19f1-4016-8db4-c60a6daa0ab4',_binary ''),('e7c18adf-18b9-48fc-92a0-698f43736bcd','414975ff-f904-4ab5-b84c-ce90b092c83a',_binary '\0'),('e7c18adf-18b9-48fc-92a0-698f43736bcd','5331ff23-6ff5-4b10-9ac9-0c413fe89907',_binary '\0'),('e7c18adf-18b9-48fc-92a0-698f43736bcd','9ecc4599-6324-4ab5-a7a2-67e68b1af5f2',_binary ''),('e7c18adf-18b9-48fc-92a0-698f43736bcd','bcb19857-2acf-43ed-9480-b1975fa5f33c',_binary ''),('e7c18adf-18b9-48fc-92a0-698f43736bcd','db8690d5-98eb-4b33-8165-cb295c69b3d2',_binary '\0'),('e7c18adf-18b9-48fc-92a0-698f43736bcd','e22978cc-f9ed-428f-90c6-383ee84fb000',_binary '\0'),('e7c18adf-18b9-48fc-92a0-698f43736bcd','f72905ec-d315-4c68-89dd-14d42907cf3e',_binary ''),('ead46d75-3ebd-458d-8d9a-8df75b027507','0d783cca-c3a4-4d95-ab32-82551105367e',_binary ''),('ead46d75-3ebd-458d-8d9a-8df75b027507','433a8036-5c4d-4675-a59e-2ac046db7713',_binary ''),('ead46d75-3ebd-458d-8d9a-8df75b027507','467375c3-0f8a-490f-b105-0bb44c15a518',_binary '\0'),('ead46d75-3ebd-458d-8d9a-8df75b027507','63210a8a-0008-4908-a26e-c374667cf2ea',_binary ''),('ead46d75-3ebd-458d-8d9a-8df75b027507','7f8eb3f6-36a3-4334-926c-7e7a067a96ad',_binary '\0'),('ead46d75-3ebd-458d-8d9a-8df75b027507','8c3bdc03-95db-4a61-833f-d816bc6d702c',_binary '\0'),('ead46d75-3ebd-458d-8d9a-8df75b027507','f070e008-1bf3-4354-9566-af729276ee3e',_binary ''),('ead46d75-3ebd-458d-8d9a-8df75b027507','f8b8a1e5-c804-4695-b5b1-35c66ddbabee',_binary '\0'),('ead46d75-3ebd-458d-8d9a-8df75b027507','fedf7ec0-e80f-4336-a9b1-17e8bf4c7b71',_binary ''),('eec28897-b54a-4d82-9488-f454e28d01ea','04f47a6c-8d2b-415f-be78-80d855e614a8',_binary '\0'),('eec28897-b54a-4d82-9488-f454e28d01ea','176332ca-d883-4329-a9d4-68884a7c275e',_binary ''),('eec28897-b54a-4d82-9488-f454e28d01ea','3617b695-9239-4d20-9271-32aa00a4825a',_binary ''),('eec28897-b54a-4d82-9488-f454e28d01ea','5753f684-aa1d-4cc0-88aa-98a2f0cab3af',_binary ''),('eec28897-b54a-4d82-9488-f454e28d01ea','76bd20ff-2540-4fb2-b91f-f1b9ec78c9d0',_binary ''),('eec28897-b54a-4d82-9488-f454e28d01ea','90332860-b400-4df0-b3a0-5ddee0d59319',_binary '\0'),('eec28897-b54a-4d82-9488-f454e28d01ea','91926bc4-0204-43c3-a034-67e94de06f80',_binary ''),('eec28897-b54a-4d82-9488-f454e28d01ea','e7c2df73-1988-4b3e-b971-24cd27bb2a0f',_binary '\0'),('eec28897-b54a-4d82-9488-f454e28d01ea','ee7ace46-13d6-42c2-9718-1c0cbd9418a8',_binary '\0');
/*!40000 ALTER TABLE `CLIENT_SCOPE_CLIENT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENT_SCOPE_ROLE_MAPPING`
--

DROP TABLE IF EXISTS `CLIENT_SCOPE_ROLE_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CLIENT_SCOPE_ROLE_MAPPING` (
  `SCOPE_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ROLE_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`SCOPE_ID`,`ROLE_ID`),
  KEY `IDX_CLSCOPE_ROLE` (`SCOPE_ID`),
  KEY `IDX_ROLE_CLSCOPE` (`ROLE_ID`),
  CONSTRAINT `FK_CL_SCOPE_RM_SCOPE` FOREIGN KEY (`SCOPE_ID`) REFERENCES `CLIENT_SCOPE` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENT_SCOPE_ROLE_MAPPING`
--

LOCK TABLES `CLIENT_SCOPE_ROLE_MAPPING` WRITE;
/*!40000 ALTER TABLE `CLIENT_SCOPE_ROLE_MAPPING` DISABLE KEYS */;
INSERT INTO `CLIENT_SCOPE_ROLE_MAPPING` VALUES ('e22978cc-f9ed-428f-90c6-383ee84fb000','28a570b2-8bd0-49f5-a9d3-ab2cafefb639'),('fb50c6e7-5a41-49e1-a6d1-933d23ad0663','44f11c4f-11de-4930-a9bb-66f1504833af');
/*!40000 ALTER TABLE `CLIENT_SCOPE_ROLE_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENT_SESSION`
--

DROP TABLE IF EXISTS `CLIENT_SESSION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CLIENT_SESSION` (
  `ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `CLIENT_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REDIRECT_URI` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `STATE` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TIMESTAMP` int DEFAULT NULL,
  `SESSION_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `AUTH_METHOD` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REALM_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `AUTH_USER_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CURRENT_ACTION` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IDX_CLIENT_SESSION_SESSION` (`SESSION_ID`),
  CONSTRAINT `FK_B4AO2VCVAT6UKAU74WBWTFQO1` FOREIGN KEY (`SESSION_ID`) REFERENCES `USER_SESSION` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENT_SESSION`
--

LOCK TABLES `CLIENT_SESSION` WRITE;
/*!40000 ALTER TABLE `CLIENT_SESSION` DISABLE KEYS */;
/*!40000 ALTER TABLE `CLIENT_SESSION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENT_SESSION_AUTH_STATUS`
--

DROP TABLE IF EXISTS `CLIENT_SESSION_AUTH_STATUS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CLIENT_SESSION_AUTH_STATUS` (
  `AUTHENTICATOR` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `STATUS` int DEFAULT NULL,
  `CLIENT_SESSION` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`CLIENT_SESSION`,`AUTHENTICATOR`),
  CONSTRAINT `AUTH_STATUS_CONSTRAINT` FOREIGN KEY (`CLIENT_SESSION`) REFERENCES `CLIENT_SESSION` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENT_SESSION_AUTH_STATUS`
--

LOCK TABLES `CLIENT_SESSION_AUTH_STATUS` WRITE;
/*!40000 ALTER TABLE `CLIENT_SESSION_AUTH_STATUS` DISABLE KEYS */;
/*!40000 ALTER TABLE `CLIENT_SESSION_AUTH_STATUS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENT_SESSION_NOTE`
--

DROP TABLE IF EXISTS `CLIENT_SESSION_NOTE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CLIENT_SESSION_NOTE` (
  `NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CLIENT_SESSION` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`CLIENT_SESSION`,`NAME`),
  CONSTRAINT `FK5EDFB00FF51C2736` FOREIGN KEY (`CLIENT_SESSION`) REFERENCES `CLIENT_SESSION` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENT_SESSION_NOTE`
--

LOCK TABLES `CLIENT_SESSION_NOTE` WRITE;
/*!40000 ALTER TABLE `CLIENT_SESSION_NOTE` DISABLE KEYS */;
/*!40000 ALTER TABLE `CLIENT_SESSION_NOTE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENT_SESSION_PROT_MAPPER`
--

DROP TABLE IF EXISTS `CLIENT_SESSION_PROT_MAPPER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CLIENT_SESSION_PROT_MAPPER` (
  `PROTOCOL_MAPPER_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `CLIENT_SESSION` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`CLIENT_SESSION`,`PROTOCOL_MAPPER_ID`),
  CONSTRAINT `FK_33A8SGQW18I532811V7O2DK89` FOREIGN KEY (`CLIENT_SESSION`) REFERENCES `CLIENT_SESSION` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENT_SESSION_PROT_MAPPER`
--

LOCK TABLES `CLIENT_SESSION_PROT_MAPPER` WRITE;
/*!40000 ALTER TABLE `CLIENT_SESSION_PROT_MAPPER` DISABLE KEYS */;
/*!40000 ALTER TABLE `CLIENT_SESSION_PROT_MAPPER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENT_SESSION_ROLE`
--

DROP TABLE IF EXISTS `CLIENT_SESSION_ROLE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CLIENT_SESSION_ROLE` (
  `ROLE_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `CLIENT_SESSION` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`CLIENT_SESSION`,`ROLE_ID`),
  CONSTRAINT `FK_11B7SGQW18I532811V7O2DV76` FOREIGN KEY (`CLIENT_SESSION`) REFERENCES `CLIENT_SESSION` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENT_SESSION_ROLE`
--

LOCK TABLES `CLIENT_SESSION_ROLE` WRITE;
/*!40000 ALTER TABLE `CLIENT_SESSION_ROLE` DISABLE KEYS */;
/*!40000 ALTER TABLE `CLIENT_SESSION_ROLE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENT_USER_SESSION_NOTE`
--

DROP TABLE IF EXISTS `CLIENT_USER_SESSION_NOTE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CLIENT_USER_SESSION_NOTE` (
  `NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `CLIENT_SESSION` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`CLIENT_SESSION`,`NAME`),
  CONSTRAINT `FK_CL_USR_SES_NOTE` FOREIGN KEY (`CLIENT_SESSION`) REFERENCES `CLIENT_SESSION` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENT_USER_SESSION_NOTE`
--

LOCK TABLES `CLIENT_USER_SESSION_NOTE` WRITE;
/*!40000 ALTER TABLE `CLIENT_USER_SESSION_NOTE` DISABLE KEYS */;
/*!40000 ALTER TABLE `CLIENT_USER_SESSION_NOTE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COMPONENT`
--

DROP TABLE IF EXISTS `COMPONENT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `COMPONENT` (
  `ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PARENT_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PROVIDER_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PROVIDER_TYPE` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REALM_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SUB_TYPE` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IDX_COMPONENT_REALM` (`REALM_ID`),
  KEY `IDX_COMPONENT_PROVIDER_TYPE` (`PROVIDER_TYPE`),
  CONSTRAINT `FK_COMPONENT_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COMPONENT`
--

LOCK TABLES `COMPONENT` WRITE;
/*!40000 ALTER TABLE `COMPONENT` DISABLE KEYS */;
INSERT INTO `COMPONENT` VALUES ('0a3f24bf-067c-4d7a-9de5-df3bf64daf31','Allowed Client Scopes','master','allowed-client-templates','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','master','anonymous'),('0f2de35b-7745-490e-80dd-850657436c56','Allowed Protocol Mapper Types','hi-library','allowed-protocol-mappers','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','hi-library','authenticated'),('137ba95a-167d-446c-bf80-afc78ee43164','aes-generated','hi-therapist','aes-generated','org.keycloak.keys.KeyProvider','hi-therapist',NULL),('148d1e6a-42c5-47ae-b004-a9ff418c7887','Allowed Client Scopes','hi','allowed-client-templates','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','hi','anonymous'),('2638397a-3bfd-4836-b359-b9370ad2a0cd','Consent Required','hi','consent-required','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','hi','anonymous'),('2f6d4da9-637b-453e-8332-025bdf01f579','Allowed Protocol Mapper Types','hi-library','allowed-protocol-mappers','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','hi-library','anonymous'),('30b8737a-833d-4e86-92f2-bddf62b79552','Consent Required','master','consent-required','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','master','anonymous'),('334e8014-e4d6-4a45-99f5-73976da3ca56','Allowed Client Scopes','hi-therapist','allowed-client-templates','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','hi-therapist','anonymous'),('39a2533a-f944-491d-b419-46770e25c58b','hmac-generated-hs512','hi-library','hmac-generated','org.keycloak.keys.KeyProvider','hi-library',NULL),('426a718a-aa81-431f-84cc-802932cb615d','fallback-RS256','master','rsa-generated','org.keycloak.keys.KeyProvider','master',NULL),('46ef48a2-728c-479c-b72e-8a9c11875e8e','hmac-generated','hi','hmac-generated','org.keycloak.keys.KeyProvider','hi',NULL),('49d50209-e174-4587-a4f8-39d60ed1c692','hmac-generated-hs512','hi','hmac-generated','org.keycloak.keys.KeyProvider','hi',NULL),('4f1fc2ce-324f-4e91-b0bf-ddb55d3c3a0d','Max Clients Limit','hi','max-clients','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','hi','anonymous'),('4f350012-6daa-4af2-b5f8-a7f5904f95c6','Allowed Protocol Mapper Types','master','allowed-protocol-mappers','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','master','authenticated'),('555d1965-3c3e-433f-b2e3-0417f01641b7','Full Scope Disabled','master','scope','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','master','anonymous'),('5aaff54e-2e56-48f9-a260-403dfc1043b6',NULL,'hi','declarative-user-profile','org.keycloak.userprofile.UserProfileProvider','hi',NULL),('5dc8ead5-ae0f-4e17-96e5-e33bd2c445c9','Allowed Client Scopes','hi-therapist','allowed-client-templates','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','hi-therapist','authenticated'),('5e680211-0235-45e7-8236-d04ccd305b2a',NULL,'hi-library','declarative-user-profile','org.keycloak.userprofile.UserProfileProvider','hi-library',NULL),('61ef42a6-d394-40bf-8af0-b7724d392933','Max Clients Limit','master','max-clients','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','master','anonymous'),('66d2b7d2-1518-4922-9cd3-97cda703360b','hmac-generated','hi-library','hmac-generated','org.keycloak.keys.KeyProvider','hi-library',NULL),('6777836c-e503-4ba3-b02b-6bee92c28713',NULL,'hi-therapist','declarative-user-profile','org.keycloak.userprofile.UserProfileProvider','hi-therapist',NULL),('6c559237-b384-4b5a-94e7-acdf03cabbbe','Max Clients Limit','hi-library','max-clients','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','hi-library','anonymous'),('7471a241-ce38-4639-88eb-bd9d675abb68','hmac-generated-hs512','hi-therapist','hmac-generated','org.keycloak.keys.KeyProvider','hi-therapist',NULL),('815fe376-b55c-482f-9848-5833feaacba7',NULL,'master','declarative-user-profile','org.keycloak.userprofile.UserProfileProvider','master',NULL),('8e17d7c0-2557-4e3c-b4c0-f54fd03c9693','Allowed Protocol Mapper Types','hi','allowed-protocol-mappers','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','hi','anonymous'),('9a0b8b92-4257-4911-a948-6d0a89644198','aes-generated','hi-library','aes-generated','org.keycloak.keys.KeyProvider','hi-library',NULL),('9c25a697-cd42-40fa-a47e-42d3a754c43a','Allowed Protocol Mapper Types','hi-therapist','allowed-protocol-mappers','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','hi-therapist','anonymous'),('9db23f98-215c-4267-b4be-b81ba957f0a6','Allowed Client Scopes','hi-library','allowed-client-templates','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','hi-library','anonymous'),('a15b9aa3-6773-4a4b-8ba2-66e6d6c9cf85','Full Scope Disabled','hi-library','scope','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','hi-library','anonymous'),('a3d3811b-01c1-444c-94bd-633b12face97','Consent Required','hi-library','consent-required','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','hi-library','anonymous'),('a730c2af-3051-4fd2-ac3a-a87a4eaf279d','Allowed Client Scopes','hi-library','allowed-client-templates','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','hi-library','authenticated'),('a8a221a5-0304-4825-b9c0-f2a288b4cdac','aes-generated','hi','aes-generated','org.keycloak.keys.KeyProvider','hi',NULL),('b28cf178-dd17-406b-ba78-d3fe47126065','rsa-generated','hi-therapist','rsa-generated','org.keycloak.keys.KeyProvider','hi-therapist',NULL),('bc33edc9-c057-4274-8694-9ca5adc2b121','fallback-HS256','master','hmac-generated','org.keycloak.keys.KeyProvider','master',NULL),('bcc79912-6111-4ad8-a5a1-50d374b97922','Allowed Client Scopes','hi','allowed-client-templates','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','hi','authenticated'),('bf58af08-912d-4825-bb3a-b00d4acd680e','Full Scope Disabled','hi-therapist','scope','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','hi-therapist','anonymous'),('c0654b8e-517a-4ca4-834a-7a01b80dbf01','rsa-generated','hi-library','rsa-generated','org.keycloak.keys.KeyProvider','hi-library',NULL),('c28e3df5-03e4-4df5-81c6-bdcd22d00e56','Trusted Hosts','hi','trusted-hosts','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','hi','anonymous'),('ca974dea-4e17-4d0e-8c4e-da1c54396693','Allowed Protocol Mapper Types','hi-therapist','allowed-protocol-mappers','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','hi-therapist','authenticated'),('ccafc9dc-c46d-4152-b826-ceed1fa8603b','hmac-generated','hi-therapist','hmac-generated','org.keycloak.keys.KeyProvider','hi-therapist',NULL),('cfe5e0bf-1246-4f61-8ee2-fbcd7362d184','Allowed Protocol Mapper Types','master','allowed-protocol-mappers','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','master','anonymous'),('d20d8481-15f9-46c4-8799-bc6b6753172f','Trusted Hosts','hi-therapist','trusted-hosts','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','hi-therapist','anonymous'),('d2a01090-9980-4d9d-a791-732c229cffbe','Allowed Client Scopes','master','allowed-client-templates','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','master','authenticated'),('d3cd434b-6615-46df-9538-47542fc703e4','Max Clients Limit','hi-therapist','max-clients','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','hi-therapist','anonymous'),('d4ceecc6-257f-4c05-a5b2-1e8c01942c98','hmac-generated-hs512','master','hmac-generated','org.keycloak.keys.KeyProvider','master',NULL),('db43d4bd-adbe-4714-a852-8ff5d35d2e67','Full Scope Disabled','hi','scope','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','hi','anonymous'),('ddf9e42a-d618-4231-938c-98d5cf7187ef','Allowed Protocol Mapper Types','hi','allowed-protocol-mappers','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','hi','authenticated'),('decee23a-28c9-4bbb-bcfa-64f419b386d3','rsa-generated','hi','rsa-generated','org.keycloak.keys.KeyProvider','hi',NULL),('e83e4721-7093-494e-bf3e-b5e59da89534','Consent Required','hi-therapist','consent-required','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','hi-therapist','anonymous'),('f0006121-bd47-4ab3-8039-b060a52fcd74','Trusted Hosts','master','trusted-hosts','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','master','anonymous'),('f4c53734-0889-4684-b3e3-c1404b14ea91','Trusted Hosts','hi-library','trusted-hosts','org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy','hi-library','anonymous'),('fd37d4bc-dfce-4031-9ffb-b55280438a25','fallback-AES','master','aes-generated','org.keycloak.keys.KeyProvider','master',NULL);
/*!40000 ALTER TABLE `COMPONENT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COMPONENT_CONFIG`
--

DROP TABLE IF EXISTS `COMPONENT_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `COMPONENT_CONFIG` (
  `ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `COMPONENT_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  PRIMARY KEY (`ID`),
  KEY `IDX_COMPO_CONFIG_COMPO` (`COMPONENT_ID`),
  CONSTRAINT `FK_COMPONENT_CONFIG` FOREIGN KEY (`COMPONENT_ID`) REFERENCES `COMPONENT` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COMPONENT_CONFIG`
--

LOCK TABLES `COMPONENT_CONFIG` WRITE;
/*!40000 ALTER TABLE `COMPONENT_CONFIG` DISABLE KEYS */;
INSERT INTO `COMPONENT_CONFIG` VALUES ('03653ab8-b879-4ba5-b998-e7d09e0c5084','39a2533a-f944-491d-b419-46770e25c58b','secret','jpA1Qc5QnL7cvxoLP8sXwuCOVq8hqSHDBrYrvdkxTcjYRzokbRKsMB_4Nl6aYWbRvWIs98RZM7P-26SXvlqTeFSBNKm284vtDi0GB9T384vOi-DJquvVJG66B8qqAbbHFyX8iZl0pl21dq7QCSAgIX__DHtwFdrF2k605YPwNTg'),('04868fe6-d89c-4dce-a27e-87dddee4768e','426a718a-aa81-431f-84cc-802932cb615d','priority','-100'),('08ef125a-a232-4f1e-806d-30e4b2cf4c9c','5dc8ead5-ae0f-4e17-96e5-e33bd2c445c9','allow-default-scopes','true'),('0c08afeb-d34f-4160-9dd2-e9aa0917715e','cfe5e0bf-1246-4f61-8ee2-fbcd7362d184','allowed-protocol-mapper-types','saml-user-property-mapper'),('11693858-468f-4e11-b0a9-564a46a52d9c','f4c53734-0889-4684-b3e3-c1404b14ea91','client-uris-must-match','true'),('1242a719-563a-4ff6-8597-3e18e5c38c59','decee23a-28c9-4bbb-bcfa-64f419b386d3','certificate','MIICkzCCAXsCBgF1mATeDjANBgkqhkiG9w0BAQsFADANMQswCQYDVQQDDAJoaTAeFw0yMDExMDUxMDQ1NTdaFw0zMDExMDUxMDQ3MzdaMA0xCzAJBgNVBAMMAmhpMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAubZNwliR7jvrOXc2SJYhDlJ1NRAOZXFp3xKR5EeZFxBVlzkKKwibX+BZyXYFXAmHrwqaoDX+Eqfws3Gjfo5V990Ge81XSv5y2NtX1xjuhy2RhZCUA84nKkKt1fzFkMJu5cS6zP7nmu+zMjREuEMeW/NkcehDrKGI3o/CcXaxAvTK6Bh9sTBshre/CGRXi2Y9m1PQJPTrePvBZFHxBwS9eST+rg02uGeLb4XhbFD7pP5HEGXrGqc+D2RpmuNU4Efyr7AxnnSN0+Pde8isRFjzGYuXEbnTTMjd+1gSCywhZAgCA73MUbeS2A+nfLlKHAzd5kMIxAA5W+Uuqk7dk+RCiwIDAQABMA0GCSqGSIb3DQEBCwUAA4IBAQCXM0yjWkESR5PZt7xa0E2SDXXetu/0QfGRVBWPjvU7D6uOkMD8ctypnc0439O4NHjIE3CLyyIKZbAl78m1PMkRJm/jQNqjPIjRiM1bTuFM90XRRIAxhq1KtjdOqbPuEDtcGFbPWWby/dJTyKhLV6qibJal5NOgIu6MnmTF+pCGGtvGR1m5xKqjzx6XVqbQ8qHwM/f4tmkFXzfaQxFBzeMEfJqNj0MdVRnmYP8kKaPwF1iEHmZWBipU1AevSOLksmvjSl2hIfVTCFlpZr7wS0a7JwTFr+8DCFVU0R0Ghqc3h3cko0/IqBDKKVKJ9dUkzy5Jdq2FZI3pIGZWZa9T3LyE'),('14272f34-4261-46a4-a1c7-6ed8cf4761db','bc33edc9-c057-4274-8694-9ca5adc2b121','priority','-100'),('169b813f-1171-4acd-8f47-3bcf956a3ba8','4f350012-6daa-4af2-b5f8-a7f5904f95c6','allowed-protocol-mapper-types','oidc-usermodel-attribute-mapper'),('17e70e8d-22d7-4de6-8f9f-984d1c38102b','49d50209-e174-4587-a4f8-39d60ed1c692','secret','ORItA70kSdTtMMuXHvaqK4YEQpMYnrPU5lOJCR55DxmhxgmyTV9olRpOzFjv1ie1BoIHjZTR31QmK4ml8A-ArFMHblYtV4lMp2LYyR87I8tTZZdJMsQif7W8oTgqI47c-ZO_b3j54MEnpNjMPOAaQY7gE3KwMJeb_RPQuMnDHuE'),('18345384-75d1-4465-8ec5-5e691b832e50','9c25a697-cd42-40fa-a47e-42d3a754c43a','allowed-protocol-mapper-types','oidc-usermodel-property-mapper'),('18ecb3b9-db6d-48dc-81f2-cd84e9bcf41b','d4ceecc6-257f-4c05-a5b2-1e8c01942c98','kid','802c3ea1-0b6d-4e54-bee6-c44706b6ff99'),('19a7615a-5f46-4db5-86e8-d31bb2532b1a','ddf9e42a-d618-4231-938c-98d5cf7187ef','allowed-protocol-mapper-types','saml-role-list-mapper'),('1a8ac9ea-c640-4852-b5b2-26a6cf2f02e8','334e8014-e4d6-4a45-99f5-73976da3ca56','allow-default-scopes','true'),('1bfd2265-7bb4-4663-b9c3-b67abac7acc9','148d1e6a-42c5-47ae-b004-a9ff418c7887','allow-default-scopes','true'),('1c72ebbf-7f41-4daa-8ec7-39dcde5ca959','7471a241-ce38-4639-88eb-bd9d675abb68','algorithm','HS512'),('1d11f6ea-be40-4d10-b59c-462c1d1a8076','6c559237-b384-4b5a-94e7-acdf03cabbbe','max-clients','200'),('1d36f023-d8ba-471c-9946-52a6552d7598','c0654b8e-517a-4ca4-834a-7a01b80dbf01','certificate','MIICozCCAYsCBgF68EJGxjANBgkqhkiG9w0BAQsFADAVMRMwEQYDVQQDDApoaS1saWJyYXJ5MB4XDTIxMDcyOTAzMTMzM1oXDTMxMDcyOTAzMTUxM1owFTETMBEGA1UEAwwKaGktbGlicmFyeTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAJ7cWatcUZ9QT2pWbjMhSByvlcHrtO3uFqP1UIdXvoiH10yX2G53cyG+sP4D4DJg1sKVBfzrdVMFKl9116XKZksmc/iXvJKtwpvn+lOBqooo330jXySLPzg0Sh0wWdTu+xxLTrGkbu2+a8rHxtOcfJ/7uS4VrkPeIHAmBGO99Qguq84wmGTS1DS59R+f2h1cg8KHYx0hkY7Fur+txc5gAZSNgc67d+1Ndd4iJOz6xT5DF6rvXHdSXGgPZ6M6O2FrenfMJeme2Z2GztK12x9zWXWX41cGXHeTXmmaQb6nE7iO9jkwSQZowHf3jR4Zl5WmsUW/pHZ467CD2Y7O8MFM42sCAwEAATANBgkqhkiG9w0BAQsFAAOCAQEAk52htc4JZBlTCxtLHqlfiV+hIyRTyp7rezuOC4nlfyzBVHneVdL54IIKSIf2NVwqWT705QXiglBcIVV5J9tfPbc9X54Sg9OTtCWsdMHBN3Dgfe2ipg0WLiosQ5ytelM8yfYj9wxXjn0uvHgVhIHil0BvdRm9939K+ULz5pZ1PNoHaoIp489OpXmGYhqTj1ufBShKSeiKCzDe/oD0dqlz6Grxxz7ge2y8wvqsJ7y2kgidM/gScOPk35XnqrHvN6duPLohbZNFXUNRggn4TlH8riy41ylax+iIltZd5rD8yNtCZvHSww9IFq1ifoK5oZMii2qn+pIfOF4qvF14zET9cw=='),('1d65f2a2-8ea8-46a4-b5c5-b359fb5fc7fa','137ba95a-167d-446c-bf80-afc78ee43164','priority','100'),('24a8ebe4-2cdc-4b93-a9e1-f59db63441b1','bcc79912-6111-4ad8-a5a1-50d374b97922','allow-default-scopes','true'),('26bc7849-9a09-4333-9093-c24644e252c1','39a2533a-f944-491d-b419-46770e25c58b','algorithm','HS512'),('276730e4-9433-4d5f-9947-14845489473a','49d50209-e174-4587-a4f8-39d60ed1c692','algorithm','HS512'),('27b45872-bb6a-4420-b64a-e792a9f9fba0','b28cf178-dd17-406b-ba78-d3fe47126065','certificate','MIICpzCCAY8CBgF13m/WqDANBgkqhkiG9w0BAQsFADAXMRUwEwYDVQQDDAxoaS10aGVyYXBpc3QwHhcNMjAxMTE5MDI1NjEyWhcNMzAxMTE5MDI1NzUyWjAXMRUwEwYDVQQDDAxoaS10aGVyYXBpc3QwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDQe5kPWtCfYJnaghS7+4jqfSdJNCcWAdzVj0APzch2f1pLZcRucHGDF5iJGSuk5m/RIVhkXg3PE5arb/4Myteylx6+EKlVl5CvdQ/pec/WbK2Mp1XI4eyhgZJhBUIxT/gX1EnXNDRBdd6QTJVshy3VkQDk0Seu6rqTYPqhd4iluAsZVTrV1jPN8g7GJucmSF9/wvZEW9jRtwTv64Rhgyyn3F9G/avWC2PmVuLS9pdHwRzIFqiS6BEhSEx5XQLdN3CvnAJ55raGtOe2DRPGLM0fy+K2zq46oMNYNIAMmJR1gp4rJU5VOE/5kx7xJMQgMqf+6qbKVRrNeRkbKiDHVFyZAgMBAAEwDQYJKoZIhvcNAQELBQADggEBAHpf6HfBw5onmk4Y91v6ov2S6YVd0IOgY3usmk8gIpUg6mkmJJP4wEqpYs57puTDy3ovHrszCBHhTcS2vo0DzWoP+zYK1A2quOssOs5Ue3/36jiT8AOWvXth29i9fCZOoOLmQI/k6J/RMMpGnWwSjCkod0XZzm3IJokJ+Ea/7R9SNJ3Yg6Qg9Ug7+RISwQVncsnbKxORjovkCYEdXUWt+sbKHJcxsAZjwiKWvKBV8++s6VZCulFJc8V9lAaKqju/Dd2ogwo8GdL+r+TCPzhUBDtlPLX3fU1EvtpLmc4rmqw9qmnPZq/yaDHt2nAfToc8uplM5MowNbCtSF6euOzkBhQ='),('27d9b61b-6fcb-466c-8016-0d69ad9fac6d','f4c53734-0889-4684-b3e3-c1404b14ea91','host-sending-registration-request-must-match','true'),('28a00f1d-9c1a-4de8-8772-c65d2a1d0aa9','ddf9e42a-d618-4231-938c-98d5cf7187ef','allowed-protocol-mapper-types','oidc-full-name-mapper'),('2a4aeeae-8d78-4fb5-ac8d-daa94ff83900','a730c2af-3051-4fd2-ac3a-a87a4eaf279d','allow-default-scopes','true'),('2aaf575c-0cfb-415c-be8b-ba1d70e5a52f','2f6d4da9-637b-453e-8332-025bdf01f579','allowed-protocol-mapper-types','saml-user-property-mapper'),('2ab0260d-da6b-4838-a810-6f41385f606a','9a0b8b92-4257-4911-a948-6d0a89644198','priority','100'),('2b049664-e886-4eb0-bd47-6ca920131f66','c28e3df5-03e4-4df5-81c6-bdcd22d00e56','client-uris-must-match','true'),('2b07faad-a94c-4217-9af8-f311d60dc08f','9a0b8b92-4257-4911-a948-6d0a89644198','kid','76fee414-4aa5-4a89-bf2e-fc7fdbcfd655'),('2b72c084-56f3-4285-8d8d-f1e23ac2ab35','d4ceecc6-257f-4c05-a5b2-1e8c01942c98','secret','R5GutjqisISIYUXnFt1GU5j9iI2v_B5yr0koeij8jK3qtLAaXTor6hNa4Lw_71NwrmRl1cH9HzzzhXrZfc99exwiEgoa34RZ0iA2TH3XvgX89ijorvDS4pUjtYq0MNrM8SdgFBuTLhAlSktUdRR5MTXtvomsJjiIyCDqu4WaRYI'),('2be9d023-fac6-4e5c-9256-62934713cc25','0f2de35b-7745-490e-80dd-850657436c56','allowed-protocol-mapper-types','saml-user-property-mapper'),('345bf9c6-2cd6-4cb4-952f-e92a05628ef9','cfe5e0bf-1246-4f61-8ee2-fbcd7362d184','allowed-protocol-mapper-types','oidc-sha256-pairwise-sub-mapper'),('3e61cb84-d9ff-42cc-b6db-769fb7e18eec','4f350012-6daa-4af2-b5f8-a7f5904f95c6','allowed-protocol-mapper-types','oidc-sha256-pairwise-sub-mapper'),('3fc382e4-1394-445c-b933-de174b7ff2d9','2f6d4da9-637b-453e-8332-025bdf01f579','allowed-protocol-mapper-types','oidc-usermodel-property-mapper'),('3fc6bd05-5c35-4725-a57d-934a17cfc505','9c25a697-cd42-40fa-a47e-42d3a754c43a','allowed-protocol-mapper-types','saml-user-attribute-mapper'),('409272bc-98c2-4b19-9266-3d597f7cf7d2','bc33edc9-c057-4274-8694-9ca5adc2b121','kid','161eba75-1ebd-4333-a04d-b4f6559623aa'),('410575e6-2d08-4c5c-97e4-f97415f9506c','2f6d4da9-637b-453e-8332-025bdf01f579','allowed-protocol-mapper-types','saml-role-list-mapper'),('417af9fa-7916-4c6e-8609-681cd972c6fb','426a718a-aa81-431f-84cc-802932cb615d','certificate','MIICmzCCAYMCBgF1kZVaYzANBgkqhkiG9w0BAQsFADARMQ8wDQYDVQQDDAZtYXN0ZXIwHhcNMjAxMTA0MDQ0NjI1WhcNMzAxMTA0MDQ0ODA1WjARMQ8wDQYDVQQDDAZtYXN0ZXIwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCcKoT5fJudT+5lgHDKY10YnZOZX3/dEP2pfXjaq0T1/i05hY/tqk1lTUY7rBs92TXtTgCBanotM9B08aRrGqeRHmj8BuGZupSuijrmfcKiwHP3wTaWSaSVBZb++dwltdu5BRvk2Q3DvP+KLddnCAIKh8c0j6aNwreoc0ziZzXF3oVktH3O7afK1e6xAj9zKATd4Zh+7b8n3xH/PLd+qBRQWuVqKVyuUQ0xjHHPUF5MMEUDOn3EAgwC4STwf+FkhIdQX/VzwWVVZCEBbddeyEAF6JGf7VyKl+8SHdVVXHUzocXomdxB/0OIzh9AXrepiD6HhLEa1QT/bdSrAoKUhTvVAgMBAAEwDQYJKoZIhvcNAQELBQADggEBAFuRqCZb9oGtXykkHllcLDh4w1HuFiZ36i66nW6KXvvPa38pQbAzmz56/bjAtZNRfgVlce9txIalFrE4guGJ7tKq9ejdfTfPB0ZV7vOftae3t8fXq3R9nW6fYLRib0si9cW5rmO77L0u9smgebTCBSDgwMkR38UEmtqlfQCBSQP6hBiDgsm2ZmSfhntNdBOUbaG8LrZvXZU7gRgv9/YFVMiHJprKiGtvyaVLr8sspEj/d6lF/6bEUA1ApoHI/aCJShezLQftMfkNhfZvcpPR4SJJc89TntVg9ZBvpxtNinekxgXgN6b9mgYITS90Qp/3wbcuVFghVp//itdXaYHL49w='),('41ff87ea-1b57-46a3-a469-04305b61b216','426a718a-aa81-431f-84cc-802932cb615d','privateKey','MIIEogIBAAKCAQEAnCqE+XybnU/uZYBwymNdGJ2TmV9/3RD9qX142qtE9f4tOYWP7apNZU1GO6wbPdk17U4AgWp6LTPQdPGkaxqnkR5o/AbhmbqUroo65n3CosBz98E2lkmklQWW/vncJbXbuQUb5NkNw7z/ii3XZwgCCofHNI+mjcK3qHNM4mc1xd6FZLR9zu2nytXusQI/cygE3eGYfu2/J98R/zy3fqgUUFrlailcrlENMYxxz1BeTDBFAzp9xAIMAuEk8H/hZISHUF/1c8FlVWQhAW3XXshABeiRn+1cipfvEh3VVVx1M6HF6JncQf9DiM4fQF63qYg+h4SxGtUE/23UqwKClIU71QIDAQABAoIBABX7YjZgFOOC4dLFzpqee/dADwuyxqPOhXY7JCzbmNxrh+Al7cmNhFFzHCTAKCF/lritlyKgY0xDk98yOGufF+E0f6CiM1VZTx52dK4HG8OfBXPlbZKgERus6sE/WH6yZ5hWoMOIzgg0bV/87eoh1W+4BxFd+xrPQtziRftEfew5GhygbOhQbdT/g6qKTaxILHqRnP5EyNguhMfe4m7lsbAaBfzUBEXWGcN1iPRSGJHLIU1CNoGihYzaYKu/JqdvcPhNlGArqyE3gvwQZ6j63hCXEypRHEY5JzpfRjXjwxnDqht5EG4U6Lq5+ZBqCsl+7NkmdByba45RTvpjZkGw4cECgYEA8F2+9Qe08o20wzgwqAcM4I2UOgaunt1NsD8i0Q7r0/tyyLH6GFxdfqZb1VqSaioyptzq8rxsgtvh/5yg27g65W839ENZHJSQmG2EV0p1VoC6gpcd8h4WJ0bvsZfpvXbLX93qZUQnzGsOLWSq73EaUhSfAHyjRJ0zD7nnI5d+x3ECgYEAplLJbHO13AW6x3T9boBlYa11bOdBZgeYbnomqDKf9QWhiiwZXmjrKNJq52MJIh5kNZogtNqnrfeSoEmUo6QuiVPHcPKwSfMe19+Mta7aTnbphXajxnat+Yk7DiU8hVsF2xcc6oqVbIaLZ5fyMBOHar10dbq1ECyXXXfMWNNBsKUCgYBI0x5X/s3D70slGpEjV39/SWXvbrbZSxOOopJZ5LturnBIfiPX3aQ2CxEnwxk5MS/Hfodwo8X8n8IJP9s8tsShXuEFEKKfFiP5CrVd/SEv5DCeAEsCYDs2Czf0BqK61JMpqIKry8qDFKxm9GkVwp7G35iM/TY6Q6aEzT5KekvfAQKBgChqU4Gj+Fv3lHRlLDQOxRPgJ3mIFC8rx1GJIx2Z9559eMxvfNahHgt0Xf/N4+lDg0w3IJ1xyG8QirOiTZkaCyjZj8wVXNsLVcJVEwcO7wNEB+ijdJaEPjA1tYDxcWxiOuELE762YCrX4sYQeQxPoodAdC0ralX8z+cpdiFbbEn1AoGABQJ6brFw7uAnqeONV2tUjfuJoczdI19KCG2h1XvhZnUgmqKsAIKW3Dpn/14EmmeYC6gqOnCEFIGnNlgJrxG8i9rKy203SBGSSLX/nzSGQWQ4Ohc5GQON3f2r6RxJho/gqD+HWLcA4DjkoblFWoNfd+TUW7U5xWHzsafZQHMrpp8='),('4266aa4f-b21f-4e3e-a707-f6f49b5e1b84','7471a241-ce38-4639-88eb-bd9d675abb68','secret','X42zbdLGA2FME_m5ejRX6bcCqGTud9n4w8Cd7XBlZ7hRjbyHK0UzfILO2N2iNIuCN1X35RsJIekQ07074Aui_uGJhU_QU0P1glXBbwDEDiBFgcjYtHvQt9zwLUvN-ceFPv7-aNwkRgey_0OovJjSW7YfNUBJH5PER3RcFzmiUzA'),('431a7266-6abb-483f-9f6d-d527b07f5301','8e17d7c0-2557-4e3c-b4c0-f54fd03c9693','allowed-protocol-mapper-types','oidc-usermodel-property-mapper'),('499da4bc-661a-4e83-bea7-39a0efb04ede','ddf9e42a-d618-4231-938c-98d5cf7187ef','allowed-protocol-mapper-types','oidc-usermodel-attribute-mapper'),('4a7fc61f-a4fd-430d-b48c-f6a8ccc9f64d','bc33edc9-c057-4274-8694-9ca5adc2b121','algorithm','HS256'),('53ada28a-b281-4de6-8dc0-b1ca265d5119','fd37d4bc-dfce-4031-9ffb-b55280438a25','secret','u_tsi-tPTkFx_evQluSjYQ'),('5569dedb-8f5b-4c1e-a733-9afdd74bc27e','8e17d7c0-2557-4e3c-b4c0-f54fd03c9693','allowed-protocol-mapper-types','oidc-full-name-mapper'),('55d320c3-202c-4e6d-a66f-d5618d4a126f','ca974dea-4e17-4d0e-8c4e-da1c54396693','allowed-protocol-mapper-types','saml-user-property-mapper'),('55e3d449-ece3-42ae-ba28-1c8e4a6f2a0c','9a0b8b92-4257-4911-a948-6d0a89644198','secret','yT_GJu3EX1NZO9eA1KtTXw'),('57ce3761-e049-4182-9fe9-6e340af81a75','4f350012-6daa-4af2-b5f8-a7f5904f95c6','allowed-protocol-mapper-types','oidc-full-name-mapper'),('58ffb181-247c-4720-ae8e-612fbe89bf84','0a3f24bf-067c-4d7a-9de5-df3bf64daf31','allow-default-scopes','true'),('592477ed-6087-4fa5-beaa-4d01cee29369','0f2de35b-7745-490e-80dd-850657436c56','allowed-protocol-mapper-types','oidc-full-name-mapper'),('5e165294-2696-455e-a2b3-70c5687b020e','a8a221a5-0304-4825-b9c0-f2a288b4cdac','kid','0be036d6-7413-4d11-a68c-66abd2f1c72b'),('5f8a27fa-0875-4819-9d6b-7cb440949a79','0f2de35b-7745-490e-80dd-850657436c56','allowed-protocol-mapper-types','saml-role-list-mapper'),('63cd951f-d074-42ba-b671-6bf091a48916','2f6d4da9-637b-453e-8332-025bdf01f579','allowed-protocol-mapper-types','oidc-usermodel-attribute-mapper'),('65d84cde-f1c4-425a-abb3-0797c0930316','815fe376-b55c-482f-9848-5833feaacba7','kc.user.profile.config','{\"attributes\":[{\"name\":\"username\",\"displayName\":\"${username}\",\"validations\":{\"length\":{\"min\":3,\"max\":255},\"username-prohibited-characters\":{},\"up-username-not-idn-homograph\":{}},\"permissions\":{\"view\":[\"admin\",\"user\"],\"edit\":[\"admin\",\"user\"]},\"multivalued\":false},{\"name\":\"email\",\"displayName\":\"${email}\",\"validations\":{\"email\":{},\"length\":{\"max\":255}},\"required\":{\"roles\":[\"user\"]},\"permissions\":{\"view\":[\"admin\",\"user\"],\"edit\":[\"admin\",\"user\"]},\"multivalued\":false},{\"name\":\"firstName\",\"displayName\":\"${firstName}\",\"validations\":{\"length\":{\"max\":255},\"person-name-prohibited-characters\":{}},\"required\":{\"roles\":[\"user\"]},\"permissions\":{\"view\":[\"admin\",\"user\"],\"edit\":[\"admin\",\"user\"]},\"multivalued\":false},{\"name\":\"lastName\",\"displayName\":\"${lastName}\",\"validations\":{\"length\":{\"max\":255},\"person-name-prohibited-characters\":{}},\"required\":{\"roles\":[\"user\"]},\"permissions\":{\"view\":[\"admin\",\"user\"],\"edit\":[\"admin\",\"user\"]},\"multivalued\":false}],\"groups\":[{\"name\":\"user-metadata\",\"displayHeader\":\"User metadata\",\"displayDescription\":\"Attributes, which refer to user metadata\"}],\"unmanagedAttributePolicy\":\"ENABLED\"}'),('66b4faec-4f2b-4446-a876-f7cefa5b7e15','9c25a697-cd42-40fa-a47e-42d3a754c43a','allowed-protocol-mapper-types','oidc-full-name-mapper'),('6701229a-1445-477d-bb90-fe2276f2267a','8e17d7c0-2557-4e3c-b4c0-f54fd03c9693','allowed-protocol-mapper-types','saml-role-list-mapper'),('689a39c5-ebd1-4116-a49a-1746ac9d4a3f','137ba95a-167d-446c-bf80-afc78ee43164','kid','a6dc1e4a-897f-4f32-a6fb-b216f11badda'),('6b38f153-5f0d-40a7-acf4-3da6d23d5988','7471a241-ce38-4639-88eb-bd9d675abb68','priority','100'),('6bdbbb69-ff22-4b8b-bd74-069f4b04be53','ccafc9dc-c46d-4152-b826-ceed1fa8603b','priority','100'),('6bf2fff8-8640-4080-a37a-1c424c82e36b','ca974dea-4e17-4d0e-8c4e-da1c54396693','allowed-protocol-mapper-types','oidc-usermodel-attribute-mapper'),('6cca9d25-f00e-44e6-a2a8-4c029a88ace4','46ef48a2-728c-479c-b72e-8a9c11875e8e','secret','GCH1jCVXVcJglPLQUiUAh_Xo0RKXCkmQ6i1aKK06otjdX1Ktz-Rtk66ElISdiNNJR9aUxdIyREoolkEyJL_09w'),('6d0fcaa8-4f11-4c05-8dde-c7f7f483d0d8','46ef48a2-728c-479c-b72e-8a9c11875e8e','priority','100'),('6ee15807-72a6-49a5-a578-d9bcddd1cd8f','d3cd434b-6615-46df-9538-47542fc703e4','max-clients','200'),('6f3d1182-d1d6-47ef-b699-018d876587ae','ca974dea-4e17-4d0e-8c4e-da1c54396693','allowed-protocol-mapper-types','oidc-address-mapper'),('74a417fe-8196-438e-8706-c51f982fb3f4','4f350012-6daa-4af2-b5f8-a7f5904f95c6','allowed-protocol-mapper-types','oidc-address-mapper'),('74d619ea-5326-45f7-a4fc-f62ba7aa2596','c0654b8e-517a-4ca4-834a-7a01b80dbf01','priority','100'),('7fd8c60e-c85c-4b64-acf9-2af98520fc7e','5e680211-0235-45e7-8236-d04ccd305b2a','kc.user.profile.config','{\"attributes\":[{\"name\":\"username\",\"displayName\":\"${username}\",\"validations\":{\"length\":{\"min\":3,\"max\":255},\"username-prohibited-characters\":{},\"up-username-not-idn-homograph\":{}},\"permissions\":{\"view\":[\"admin\",\"user\"],\"edit\":[\"admin\",\"user\"]},\"multivalued\":false},{\"name\":\"email\",\"displayName\":\"${email}\",\"validations\":{\"email\":{},\"length\":{\"max\":255}},\"required\":{\"roles\":[\"user\"]},\"permissions\":{\"view\":[\"admin\",\"user\"],\"edit\":[\"admin\",\"user\"]},\"multivalued\":false},{\"name\":\"firstName\",\"displayName\":\"${firstName}\",\"validations\":{\"length\":{\"max\":255},\"person-name-prohibited-characters\":{}},\"required\":{\"roles\":[\"user\"]},\"permissions\":{\"view\":[\"admin\",\"user\"],\"edit\":[\"admin\",\"user\"]},\"multivalued\":false},{\"name\":\"lastName\",\"displayName\":\"${lastName}\",\"validations\":{\"length\":{\"max\":255},\"person-name-prohibited-characters\":{}},\"required\":{\"roles\":[\"user\"]},\"permissions\":{\"view\":[\"admin\",\"user\"],\"edit\":[\"admin\",\"user\"]},\"multivalued\":false}],\"groups\":[{\"name\":\"user-metadata\",\"displayHeader\":\"User metadata\",\"displayDescription\":\"Attributes, which refer to user metadata\"}],\"unmanagedAttributePolicy\":\"ENABLED\"}'),('8191bc3f-d2d6-40bb-a81e-9fd061b337a5','4f350012-6daa-4af2-b5f8-a7f5904f95c6','allowed-protocol-mapper-types','saml-role-list-mapper'),('81f82500-66d4-4c47-80eb-ca4f1efdd914','0f2de35b-7745-490e-80dd-850657436c56','allowed-protocol-mapper-types','saml-user-attribute-mapper'),('845dcb79-7921-46db-901f-c3e38e2174c2','39a2533a-f944-491d-b419-46770e25c58b','kid','3c6668fb-fb7b-43ce-a901-f52a34a4b26f'),('85ba43f6-5d32-4102-8402-aab600955f17','fd37d4bc-dfce-4031-9ffb-b55280438a25','kid','5717f654-6cde-4825-8432-ab9573b1388b'),('87adc3ab-339c-4f62-a13e-af8f2f8ab816','2f6d4da9-637b-453e-8332-025bdf01f579','allowed-protocol-mapper-types','oidc-full-name-mapper'),('893fedd2-6671-424e-80bf-794f18275afd','ddf9e42a-d618-4231-938c-98d5cf7187ef','allowed-protocol-mapper-types','oidc-address-mapper'),('8ab1cd94-f594-47bd-a5c4-b275f3c3976a','cfe5e0bf-1246-4f61-8ee2-fbcd7362d184','allowed-protocol-mapper-types','saml-role-list-mapper'),('8b449a6c-bf00-4081-a20e-a3a7baf0a299','cfe5e0bf-1246-4f61-8ee2-fbcd7362d184','allowed-protocol-mapper-types','oidc-usermodel-property-mapper'),('8c3b1487-1129-4405-a0b4-d2c76acd4925','c0654b8e-517a-4ca4-834a-7a01b80dbf01','privateKey','MIIEpAIBAAKCAQEAntxZq1xRn1BPalZuMyFIHK+Vweu07e4Wo/VQh1e+iIfXTJfYbndzIb6w/gPgMmDWwpUF/Ot1UwUqX3XXpcpmSyZz+Je8kq3Cm+f6U4GqiijffSNfJIs/ODRKHTBZ1O77HEtOsaRu7b5rysfG05x8n/u5LhWuQ94gcCYEY731CC6rzjCYZNLUNLn1H5/aHVyDwodjHSGRjsW6v63FzmABlI2Bzrt37U113iIk7PrFPkMXqu9cd1JcaA9nozo7YWt6d8wl6Z7ZnYbO0rXbH3NZdZfjVwZcd5NeaZpBvqcTuI72OTBJBmjAd/eNHhmXlaaxRb+kdnjrsIPZjs7wwUzjawIDAQABAoIBADlr+rmXKCXG+L2+Oh0fNZqw2Rf8ZCzwt5xSSuZxD/z35RnZdTEQ2jvjWsSmj/6FxHsXNM/kKEd3AYb56JYT3//gCWFdL5txVXvXUUOoBgXkmkv4YiaqcpKVTAja9k2iiIAEtJA/mJ01DG+C4NqSoPWPHrOKwK/ldaI0C7gl7JElAtczX+qlrRhdS978A7rhGctsAXg6sPwVQtDu0N9s+sjuK/4/Ad0PNYpdAkNP0n/aZhDSoXb3xPoPFwBc2hp/EWiVRc32VyUZiifKA3LBsuHiI+4EFlwv0nEosc6Oq7eUQOCJmd243OpMab0Rx9Cda+lOecim471ZvWzMb4FoUrkCgYEA4fbbR0spY1McupbdLZjpm1AXhYxgSkHmcRGhZh4sU0a8uE1LorgZPCbTyjtEsfTm5Ey8Q4lcIaAv3KZB28qBk7X+vGkwsXmToY8f6vIJpXLOulRe8WFz1QdyK/faag5hzCg9zhwzJTVi5ncAbJbHNTryX04wLn0tcCVIz35MCiUCgYEAs/oV1kKc5as9zYurLubCX4rD2HZPKxCW+zMScD3WDKA3l5W+HYwUDCNS7fbn152OaNOKxOEcMbR5dk9fdt0GlVqaELYVghy+yHzp1sBvv337YYcZyto7ACCwJxNLgkWIrm3QmMUzCdUgd7xRK2boFLupAHq4oKABK8EPS882Gk8CgYEAqjuMVTiVtKNfqF6RwJFLpNuA7PalcCwXjKVIn6Mpp49KC9sHmU3yjPN/aQKfrSWgcOwyhPrNsvN4O1XxlcEJP5vDjnP84CeEhhlKZXj0tXU5svxvDpBpcFsMs30lSfMN0H2cmlN6YJTIrnGGm0g4Sazf/dbsy4k4mx0rrk4qwRUCgYEAmbyw1puERrOmUWRTT/cSZma0sL0vF0xOjDmuMG7B33skwbnJ8pdrsIqkFl3o4UfXFDhPu6nHWbYeYy+eDnzzWLVSEaBYcxJ27e+2GBm920eUalTrdVpBN/S0REy5HYikHsvzeexJksaZu24DsB1xdfRvgtdRyvOizGtX05wnTQUCgYB3yWg19KVtxjNj8ePTZI1ChJI88Q5HUW6f5mGpB5qKZQ+/kWQNGh0rZK4uemQD/QR0xqnXEJ/XGEqf0dof/wBWAAR5eiGEVAGR4vTky21IlHa0ncsRpEWVdE+onj6sjrFe4O095WywIHYVXYDxhczDG9wRNjMJkxAjQh+d2nHWZA=='),('91a2d595-d075-48af-b000-63ca7d396e7a','66d2b7d2-1518-4922-9cd3-97cda703360b','algorithm','HS256'),('92c3402f-33cf-41c1-802b-e9e2cd9309dd','d20d8481-15f9-46c4-8799-bc6b6753172f','client-uris-must-match','true'),('9309c2ab-ad53-41c6-a696-f1b44da6e15d','61ef42a6-d394-40bf-8af0-b7724d392933','max-clients','200'),('94f8826e-0321-401a-adb3-e879f7f4dae7','2f6d4da9-637b-453e-8332-025bdf01f579','allowed-protocol-mapper-types','saml-user-attribute-mapper'),('9524315f-1dc4-4f48-b263-89d722265817','ccafc9dc-c46d-4152-b826-ceed1fa8603b','kid','81114cf8-1554-4e8d-bcf8-600aa6ef6080'),('98dfc199-5d29-4f32-996b-8744d5a34666','ca974dea-4e17-4d0e-8c4e-da1c54396693','allowed-protocol-mapper-types','oidc-usermodel-property-mapper'),('9b5fc2df-2ccc-4ed2-b492-a3cdb12b68fd','ca974dea-4e17-4d0e-8c4e-da1c54396693','allowed-protocol-mapper-types','saml-role-list-mapper'),('9ca459e2-d37c-4752-ae7b-fbc2c6bea139','66d2b7d2-1518-4922-9cd3-97cda703360b','secret','VkJiOpkqPXu_xcnRRaFryZwh0925fKt-EtO4TsqZMjFqrSufIgFbU8Om4NrHC6Z41TVwVilwFFZ_Ho3jvEEBnA'),('a41a3115-3aad-4876-a351-be50856fcca3','46ef48a2-728c-479c-b72e-8a9c11875e8e','kid','8f1ee7ec-47fe-4b98-b292-bbeebb9d5251'),('a43a6873-d7c5-4e13-b7dd-24039a12f3ee','ca974dea-4e17-4d0e-8c4e-da1c54396693','allowed-protocol-mapper-types','oidc-full-name-mapper'),('a4b89d65-a926-44d2-ab87-b78737a1d03e','decee23a-28c9-4bbb-bcfa-64f419b386d3','priority','100'),('a5009229-96d8-4d1e-b8f1-4487f4e5930e','66d2b7d2-1518-4922-9cd3-97cda703360b','kid','e9456fd5-a470-40b1-928a-b261f6b26ede'),('a5c21a78-2e5a-442a-8019-ba7a7999efb6','39a2533a-f944-491d-b419-46770e25c58b','priority','100'),('a887d193-086d-48a1-afff-f0def376432b','f0006121-bd47-4ab3-8039-b060a52fcd74','client-uris-must-match','true'),('a9121e37-aedc-4e2a-bd2e-621904ca953c','decee23a-28c9-4bbb-bcfa-64f419b386d3','privateKey','MIIEpAIBAAKCAQEAubZNwliR7jvrOXc2SJYhDlJ1NRAOZXFp3xKR5EeZFxBVlzkKKwibX+BZyXYFXAmHrwqaoDX+Eqfws3Gjfo5V990Ge81XSv5y2NtX1xjuhy2RhZCUA84nKkKt1fzFkMJu5cS6zP7nmu+zMjREuEMeW/NkcehDrKGI3o/CcXaxAvTK6Bh9sTBshre/CGRXi2Y9m1PQJPTrePvBZFHxBwS9eST+rg02uGeLb4XhbFD7pP5HEGXrGqc+D2RpmuNU4Efyr7AxnnSN0+Pde8isRFjzGYuXEbnTTMjd+1gSCywhZAgCA73MUbeS2A+nfLlKHAzd5kMIxAA5W+Uuqk7dk+RCiwIDAQABAoIBAQCoDXF2QcHkjHJCsT79FmXZWQLZPqtYXvYIN/yvT58YQN7DFom+AW7gptt5NASLkdAntPfRrKo65aAqMdZaSqE+x9L7KwkoQvNYi7yEV/pZdwHtlLRscRv94RL/xlpdsaS65XiI0s5w5SIKd0QMXihV2v11GlJLIG4DwKGbHWX3HlEvdEMB0HS8cRS7HyjL/YuGVqRTRtXMq1g559QbIqQ99QQyjJzb5izl502pftC6sxub0IOZ9236oPXXJkf6RAR0eo1FNcfYbMPL/TMbvcACFAy8mXhQ94aioZPJ+BQ8WWG4+mzRO/8NElur9Nq452hjnFY5f7X7n1OVEoiRByUhAoGBAPpSf6iocjyvsaKC7s7dPlnQQHuWwDnfKZaH9Duo/C7o6tHEzsBWR+IM9xJKNoYrsludV2iP9QNugm8KGaxmIprm9gDkmSCUc0bXGxFcjR/1W7CPCvNC3lJX7cwNPHtvpd5CBgHxyGgpK8gl+kDx7US3m3d9Y9oFjByIcnECS94bAoGBAL3spR6meNMDxosdDWYiI47XfDa9mQwdafn5NJnNHYaP4GEi0ylH9LUWTq68zDfivHeFdmFPW/GA+5m5l7jr2NBcBCy/P5lfNTUYpTwSpOBmCaJLsk2OFsRic+KDEA+tNjee1q+QvUKwF7vlzGAtOf9yxu7f9fMn5RpHyWpAqLRRAoGBAOUZzmbBTFSIhK504TYJPYCb3fh+/4231mtEIN7diXkxiYDVfFiCXyXfsd1WeNKReZrpxU8Yuika4lvYRakIjVFyYuJsVk2AMIU8aDSanTsLp5BPSrlbkPiSKzzfPGTIyWlCyhbLgBz82WpEf+cixIJo/Ov+of2vqA2RQBR4ApHTAoGAG8D+LCl1lJiDpgab06X/fjs9Gp7AQ8X0m6PwLN2NiAF0b51wMCMkvmXBH8XVLgGDOxAUyYmYTQVlPwShCFPmviQENCnKeHYyR00PsGSlFWmz1LStHKo753zfpGU0rqXIO36JruQ+1AT5ouqk4BUb2ZmDOpsdzOeykhGVfGJwhNECgYB0AilSHd1jm/rSEef/HY/FJWbndAj/180wPGEg4GdZHFPnBlL+1p62+DupkZdfUrzQNTKAhqmW3QN4jHQbYxA0stMIiv8rFyx+4cqVLZScG/GdrqvCDysiy0i0gH6QOWtwtXV3SAw+FaR76c9nIZQ0VLEsUMo0bWcOjwiTWiXU3w=='),('abae53fe-bbbb-41dd-945e-25e0061b94a4','fd37d4bc-dfce-4031-9ffb-b55280438a25','priority','-100'),('abafdf49-391f-4b56-8b61-40aa5cd7e1a8','6777836c-e503-4ba3-b02b-6bee92c28713','kc.user.profile.config','{\"attributes\":[{\"name\":\"username\",\"displayName\":\"${username}\",\"validations\":{\"length\":{\"min\":3,\"max\":255},\"username-prohibited-characters\":{},\"up-username-not-idn-homograph\":{}},\"permissions\":{\"view\":[\"admin\",\"user\"],\"edit\":[\"admin\",\"user\"]},\"multivalued\":false},{\"name\":\"email\",\"displayName\":\"${email}\",\"validations\":{\"email\":{},\"length\":{\"max\":255}},\"required\":{\"roles\":[\"user\"]},\"permissions\":{\"view\":[\"admin\",\"user\"],\"edit\":[\"admin\",\"user\"]},\"multivalued\":false},{\"name\":\"firstName\",\"displayName\":\"${firstName}\",\"validations\":{\"length\":{\"max\":255},\"person-name-prohibited-characters\":{}},\"required\":{\"roles\":[\"user\"]},\"permissions\":{\"view\":[\"admin\",\"user\"],\"edit\":[\"admin\",\"user\"]},\"multivalued\":false},{\"name\":\"lastName\",\"displayName\":\"${lastName}\",\"validations\":{\"length\":{\"max\":255},\"person-name-prohibited-characters\":{}},\"required\":{\"roles\":[\"user\"]},\"permissions\":{\"view\":[\"admin\",\"user\"],\"edit\":[\"admin\",\"user\"]},\"multivalued\":false}],\"groups\":[{\"name\":\"user-metadata\",\"displayHeader\":\"User metadata\",\"displayDescription\":\"Attributes, which refer to user metadata\"}],\"unmanagedAttributePolicy\":\"ENABLED\"}'),('abfdf2a7-bca1-45d3-8f8c-e8d5591ed65d','0f2de35b-7745-490e-80dd-850657436c56','allowed-protocol-mapper-types','oidc-address-mapper'),('ad83caf8-eca6-4349-8835-24059bbdd440','c28e3df5-03e4-4df5-81c6-bdcd22d00e56','host-sending-registration-request-must-match','true'),('b03f764c-f169-45a9-98e6-dfc0ce750537','4f1fc2ce-324f-4e91-b0bf-ddb55d3c3a0d','max-clients','200'),('b1b30bcb-c0ef-4784-87dd-c89420563b68','cfe5e0bf-1246-4f61-8ee2-fbcd7362d184','allowed-protocol-mapper-types','saml-user-attribute-mapper'),('b2704b9f-e964-4e10-bfaf-e67721b801c5','d2a01090-9980-4d9d-a791-732c229cffbe','allow-default-scopes','true'),('b3282684-d255-4fbd-97e2-4cad1b602b69','ccafc9dc-c46d-4152-b826-ceed1fa8603b','secret','CUSr09jP1FylrgqK1ZNXCckcpc6ME-8nUSPx7Ph7vq2WDiN8gan3he0ka8CeoR5K8CKg7lR_216h51M5IpEUKA'),('b4585abc-db4f-4c8d-99d8-e7a82ae246a3','ca974dea-4e17-4d0e-8c4e-da1c54396693','allowed-protocol-mapper-types','saml-user-attribute-mapper'),('b5a27731-34d6-4fb9-a57f-664564be36f4','49d50209-e174-4587-a4f8-39d60ed1c692','priority','100'),('b6e214eb-0f84-41dd-ba61-56afee4275dc','4f350012-6daa-4af2-b5f8-a7f5904f95c6','allowed-protocol-mapper-types','saml-user-attribute-mapper'),('bb3cba7c-abf5-4e52-b392-de9c2a34eb17','66d2b7d2-1518-4922-9cd3-97cda703360b','priority','100'),('bc25e9bb-7f82-4eae-b4ce-bf11ac07d69e','0f2de35b-7745-490e-80dd-850657436c56','allowed-protocol-mapper-types','oidc-sha256-pairwise-sub-mapper'),('bc4b68f8-7570-407e-8d84-10b7541dfe38','ccafc9dc-c46d-4152-b826-ceed1fa8603b','algorithm','HS256'),('bc71eda2-f442-4d20-b66a-bc66c66a4489','8e17d7c0-2557-4e3c-b4c0-f54fd03c9693','allowed-protocol-mapper-types','oidc-sha256-pairwise-sub-mapper'),('c278acf8-554d-4ae8-a865-74b9aab3f5b7','cfe5e0bf-1246-4f61-8ee2-fbcd7362d184','allowed-protocol-mapper-types','oidc-full-name-mapper'),('c41b155a-9752-4ee8-a78f-9754b5817499','cfe5e0bf-1246-4f61-8ee2-fbcd7362d184','allowed-protocol-mapper-types','oidc-usermodel-attribute-mapper'),('c5e77822-77f2-437f-aef0-790119640abe','9c25a697-cd42-40fa-a47e-42d3a754c43a','allowed-protocol-mapper-types','oidc-usermodel-attribute-mapper'),('c7813bab-e3f4-45ed-a6d2-eb538a02fd6d','d20d8481-15f9-46c4-8799-bc6b6753172f','host-sending-registration-request-must-match','true'),('cb74c7ed-7cc6-479e-993e-10dbfa4552bb','9c25a697-cd42-40fa-a47e-42d3a754c43a','allowed-protocol-mapper-types','oidc-sha256-pairwise-sub-mapper'),('cd3059c8-4735-42fa-a821-b80587763cac','a8a221a5-0304-4825-b9c0-f2a288b4cdac','priority','100'),('cf385bfc-94c4-4620-94f1-d65673f2bddf','b28cf178-dd17-406b-ba78-d3fe47126065','privateKey','MIIEpAIBAAKCAQEA0HuZD1rQn2CZ2oIUu/uI6n0nSTQnFgHc1Y9AD83Idn9aS2XEbnBxgxeYiRkrpOZv0SFYZF4NzxOWq2/+DMrXspcevhCpVZeQr3UP6XnP1mytjKdVyOHsoYGSYQVCMU/4F9RJ1zQ0QXXekEyVbIct1ZEA5NEnruq6k2D6oXeIpbgLGVU61dYzzfIOxibnJkhff8L2RFvY0bcE7+uEYYMsp9xfRv2r1gtj5lbi0vaXR8EcyBaokugRIUhMeV0C3Tdwr5wCeea2hrTntg0TxizNH8vits6uOqDDWDSADJiUdYKeKyVOVThP+ZMe8STEIDKn/uqmylUazXkZGyogx1RcmQIDAQABAoIBAQCgUFqbVw8Tbzn/r4V4I+zdu41pGiRwJNCGm9f8DxZ2IGnzjnblIav3zT4rNmK8M8KKAuUwkK53rK1wePbXKWeB2fj22GMOATVt5kttEpFCZmFxxf8OMMRAUR2ZY2zJ9J9m24RIaslACP4y4eEJCk2xawZP7ZFhTPhZefpgDUXTf3YbM1HiSQZfKfX6M+nEh9pRMfSo4u7KiwHgw/x576H6nIuhMhyT1Vk61/ZHj5/RHQY2yuRPiQ+dEfWXFG2kp6RDDmMFSdtUphQDjEOIqvDTNA+Sd9YN+UaeoVYlLoEP2bTtVDE1vk1aHIln3JkuirR/YVw7Qpuk/EZilDF/6lXxAoGBAOp4GGaTDFoSTFG0kKTxPM1/6vxVrapxaxCF+D2ibEZAk1vLykBoEv6uo1VmHBQhCQsaUeR4CVk/1SMxochuNhrJbT8mbx0dQ3dwZrgVULm5D5+BixER+9vfWhupn4PgZBCzKJG6Ok2LSyW/gnDnqTQLHt954AfW5SBhncXw2KkNAoGBAOOgnZ7btU8sbISn6oNzZwtWPupeUVKiQ9CNF/EN9X16PuX6i1knCQ6Ziebnibhb78C/Sysu+Wbuqi2OqAm1A7fqsLc/bX9RsVHTQoscndRjz1qT7jQSjiIZbY/p0yw8SfIr/ecB5xaxOWbXQMawzauYxpBCtkZRUfOj/c7oPka9AoGBAKXTFf7FlQDG3C8U8w+UhZoZFAouVkqrODtRZIXCr6zn0tAjSwFOGdEBlga51rXtv0WY8b4Rnxr96DGh0ne8aot7VcZJ2l/O6H46gotCl/siBQicR8xk2alhR4s05doRAvREoTafbMiW8SjbTtenH6XtD4Kh4W3p79Z882agtbqpAoGAJEOteOaV7yQrscKyuPiEvSijY2FdYWXamfowi0XnC3OTW75bvvtaFQpfDvtqVIXJH5MaXanhMAXr9NAac1l0WzO3raocPsF8F4YpvtHzTygLm+mfdIpUPJiCfQAKlayRN1TM4aXK9DGN7JV0i3MVgTYYxFjsgy1negJxaCpV6Z0CgYBNkE2wHta+Qhxw9aXDZXrZ0G1T7mE/oxBU5b4u23/gZ4QCjOvGpr3bde69RTYMwcRMtpLeCVPyvGhjs0xylDDT/myQxuvLUjZ9BlD7ANc1VMrOfUKTDhlbSD6nWNk/3IwDRc6j3rwD5Ffs+NxeDTgtheOtaum3bI+uEwgGzrRqmA=='),('d029d0e3-4277-46ae-a487-4c9dd95dfb21','a8a221a5-0304-4825-b9c0-f2a288b4cdac','secret','jydoN8aQzZ3gZmow6mFzDw'),('d2964a1e-c7aa-444e-8e07-fb61f120bb6f','9c25a697-cd42-40fa-a47e-42d3a754c43a','allowed-protocol-mapper-types','saml-role-list-mapper'),('d3de67d4-c49a-4fc2-a8e5-c68c8432fae5','137ba95a-167d-446c-bf80-afc78ee43164','secret','vZdsFddRGOJgZhndHL4-Hw'),('d6044163-e9df-465b-8236-6ac524b6e200','f0006121-bd47-4ab3-8039-b060a52fcd74','host-sending-registration-request-must-match','true'),('d71e73fe-d650-4d7d-8b57-4e0e2f3264e4','0f2de35b-7745-490e-80dd-850657436c56','allowed-protocol-mapper-types','oidc-usermodel-property-mapper'),('d79ce3cb-dcd2-4520-a4c8-4b38d9532335','8e17d7c0-2557-4e3c-b4c0-f54fd03c9693','allowed-protocol-mapper-types','oidc-address-mapper'),('d7f19bca-b7aa-4f73-bc81-592e1ccc3d0d','7471a241-ce38-4639-88eb-bd9d675abb68','kid','4896e3fa-ec23-4c8b-b8cb-40f01f8d6d13'),('d89a642b-3204-4812-aa17-fecad56eb381','4f350012-6daa-4af2-b5f8-a7f5904f95c6','allowed-protocol-mapper-types','saml-user-property-mapper'),('d8afd2de-cbc7-4f7a-a626-37f68ef9d3da','2f6d4da9-637b-453e-8332-025bdf01f579','allowed-protocol-mapper-types','oidc-sha256-pairwise-sub-mapper'),('d9b4da1f-d9de-4090-ad59-07289240ccc2','8e17d7c0-2557-4e3c-b4c0-f54fd03c9693','allowed-protocol-mapper-types','oidc-usermodel-attribute-mapper'),('da6404e8-7293-415d-b323-6a64e3b8f1c2','ca974dea-4e17-4d0e-8c4e-da1c54396693','allowed-protocol-mapper-types','oidc-sha256-pairwise-sub-mapper'),('daf131b3-9455-4f68-907e-808ccbf38585','426a718a-aa81-431f-84cc-802932cb615d','algorithm','RS256'),('de597656-8477-4b8c-80c6-e68ba42ea2f5','9db23f98-215c-4267-b4be-b81ba957f0a6','allow-default-scopes','true'),('e1f57994-d248-4425-9dfb-e315ab34c915','4f350012-6daa-4af2-b5f8-a7f5904f95c6','allowed-protocol-mapper-types','oidc-usermodel-property-mapper'),('e59d714e-832e-4939-808e-b24bef1903a8','9c25a697-cd42-40fa-a47e-42d3a754c43a','allowed-protocol-mapper-types','saml-user-property-mapper'),('e85ab7df-522e-4ddf-85f3-cd8be0faa8d2','46ef48a2-728c-479c-b72e-8a9c11875e8e','algorithm','HS256'),('eca91a90-4024-4472-ac42-e8aae0df18ce','d4ceecc6-257f-4c05-a5b2-1e8c01942c98','priority','100'),('eeb87e62-1334-4408-9567-428316d56b10','0f2de35b-7745-490e-80dd-850657436c56','allowed-protocol-mapper-types','oidc-usermodel-attribute-mapper'),('eef16aed-d1cf-4488-905f-b6187b6289cb','ddf9e42a-d618-4231-938c-98d5cf7187ef','allowed-protocol-mapper-types','saml-user-property-mapper'),('ef0efcbc-82ad-4c17-b2ec-53eca3fe4081','5aaff54e-2e56-48f9-a260-403dfc1043b6','kc.user.profile.config','{\"attributes\":[{\"name\":\"username\",\"displayName\":\"${username}\",\"validations\":{\"length\":{\"min\":3,\"max\":255},\"username-prohibited-characters\":{},\"up-username-not-idn-homograph\":{}},\"permissions\":{\"view\":[\"admin\",\"user\"],\"edit\":[\"admin\",\"user\"]},\"multivalued\":false},{\"name\":\"email\",\"displayName\":\"${email}\",\"validations\":{\"email\":{},\"length\":{\"max\":255}},\"required\":{\"roles\":[\"user\"]},\"permissions\":{\"view\":[\"admin\",\"user\"],\"edit\":[\"admin\",\"user\"]},\"multivalued\":false},{\"name\":\"firstName\",\"displayName\":\"${firstName}\",\"validations\":{\"length\":{\"max\":255},\"person-name-prohibited-characters\":{}},\"required\":{\"roles\":[\"user\"]},\"permissions\":{\"view\":[\"admin\",\"user\"],\"edit\":[\"admin\",\"user\"]},\"multivalued\":false},{\"name\":\"lastName\",\"displayName\":\"${lastName}\",\"validations\":{\"length\":{\"max\":255},\"person-name-prohibited-characters\":{}},\"required\":{\"roles\":[\"user\"]},\"permissions\":{\"view\":[\"admin\",\"user\"],\"edit\":[\"admin\",\"user\"]},\"multivalued\":false}],\"groups\":[{\"name\":\"user-metadata\",\"displayHeader\":\"User metadata\",\"displayDescription\":\"Attributes, which refer to user metadata\"}],\"unmanagedAttributePolicy\":\"ENABLED\"}'),('efc5b58e-84fd-4e58-b8ba-a32425c6a6de','b28cf178-dd17-406b-ba78-d3fe47126065','priority','100'),('f484b350-5912-4826-ba14-81a167b5d9f4','2f6d4da9-637b-453e-8332-025bdf01f579','allowed-protocol-mapper-types','oidc-address-mapper'),('f5db0199-30b9-4f58-a14e-13db70344b32','ddf9e42a-d618-4231-938c-98d5cf7187ef','allowed-protocol-mapper-types','oidc-usermodel-property-mapper'),('f7ca2109-a0e3-42c9-a916-7789cfb0de3c','ddf9e42a-d618-4231-938c-98d5cf7187ef','allowed-protocol-mapper-types','saml-user-attribute-mapper'),('f7f8d4c7-00ba-4610-8d79-bd42f7e6b5b9','d4ceecc6-257f-4c05-a5b2-1e8c01942c98','algorithm','HS512'),('f844fad0-6d06-47da-ae92-db8545d2d137','8e17d7c0-2557-4e3c-b4c0-f54fd03c9693','allowed-protocol-mapper-types','saml-user-attribute-mapper'),('f8467137-1bb2-4111-b81d-8152c0b7077d','ddf9e42a-d618-4231-938c-98d5cf7187ef','allowed-protocol-mapper-types','oidc-sha256-pairwise-sub-mapper'),('f9c44769-b32e-4fc5-b323-155b2382d65e','cfe5e0bf-1246-4f61-8ee2-fbcd7362d184','allowed-protocol-mapper-types','oidc-address-mapper'),('fc60219e-6412-46e7-b1ca-e5dfde54af3c','49d50209-e174-4587-a4f8-39d60ed1c692','kid','579a8847-5dac-450b-819c-d7acd0968030'),('fd1a8d7d-b75d-4ff2-81a3-f84b768b1f91','bc33edc9-c057-4274-8694-9ca5adc2b121','secret','0i_JMrFpQFFES4i95SrG1wNjCppZmpwCMcZde5lCAIPqN3BrpCubu56sBfpU_QFxNuG1385Nk8OT-I9EDR66pw'),('fe4bae8c-6d4b-4aff-ad08-fa88e5c1bf96','8e17d7c0-2557-4e3c-b4c0-f54fd03c9693','allowed-protocol-mapper-types','saml-user-property-mapper'),('ffad0610-1826-4373-a6dc-94b554a870cc','9c25a697-cd42-40fa-a47e-42d3a754c43a','allowed-protocol-mapper-types','oidc-address-mapper');
/*!40000 ALTER TABLE `COMPONENT_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COMPOSITE_ROLE`
--

DROP TABLE IF EXISTS `COMPOSITE_ROLE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `COMPOSITE_ROLE` (
  `COMPOSITE` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `CHILD_ROLE` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`COMPOSITE`,`CHILD_ROLE`),
  KEY `IDX_COMPOSITE` (`COMPOSITE`),
  KEY `IDX_COMPOSITE_CHILD` (`CHILD_ROLE`),
  CONSTRAINT `FK_A63WVEKFTU8JO1PNJ81E7MCE2` FOREIGN KEY (`COMPOSITE`) REFERENCES `KEYCLOAK_ROLE` (`ID`),
  CONSTRAINT `FK_GR7THLLB9LU8Q4VQA4524JJY8` FOREIGN KEY (`CHILD_ROLE`) REFERENCES `KEYCLOAK_ROLE` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COMPOSITE_ROLE`
--

LOCK TABLES `COMPOSITE_ROLE` WRITE;
/*!40000 ALTER TABLE `COMPOSITE_ROLE` DISABLE KEYS */;
INSERT INTO `COMPOSITE_ROLE` VALUES ('032f3007-2de0-4d68-a1f2-2bcb362c49e4','22ffa567-5b11-4982-afc8-f3116f592f31'),('059bac13-47e5-4328-87b6-91d719adb748','8d4c4127-a801-4654-83a1-4ac23c6da4b3'),('0ee3a335-cb19-472e-84d5-57498e202144','2b3dc8b2-ff69-4268-9b64-d2f7f79f4c2c'),('0ee3a335-cb19-472e-84d5-57498e202144','fd58fb2c-7a94-49fc-bc74-1de11d3fe33c'),('18ad43de-71c2-4a8b-ad73-f07085acdf31','31dd067f-5aa5-4ac2-896c-8a42efb5062e'),('242285dd-bda3-4f01-a8c5-8edf054b9c00','22443081-8011-43ff-b0db-7c73d25c8539'),('298e3fa8-5bb9-43f6-8859-f09da0d5c99b','1211a063-da3c-4820-b606-6fd4f291bc9e'),('29a39de2-caac-47cc-bcce-18f040c746dc','1a46e084-3c0f-47a6-a387-8a6a81704c2f'),('29a39de2-caac-47cc-bcce-18f040c746dc','56fbb983-3bbf-434a-9142-553aef29cd68'),('3992601b-152d-4c5e-bcff-7007b41923e3','54f3ba9c-339a-47f1-9c90-7adb0dc81720'),('425151dd-871a-4a94-80a8-8a211b216b55','d4aa5643-4212-404c-8d33-dfc4d4800a43'),('425151dd-871a-4a94-80a8-8a211b216b55','e55c716f-3837-46a3-bc18-f7edd296ef69'),('4a38d073-c8b2-4d2f-a41b-309828b871c8','5bd24075-4f1a-4f31-9646-d152685192a8'),('561aa322-24db-4b3e-837e-95566a8010a1','22d81b87-2705-4b8a-9f17-d8c73bbb8ada'),('561aa322-24db-4b3e-837e-95566a8010a1','56fceb4c-8177-42bb-ae99-b408c919532e'),('573c17a8-7fb7-4771-a70e-9fd0582447d6','01373fa2-c341-4881-8b0e-942183911915'),('6cffa52e-4534-4267-a398-63e94eef7516','bb4fa995-fd79-481b-86bd-a36badee6ddd'),('6e394702-4f6a-4b94-9470-519fd14eead7','14f729d2-c548-4e43-bb0c-d974bc6af896'),('6e394702-4f6a-4b94-9470-519fd14eead7','c181012a-31a5-4a76-acf7-75d7a6e0bb59'),('77ed6c0f-1fa1-4634-8e79-4d65333ca865','28a570b2-8bd0-49f5-a9d3-ab2cafefb639'),('77ed6c0f-1fa1-4634-8e79-4d65333ca865','298e3fa8-5bb9-43f6-8859-f09da0d5c99b'),('77ed6c0f-1fa1-4634-8e79-4d65333ca865','368e1c70-6301-46e4-ae40-067ebe468d7c'),('77ed6c0f-1fa1-4634-8e79-4d65333ca865','cdf78286-af3f-4934-8a79-1a93399bc6e7'),('7a77eaa4-ec6d-4364-9d61-113997360274','22d81b87-2705-4b8a-9f17-d8c73bbb8ada'),('7a77eaa4-ec6d-4364-9d61-113997360274','2e12ca9a-83f4-4aed-98a7-7fa6ea1ba299'),('7a77eaa4-ec6d-4364-9d61-113997360274','3992601b-152d-4c5e-bcff-7007b41923e3'),('7a77eaa4-ec6d-4364-9d61-113997360274','3cccce94-b48e-4c33-8958-4f7657fc314b'),('7a77eaa4-ec6d-4364-9d61-113997360274','48dfb461-04ca-48a5-95e3-1371514e7f0a'),('7a77eaa4-ec6d-4364-9d61-113997360274','5460ad86-a19a-467f-ba48-9c1ad3377b1c'),('7a77eaa4-ec6d-4364-9d61-113997360274','54f3ba9c-339a-47f1-9c90-7adb0dc81720'),('7a77eaa4-ec6d-4364-9d61-113997360274','561aa322-24db-4b3e-837e-95566a8010a1'),('7a77eaa4-ec6d-4364-9d61-113997360274','56fceb4c-8177-42bb-ae99-b408c919532e'),('7a77eaa4-ec6d-4364-9d61-113997360274','5ddd5c4c-e4d8-45d0-a399-d240e8a434c3'),('7a77eaa4-ec6d-4364-9d61-113997360274','5eeae865-ed74-4f5b-8901-8ef7f397fb18'),('7a77eaa4-ec6d-4364-9d61-113997360274','684b9754-6a4e-496d-887b-6c5a9e9b38b8'),('7a77eaa4-ec6d-4364-9d61-113997360274','864c5a94-0990-484f-be31-2a78ed815e00'),('7a77eaa4-ec6d-4364-9d61-113997360274','9bb9ff1d-b7b5-465b-a062-ce5008ff6cf3'),('7a77eaa4-ec6d-4364-9d61-113997360274','a101ab45-c2cd-49c1-9f29-858b1cbfcd1c'),('7a77eaa4-ec6d-4364-9d61-113997360274','a1536262-08cb-4b79-b0db-c676eb890b2e'),('7a77eaa4-ec6d-4364-9d61-113997360274','c43fba40-8523-428c-b2ce-793efe0fa6de'),('7a77eaa4-ec6d-4364-9d61-113997360274','fb46403d-6bd8-43ef-8a34-d4b177c7134d'),('909d09c1-22eb-4144-b5ec-30b8de651dd2','fb4125e3-a3e4-4078-a7d4-1e45370023c1'),('9477a00f-8934-4e15-b988-08202d1975d7','1e93736d-f776-45b2-a96b-d25eea66709b'),('9477a00f-8934-4e15-b988-08202d1975d7','402f483e-b25a-4ef6-a7b5-edd149476a66'),('9ac3098d-e17e-4f43-acd8-efcefdbe37c8','79379a0d-8564-4c5a-9281-80e6e8f9c259'),('9df01365-d95e-4866-af36-e9001bf2d534','00ae66f6-1cf0-44be-936b-9e45bd50c9ab'),('9df01365-d95e-4866-af36-e9001bf2d534','01373fa2-c341-4881-8b0e-942183911915'),('9df01365-d95e-4866-af36-e9001bf2d534','0ee3a335-cb19-472e-84d5-57498e202144'),('9df01365-d95e-4866-af36-e9001bf2d534','16f34db3-a6ac-4df5-b516-16890e1201a5'),('9df01365-d95e-4866-af36-e9001bf2d534','1a46e084-3c0f-47a6-a387-8a6a81704c2f'),('9df01365-d95e-4866-af36-e9001bf2d534','21b3d453-d39d-4fd8-84a0-bf6ee4f2d404'),('9df01365-d95e-4866-af36-e9001bf2d534','26ffdef8-ad2b-4982-b273-13a8613a8fae'),('9df01365-d95e-4866-af36-e9001bf2d534','2830fd54-4c44-4201-bd85-d52bbfc5ee31'),('9df01365-d95e-4866-af36-e9001bf2d534','29a39de2-caac-47cc-bcce-18f040c746dc'),('9df01365-d95e-4866-af36-e9001bf2d534','2ae4040e-08ea-4c17-ac2f-6bbf064c4342'),('9df01365-d95e-4866-af36-e9001bf2d534','2b3dc8b2-ff69-4268-9b64-d2f7f79f4c2c'),('9df01365-d95e-4866-af36-e9001bf2d534','34b02a3d-8a87-46f2-87c5-f909eed28d33'),('9df01365-d95e-4866-af36-e9001bf2d534','41ad038d-890e-4170-82bf-a29bb6490b65'),('9df01365-d95e-4866-af36-e9001bf2d534','425151dd-871a-4a94-80a8-8a211b216b55'),('9df01365-d95e-4866-af36-e9001bf2d534','4932c89c-41ac-4345-be94-39117f2c07fd'),('9df01365-d95e-4866-af36-e9001bf2d534','4a627f10-a570-4e66-8c08-563e2471582b'),('9df01365-d95e-4866-af36-e9001bf2d534','4e3e0eef-4bbe-4828-a15f-e121afe02340'),('9df01365-d95e-4866-af36-e9001bf2d534','4fa64c47-26ef-475a-9e44-28af07a418e9'),('9df01365-d95e-4866-af36-e9001bf2d534','53629c47-2fee-4562-a4dc-a540c93bb3e4'),('9df01365-d95e-4866-af36-e9001bf2d534','53d64e50-e2eb-4a7d-be80-0b8d67ec33f5'),('9df01365-d95e-4866-af36-e9001bf2d534','566678c5-562a-45b4-8471-7337910500a3'),('9df01365-d95e-4866-af36-e9001bf2d534','56fbb983-3bbf-434a-9142-553aef29cd68'),('9df01365-d95e-4866-af36-e9001bf2d534','573c17a8-7fb7-4771-a70e-9fd0582447d6'),('9df01365-d95e-4866-af36-e9001bf2d534','5a889eca-bf6b-4de9-bcdb-c4aa9bf25af7'),('9df01365-d95e-4866-af36-e9001bf2d534','62301597-66eb-4d5a-ac39-9979524c2010'),('9df01365-d95e-4866-af36-e9001bf2d534','6cffa52e-4534-4267-a398-63e94eef7516'),('9df01365-d95e-4866-af36-e9001bf2d534','70f1aa72-6a63-4f4b-8cbc-7e2ad035de51'),('9df01365-d95e-4866-af36-e9001bf2d534','74f0f19f-af21-4bd0-a1cb-4be5ad4f1f42'),('9df01365-d95e-4866-af36-e9001bf2d534','7647bb87-9809-490e-990c-48a28db22b0a'),('9df01365-d95e-4866-af36-e9001bf2d534','7caf6225-3ccd-4ddb-95f3-8d409c318f94'),('9df01365-d95e-4866-af36-e9001bf2d534','7d5e9c61-db23-4e8e-9ba8-bbe670180da7'),('9df01365-d95e-4866-af36-e9001bf2d534','7f932738-c306-46fb-8bb1-48b9226d467b'),('9df01365-d95e-4866-af36-e9001bf2d534','7fa3b186-7572-4edf-b1a7-c35927506483'),('9df01365-d95e-4866-af36-e9001bf2d534','8010acf7-3276-4985-b12f-3cbc1a26dd3b'),('9df01365-d95e-4866-af36-e9001bf2d534','85ac723d-87f6-4438-8ff1-d2e4007bb8c4'),('9df01365-d95e-4866-af36-e9001bf2d534','872aaf1b-421f-4bfe-8fdb-cb90327c55e3'),('9df01365-d95e-4866-af36-e9001bf2d534','88c0020d-dce6-4262-9d23-beb583ea89d0'),('9df01365-d95e-4866-af36-e9001bf2d534','89ad497a-d027-48df-96ae-ad8810931dff'),('9df01365-d95e-4866-af36-e9001bf2d534','9243fa25-7798-487d-9ce4-34e255394c7b'),('9df01365-d95e-4866-af36-e9001bf2d534','9fb9f866-c307-41c7-94e5-a1513edd5c68'),('9df01365-d95e-4866-af36-e9001bf2d534','a089e73e-1f72-47e1-9e6b-678d471ca446'),('9df01365-d95e-4866-af36-e9001bf2d534','ab85019a-b17f-4c23-afad-13cdf037c695'),('9df01365-d95e-4866-af36-e9001bf2d534','b43dda3f-f119-4549-910c-5d9765845ccd'),('9df01365-d95e-4866-af36-e9001bf2d534','b44f6419-b97e-4055-acfe-075336cb910c'),('9df01365-d95e-4866-af36-e9001bf2d534','b6416210-c646-43a2-976a-bb5f0a58e8f6'),('9df01365-d95e-4866-af36-e9001bf2d534','b8f8da75-9378-4e8a-a9a7-11c07d8639f4'),('9df01365-d95e-4866-af36-e9001bf2d534','ba425f7d-8d3c-42df-99cc-a36efe9adfbd'),('9df01365-d95e-4866-af36-e9001bf2d534','bb4fa995-fd79-481b-86bd-a36badee6ddd'),('9df01365-d95e-4866-af36-e9001bf2d534','bceb2071-33b4-4cd8-995f-5c1a6ed83998'),('9df01365-d95e-4866-af36-e9001bf2d534','bda0f1b4-9b28-42c3-b2eb-65688de4c3a9'),('9df01365-d95e-4866-af36-e9001bf2d534','bf291eac-9e88-488a-8b9c-3eecd827accf'),('9df01365-d95e-4866-af36-e9001bf2d534','c3e3d308-4e19-4295-b474-83446e85ef8b'),('9df01365-d95e-4866-af36-e9001bf2d534','c3fb18d5-1fa5-48e6-bb25-013fa16accb5'),('9df01365-d95e-4866-af36-e9001bf2d534','c4258163-6732-4619-8858-60447dbaa16c'),('9df01365-d95e-4866-af36-e9001bf2d534','c9f8b913-eb44-4e53-85ab-6314111968cb'),('9df01365-d95e-4866-af36-e9001bf2d534','ce5b976f-2769-4571-bfb2-a5bcccc988cc'),('9df01365-d95e-4866-af36-e9001bf2d534','cee3835d-f183-4802-9539-ef0eb64edd76'),('9df01365-d95e-4866-af36-e9001bf2d534','cf361d06-de87-4e7b-af50-15543e801331'),('9df01365-d95e-4866-af36-e9001bf2d534','d4aa5643-4212-404c-8d33-dfc4d4800a43'),('9df01365-d95e-4866-af36-e9001bf2d534','db105e10-4cb3-42dd-9859-d2bafd0ee380'),('9df01365-d95e-4866-af36-e9001bf2d534','dcca5cfc-246c-4b86-8e90-21626faf6844'),('9df01365-d95e-4866-af36-e9001bf2d534','e55c716f-3837-46a3-bc18-f7edd296ef69'),('9df01365-d95e-4866-af36-e9001bf2d534','e601c120-4492-43f9-905d-79ae0944e1b2'),('9df01365-d95e-4866-af36-e9001bf2d534','e768d5af-dcba-471f-a394-ddb396e944b1'),('9df01365-d95e-4866-af36-e9001bf2d534','ec491403-06e6-422f-8ddf-a7d8fe4ccb2e'),('9df01365-d95e-4866-af36-e9001bf2d534','ecc92669-d6ea-4e37-9fae-d2668999ad98'),('9df01365-d95e-4866-af36-e9001bf2d534','f0d9e002-07dc-496f-baa9-3e933bda4afd'),('9df01365-d95e-4866-af36-e9001bf2d534','f34f5ab1-6e50-40a2-9867-027a204cc7e9'),('9df01365-d95e-4866-af36-e9001bf2d534','f967e712-b9c7-4c96-b2f2-23e91316a3a8'),('9df01365-d95e-4866-af36-e9001bf2d534','f984b833-991e-461c-b01b-e57ba9da2903'),('9df01365-d95e-4866-af36-e9001bf2d534','fac4ad96-b1f9-45c2-96cf-c5701f048f9d'),('9df01365-d95e-4866-af36-e9001bf2d534','fd58fb2c-7a94-49fc-bc74-1de11d3fe33c'),('9df01365-d95e-4866-af36-e9001bf2d534','ff169916-d575-4626-84f8-d41b7aa2a907'),('a53af599-a6dc-44bf-a6ff-71171b218c7a','f6d665b3-80d6-4129-8b48-feeb881164b8'),('aeac672f-dc8f-450e-b2e3-ab866af60ae0','68058e8a-9155-4286-8c47-2009a9e63b39'),('b30da0e7-4091-4583-8472-419ccb8f9de0','1cb16ce1-3a7f-43b9-bacf-10c1ad9a49bc'),('bceb2071-33b4-4cd8-995f-5c1a6ed83998','cee3835d-f183-4802-9539-ef0eb64edd76'),('dc2548b0-a639-46fa-b100-d9e79403159a','b8d4e191-773f-4142-a859-8314a7fb5926'),('e6320424-9682-466c-bc33-131ffeb0c062','054bebcf-01e1-4372-bde4-ff06daa0d164'),('e6320424-9682-466c-bc33-131ffeb0c062','120ca44d-f527-4bb3-9583-d8161284cbde'),('e6320424-9682-466c-bc33-131ffeb0c062','14ac522d-5f9f-495c-8481-87e42bb08980'),('e6320424-9682-466c-bc33-131ffeb0c062','14f729d2-c548-4e43-bb0c-d974bc6af896'),('e6320424-9682-466c-bc33-131ffeb0c062','308a36be-0b75-42e8-8917-b711d045134d'),('e6320424-9682-466c-bc33-131ffeb0c062','44be220f-b334-4263-9cf7-f8f561e78cd8'),('e6320424-9682-466c-bc33-131ffeb0c062','49e18c09-e656-430c-b553-e6ecc1021764'),('e6320424-9682-466c-bc33-131ffeb0c062','4b6e58bc-31ce-4f87-ba54-d537ca2592cd'),('e6320424-9682-466c-bc33-131ffeb0c062','52e3937a-614a-4d35-94df-cbb332b995ec'),('e6320424-9682-466c-bc33-131ffeb0c062','6e394702-4f6a-4b94-9470-519fd14eead7'),('e6320424-9682-466c-bc33-131ffeb0c062','a43df422-48c0-4a17-bf2a-d628deb44d5f'),('e6320424-9682-466c-bc33-131ffeb0c062','afaee320-f76a-48ad-a700-b106d05813d9'),('e6320424-9682-466c-bc33-131ffeb0c062','b6f16505-bdbe-4ee0-af77-06ddb84cb62c'),('e6320424-9682-466c-bc33-131ffeb0c062','b82479b2-0770-4d20-b015-ffeb651b6fe1'),('e6320424-9682-466c-bc33-131ffeb0c062','b8d4e191-773f-4142-a859-8314a7fb5926'),('e6320424-9682-466c-bc33-131ffeb0c062','c181012a-31a5-4a76-acf7-75d7a6e0bb59'),('e6320424-9682-466c-bc33-131ffeb0c062','dc2548b0-a639-46fa-b100-d9e79403159a'),('e6320424-9682-466c-bc33-131ffeb0c062','de71c678-fba9-42bc-a16c-a0a339d0c820'),('e71ff6bd-cc83-4652-a644-5d3308854fdd','44f11c4f-11de-4930-a9bb-66f1504833af'),('e71ff6bd-cc83-4652-a644-5d3308854fdd','4a38d073-c8b2-4d2f-a41b-309828b871c8'),('e71ff6bd-cc83-4652-a644-5d3308854fdd','a9a48d94-076e-4dd8-902b-fa5b4cc92561'),('e71ff6bd-cc83-4652-a644-5d3308854fdd','d686ff30-9ce6-4d21-b40e-954cf53da12d'),('efba8528-db6b-44f6-a982-8b9e095d3927','10726d7c-b18f-4cee-86ed-85b47f0cf37e'),('efba8528-db6b-44f6-a982-8b9e095d3927','1e93736d-f776-45b2-a96b-d25eea66709b'),('efba8528-db6b-44f6-a982-8b9e095d3927','22443081-8011-43ff-b0db-7c73d25c8539'),('efba8528-db6b-44f6-a982-8b9e095d3927','23eaffa9-c12b-4f4c-93b2-6c4ac04ada97'),('efba8528-db6b-44f6-a982-8b9e095d3927','242285dd-bda3-4f01-a8c5-8edf054b9c00'),('efba8528-db6b-44f6-a982-8b9e095d3927','2aec1f96-5ff5-4c69-8762-e27ccf92b0aa'),('efba8528-db6b-44f6-a982-8b9e095d3927','35326eab-a0bd-41ec-a152-be9086d25489'),('efba8528-db6b-44f6-a982-8b9e095d3927','402f483e-b25a-4ef6-a7b5-edd149476a66'),('efba8528-db6b-44f6-a982-8b9e095d3927','70c3353e-289e-4686-b254-6a8475f53402'),('efba8528-db6b-44f6-a982-8b9e095d3927','7fcb25fc-35c6-4ad3-8519-d4bc40635022'),('efba8528-db6b-44f6-a982-8b9e095d3927','9477a00f-8934-4e15-b988-08202d1975d7'),('efba8528-db6b-44f6-a982-8b9e095d3927','9df676e9-1d82-416a-b64e-342b628b22fd'),('efba8528-db6b-44f6-a982-8b9e095d3927','a00df050-5498-4548-89e5-a8e0d746b586'),('efba8528-db6b-44f6-a982-8b9e095d3927','a0ed7511-4e73-496b-8381-4830ea6c8a86'),('efba8528-db6b-44f6-a982-8b9e095d3927','c632a80d-e13b-4858-96a1-98211e7835a7'),('efba8528-db6b-44f6-a982-8b9e095d3927','d8978dbe-2f95-407f-bc7c-c5425b8bfaaa'),('efba8528-db6b-44f6-a982-8b9e095d3927','e6bc4d2e-62c3-4ca8-b5fe-3dd02e0b6e55'),('efba8528-db6b-44f6-a982-8b9e095d3927','ebdb7e9c-5c47-4c4e-8a34-4c1f48cbf3dd'),('f0d9e002-07dc-496f-baa9-3e933bda4afd','4fa64c47-26ef-475a-9e44-28af07a418e9'),('f967e712-b9c7-4c96-b2f2-23e91316a3a8','566678c5-562a-45b4-8471-7337910500a3'),('f967e712-b9c7-4c96-b2f2-23e91316a3a8','7fa3b186-7572-4edf-b1a7-c35927506483');
/*!40000 ALTER TABLE `COMPOSITE_ROLE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CREDENTIAL`
--

DROP TABLE IF EXISTS `CREDENTIAL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CREDENTIAL` (
  `ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `SALT` tinyblob,
  `TYPE` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `USER_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CREATED_DATE` bigint DEFAULT NULL,
  `USER_LABEL` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SECRET_DATA` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `CREDENTIAL_DATA` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `PRIORITY` int DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IDX_USER_CREDENTIAL` (`USER_ID`),
  CONSTRAINT `FK_PFYR0GLASQYL0DEI3KL69R6V0` FOREIGN KEY (`USER_ID`) REFERENCES `USER_ENTITY` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CREDENTIAL`
--

LOCK TABLES `CREDENTIAL` WRITE;
/*!40000 ALTER TABLE `CREDENTIAL` DISABLE KEYS */;
INSERT INTO `CREDENTIAL` VALUES ('03453cad-823e-4531-8922-5eda1b65672b',NULL,'password','730d393a-7ffc-47d2-9d9e-f7747ef74ced',1743753264289,'My password','{\"value\":\"s+GIQzwWJeAQvy4ghfSwoYFZuwctC/Xr3QMlwlUb64k=\",\"salt\":\"Mr9UUwT23McIbont5QeNZg==\",\"additionalParameters\":{}}','{\"hashIterations\":5,\"algorithm\":\"argon2\",\"additionalParameters\":{\"hashLength\":[\"32\"],\"memory\":[\"7168\"],\"type\":[\"id\"],\"version\":[\"1.3\"],\"parallelism\":[\"1\"]}}',10),('30afa74c-5f3d-4b98-b5db-9ea519874062',NULL,'password','4688d9ef-f6e2-4d2e-8eef-b394fc6d6b76',1743754843083,'My password','{\"value\":\"Fu1KKY3JKuC4ph6zcCGfuUupzXrPBSGpahq55epdPIY=\",\"salt\":\"x2hQMHBL1sJjsWDTcLAKfg==\",\"additionalParameters\":{}}','{\"hashIterations\":5,\"algorithm\":\"argon2\",\"additionalParameters\":{\"hashLength\":[\"32\"],\"memory\":[\"7168\"],\"type\":[\"id\"],\"version\":[\"1.3\"],\"parallelism\":[\"1\"]}}',10),('5ae1e880-47b2-4c7b-9e25-5eee26df40e6',NULL,'password','07cfcdaa-d117-4f30-8b94-1d0e30196515',1743670592646,'My password','{\"value\":\"iyPs1oHok1TGBF3y9EeaCQsIHQoHS1W018KqY+okA3Y=\",\"salt\":\"YULDvtNdgGOiLWPltPgvSQ==\",\"additionalParameters\":{}}','{\"hashIterations\":5,\"algorithm\":\"argon2\",\"additionalParameters\":{\"hashLength\":[\"32\"],\"memory\":[\"7168\"],\"type\":[\"id\"],\"version\":[\"1.3\"],\"parallelism\":[\"1\"]}}',10),('89385164-ed43-4cc6-92a5-b8ff07569502',NULL,'password','ff717361-63cd-4068-9a80-5f7be827009f',1743753233219,'My password','{\"value\":\"SSIJHnN14ds4Eyl4FwVDyH7kHqtCmQdAcda9g/QIm74=\",\"salt\":\"GbRedLYqzjGci6OtYSSJsA==\",\"additionalParameters\":{}}','{\"hashIterations\":5,\"algorithm\":\"argon2\",\"additionalParameters\":{\"hashLength\":[\"32\"],\"memory\":[\"7168\"],\"type\":[\"id\"],\"version\":[\"1.3\"],\"parallelism\":[\"1\"]}}',10),('9b439c47-9768-46ab-99c7-2200f4c50d2c',NULL,'password','1d46a5b9-3e17-42ab-a8bd-c2d1c4700e84',1743993399903,'My password','{\"value\":\"aOrnLykVdrCEcc85VF/cy8N2skUh8q9hSHYs4LhWC/8=\",\"salt\":\"Se/C+1v+hF79oQs2rfNQFA==\",\"additionalParameters\":{}}','{\"hashIterations\":5,\"algorithm\":\"argon2\",\"additionalParameters\":{\"hashLength\":[\"32\"],\"memory\":[\"7168\"],\"type\":[\"id\"],\"version\":[\"1.3\"],\"parallelism\":[\"1\"]}}',10),('b2afd2ff-167d-4220-9486-16cb4cf8f224',NULL,'password','f2041bb8-59ef-4663-8142-8c8c8223f851',1743670615855,'My password','{\"value\":\"2d53IREs4vqAkJqsSJMTWC4Y3W7gIK2HHWrv+wkiFLU=\",\"salt\":\"IONB8TKGo3wEP9Wt/+AivQ==\",\"additionalParameters\":{}}','{\"hashIterations\":5,\"algorithm\":\"argon2\",\"additionalParameters\":{\"hashLength\":[\"32\"],\"memory\":[\"7168\"],\"type\":[\"id\"],\"version\":[\"1.3\"],\"parallelism\":[\"1\"]}}',10),('c0620985-eff6-4fde-91b0-af15a2011916',NULL,'password','6f6845e2-f1b4-4a00-aae6-f8cf1a69479d',1743753199407,'My password','{\"value\":\"WsHFMILqQfjq9rHsS2ZFHnz/nfX/AJE6EedPiloLRwM=\",\"salt\":\"NRhKUWD/GD5kDA2KTJfR+w==\",\"additionalParameters\":{}}','{\"hashIterations\":5,\"algorithm\":\"argon2\",\"additionalParameters\":{\"hashLength\":[\"32\"],\"memory\":[\"7168\"],\"type\":[\"id\"],\"version\":[\"1.3\"],\"parallelism\":[\"1\"]}}',10),('cbed1e87-5b2a-4b58-a731-99eb57d0ea54',NULL,'password','aea2b548-e5aa-4663-85d0-966d96c2da47',1743753863083,'My password','{\"value\":\"VSUdTcPb8UXEiLcqw0XWBYMG/10XYXA5r94hrpr5BhA=\",\"salt\":\"Ghm37uUl/mUCYg1UMj25FA==\",\"additionalParameters\":{}}','{\"hashIterations\":5,\"algorithm\":\"argon2\",\"additionalParameters\":{\"hashLength\":[\"32\"],\"memory\":[\"7168\"],\"type\":[\"id\"],\"version\":[\"1.3\"],\"parallelism\":[\"1\"]}}',10),('ee70d2a0-d1a1-4a99-9aa3-3b799b70e507',NULL,'password','e5a40a06-e7f9-47e4-b817-acd16c665e68',1743753141247,'My password','{\"value\":\"h4HuXAqSOMvaCD0gzoOhZM847I0CXQxTHWgwnHx7eFY=\",\"salt\":\"B81YEm79cAiLotODKlTglw==\",\"additionalParameters\":{}}','{\"hashIterations\":5,\"algorithm\":\"argon2\",\"additionalParameters\":{\"hashLength\":[\"32\"],\"memory\":[\"7168\"],\"type\":[\"id\"],\"version\":[\"1.3\"],\"parallelism\":[\"1\"]}}',10);
/*!40000 ALTER TABLE `CREDENTIAL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DATABASECHANGELOG`
--

DROP TABLE IF EXISTS `DATABASECHANGELOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DATABASECHANGELOG` (
  `ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `AUTHOR` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `FILENAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `DATEEXECUTED` datetime NOT NULL,
  `ORDEREXECUTED` int NOT NULL,
  `EXECTYPE` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `MD5SUM` varchar(35) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DESCRIPTION` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `COMMENTS` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TAG` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `LIQUIBASE` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CONTEXTS` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `LABELS` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DEPLOYMENT_ID` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DATABASECHANGELOG`
--

LOCK TABLES `DATABASECHANGELOG` WRITE;
/*!40000 ALTER TABLE `DATABASECHANGELOG` DISABLE KEYS */;
INSERT INTO `DATABASECHANGELOG` VALUES ('1.0.0.Final-KEYCLOAK-5461','sthorger@redhat.com','META-INF/jpa-changelog-1.0.0.Final.xml','2020-11-04 04:24:01',1,'EXECUTED','9:6f1016664e21e16d26517a4418f5e3df','createTable tableName=APPLICATION_DEFAULT_ROLES; createTable tableName=CLIENT; createTable tableName=CLIENT_SESSION; createTable tableName=CLIENT_SESSION_ROLE; createTable tableName=COMPOSITE_ROLE; createTable tableName=CREDENTIAL; createTable tab...','',NULL,'3.5.4',NULL,NULL,'4463827752'),('1.0.0.Final-KEYCLOAK-5461','sthorger@redhat.com','META-INF/db2-jpa-changelog-1.0.0.Final.xml','2020-11-04 04:24:01',2,'MARK_RAN','9:828775b1596a07d1200ba1d49e5e3941','createTable tableName=APPLICATION_DEFAULT_ROLES; createTable tableName=CLIENT; createTable tableName=CLIENT_SESSION; createTable tableName=CLIENT_SESSION_ROLE; createTable tableName=COMPOSITE_ROLE; createTable tableName=CREDENTIAL; createTable tab...','',NULL,'3.5.4',NULL,NULL,'4463827752'),('1.1.0.Beta1','sthorger@redhat.com','META-INF/jpa-changelog-1.1.0.Beta1.xml','2020-11-04 04:24:04',3,'EXECUTED','9:5f090e44a7d595883c1fb61f4b41fd38','delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=CLIENT_ATTRIBUTES; createTable tableName=CLIENT_SESSION_NOTE; createTable tableName=APP_NODE_REGISTRATIONS; addColumn table...','',NULL,'3.5.4',NULL,NULL,'4463827752'),('1.1.0.Final','sthorger@redhat.com','META-INF/jpa-changelog-1.1.0.Final.xml','2020-11-04 04:24:04',4,'EXECUTED','9:c07e577387a3d2c04d1adc9aaad8730e','renameColumn newColumnName=EVENT_TIME, oldColumnName=TIME, tableName=EVENT_ENTITY','',NULL,'3.5.4',NULL,NULL,'4463827752'),('1.2.0.Beta1','psilva@redhat.com','META-INF/jpa-changelog-1.2.0.Beta1.xml','2020-11-04 04:24:10',5,'EXECUTED','9:b68ce996c655922dbcd2fe6b6ae72686','delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=PROTOCOL_MAPPER; createTable tableName=PROTOCOL_MAPPER_CONFIG; createTable tableName=...','',NULL,'3.5.4',NULL,NULL,'4463827752'),('1.2.0.Beta1','psilva@redhat.com','META-INF/db2-jpa-changelog-1.2.0.Beta1.xml','2020-11-04 04:24:10',6,'MARK_RAN','9:543b5c9989f024fe35c6f6c5a97de88e','delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=PROTOCOL_MAPPER; createTable tableName=PROTOCOL_MAPPER_CONFIG; createTable tableName=...','',NULL,'3.5.4',NULL,NULL,'4463827752'),('1.2.0.RC1','bburke@redhat.com','META-INF/jpa-changelog-1.2.0.CR1.xml','2020-11-04 04:24:15',7,'EXECUTED','9:765afebbe21cf5bbca048e632df38336','delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=MIGRATION_MODEL; createTable tableName=IDENTITY_P...','',NULL,'3.5.4',NULL,NULL,'4463827752'),('1.2.0.RC1','bburke@redhat.com','META-INF/db2-jpa-changelog-1.2.0.CR1.xml','2020-11-04 04:24:15',8,'MARK_RAN','9:db4a145ba11a6fdaefb397f6dbf829a1','delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=MIGRATION_MODEL; createTable tableName=IDENTITY_P...','',NULL,'3.5.4',NULL,NULL,'4463827752'),('1.2.0.Final','keycloak','META-INF/jpa-changelog-1.2.0.Final.xml','2020-11-04 04:24:16',9,'EXECUTED','9:9d05c7be10cdb873f8bcb41bc3a8ab23','update tableName=CLIENT; update tableName=CLIENT; update tableName=CLIENT','',NULL,'3.5.4',NULL,NULL,'4463827752'),('1.3.0','bburke@redhat.com','META-INF/jpa-changelog-1.3.0.xml','2020-11-04 04:24:21',10,'EXECUTED','9:18593702353128d53111f9b1ff0b82b8','delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=ADMI...','',NULL,'3.5.4',NULL,NULL,'4463827752'),('1.4.0','bburke@redhat.com','META-INF/jpa-changelog-1.4.0.xml','2020-11-04 04:24:24',11,'EXECUTED','9:6122efe5f090e41a85c0f1c9e52cbb62','delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...','',NULL,'3.5.4',NULL,NULL,'4463827752'),('1.4.0','bburke@redhat.com','META-INF/db2-jpa-changelog-1.4.0.xml','2020-11-04 04:24:24',12,'MARK_RAN','9:e1ff28bf7568451453f844c5d54bb0b5','delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...','',NULL,'3.5.4',NULL,NULL,'4463827752'),('1.5.0','bburke@redhat.com','META-INF/jpa-changelog-1.5.0.xml','2020-11-04 04:24:24',13,'EXECUTED','9:7af32cd8957fbc069f796b61217483fd','delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...','',NULL,'3.5.4',NULL,NULL,'4463827752'),('1.6.1_from15','mposolda@redhat.com','META-INF/jpa-changelog-1.6.1.xml','2020-11-04 04:24:25',14,'EXECUTED','9:6005e15e84714cd83226bf7879f54190','addColumn tableName=REALM; addColumn tableName=KEYCLOAK_ROLE; addColumn tableName=CLIENT; createTable tableName=OFFLINE_USER_SESSION; createTable tableName=OFFLINE_CLIENT_SESSION; addPrimaryKey constraintName=CONSTRAINT_OFFL_US_SES_PK2, tableName=...','',NULL,'3.5.4',NULL,NULL,'4463827752'),('1.6.1_from16-pre','mposolda@redhat.com','META-INF/jpa-changelog-1.6.1.xml','2020-11-04 04:24:25',15,'MARK_RAN','9:bf656f5a2b055d07f314431cae76f06c','delete tableName=OFFLINE_CLIENT_SESSION; delete tableName=OFFLINE_USER_SESSION','',NULL,'3.5.4',NULL,NULL,'4463827752'),('1.6.1_from16','mposolda@redhat.com','META-INF/jpa-changelog-1.6.1.xml','2020-11-04 04:24:25',16,'MARK_RAN','9:f8dadc9284440469dcf71e25ca6ab99b','dropPrimaryKey constraintName=CONSTRAINT_OFFLINE_US_SES_PK, tableName=OFFLINE_USER_SESSION; dropPrimaryKey constraintName=CONSTRAINT_OFFLINE_CL_SES_PK, tableName=OFFLINE_CLIENT_SESSION; addColumn tableName=OFFLINE_USER_SESSION; update tableName=OF...','',NULL,'3.5.4',NULL,NULL,'4463827752'),('1.6.1','mposolda@redhat.com','META-INF/jpa-changelog-1.6.1.xml','2020-11-04 04:24:26',17,'EXECUTED','9:d41d8cd98f00b204e9800998ecf8427e','empty','',NULL,'3.5.4',NULL,NULL,'4463827752'),('1.7.0','bburke@redhat.com','META-INF/jpa-changelog-1.7.0.xml','2020-11-04 04:24:29',18,'EXECUTED','9:3368ff0be4c2855ee2dd9ca813b38d8e','createTable tableName=KEYCLOAK_GROUP; createTable tableName=GROUP_ROLE_MAPPING; createTable tableName=GROUP_ATTRIBUTE; createTable tableName=USER_GROUP_MEMBERSHIP; createTable tableName=REALM_DEFAULT_GROUPS; addColumn tableName=IDENTITY_PROVIDER; ...','',NULL,'3.5.4',NULL,NULL,'4463827752'),('1.8.0','mposolda@redhat.com','META-INF/jpa-changelog-1.8.0.xml','2020-11-04 04:24:32',19,'EXECUTED','9:8ac2fb5dd030b24c0570a763ed75ed20','addColumn tableName=IDENTITY_PROVIDER; createTable tableName=CLIENT_TEMPLATE; createTable tableName=CLIENT_TEMPLATE_ATTRIBUTES; createTable tableName=TEMPLATE_SCOPE_MAPPING; dropNotNullConstraint columnName=CLIENT_ID, tableName=PROTOCOL_MAPPER; ad...','',NULL,'3.5.4',NULL,NULL,'4463827752'),('1.8.0-2','keycloak','META-INF/jpa-changelog-1.8.0.xml','2020-11-04 04:24:32',20,'EXECUTED','9:f91ddca9b19743db60e3057679810e6c','dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; update tableName=CREDENTIAL','',NULL,'3.5.4',NULL,NULL,'4463827752'),('1.8.0','mposolda@redhat.com','META-INF/db2-jpa-changelog-1.8.0.xml','2020-11-04 04:24:32',21,'MARK_RAN','9:831e82914316dc8a57dc09d755f23c51','addColumn tableName=IDENTITY_PROVIDER; createTable tableName=CLIENT_TEMPLATE; createTable tableName=CLIENT_TEMPLATE_ATTRIBUTES; createTable tableName=TEMPLATE_SCOPE_MAPPING; dropNotNullConstraint columnName=CLIENT_ID, tableName=PROTOCOL_MAPPER; ad...','',NULL,'3.5.4',NULL,NULL,'4463827752'),('1.8.0-2','keycloak','META-INF/db2-jpa-changelog-1.8.0.xml','2020-11-04 04:24:32',22,'MARK_RAN','9:f91ddca9b19743db60e3057679810e6c','dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; update tableName=CREDENTIAL','',NULL,'3.5.4',NULL,NULL,'4463827752'),('1.9.0','mposolda@redhat.com','META-INF/jpa-changelog-1.9.0.xml','2020-11-04 04:24:33',23,'EXECUTED','9:bc3d0f9e823a69dc21e23e94c7a94bb1','update tableName=REALM; update tableName=REALM; update tableName=REALM; update tableName=REALM; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=REALM; update tableName=REALM; customChange; dr...','',NULL,'3.5.4',NULL,NULL,'4463827752'),('1.9.1','keycloak','META-INF/jpa-changelog-1.9.1.xml','2020-11-04 04:24:34',24,'EXECUTED','9:c9999da42f543575ab790e76439a2679','modifyDataType columnName=PRIVATE_KEY, tableName=REALM; modifyDataType columnName=PUBLIC_KEY, tableName=REALM; modifyDataType columnName=CERTIFICATE, tableName=REALM','',NULL,'3.5.4',NULL,NULL,'4463827752'),('1.9.1','keycloak','META-INF/db2-jpa-changelog-1.9.1.xml','2020-11-04 04:24:34',25,'MARK_RAN','9:0d6c65c6f58732d81569e77b10ba301d','modifyDataType columnName=PRIVATE_KEY, tableName=REALM; modifyDataType columnName=CERTIFICATE, tableName=REALM','',NULL,'3.5.4',NULL,NULL,'4463827752'),('1.9.2','keycloak','META-INF/jpa-changelog-1.9.2.xml','2020-11-04 04:24:35',26,'EXECUTED','9:fc576660fc016ae53d2d4778d84d86d0','createIndex indexName=IDX_USER_EMAIL, tableName=USER_ENTITY; createIndex indexName=IDX_USER_ROLE_MAPPING, tableName=USER_ROLE_MAPPING; createIndex indexName=IDX_USER_GROUP_MAPPING, tableName=USER_GROUP_MEMBERSHIP; createIndex indexName=IDX_USER_CO...','',NULL,'3.5.4',NULL,NULL,'4463827752'),('authz-2.0.0','psilva@redhat.com','META-INF/jpa-changelog-authz-2.0.0.xml','2020-11-04 04:24:39',27,'EXECUTED','9:43ed6b0da89ff77206289e87eaa9c024','createTable tableName=RESOURCE_SERVER; addPrimaryKey constraintName=CONSTRAINT_FARS, tableName=RESOURCE_SERVER; addUniqueConstraint constraintName=UK_AU8TT6T700S9V50BU18WS5HA6, tableName=RESOURCE_SERVER; createTable tableName=RESOURCE_SERVER_RESOU...','',NULL,'3.5.4',NULL,NULL,'4463827752'),('authz-2.5.1','psilva@redhat.com','META-INF/jpa-changelog-authz-2.5.1.xml','2020-11-04 04:24:39',28,'EXECUTED','9:44bae577f551b3738740281eceb4ea70','update tableName=RESOURCE_SERVER_POLICY','',NULL,'3.5.4',NULL,NULL,'4463827752'),('2.1.0-KEYCLOAK-5461','bburke@redhat.com','META-INF/jpa-changelog-2.1.0.xml','2020-11-04 04:24:42',29,'EXECUTED','9:bd88e1f833df0420b01e114533aee5e8','createTable tableName=BROKER_LINK; createTable tableName=FED_USER_ATTRIBUTE; createTable tableName=FED_USER_CONSENT; createTable tableName=FED_USER_CONSENT_ROLE; createTable tableName=FED_USER_CONSENT_PROT_MAPPER; createTable tableName=FED_USER_CR...','',NULL,'3.5.4',NULL,NULL,'4463827752'),('2.2.0','bburke@redhat.com','META-INF/jpa-changelog-2.2.0.xml','2020-11-04 04:24:43',30,'EXECUTED','9:a7022af5267f019d020edfe316ef4371','addColumn tableName=ADMIN_EVENT_ENTITY; createTable tableName=CREDENTIAL_ATTRIBUTE; createTable tableName=FED_CREDENTIAL_ATTRIBUTE; modifyDataType columnName=VALUE, tableName=CREDENTIAL; addForeignKeyConstraint baseTableName=FED_CREDENTIAL_ATTRIBU...','',NULL,'3.5.4',NULL,NULL,'4463827752'),('2.3.0','bburke@redhat.com','META-INF/jpa-changelog-2.3.0.xml','2020-11-04 04:24:45',31,'EXECUTED','9:fc155c394040654d6a79227e56f5e25a','createTable tableName=FEDERATED_USER; addPrimaryKey constraintName=CONSTR_FEDERATED_USER, tableName=FEDERATED_USER; dropDefaultValue columnName=TOTP, tableName=USER_ENTITY; dropColumn columnName=TOTP, tableName=USER_ENTITY; addColumn tableName=IDE...','',NULL,'3.5.4',NULL,NULL,'4463827752'),('2.4.0','bburke@redhat.com','META-INF/jpa-changelog-2.4.0.xml','2020-11-04 04:24:45',32,'EXECUTED','9:eac4ffb2a14795e5dc7b426063e54d88','customChange','',NULL,'3.5.4',NULL,NULL,'4463827752'),('2.5.0','bburke@redhat.com','META-INF/jpa-changelog-2.5.0.xml','2020-11-04 04:24:45',33,'EXECUTED','9:54937c05672568c4c64fc9524c1e9462','customChange; modifyDataType columnName=USER_ID, tableName=OFFLINE_USER_SESSION','',NULL,'3.5.4',NULL,NULL,'4463827752'),('2.5.0-unicode-oracle','hmlnarik@redhat.com','META-INF/jpa-changelog-2.5.0.xml','2020-11-04 04:24:45',34,'MARK_RAN','9:3a32bace77c84d7678d035a7f5a8084e','modifyDataType columnName=DESCRIPTION, tableName=AUTHENTICATION_FLOW; modifyDataType columnName=DESCRIPTION, tableName=CLIENT_TEMPLATE; modifyDataType columnName=DESCRIPTION, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=DESCRIPTION,...','',NULL,'3.5.4',NULL,NULL,'4463827752'),('2.5.0-unicode-other-dbs','hmlnarik@redhat.com','META-INF/jpa-changelog-2.5.0.xml','2020-11-04 04:24:49',35,'EXECUTED','9:33d72168746f81f98ae3a1e8e0ca3554','modifyDataType columnName=DESCRIPTION, tableName=AUTHENTICATION_FLOW; modifyDataType columnName=DESCRIPTION, tableName=CLIENT_TEMPLATE; modifyDataType columnName=DESCRIPTION, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=DESCRIPTION,...','',NULL,'3.5.4',NULL,NULL,'4463827752'),('2.5.0-duplicate-email-support','slawomir@dabek.name','META-INF/jpa-changelog-2.5.0.xml','2020-11-04 04:24:49',36,'EXECUTED','9:61b6d3d7a4c0e0024b0c839da283da0c','addColumn tableName=REALM','',NULL,'3.5.4',NULL,NULL,'4463827752'),('2.5.0-unique-group-names','hmlnarik@redhat.com','META-INF/jpa-changelog-2.5.0.xml','2020-11-04 04:24:49',37,'EXECUTED','9:8dcac7bdf7378e7d823cdfddebf72fda','addUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP','',NULL,'3.5.4',NULL,NULL,'4463827752'),('2.5.1','bburke@redhat.com','META-INF/jpa-changelog-2.5.1.xml','2020-11-04 04:24:50',38,'EXECUTED','9:a2b870802540cb3faa72098db5388af3','addColumn tableName=FED_USER_CONSENT','',NULL,'3.5.4',NULL,NULL,'4463827752'),('3.0.0','bburke@redhat.com','META-INF/jpa-changelog-3.0.0.xml','2020-11-04 04:24:50',39,'EXECUTED','9:132a67499ba24bcc54fb5cbdcfe7e4c0','addColumn tableName=IDENTITY_PROVIDER','',NULL,'3.5.4',NULL,NULL,'4463827752'),('3.2.0-fix','keycloak','META-INF/jpa-changelog-3.2.0.xml','2020-11-04 04:24:50',40,'MARK_RAN','9:938f894c032f5430f2b0fafb1a243462','addNotNullConstraint columnName=REALM_ID, tableName=CLIENT_INITIAL_ACCESS','',NULL,'3.5.4',NULL,NULL,'4463827752'),('3.2.0-fix-with-keycloak-5416','keycloak','META-INF/jpa-changelog-3.2.0.xml','2020-11-04 04:24:50',41,'MARK_RAN','9:845c332ff1874dc5d35974b0babf3006','dropIndex indexName=IDX_CLIENT_INIT_ACC_REALM, tableName=CLIENT_INITIAL_ACCESS; addNotNullConstraint columnName=REALM_ID, tableName=CLIENT_INITIAL_ACCESS; createIndex indexName=IDX_CLIENT_INIT_ACC_REALM, tableName=CLIENT_INITIAL_ACCESS','',NULL,'3.5.4',NULL,NULL,'4463827752'),('3.2.0-fix-offline-sessions','hmlnarik','META-INF/jpa-changelog-3.2.0.xml','2020-11-04 04:24:50',42,'EXECUTED','9:fc86359c079781adc577c5a217e4d04c','customChange','',NULL,'3.5.4',NULL,NULL,'4463827752'),('3.2.0-fixed','keycloak','META-INF/jpa-changelog-3.2.0.xml','2020-11-04 04:24:55',43,'EXECUTED','9:59a64800e3c0d09b825f8a3b444fa8f4','addColumn tableName=REALM; dropPrimaryKey constraintName=CONSTRAINT_OFFL_CL_SES_PK2, tableName=OFFLINE_CLIENT_SESSION; dropColumn columnName=CLIENT_SESSION_ID, tableName=OFFLINE_CLIENT_SESSION; addPrimaryKey constraintName=CONSTRAINT_OFFL_CL_SES_P...','',NULL,'3.5.4',NULL,NULL,'4463827752'),('3.3.0','keycloak','META-INF/jpa-changelog-3.3.0.xml','2020-11-04 04:24:55',44,'EXECUTED','9:d48d6da5c6ccf667807f633fe489ce88','addColumn tableName=USER_ENTITY','',NULL,'3.5.4',NULL,NULL,'4463827752'),('authz-3.4.0.CR1-resource-server-pk-change-part1','glavoie@gmail.com','META-INF/jpa-changelog-authz-3.4.0.CR1.xml','2020-11-04 04:24:56',45,'EXECUTED','9:dde36f7973e80d71fceee683bc5d2951','addColumn tableName=RESOURCE_SERVER_POLICY; addColumn tableName=RESOURCE_SERVER_RESOURCE; addColumn tableName=RESOURCE_SERVER_SCOPE','',NULL,'3.5.4',NULL,NULL,'4463827752'),('authz-3.4.0.CR1-resource-server-pk-change-part2-KEYCLOAK-6095','hmlnarik@redhat.com','META-INF/jpa-changelog-authz-3.4.0.CR1.xml','2020-11-04 04:24:56',46,'EXECUTED','9:b855e9b0a406b34fa323235a0cf4f640','customChange','',NULL,'3.5.4',NULL,NULL,'4463827752'),('authz-3.4.0.CR1-resource-server-pk-change-part3-fixed','glavoie@gmail.com','META-INF/jpa-changelog-authz-3.4.0.CR1.xml','2020-11-04 04:24:56',47,'MARK_RAN','9:51abbacd7b416c50c4421a8cabf7927e','dropIndex indexName=IDX_RES_SERV_POL_RES_SERV, tableName=RESOURCE_SERVER_POLICY; dropIndex indexName=IDX_RES_SRV_RES_RES_SRV, tableName=RESOURCE_SERVER_RESOURCE; dropIndex indexName=IDX_RES_SRV_SCOPE_RES_SRV, tableName=RESOURCE_SERVER_SCOPE','',NULL,'3.5.4',NULL,NULL,'4463827752'),('authz-3.4.0.CR1-resource-server-pk-change-part3-fixed-nodropindex','glavoie@gmail.com','META-INF/jpa-changelog-authz-3.4.0.CR1.xml','2020-11-04 04:24:59',48,'EXECUTED','9:bdc99e567b3398bac83263d375aad143','addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, tableName=RESOURCE_SERVER_POLICY; addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, tableName=RESOURCE_SERVER_RESOURCE; addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, ...','',NULL,'3.5.4',NULL,NULL,'4463827752'),('authn-3.4.0.CR1-refresh-token-max-reuse','glavoie@gmail.com','META-INF/jpa-changelog-authz-3.4.0.CR1.xml','2020-11-04 04:24:59',49,'EXECUTED','9:d198654156881c46bfba39abd7769e69','addColumn tableName=REALM','',NULL,'3.5.4',NULL,NULL,'4463827752'),('3.4.0','keycloak','META-INF/jpa-changelog-3.4.0.xml','2020-11-04 04:25:04',50,'EXECUTED','9:cfdd8736332ccdd72c5256ccb42335db','addPrimaryKey constraintName=CONSTRAINT_REALM_DEFAULT_ROLES, tableName=REALM_DEFAULT_ROLES; addPrimaryKey constraintName=CONSTRAINT_COMPOSITE_ROLE, tableName=COMPOSITE_ROLE; addPrimaryKey constraintName=CONSTR_REALM_DEFAULT_GROUPS, tableName=REALM...','',NULL,'3.5.4',NULL,NULL,'4463827752'),('3.4.0-KEYCLOAK-5230','hmlnarik@redhat.com','META-INF/jpa-changelog-3.4.0.xml','2020-11-04 04:25:05',51,'EXECUTED','9:7c84de3d9bd84d7f077607c1a4dcb714','createIndex indexName=IDX_FU_ATTRIBUTE, tableName=FED_USER_ATTRIBUTE; createIndex indexName=IDX_FU_CONSENT, tableName=FED_USER_CONSENT; createIndex indexName=IDX_FU_CONSENT_RU, tableName=FED_USER_CONSENT; createIndex indexName=IDX_FU_CREDENTIAL, t...','',NULL,'3.5.4',NULL,NULL,'4463827752'),('3.4.1','psilva@redhat.com','META-INF/jpa-changelog-3.4.1.xml','2020-11-04 04:25:05',52,'EXECUTED','9:5a6bb36cbefb6a9d6928452c0852af2d','modifyDataType columnName=VALUE, tableName=CLIENT_ATTRIBUTES','',NULL,'3.5.4',NULL,NULL,'4463827752'),('3.4.2','keycloak','META-INF/jpa-changelog-3.4.2.xml','2020-11-04 04:25:05',53,'EXECUTED','9:8f23e334dbc59f82e0a328373ca6ced0','update tableName=REALM','',NULL,'3.5.4',NULL,NULL,'4463827752'),('3.4.2-KEYCLOAK-5172','mkanis@redhat.com','META-INF/jpa-changelog-3.4.2.xml','2020-11-04 04:25:05',54,'EXECUTED','9:9156214268f09d970cdf0e1564d866af','update tableName=CLIENT','',NULL,'3.5.4',NULL,NULL,'4463827752'),('4.0.0-KEYCLOAK-6335','bburke@redhat.com','META-INF/jpa-changelog-4.0.0.xml','2020-11-04 04:25:05',55,'EXECUTED','9:db806613b1ed154826c02610b7dbdf74','createTable tableName=CLIENT_AUTH_FLOW_BINDINGS; addPrimaryKey constraintName=C_CLI_FLOW_BIND, tableName=CLIENT_AUTH_FLOW_BINDINGS','',NULL,'3.5.4',NULL,NULL,'4463827752'),('4.0.0-CLEANUP-UNUSED-TABLE','bburke@redhat.com','META-INF/jpa-changelog-4.0.0.xml','2020-11-04 04:25:05',56,'EXECUTED','9:229a041fb72d5beac76bb94a5fa709de','dropTable tableName=CLIENT_IDENTITY_PROV_MAPPING','',NULL,'3.5.4',NULL,NULL,'4463827752'),('4.0.0-KEYCLOAK-6228','bburke@redhat.com','META-INF/jpa-changelog-4.0.0.xml','2020-11-04 04:25:06',57,'EXECUTED','9:079899dade9c1e683f26b2aa9ca6ff04','dropUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHOGM8UEWRT, tableName=USER_CONSENT; dropNotNullConstraint columnName=CLIENT_ID, tableName=USER_CONSENT; addColumn tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHO...','',NULL,'3.5.4',NULL,NULL,'4463827752'),('4.0.0-KEYCLOAK-5579-fixed','mposolda@redhat.com','META-INF/jpa-changelog-4.0.0.xml','2020-11-04 04:25:15',58,'EXECUTED','9:139b79bcbbfe903bb1c2d2a4dbf001d9','dropForeignKeyConstraint baseTableName=CLIENT_TEMPLATE_ATTRIBUTES, constraintName=FK_CL_TEMPL_ATTR_TEMPL; renameTable newTableName=CLIENT_SCOPE_ATTRIBUTES, oldTableName=CLIENT_TEMPLATE_ATTRIBUTES; renameColumn newColumnName=SCOPE_ID, oldColumnName...','',NULL,'3.5.4',NULL,NULL,'4463827752'),('authz-4.0.0.CR1','psilva@redhat.com','META-INF/jpa-changelog-authz-4.0.0.CR1.xml','2020-11-04 04:25:18',59,'EXECUTED','9:b55738ad889860c625ba2bf483495a04','createTable tableName=RESOURCE_SERVER_PERM_TICKET; addPrimaryKey constraintName=CONSTRAINT_FAPMT, tableName=RESOURCE_SERVER_PERM_TICKET; addForeignKeyConstraint baseTableName=RESOURCE_SERVER_PERM_TICKET, constraintName=FK_FRSRHO213XCX4WNKOG82SSPMT...','',NULL,'3.5.4',NULL,NULL,'4463827752'),('authz-4.0.0.Beta3','psilva@redhat.com','META-INF/jpa-changelog-authz-4.0.0.Beta3.xml','2020-11-04 04:25:18',60,'EXECUTED','9:e0057eac39aa8fc8e09ac6cfa4ae15fe','addColumn tableName=RESOURCE_SERVER_POLICY; addColumn tableName=RESOURCE_SERVER_PERM_TICKET; addForeignKeyConstraint baseTableName=RESOURCE_SERVER_PERM_TICKET, constraintName=FK_FRSRPO2128CX4WNKOG82SSRFY, referencedTableName=RESOURCE_SERVER_POLICY','',NULL,'3.5.4',NULL,NULL,'4463827752'),('authz-4.2.0.Final','mhajas@redhat.com','META-INF/jpa-changelog-authz-4.2.0.Final.xml','2020-11-04 04:25:19',61,'EXECUTED','9:42a33806f3a0443fe0e7feeec821326c','createTable tableName=RESOURCE_URIS; addForeignKeyConstraint baseTableName=RESOURCE_URIS, constraintName=FK_RESOURCE_SERVER_URIS, referencedTableName=RESOURCE_SERVER_RESOURCE; customChange; dropColumn columnName=URI, tableName=RESOURCE_SERVER_RESO...','',NULL,'3.5.4',NULL,NULL,'4463827752'),('authz-4.2.0.Final-KEYCLOAK-9944','hmlnarik@redhat.com','META-INF/jpa-changelog-authz-4.2.0.Final.xml','2020-11-04 04:25:19',62,'EXECUTED','9:9968206fca46eecc1f51db9c024bfe56','addPrimaryKey constraintName=CONSTRAINT_RESOUR_URIS_PK, tableName=RESOURCE_URIS','',NULL,'3.5.4',NULL,NULL,'4463827752'),('4.2.0-KEYCLOAK-6313','wadahiro@gmail.com','META-INF/jpa-changelog-4.2.0.xml','2020-11-04 04:25:19',63,'EXECUTED','9:92143a6daea0a3f3b8f598c97ce55c3d','addColumn tableName=REQUIRED_ACTION_PROVIDER','',NULL,'3.5.4',NULL,NULL,'4463827752'),('4.3.0-KEYCLOAK-7984','wadahiro@gmail.com','META-INF/jpa-changelog-4.3.0.xml','2020-11-04 04:25:19',64,'EXECUTED','9:82bab26a27195d889fb0429003b18f40','update tableName=REQUIRED_ACTION_PROVIDER','',NULL,'3.5.4',NULL,NULL,'4463827752'),('4.6.0-KEYCLOAK-7950','psilva@redhat.com','META-INF/jpa-changelog-4.6.0.xml','2020-11-04 04:25:19',65,'EXECUTED','9:e590c88ddc0b38b0ae4249bbfcb5abc3','update tableName=RESOURCE_SERVER_RESOURCE','',NULL,'3.5.4',NULL,NULL,'4463827752'),('4.6.0-KEYCLOAK-8377','keycloak','META-INF/jpa-changelog-4.6.0.xml','2020-11-04 04:25:20',66,'EXECUTED','9:5c1f475536118dbdc38d5d7977950cc0','createTable tableName=ROLE_ATTRIBUTE; addPrimaryKey constraintName=CONSTRAINT_ROLE_ATTRIBUTE_PK, tableName=ROLE_ATTRIBUTE; addForeignKeyConstraint baseTableName=ROLE_ATTRIBUTE, constraintName=FK_ROLE_ATTRIBUTE_ID, referencedTableName=KEYCLOAK_ROLE...','',NULL,'3.5.4',NULL,NULL,'4463827752'),('4.6.0-KEYCLOAK-8555','gideonray@gmail.com','META-INF/jpa-changelog-4.6.0.xml','2020-11-04 04:25:20',67,'EXECUTED','9:e7c9f5f9c4d67ccbbcc215440c718a17','createIndex indexName=IDX_COMPONENT_PROVIDER_TYPE, tableName=COMPONENT','',NULL,'3.5.4',NULL,NULL,'4463827752'),('4.7.0-KEYCLOAK-1267','sguilhen@redhat.com','META-INF/jpa-changelog-4.7.0.xml','2020-11-04 04:25:20',68,'EXECUTED','9:88e0bfdda924690d6f4e430c53447dd5','addColumn tableName=REALM','',NULL,'3.5.4',NULL,NULL,'4463827752'),('4.7.0-KEYCLOAK-7275','keycloak','META-INF/jpa-changelog-4.7.0.xml','2020-11-04 04:25:20',69,'EXECUTED','9:f53177f137e1c46b6a88c59ec1cb5218','renameColumn newColumnName=CREATED_ON, oldColumnName=LAST_SESSION_REFRESH, tableName=OFFLINE_USER_SESSION; addNotNullConstraint columnName=CREATED_ON, tableName=OFFLINE_USER_SESSION; addColumn tableName=OFFLINE_USER_SESSION; customChange; createIn...','',NULL,'3.5.4',NULL,NULL,'4463827752'),('4.8.0-KEYCLOAK-8835','sguilhen@redhat.com','META-INF/jpa-changelog-4.8.0.xml','2020-11-04 04:25:21',70,'EXECUTED','9:a74d33da4dc42a37ec27121580d1459f','addNotNullConstraint columnName=SSO_MAX_LIFESPAN_REMEMBER_ME, tableName=REALM; addNotNullConstraint columnName=SSO_IDLE_TIMEOUT_REMEMBER_ME, tableName=REALM','',NULL,'3.5.4',NULL,NULL,'4463827752'),('authz-7.0.0-KEYCLOAK-10443','psilva@redhat.com','META-INF/jpa-changelog-authz-7.0.0.xml','2020-11-04 04:25:21',71,'EXECUTED','9:fd4ade7b90c3b67fae0bfcfcb42dfb5f','addColumn tableName=RESOURCE_SERVER','',NULL,'3.5.4',NULL,NULL,'4463827752'),('8.0.0-adding-credential-columns','keycloak','META-INF/jpa-changelog-8.0.0.xml','2020-11-04 04:25:21',72,'EXECUTED','9:aa072ad090bbba210d8f18781b8cebf4','addColumn tableName=CREDENTIAL; addColumn tableName=FED_USER_CREDENTIAL','',NULL,'3.5.4',NULL,NULL,'4463827752'),('8.0.0-updating-credential-data-not-oracle','keycloak','META-INF/jpa-changelog-8.0.0.xml','2020-11-04 04:25:21',73,'EXECUTED',NULL,'update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL','',NULL,'3.5.4',NULL,NULL,'4463827752'),('8.0.0-updating-credential-data-oracle','keycloak','META-INF/jpa-changelog-8.0.0.xml','2020-11-04 04:25:21',74,'MARK_RAN',NULL,'update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL','',NULL,'3.5.4',NULL,NULL,'4463827752'),('8.0.0-credential-cleanup-fixed','keycloak','META-INF/jpa-changelog-8.0.0.xml','2020-11-04 04:25:25',75,'EXECUTED','9:2b9cc12779be32c5b40e2e67711a218b','dropDefaultValue columnName=COUNTER, tableName=CREDENTIAL; dropDefaultValue columnName=DIGITS, tableName=CREDENTIAL; dropDefaultValue columnName=PERIOD, tableName=CREDENTIAL; dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; dropColumn ...','',NULL,'3.5.4',NULL,NULL,'4463827752'),('8.0.0-resource-tag-support','keycloak','META-INF/jpa-changelog-8.0.0.xml','2020-11-04 04:25:25',76,'EXECUTED','9:91fa186ce7a5af127a2d7a91ee083cc5','addColumn tableName=MIGRATION_MODEL; createIndex indexName=IDX_UPDATE_TIME, tableName=MIGRATION_MODEL','',NULL,'3.5.4',NULL,NULL,'4463827752'),('9.0.0-always-display-client','keycloak','META-INF/jpa-changelog-9.0.0.xml','2020-11-04 04:25:25',77,'EXECUTED','9:6335e5c94e83a2639ccd68dd24e2e5ad','addColumn tableName=CLIENT','',NULL,'3.5.4',NULL,NULL,'4463827752'),('9.0.0-drop-constraints-for-column-increase','keycloak','META-INF/jpa-changelog-9.0.0.xml','2020-11-04 04:25:25',78,'MARK_RAN','9:6bdb5658951e028bfe16fa0a8228b530','dropUniqueConstraint constraintName=UK_FRSR6T700S9V50BU18WS5PMT, tableName=RESOURCE_SERVER_PERM_TICKET; dropUniqueConstraint constraintName=UK_FRSR6T700S9V50BU18WS5HA6, tableName=RESOURCE_SERVER_RESOURCE; dropPrimaryKey constraintName=CONSTRAINT_O...','',NULL,'3.5.4',NULL,NULL,'4463827752'),('9.0.0-increase-column-size-federated-fk','keycloak','META-INF/jpa-changelog-9.0.0.xml','2020-11-04 04:25:27',79,'EXECUTED','9:d5bc15a64117ccad481ce8792d4c608f','modifyDataType columnName=CLIENT_ID, tableName=FED_USER_CONSENT; modifyDataType columnName=CLIENT_REALM_CONSTRAINT, tableName=KEYCLOAK_ROLE; modifyDataType columnName=OWNER, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=CLIENT_ID, ta...','',NULL,'3.5.4',NULL,NULL,'4463827752'),('9.0.0-recreate-constraints-after-column-increase','keycloak','META-INF/jpa-changelog-9.0.0.xml','2020-11-04 04:25:27',80,'MARK_RAN','9:077cba51999515f4d3e7ad5619ab592c','addNotNullConstraint columnName=CLIENT_ID, tableName=OFFLINE_CLIENT_SESSION; addNotNullConstraint columnName=OWNER, tableName=RESOURCE_SERVER_PERM_TICKET; addNotNullConstraint columnName=REQUESTER, tableName=RESOURCE_SERVER_PERM_TICKET; addNotNull...','',NULL,'3.5.4',NULL,NULL,'4463827752'),('9.0.1-add-index-to-client.client_id','keycloak','META-INF/jpa-changelog-9.0.1.xml','2020-11-04 04:25:27',81,'EXECUTED','9:be969f08a163bf47c6b9e9ead8ac2afb','createIndex indexName=IDX_CLIENT_ID, tableName=CLIENT','',NULL,'3.5.4',NULL,NULL,'4463827752'),('9.0.1-KEYCLOAK-12579-drop-constraints','keycloak','META-INF/jpa-changelog-9.0.1.xml','2020-11-04 04:25:27',82,'MARK_RAN','9:6d3bb4408ba5a72f39bd8a0b301ec6e3','dropUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP','',NULL,'3.5.4',NULL,NULL,'4463827752'),('9.0.1-KEYCLOAK-12579-add-not-null-constraint','keycloak','META-INF/jpa-changelog-9.0.1.xml','2020-11-04 04:25:27',83,'EXECUTED','9:966bda61e46bebf3cc39518fbed52fa7','addNotNullConstraint columnName=PARENT_GROUP, tableName=KEYCLOAK_GROUP','',NULL,'3.5.4',NULL,NULL,'4463827752'),('9.0.1-KEYCLOAK-12579-recreate-constraints','keycloak','META-INF/jpa-changelog-9.0.1.xml','2020-11-04 04:25:27',84,'MARK_RAN','9:8dcac7bdf7378e7d823cdfddebf72fda','addUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP','',NULL,'3.5.4',NULL,NULL,'4463827752'),('9.0.1-add-index-to-events','keycloak','META-INF/jpa-changelog-9.0.1.xml','2020-11-04 04:25:27',85,'EXECUTED','9:7d93d602352a30c0c317e6a609b56599','createIndex indexName=IDX_EVENT_TIME, tableName=EVENT_ENTITY','',NULL,'3.5.4',NULL,NULL,'4463827752'),('map-remove-ri','keycloak','META-INF/jpa-changelog-11.0.0.xml','2020-11-04 04:25:28',86,'EXECUTED','9:71c5969e6cdd8d7b6f47cebc86d37627','dropForeignKeyConstraint baseTableName=REALM, constraintName=FK_TRAF444KK6QRKMS7N56AIWQ5Y; dropForeignKeyConstraint baseTableName=KEYCLOAK_ROLE, constraintName=FK_KJHO5LE2C0RAL09FL8CM9WFW9','',NULL,'3.5.4',NULL,NULL,'4463827752'),('map-remove-ri','keycloak','META-INF/jpa-changelog-12.0.0.xml','2025-02-20 01:26:28',87,'EXECUTED','9:a9ba7d47f065f041b7da856a81762021','dropForeignKeyConstraint baseTableName=REALM_DEFAULT_GROUPS, constraintName=FK_DEF_GROUPS_GROUP; dropForeignKeyConstraint baseTableName=REALM_DEFAULT_ROLES, constraintName=FK_H4WPD7W4HSOOLNI3H0SW7BTJE; dropForeignKeyConstraint baseTableName=CLIENT...','',NULL,'3.5.4',NULL,NULL,'0014788098'),('12.1.0-add-realm-localization-table','keycloak','META-INF/jpa-changelog-12.0.0.xml','2025-02-20 01:26:28',88,'EXECUTED','9:fffabce2bc01e1a8f5110d5278500065','createTable tableName=REALM_LOCALIZATIONS; addPrimaryKey tableName=REALM_LOCALIZATIONS','',NULL,'3.5.4',NULL,NULL,'0014788098'),('default-roles','keycloak','META-INF/jpa-changelog-13.0.0.xml','2025-02-20 01:28:52',89,'EXECUTED','9:fa8a5b5445e3857f4b010bafb5009957','addColumn tableName=REALM; customChange','',NULL,'3.5.4',NULL,NULL,'0014932310'),('default-roles-cleanup','keycloak','META-INF/jpa-changelog-13.0.0.xml','2025-02-20 01:28:52',90,'EXECUTED','9:67ac3241df9a8582d591c5ed87125f39','dropTable tableName=REALM_DEFAULT_ROLES; dropTable tableName=CLIENT_DEFAULT_ROLES','',NULL,'3.5.4',NULL,NULL,'0014932310'),('13.0.0-KEYCLOAK-16844','keycloak','META-INF/jpa-changelog-13.0.0.xml','2025-02-20 01:28:52',91,'EXECUTED','9:ad1194d66c937e3ffc82386c050ba089','createIndex indexName=IDX_OFFLINE_USS_PRELOAD, tableName=OFFLINE_USER_SESSION','',NULL,'3.5.4',NULL,NULL,'0014932310'),('map-remove-ri-13.0.0','keycloak','META-INF/jpa-changelog-13.0.0.xml','2025-02-20 01:28:52',92,'EXECUTED','9:d9be619d94af5a2f5d07b9f003543b91','dropForeignKeyConstraint baseTableName=DEFAULT_CLIENT_SCOPE, constraintName=FK_R_DEF_CLI_SCOPE_SCOPE; dropForeignKeyConstraint baseTableName=CLIENT_SCOPE_CLIENT, constraintName=FK_C_CLI_SCOPE_SCOPE; dropForeignKeyConstraint baseTableName=CLIENT_SC...','',NULL,'3.5.4',NULL,NULL,'0014932310'),('13.0.0-KEYCLOAK-17992-drop-constraints','keycloak','META-INF/jpa-changelog-13.0.0.xml','2025-02-20 01:28:52',93,'MARK_RAN','9:544d201116a0fcc5a5da0925fbbc3bde','dropPrimaryKey constraintName=C_CLI_SCOPE_BIND, tableName=CLIENT_SCOPE_CLIENT; dropIndex indexName=IDX_CLSCOPE_CL, tableName=CLIENT_SCOPE_CLIENT; dropIndex indexName=IDX_CL_CLSCOPE, tableName=CLIENT_SCOPE_CLIENT','',NULL,'3.5.4',NULL,NULL,'0014932310'),('13.0.0-increase-column-size-federated','keycloak','META-INF/jpa-changelog-13.0.0.xml','2025-02-20 01:28:52',94,'EXECUTED','9:43c0c1055b6761b4b3e89de76d612ccf','modifyDataType columnName=CLIENT_ID, tableName=CLIENT_SCOPE_CLIENT; modifyDataType columnName=SCOPE_ID, tableName=CLIENT_SCOPE_CLIENT','',NULL,'3.5.4',NULL,NULL,'0014932310'),('13.0.0-KEYCLOAK-17992-recreate-constraints','keycloak','META-INF/jpa-changelog-13.0.0.xml','2025-02-20 01:28:52',95,'MARK_RAN','9:8bd711fd0330f4fe980494ca43ab1139','addNotNullConstraint columnName=CLIENT_ID, tableName=CLIENT_SCOPE_CLIENT; addNotNullConstraint columnName=SCOPE_ID, tableName=CLIENT_SCOPE_CLIENT; addPrimaryKey constraintName=C_CLI_SCOPE_BIND, tableName=CLIENT_SCOPE_CLIENT; createIndex indexName=...','',NULL,'3.5.4',NULL,NULL,'0014932310'),('json-string-accomodation-fixed','keycloak','META-INF/jpa-changelog-13.0.0.xml','2025-02-20 01:28:52',96,'EXECUTED','9:e07d2bc0970c348bb06fb63b1f82ddbf','addColumn tableName=REALM_ATTRIBUTE; update tableName=REALM_ATTRIBUTE; dropColumn columnName=VALUE, tableName=REALM_ATTRIBUTE; renameColumn newColumnName=VALUE, oldColumnName=VALUE_NEW, tableName=REALM_ATTRIBUTE','',NULL,'3.5.4',NULL,NULL,'0014932310'),('8.0.0-updating-credential-data-not-oracle-fixed','keycloak','META-INF/jpa-changelog-8.0.0.xml','2025-02-20 01:30:34',97,'MARK_RAN','9:1ae6be29bab7c2aa376f6983b932be37','update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL','',NULL,'3.5.4',NULL,NULL,'0015034159'),('8.0.0-updating-credential-data-oracle-fixed','keycloak','META-INF/jpa-changelog-8.0.0.xml','2025-02-20 01:30:34',98,'MARK_RAN','9:14706f286953fc9a25286dbd8fb30d97','update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL','',NULL,'3.5.4',NULL,NULL,'0015034159'),('14.0.0-KEYCLOAK-11019','keycloak','META-INF/jpa-changelog-14.0.0.xml','2025-02-20 01:30:34',99,'EXECUTED','9:24fb8611e97f29989bea412aa38d12b7','createIndex indexName=IDX_OFFLINE_CSS_PRELOAD, tableName=OFFLINE_CLIENT_SESSION; createIndex indexName=IDX_OFFLINE_USS_BY_USER, tableName=OFFLINE_USER_SESSION; createIndex indexName=IDX_OFFLINE_USS_BY_USERSESS, tableName=OFFLINE_USER_SESSION','',NULL,'3.5.4',NULL,NULL,'0015034159'),('14.0.0-KEYCLOAK-18286','keycloak','META-INF/jpa-changelog-14.0.0.xml','2025-02-20 01:30:34',100,'MARK_RAN','9:259f89014ce2506ee84740cbf7163aa7','createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES','',NULL,'3.5.4',NULL,NULL,'0015034159'),('14.0.0-KEYCLOAK-18286-mysql','keycloak','META-INF/jpa-changelog-14.0.0.xml','2025-02-20 01:30:34',101,'EXECUTED',NULL,'createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES','',NULL,'3.5.4',NULL,NULL,'0015034159'),('KEYCLOAK-17267-add-index-to-user-attributes','keycloak','META-INF/jpa-changelog-14.0.0.xml','2025-02-20 01:30:34',102,'EXECUTED','9:0b305d8d1277f3a89a0a53a659ad274c','createIndex indexName=IDX_USER_ATTRIBUTE_NAME, tableName=USER_ATTRIBUTE','',NULL,'3.5.4',NULL,NULL,'0015034159'),('KEYCLOAK-18146-add-saml-art-binding-identifier','keycloak','META-INF/jpa-changelog-14.0.0.xml','2025-02-20 01:30:34',103,'EXECUTED','9:2c374ad2cdfe20e2905a84c8fac48460','customChange','',NULL,'3.5.4',NULL,NULL,'0015034159'),('14.0.0-KEYCLOAK-18286-revert','keycloak','META-INF/jpa-changelog-14.0.0.xml','2025-02-20 01:39:00',104,'EXECUTED','9:04baaf56c116ed19951cbc2cca584022','dropIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES','',NULL,'3.5.4',NULL,NULL,'0015539948'),('14.0.0-KEYCLOAK-18286-supported-dbs','keycloak','META-INF/jpa-changelog-14.0.0.xml','2025-02-20 01:39:00',105,'EXECUTED','9:bd2bd0fc7768cf0845ac96a8786fa735','createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES','',NULL,'3.5.4',NULL,NULL,'0015539948'),('14.0.0-KEYCLOAK-18286-unsupported-dbs','keycloak','META-INF/jpa-changelog-14.0.0.xml','2025-02-20 01:39:00',106,'MARK_RAN','9:d3d977031d431db16e2c181ce49d73e9','createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES','',NULL,'3.5.4',NULL,NULL,'0015539948'),('15.0.0-KEYCLOAK-18467','keycloak','META-INF/jpa-changelog-15.0.0.xml','2025-02-20 01:39:00',107,'EXECUTED','9:47a760639ac597360a8219f5b768b4de','addColumn tableName=REALM_LOCALIZATIONS; update tableName=REALM_LOCALIZATIONS; dropColumn columnName=TEXTS, tableName=REALM_LOCALIZATIONS; renameColumn newColumnName=TEXTS, oldColumnName=TEXTS_NEW, tableName=REALM_LOCALIZATIONS; addNotNullConstrai...','',NULL,'3.5.4',NULL,NULL,'0015539948'),('17.0.0-9562','keycloak','META-INF/jpa-changelog-17.0.0.xml','2025-02-20 01:47:00',108,'EXECUTED','9:a6272f0576727dd8cad2522335f5d99e','createIndex indexName=IDX_USER_SERVICE_ACCOUNT, tableName=USER_ENTITY','',NULL,'4.8.0',NULL,NULL,'0016020504'),('18.0.0-10625-IDX_ADMIN_EVENT_TIME','keycloak','META-INF/jpa-changelog-18.0.0.xml','2025-02-20 01:47:00',109,'EXECUTED','9:015479dbd691d9cc8669282f4828c41d','createIndex indexName=IDX_ADMIN_EVENT_TIME, tableName=ADMIN_EVENT_ENTITY','',NULL,'4.8.0',NULL,NULL,'0016020504'),('19.0.0-10135','keycloak','META-INF/jpa-changelog-19.0.0.xml','2025-02-20 01:47:00',110,'EXECUTED','9:9518e495fdd22f78ad6425cc30630221','customChange','',NULL,'4.8.0',NULL,NULL,'0016020504'),('20.0.0-12964-supported-dbs','keycloak','META-INF/jpa-changelog-20.0.0.xml','2025-02-20 01:47:00',111,'EXECUTED','9:f2e1331a71e0aa85e5608fe42f7f681c','createIndex indexName=IDX_GROUP_ATT_BY_NAME_VALUE, tableName=GROUP_ATTRIBUTE','',NULL,'4.8.0',NULL,NULL,'0016020504'),('20.0.0-12964-unsupported-dbs','keycloak','META-INF/jpa-changelog-20.0.0.xml','2025-02-20 01:47:00',112,'MARK_RAN','9:1a6fcaa85e20bdeae0a9ce49b41946a5','createIndex indexName=IDX_GROUP_ATT_BY_NAME_VALUE, tableName=GROUP_ATTRIBUTE','',NULL,'4.8.0',NULL,NULL,'0016020504'),('client-attributes-string-accomodation-fixed','keycloak','META-INF/jpa-changelog-20.0.0.xml','2025-02-20 01:47:00',113,'EXECUTED','9:3f332e13e90739ed0c35b0b25b7822ca','addColumn tableName=CLIENT_ATTRIBUTES; update tableName=CLIENT_ATTRIBUTES; dropColumn columnName=VALUE, tableName=CLIENT_ATTRIBUTES; renameColumn newColumnName=VALUE, oldColumnName=VALUE_NEW, tableName=CLIENT_ATTRIBUTES','',NULL,'4.8.0',NULL,NULL,'0016020504'),('21.0.2-17277','keycloak','META-INF/jpa-changelog-21.0.2.xml','2025-02-20 01:52:01',114,'EXECUTED','9:7ee1f7a3fb8f5588f171fb9a6ab623c0','customChange','',NULL,'4.16.1',NULL,NULL,'0016321580'),('21.1.0-19404','keycloak','META-INF/jpa-changelog-21.1.0.xml','2025-02-20 01:52:01',115,'EXECUTED','9:3d7e830b52f33676b9d64f7f2b2ea634','modifyDataType columnName=DECISION_STRATEGY, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=LOGIC, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=POLICY_ENFORCE_MODE, tableName=RESOURCE_SERVER','',NULL,'4.16.1',NULL,NULL,'0016321580'),('21.1.0-19404-2','keycloak','META-INF/jpa-changelog-21.1.0.xml','2025-02-20 01:52:01',116,'MARK_RAN','9:627d032e3ef2c06c0e1f73d2ae25c26c','addColumn tableName=RESOURCE_SERVER_POLICY; update tableName=RESOURCE_SERVER_POLICY; dropColumn columnName=DECISION_STRATEGY, tableName=RESOURCE_SERVER_POLICY; renameColumn newColumnName=DECISION_STRATEGY, oldColumnName=DECISION_STRATEGY_NEW, tabl...','',NULL,'4.16.1',NULL,NULL,'0016321580'),('22.0.0-17484-updated','keycloak','META-INF/jpa-changelog-22.0.0.xml','2025-02-20 01:54:27',117,'EXECUTED','9:90af0bfd30cafc17b9f4d6eccd92b8b3','customChange','',NULL,'4.23.2',NULL,NULL,'0016466910'),('22.0.5-24031','keycloak','META-INF/jpa-changelog-22.0.0.xml','2025-02-20 01:54:27',118,'MARK_RAN','9:a60d2d7b315ec2d3eba9e2f145f9df28','customChange','',NULL,'4.23.2',NULL,NULL,'0016466910'),('23.0.0-12062','keycloak','META-INF/jpa-changelog-23.0.0.xml','2025-02-20 01:56:31',119,'EXECUTED','9:2168fbe728fec46ae9baf15bf80927b8','addColumn tableName=COMPONENT_CONFIG; update tableName=COMPONENT_CONFIG; dropColumn columnName=VALUE, tableName=COMPONENT_CONFIG; renameColumn newColumnName=VALUE, oldColumnName=VALUE_NEW, tableName=COMPONENT_CONFIG','',NULL,'4.23.2',NULL,NULL,'0016590136'),('23.0.0-17258','keycloak','META-INF/jpa-changelog-23.0.0.xml','2025-02-20 01:56:31',120,'EXECUTED','9:36506d679a83bbfda85a27ea1864dca8','addColumn tableName=EVENT_ENTITY','',NULL,'4.23.2',NULL,NULL,'0016590136'),('24.0.0-9758','keycloak','META-INF/jpa-changelog-24.0.0.xml','2025-02-20 01:58:45',121,'EXECUTED','9:502c557a5189f600f0f445a9b49ebbce','addColumn tableName=USER_ATTRIBUTE; addColumn tableName=FED_USER_ATTRIBUTE; createIndex indexName=USER_ATTR_LONG_VALUES, tableName=USER_ATTRIBUTE; createIndex indexName=FED_USER_ATTR_LONG_VALUES, tableName=FED_USER_ATTRIBUTE; createIndex indexName...','',NULL,'4.25.1',NULL,NULL,'0016725105'),('24.0.0-9758-2','keycloak','META-INF/jpa-changelog-24.0.0.xml','2025-02-20 01:58:45',122,'EXECUTED','9:bf0fdee10afdf597a987adbf291db7b2','customChange','',NULL,'4.25.1',NULL,NULL,'0016725105'),('24.0.0-26618-drop-index-if-present','keycloak','META-INF/jpa-changelog-24.0.0.xml','2025-02-20 01:58:46',123,'EXECUTED','9:04baaf56c116ed19951cbc2cca584022','dropIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES','',NULL,'4.25.1',NULL,NULL,'0016725105'),('24.0.0-26618-reindex','keycloak','META-INF/jpa-changelog-24.0.0.xml','2025-02-20 01:58:46',124,'EXECUTED','9:bd2bd0fc7768cf0845ac96a8786fa735','createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES','',NULL,'4.25.1',NULL,NULL,'0016725105'),('24.0.2-27228','keycloak','META-INF/jpa-changelog-24.0.2.xml','2025-02-20 01:58:46',125,'EXECUTED','9:eaee11f6b8aa25d2cc6a84fb86fc6238','customChange','',NULL,'4.25.1',NULL,NULL,'0016725105'),('24.0.2-27967-drop-index-if-present','keycloak','META-INF/jpa-changelog-24.0.2.xml','2025-02-20 01:58:46',126,'MARK_RAN','9:04baaf56c116ed19951cbc2cca584022','dropIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES','',NULL,'4.25.1',NULL,NULL,'0016725105'),('24.0.2-27967-reindex','keycloak','META-INF/jpa-changelog-24.0.2.xml','2025-02-20 01:58:46',127,'MARK_RAN','9:d3d977031d431db16e2c181ce49d73e9','createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES','',NULL,'4.25.1',NULL,NULL,'0016725105'),('18.0.15-30992-index-consent','keycloak','META-INF/jpa-changelog-18.0.15.xml','2025-02-20 02:54:50',128,'EXECUTED','9:80071ede7a05604b1f4906f3bf3b00f0','createIndex indexName=IDX_USCONSENT_SCOPE_ID, tableName=USER_CONSENT_CLIENT_SCOPE','',NULL,'4.25.1',NULL,NULL,'0020089086'),('25.0.0-28265-tables','keycloak','META-INF/jpa-changelog-25.0.0.xml','2025-02-20 02:54:50',129,'EXECUTED','9:deda2df035df23388af95bbd36c17cef','addColumn tableName=OFFLINE_USER_SESSION; addColumn tableName=OFFLINE_CLIENT_SESSION','',NULL,'4.25.1',NULL,NULL,'0020089086'),('25.0.0-28265-index-creation','keycloak','META-INF/jpa-changelog-25.0.0.xml','2025-02-20 02:54:50',130,'EXECUTED','9:3e96709818458ae49f3c679ae58d263a','createIndex indexName=IDX_OFFLINE_USS_BY_LAST_SESSION_REFRESH, tableName=OFFLINE_USER_SESSION','',NULL,'4.25.1',NULL,NULL,'0020089086'),('25.0.0-28265-index-cleanup','keycloak','META-INF/jpa-changelog-25.0.0.xml','2025-02-20 02:54:50',131,'EXECUTED','9:8c0cfa341a0474385b324f5c4b2dfcc1','dropIndex indexName=IDX_OFFLINE_USS_CREATEDON, tableName=OFFLINE_USER_SESSION; dropIndex indexName=IDX_OFFLINE_USS_PRELOAD, tableName=OFFLINE_USER_SESSION; dropIndex indexName=IDX_OFFLINE_USS_BY_USERSESS, tableName=OFFLINE_USER_SESSION; dropIndex ...','',NULL,'4.25.1',NULL,NULL,'0020089086'),('25.0.0-28265-index-2-mysql','keycloak','META-INF/jpa-changelog-25.0.0.xml','2025-02-20 02:54:50',132,'EXECUTED','9:b7ef76036d3126bb83c2423bf4d449d6','createIndex indexName=IDX_OFFLINE_USS_BY_BROKER_SESSION_ID, tableName=OFFLINE_USER_SESSION','',NULL,'4.25.1',NULL,NULL,'0020089086'),('25.0.0-28265-index-2-not-mysql','keycloak','META-INF/jpa-changelog-25.0.0.xml','2025-02-20 02:54:50',133,'MARK_RAN','9:23396cf51ab8bc1ae6f0cac7f9f6fcf7','createIndex indexName=IDX_OFFLINE_USS_BY_BROKER_SESSION_ID, tableName=OFFLINE_USER_SESSION','',NULL,'4.25.1',NULL,NULL,'0020089086'),('25.0.0-org','keycloak','META-INF/jpa-changelog-25.0.0.xml','2025-02-20 02:54:50',134,'EXECUTED','9:5c859965c2c9b9c72136c360649af157','createTable tableName=ORG; addUniqueConstraint constraintName=UK_ORG_NAME, tableName=ORG; addUniqueConstraint constraintName=UK_ORG_GROUP, tableName=ORG; createTable tableName=ORG_DOMAIN','',NULL,'4.25.1',NULL,NULL,'0020089086'),('unique-consentuser','keycloak','META-INF/jpa-changelog-25.0.0.xml','2025-02-20 02:54:51',135,'MARK_RAN','9:5857626a2ea8767e9a6c66bf3a2cb32f','customChange; dropUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHOGM8UEWRT, tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_LOCAL_CONSENT, tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_EXTERNAL_CONSENT, tableName=...','',NULL,'4.25.1',NULL,NULL,'0020089086'),('unique-consentuser-mysql','keycloak','META-INF/jpa-changelog-25.0.0.xml','2025-02-20 02:54:51',136,'EXECUTED','9:b79478aad5adaa1bc428e31563f55e8e','customChange; dropUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHOGM8UEWRT, tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_LOCAL_CONSENT, tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_EXTERNAL_CONSENT, tableName=...','',NULL,'4.25.1',NULL,NULL,'0020089086'),('25.0.0-28861-index-creation','keycloak','META-INF/jpa-changelog-25.0.0.xml','2025-02-20 02:54:51',137,'EXECUTED','9:b9acb58ac958d9ada0fe12a5d4794ab1','createIndex indexName=IDX_PERM_TICKET_REQUESTER, tableName=RESOURCE_SERVER_PERM_TICKET; createIndex indexName=IDX_PERM_TICKET_OWNER, tableName=RESOURCE_SERVER_PERM_TICKET','',NULL,'4.25.1',NULL,NULL,'0020089086');
/*!40000 ALTER TABLE `DATABASECHANGELOG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DATABASECHANGELOGLOCK`
--

DROP TABLE IF EXISTS `DATABASECHANGELOGLOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DATABASECHANGELOGLOCK` (
  `ID` int NOT NULL,
  `LOCKED` bit(1) NOT NULL,
  `LOCKGRANTED` datetime DEFAULT NULL,
  `LOCKEDBY` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DATABASECHANGELOGLOCK`
--

LOCK TABLES `DATABASECHANGELOGLOCK` WRITE;
/*!40000 ALTER TABLE `DATABASECHANGELOGLOCK` DISABLE KEYS */;
INSERT INTO `DATABASECHANGELOGLOCK` VALUES (1,_binary '\0',NULL,NULL),(1000,_binary '\0',NULL,NULL),(1001,_binary '\0',NULL,NULL);
/*!40000 ALTER TABLE `DATABASECHANGELOGLOCK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DEFAULT_CLIENT_SCOPE`
--

DROP TABLE IF EXISTS `DEFAULT_CLIENT_SCOPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DEFAULT_CLIENT_SCOPE` (
  `REALM_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `SCOPE_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `DEFAULT_SCOPE` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`REALM_ID`,`SCOPE_ID`),
  KEY `IDX_DEFCLS_REALM` (`REALM_ID`),
  KEY `IDX_DEFCLS_SCOPE` (`SCOPE_ID`),
  CONSTRAINT `FK_R_DEF_CLI_SCOPE_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DEFAULT_CLIENT_SCOPE`
--

LOCK TABLES `DEFAULT_CLIENT_SCOPE` WRITE;
/*!40000 ALTER TABLE `DEFAULT_CLIENT_SCOPE` DISABLE KEYS */;
INSERT INTO `DEFAULT_CLIENT_SCOPE` VALUES ('hi','01bd005a-2d2b-4826-9f76-953fcaf6d1bd',_binary ''),('hi','04f47a6c-8d2b-415f-be78-80d855e614a8',_binary '\0'),('hi','176332ca-d883-4329-a9d4-68884a7c275e',_binary ''),('hi','20d24c08-4287-49c0-9e96-23b74cb9dde4',_binary ''),('hi','3617b695-9239-4d20-9271-32aa00a4825a',_binary ''),('hi','5753f684-aa1d-4cc0-88aa-98a2f0cab3af',_binary ''),('hi','76bd20ff-2540-4fb2-b91f-f1b9ec78c9d0',_binary ''),('hi','90332860-b400-4df0-b3a0-5ddee0d59319',_binary '\0'),('hi','91926bc4-0204-43c3-a034-67e94de06f80',_binary ''),('hi','e7c2df73-1988-4b3e-b971-24cd27bb2a0f',_binary '\0'),('hi','ee7ace46-13d6-42c2-9718-1c0cbd9418a8',_binary '\0'),('hi-library','2a8bc487-583c-43dc-8d29-1ad0950d438b',_binary ''),('hi-library','356d3968-262b-4bee-8d44-0d93e880b01a',_binary ''),('hi-library','4072c001-f7e7-4fa4-9f9f-0f099a308dfe',_binary '\0'),('hi-library','41cca0ba-533b-45a7-99c1-8b4ecf149f06',_binary ''),('hi-library','46172ddf-6ae6-4156-8d29-27e64cc13377',_binary ''),('hi-library','4d7db1a2-1bb6-4104-801b-ea18bd31d25e',_binary '\0'),('hi-library','6ec5000c-e317-4360-8f97-2f3545494994',_binary ''),('hi-library','77249e04-e2d2-4031-9667-8786a866947c',_binary ''),('hi-library','c32f9638-55d0-4d5a-a3fb-feb682bc420c',_binary '\0'),('hi-library','c860f1d3-2172-40b1-9ce2-84911e6a17a9',_binary ''),('hi-library','fb50c6e7-5a41-49e1-a6d1-933d23ad0663',_binary '\0'),('hi-therapist','0d783cca-c3a4-4d95-ab32-82551105367e',_binary ''),('hi-therapist','32a3853a-b88f-4676-a8ff-36e7f9b1ec44',_binary ''),('hi-therapist','433a8036-5c4d-4675-a59e-2ac046db7713',_binary ''),('hi-therapist','467375c3-0f8a-490f-b105-0bb44c15a518',_binary '\0'),('hi-therapist','63210a8a-0008-4908-a26e-c374667cf2ea',_binary ''),('hi-therapist','7f8eb3f6-36a3-4334-926c-7e7a067a96ad',_binary '\0'),('hi-therapist','80525d8c-f22c-4adc-a0de-adf5ebf8a6bb',_binary ''),('hi-therapist','8c3bdc03-95db-4a61-833f-d816bc6d702c',_binary '\0'),('hi-therapist','f070e008-1bf3-4354-9566-af729276ee3e',_binary ''),('hi-therapist','f8b8a1e5-c804-4695-b5b1-35c66ddbabee',_binary '\0'),('hi-therapist','fedf7ec0-e80f-4336-a9b1-17e8bf4c7b71',_binary ''),('master','0ea1d4c1-d78e-433a-9a43-d31c1c298deb',_binary ''),('master','275e4568-19f1-4016-8db4-c60a6daa0ab4',_binary ''),('master','414975ff-f904-4ab5-b84c-ce90b092c83a',_binary '\0'),('master','5331ff23-6ff5-4b10-9ac9-0c413fe89907',_binary '\0'),('master','6c42b94b-4d9d-47e4-b334-74526eba766b',_binary ''),('master','8cf5052c-143d-4034-a453-71443d4c683c',_binary ''),('master','9ecc4599-6324-4ab5-a7a2-67e68b1af5f2',_binary ''),('master','bcb19857-2acf-43ed-9480-b1975fa5f33c',_binary ''),('master','db8690d5-98eb-4b33-8165-cb295c69b3d2',_binary '\0'),('master','e22978cc-f9ed-428f-90c6-383ee84fb000',_binary '\0'),('master','f72905ec-d315-4c68-89dd-14d42907cf3e',_binary '');
/*!40000 ALTER TABLE `DEFAULT_CLIENT_SCOPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EVENT_ENTITY`
--

DROP TABLE IF EXISTS `EVENT_ENTITY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EVENT_ENTITY` (
  `ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `CLIENT_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DETAILS_JSON` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `ERROR` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `IP_ADDRESS` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REALM_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SESSION_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `EVENT_TIME` bigint DEFAULT NULL,
  `TYPE` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `USER_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DETAILS_JSON_LONG_VALUE` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  PRIMARY KEY (`ID`),
  KEY `IDX_EVENT_TIME` (`REALM_ID`,`EVENT_TIME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EVENT_ENTITY`
--

LOCK TABLES `EVENT_ENTITY` WRITE;
/*!40000 ALTER TABLE `EVENT_ENTITY` DISABLE KEYS */;
INSERT INTO `EVENT_ENTITY` VALUES ('0853e82f-9a9e-4e45-a0e4-190e5957e60f','hiv_frontend','{\"token_id\":\"5d78bf3f-344f-45bc-bab7-e8453752d0f6\",\"grant_type\":\"authorization_code\",\"refresh_token_type\":\"Refresh\",\"scope\":\"openid profile email\",\"refresh_token_id\":\"267ce9a5-1535-4962-beef-7576ad2aa121\",\"code_id\":\"a596e4dd-b7f6-432f-9c19-fef64f41971c\",\"client_auth_method\":\"client-secret\"}',NULL,'10.10.2.198','Hi','a596e4dd-b7f6-432f-9c19-fef64f41971c',1604571951036,'CODE_TO_TOKEN','519652bc-24a1-4b7a-a65a-7003d745e6f5',NULL),('0adacc3a-4988-46e2-a55c-893193917ffb','hiv_frontend','{\"auth_method\":\"openid-connect\",\"auth_type\":\"code\",\"redirect_uri\":\"http://localhost:3000/\",\"consent\":\"no_consent_required\",\"code_id\":\"2a2a9cd6-840d-4e52-aa76-83edae42a618\",\"username\":\"phearoth\"}',NULL,'10.10.2.198','Hi','2a2a9cd6-840d-4e52-aa76-83edae42a618',1604572326521,'LOGIN','519652bc-24a1-4b7a-a65a-7003d745e6f5',NULL),('10d242cc-e746-49d4-8fb4-3b72cc37194c','sts_frontend','{\"token_id\":\"9fce7927-66fa-46f9-a3e5-436691f50b56\",\"grant_type\":\"authorization_code\",\"refresh_token_type\":\"Refresh\",\"scope\":\"openid profile email\",\"refresh_token_id\":\"264c5ee8-7eae-4ade-9402-15734d5c3df1\",\"code_id\":\"b91bc866-e6ff-40b5-984e-826d99e05e1d\",\"client_auth_method\":\"client-secret\"}',NULL,'10.10.2.198','sts','b91bc866-e6ff-40b5-984e-826d99e05e1d',1604570573619,'CODE_TO_TOKEN','1c225af7-8324-4dfb-9495-0cf032fb0cf0',NULL),('13d7d5a3-fb5f-4346-b064-ea528c11e468','sts_frontend','{\"auth_method\":\"openid-connect\",\"auth_type\":\"code\",\"response_type\":\"code\",\"redirect_uri\":\"http://localhost:3000/admin\",\"consent\":\"no_consent_required\",\"code_id\":\"b91bc866-e6ff-40b5-984e-826d99e05e1d\",\"response_mode\":\"fragment\",\"username\":\"phearoth\"}',NULL,'10.10.2.198','sts','b91bc866-e6ff-40b5-984e-826d99e05e1d',1604570136129,'LOGIN','1c225af7-8324-4dfb-9495-0cf032fb0cf0',NULL),('19f4ca7e-1ac3-466a-a3d9-7e8982fcefd5','hiv_frontend','{\"token_id\":\"f284577f-dd35-4be8-ac3b-7fe5c435ae22\",\"grant_type\":\"authorization_code\",\"refresh_token_type\":\"Refresh\",\"scope\":\"openid profile email\",\"refresh_token_id\":\"f6e39fec-6f36-405c-8dd9-35a115448455\",\"code_id\":\"8f79e94c-87fd-4a50-8098-190e72118c23\",\"client_auth_method\":\"client-secret\"}',NULL,'10.10.2.198','Hi','8f79e94c-87fd-4a50-8098-190e72118c23',1604572695601,'CODE_TO_TOKEN','519652bc-24a1-4b7a-a65a-7003d745e6f5',NULL),('2509bffc-118c-403c-b253-de30a0180e2b','hiv_frontend','{\"auth_method\":\"openid-connect\",\"auth_type\":\"code\",\"redirect_uri\":\"http://localhost:3000/admin\",\"consent\":\"no_consent_required\",\"code_id\":\"84a72804-1d6b-42e5-ac75-b61c5647f301\",\"username\":\"phearoth\"}',NULL,'10.10.2.198','Hi','84a72804-1d6b-42e5-ac75-b61c5647f301',1604571564515,'LOGIN','519652bc-24a1-4b7a-a65a-7003d745e6f5',NULL),('272ac1f2-be74-4e22-99d0-d5f3d4f453e3','sts_frontend','{\"token_id\":\"3c82a0e4-cd52-48ae-9e1c-72d8733bec4e\",\"grant_type\":\"authorization_code\",\"refresh_token_type\":\"Refresh\",\"scope\":\"openid profile email\",\"refresh_token_id\":\"53d453af-d1fe-4c32-b8b7-d3941f4fce22\",\"code_id\":\"b91bc866-e6ff-40b5-984e-826d99e05e1d\",\"client_auth_method\":\"client-secret\"}',NULL,'10.10.2.198','sts','b91bc866-e6ff-40b5-984e-826d99e05e1d',1604570252549,'CODE_TO_TOKEN','1c225af7-8324-4dfb-9495-0cf032fb0cf0',NULL),('28200aeb-96e2-45eb-83b7-3cf2071ead7f','sts_frontend','{\"token_id\":\"894bb3d9-4960-4e5f-b427-18b09217472b\",\"grant_type\":\"authorization_code\",\"refresh_token_type\":\"Refresh\",\"scope\":\"openid profile email\",\"refresh_token_id\":\"5add6d6b-5f0f-4d29-99de-6858205f9c28\",\"code_id\":\"b91bc866-e6ff-40b5-984e-826d99e05e1d\",\"client_auth_method\":\"client-secret\"}',NULL,'10.10.2.198','sts','b91bc866-e6ff-40b5-984e-826d99e05e1d',1604570276411,'CODE_TO_TOKEN','1c225af7-8324-4dfb-9495-0cf032fb0cf0',NULL),('2a1cb3c6-5322-4d36-b482-bd088ec7ca6a','sts_frontend','{\"auth_method\":\"openid-connect\",\"auth_type\":\"code\",\"response_type\":\"code\",\"redirect_uri\":\"http://localhost:3000/admin\",\"consent\":\"no_consent_required\",\"code_id\":\"b91bc866-e6ff-40b5-984e-826d99e05e1d\",\"response_mode\":\"fragment\",\"username\":\"phearoth\"}',NULL,'10.10.2.198','sts','b91bc866-e6ff-40b5-984e-826d99e05e1d',1604570135045,'LOGIN','1c225af7-8324-4dfb-9495-0cf032fb0cf0',NULL),('2ae24934-c39d-437c-a37d-2bc290ca9f8d','hiv_frontend','{\"auth_method\":\"openid-connect\",\"auth_type\":\"code\",\"redirect_uri\":\"http://localhost:3000/admin\",\"consent\":\"no_consent_required\",\"code_id\":\"5a652b51-84f0-4d2c-8630-e79aa88c1725\",\"username\":\"phearoth\"}',NULL,'10.10.2.198','Hi','5a652b51-84f0-4d2c-8630-e79aa88c1725',1604571946857,'LOGIN','519652bc-24a1-4b7a-a65a-7003d745e6f5',NULL),('317da17d-48da-485b-9190-dddc61922cef','hiv_frontend','{\"auth_method\":\"openid-connect\",\"auth_type\":\"code\",\"redirect_uri\":\"http://localhost:3000/\",\"consent\":\"no_consent_required\",\"code_id\":\"d4afe410-8b7c-41e3-8611-db81f60b3894\",\"username\":\"phearoth\"}',NULL,'10.10.2.198','Hi','d4afe410-8b7c-41e3-8611-db81f60b3894',1604571957928,'LOGIN','519652bc-24a1-4b7a-a65a-7003d745e6f5',NULL),('42925c54-2855-485e-87e8-62e256b4ffdc','sts_frontend','{\"token_id\":\"67902630-5901-4567-8238-6f8541327191\",\"grant_type\":\"authorization_code\",\"refresh_token_type\":\"Refresh\",\"scope\":\"openid profile email\",\"refresh_token_id\":\"9190ddc0-e0ec-47cc-bdfd-4342dc653c27\",\"code_id\":\"b91bc866-e6ff-40b5-984e-826d99e05e1d\",\"client_auth_method\":\"client-secret\"}',NULL,'10.10.2.198','sts','b91bc866-e6ff-40b5-984e-826d99e05e1d',1604570130193,'CODE_TO_TOKEN','1c225af7-8324-4dfb-9495-0cf032fb0cf0',NULL),('44bdb124-f932-4606-b1b7-447ee8b6df83','hiv_frontend','{\"auth_method\":\"openid-connect\",\"auth_type\":\"code\",\"redirect_uri\":\"http://localhost:3004/\",\"consent\":\"no_consent_required\",\"code_id\":\"207d843c-19a5-43a8-b438-ce9773d27187\",\"username\":\"chanthorn@web-essentials.co\"}',NULL,'10.10.2.136','Hi','207d843c-19a5-43a8-b438-ce9773d27187',1604573023210,'LOGIN','5a3b4694-3690-4bcd-8f39-9b1fecff1dd1',NULL),('45ea8b3b-3262-4b50-a01d-87f51918ce4f','hiv_frontend','{\"token_id\":\"83576b26-49a8-4ff2-8a5e-604782ed465f\",\"grant_type\":\"authorization_code\",\"refresh_token_type\":\"Refresh\",\"scope\":\"openid profile email\",\"refresh_token_id\":\"8e6fd3e2-bea8-42ad-bfb0-aed531ad2d1a\",\"code_id\":\"d85e358d-2044-4b54-8edf-4d6b042b80f6\",\"client_auth_method\":\"client-secret\"}',NULL,'10.10.2.198','Hi','d85e358d-2044-4b54-8edf-4d6b042b80f6',1604572394328,'CODE_TO_TOKEN','519652bc-24a1-4b7a-a65a-7003d745e6f5',NULL),('4c4b5479-3394-4cbb-9b59-ebb0029922d9','sts_frontend','{\"token_id\":\"9764a6ae-5f78-4b7f-932c-067902c6403f\",\"grant_type\":\"authorization_code\",\"refresh_token_type\":\"Refresh\",\"scope\":\"openid profile email\",\"refresh_token_id\":\"4e224620-409a-4f19-8c4c-1d317248c4f5\",\"code_id\":\"b91bc866-e6ff-40b5-984e-826d99e05e1d\",\"client_auth_method\":\"client-secret\"}',NULL,'10.10.2.198','sts','b91bc866-e6ff-40b5-984e-826d99e05e1d',1604570136366,'CODE_TO_TOKEN','1c225af7-8324-4dfb-9495-0cf032fb0cf0',NULL),('66b02028-4581-402b-94b7-f4b84583b1b9','sts_frontend','{\"token_id\":\"6d59945b-c52e-4045-b010-ca12cd62a167\",\"grant_type\":\"authorization_code\",\"refresh_token_type\":\"Refresh\",\"scope\":\"openid profile email\",\"refresh_token_id\":\"c84f4c39-64c8-49e7-9392-4ce58d382c99\",\"code_id\":\"b91bc866-e6ff-40b5-984e-826d99e05e1d\",\"client_auth_method\":\"client-secret\"}',NULL,'10.10.2.198','sts','b91bc866-e6ff-40b5-984e-826d99e05e1d',1604570138466,'CODE_TO_TOKEN','1c225af7-8324-4dfb-9495-0cf032fb0cf0',NULL),('6e058d3c-b39b-4d6f-bd98-51c74dfe4b52','hiv_frontend','{\"token_id\":\"84f46b74-e19f-4476-be78-2764c97e08e4\",\"grant_type\":\"authorization_code\",\"refresh_token_type\":\"Refresh\",\"scope\":\"openid profile email\",\"refresh_token_id\":\"3b4d81b0-227c-4af3-889a-4e484319ab6b\",\"code_id\":\"5f45ea68-be80-476a-8cb5-76c56b2cf8b2\",\"client_auth_method\":\"client-secret\"}',NULL,'10.10.2.198','Hi','5f45ea68-be80-476a-8cb5-76c56b2cf8b2',1604571559188,'CODE_TO_TOKEN','519652bc-24a1-4b7a-a65a-7003d745e6f5',NULL),('6e0ed998-4ea5-41c0-9da4-3c9b6e65909d','hiv_frontend','{\"auth_method\":\"openid-connect\",\"auth_type\":\"code\",\"redirect_uri\":\"http://localhost:3000/\",\"consent\":\"no_consent_required\",\"code_id\":\"d85e358d-2044-4b54-8edf-4d6b042b80f6\",\"username\":\"phearoth\"}',NULL,'10.10.2.198','Hi','d85e358d-2044-4b54-8edf-4d6b042b80f6',1604572393815,'LOGIN','519652bc-24a1-4b7a-a65a-7003d745e6f5',NULL),('73097e42-4407-48f1-95e5-9b00867978e4','hiv_frontend','{\"auth_method\":\"openid-connect\",\"auth_type\":\"code\",\"redirect_uri\":\"http://localhost:3004/\",\"code_id\":\"bd61ad81-f4f2-4576-8f9e-41e9079f3a6d\",\"username\":\"chanthorn@web-essentials.co\"}','invalid_user_credentials','10.10.2.136','Hi',NULL,1604572973721,'LOGIN_ERROR','5a3b4694-3690-4bcd-8f39-9b1fecff1dd1',NULL),('754cdc88-22df-4c2b-a9cc-a646742f0448','hiv_frontend','{\"token_id\":\"94f734f9-088d-44eb-a1ac-2a7cf9d954ea\",\"grant_type\":\"authorization_code\",\"refresh_token_type\":\"Refresh\",\"scope\":\"openid profile email\",\"refresh_token_id\":\"167eaf9d-b970-4ac2-b208-9ddccb72db33\",\"code_id\":\"207d843c-19a5-43a8-b438-ce9773d27187\",\"client_auth_method\":\"client-secret\"}',NULL,'10.10.2.136','Hi','207d843c-19a5-43a8-b438-ce9773d27187',1604573023576,'CODE_TO_TOKEN','5a3b4694-3690-4bcd-8f39-9b1fecff1dd1',NULL),('7a334a05-0a1c-4385-b42d-fbeb49f7d369','hiv_frontend','{\"auth_method\":\"openid-connect\",\"auth_type\":\"code\",\"redirect_uri\":\"http://localhost:3004/\",\"code_id\":\"b52562f6-7344-4e15-95e5-bd200dd0a0ec\"}','user_not_found','10.10.2.136','Hi',NULL,1604572192115,'LOGIN_ERROR',NULL,NULL),('8944220b-71ee-4db6-8877-6931be2164bf','security-admin-console','null','invalid_request','10.10.2.136','Hi',NULL,1604572943898,'LOGIN_ERROR',NULL,NULL),('89f148c0-72b3-42b9-9d26-0c78db3547c5','sts_frontend','{\"auth_method\":\"openid-connect\",\"auth_type\":\"code\",\"redirect_uri\":\"http://localhost:3000/\",\"consent\":\"no_consent_required\",\"code_id\":\"b91bc866-e6ff-40b5-984e-826d99e05e1d\",\"username\":\"phearoth\"}',NULL,'10.10.2.198','sts','b91bc866-e6ff-40b5-984e-826d99e05e1d',1604570129571,'LOGIN','1c225af7-8324-4dfb-9495-0cf032fb0cf0',NULL),('8c00d7c8-7f13-4c59-a690-9fb2cb5ee3ae','sts_frontend','{\"auth_method\":\"openid-connect\",\"auth_type\":\"code\",\"response_type\":\"code\",\"redirect_uri\":\"http://localhost:3000/\",\"consent\":\"no_consent_required\",\"code_id\":\"b91bc866-e6ff-40b5-984e-826d99e05e1d\",\"response_mode\":\"fragment\",\"username\":\"phearoth\"}',NULL,'10.10.2.198','sts','b91bc866-e6ff-40b5-984e-826d99e05e1d',1604570252256,'LOGIN','1c225af7-8324-4dfb-9495-0cf032fb0cf0',NULL),('8e8bc794-4155-4378-a580-f36a346cd3b1','sts_frontend','{\"auth_method\":\"openid-connect\",\"auth_type\":\"code\",\"response_type\":\"code\",\"redirect_uri\":\"http://localhost:3000/\",\"consent\":\"no_consent_required\",\"code_id\":\"b91bc866-e6ff-40b5-984e-826d99e05e1d\",\"response_mode\":\"fragment\",\"username\":\"phearoth\"}',NULL,'10.10.2.198','sts','b91bc866-e6ff-40b5-984e-826d99e05e1d',1604570215763,'LOGIN','1c225af7-8324-4dfb-9495-0cf032fb0cf0',NULL),('90d6acd1-a0b7-4985-8aff-31e01dbe3cc5','sts_frontend','{\"token_id\":\"f376235d-3c0b-41f0-aeae-d75fe2edc3dd\",\"grant_type\":\"authorization_code\",\"refresh_token_type\":\"Refresh\",\"scope\":\"openid profile email\",\"refresh_token_id\":\"8c972c63-b89e-481a-bf8a-69f9f3c9ecbe\",\"code_id\":\"b91bc866-e6ff-40b5-984e-826d99e05e1d\",\"client_auth_method\":\"client-secret\"}',NULL,'10.10.2.198','sts','b91bc866-e6ff-40b5-984e-826d99e05e1d',1604570135320,'CODE_TO_TOKEN','1c225af7-8324-4dfb-9495-0cf032fb0cf0',NULL),('9cc5c8c5-b0ca-425b-800d-b1e508949f29','sts_frontend','{\"auth_method\":\"openid-connect\",\"auth_type\":\"code\",\"redirect_uri\":\"http://localhost:3000/\",\"code_id\":\"b91bc866-e6ff-40b5-984e-826d99e05e1d\",\"username\":\"phearoth\"}','user_disabled','10.10.2.198','sts',NULL,1604570110373,'LOGIN_ERROR','1c225af7-8324-4dfb-9495-0cf032fb0cf0',NULL),('9e47f3e6-1b0d-480a-8806-32a9b5071a59','sts_frontend','{\"auth_method\":\"openid-connect\",\"auth_type\":\"code\",\"response_type\":\"code\",\"redirect_uri\":\"http://localhost:3000/\",\"consent\":\"no_consent_required\",\"code_id\":\"b91bc866-e6ff-40b5-984e-826d99e05e1d\",\"response_mode\":\"fragment\",\"username\":\"phearoth\"}',NULL,'10.10.2.198','sts','b91bc866-e6ff-40b5-984e-826d99e05e1d',1604570276171,'LOGIN','1c225af7-8324-4dfb-9495-0cf032fb0cf0',NULL),('b34ecb4d-53f5-4fe0-bfd1-1094e415f5f6','hiv_frontend','{\"auth_method\":\"openid-connect\",\"auth_type\":\"code\",\"redirect_uri\":\"http://localhost:3000/\",\"consent\":\"no_consent_required\",\"code_id\":\"9ade3a30-4305-4331-96c3-8a81f1cdedf7\",\"username\":\"phearoth\"}',NULL,'10.10.2.198','Hi','9ade3a30-4305-4331-96c3-8a81f1cdedf7',1604572525283,'LOGIN','519652bc-24a1-4b7a-a65a-7003d745e6f5',NULL),('b3bd5cf3-161c-4156-a3bc-a8ca9c4e1a7f','hiv_frontend','{\"auth_method\":\"openid-connect\",\"auth_type\":\"code\",\"redirect_uri\":\"http://localhost:3000/admin\",\"consent\":\"no_consent_required\",\"code_id\":\"a596e4dd-b7f6-432f-9c19-fef64f41971c\",\"username\":\"phearoth\"}',NULL,'10.10.2.198','Hi','a596e4dd-b7f6-432f-9c19-fef64f41971c',1604571950533,'LOGIN','519652bc-24a1-4b7a-a65a-7003d745e6f5',NULL),('bb8f78b0-5a5a-4e3f-90f6-cb59068bb848','hiv_frontend','{\"auth_method\":\"openid-connect\",\"auth_type\":\"code\",\"redirect_uri\":\"http://localhost:3000/admin\",\"consent\":\"no_consent_required\",\"code_id\":\"8f79e94c-87fd-4a50-8098-190e72118c23\",\"username\":\"phearoth\"}',NULL,'10.10.2.198','Hi','8f79e94c-87fd-4a50-8098-190e72118c23',1604572695016,'LOGIN','519652bc-24a1-4b7a-a65a-7003d745e6f5',NULL),('c09bb8a9-4a7a-4f31-a6c1-6e25a4049ee6','hiv_frontend','{\"token_id\":\"f3dd4ab7-b11a-4c90-82b0-9063ecbdd4c8\",\"grant_type\":\"authorization_code\",\"refresh_token_type\":\"Refresh\",\"scope\":\"openid profile email\",\"refresh_token_id\":\"8989334e-4de9-4b3b-a589-8c54790aba2f\",\"code_id\":\"9ade3a30-4305-4331-96c3-8a81f1cdedf7\",\"client_auth_method\":\"client-secret\"}',NULL,'10.10.2.198','Hi','9ade3a30-4305-4331-96c3-8a81f1cdedf7',1604572525822,'CODE_TO_TOKEN','519652bc-24a1-4b7a-a65a-7003d745e6f5',NULL),('c9685081-785c-4aea-abea-de8f2a0b6efc','hiv_frontend','{\"auth_method\":\"openid-connect\",\"auth_type\":\"code\",\"redirect_uri\":\"http://localhost:3000/admin\",\"consent\":\"no_consent_required\",\"code_id\":\"5f45ea68-be80-476a-8cb5-76c56b2cf8b2\",\"username\":\"phearoth\"}',NULL,'10.10.2.198','Hi','5f45ea68-be80-476a-8cb5-76c56b2cf8b2',1604571558556,'LOGIN','519652bc-24a1-4b7a-a65a-7003d745e6f5',NULL),('c97cf0af-ad08-4b67-a111-5346989462aa','hiv_frontend','{\"token_id\":\"63bda273-0b44-446c-a944-4a43349b77fd\",\"grant_type\":\"authorization_code\",\"refresh_token_type\":\"Refresh\",\"scope\":\"openid profile email\",\"refresh_token_id\":\"1e84dd8c-7832-47a1-a726-59325ec172f1\",\"code_id\":\"2a2a9cd6-840d-4e52-aa76-83edae42a618\",\"client_auth_method\":\"client-secret\"}',NULL,'10.10.2.198','Hi','2a2a9cd6-840d-4e52-aa76-83edae42a618',1604572327175,'CODE_TO_TOKEN','519652bc-24a1-4b7a-a65a-7003d745e6f5',NULL),('d355a4f1-d2d1-4ad0-9444-1528ab4c34be','hiv_frontend','{\"token_id\":\"ce5b93a6-5892-4573-b23f-bf21cdd693d9\",\"grant_type\":\"authorization_code\",\"refresh_token_type\":\"Refresh\",\"scope\":\"openid profile email\",\"refresh_token_id\":\"e9b8a54b-f187-4e6e-ab14-a8c9134c28a4\",\"code_id\":\"d4afe410-8b7c-41e3-8611-db81f60b3894\",\"client_auth_method\":\"client-secret\"}',NULL,'10.10.2.198','Hi','d4afe410-8b7c-41e3-8611-db81f60b3894',1604571958585,'CODE_TO_TOKEN','519652bc-24a1-4b7a-a65a-7003d745e6f5',NULL),('d43de23e-4ed6-4482-ba06-dee2a56c8f70','sts_frontend','{\"auth_method\":\"openid-connect\",\"auth_type\":\"code\",\"redirect_uri\":\"http://localhost:3000/\",\"code_id\":\"b91bc866-e6ff-40b5-984e-826d99e05e1d\",\"username\":\"phearoth\"}','user_disabled','10.10.2.198','sts',NULL,1604570115638,'LOGIN_ERROR','1c225af7-8324-4dfb-9495-0cf032fb0cf0',NULL),('d6a14d7f-7c9e-4869-9017-0c7ec3f4da29','hiv_frontend','{\"token_id\":\"cba27a32-59c4-4530-9389-c9f6624a774a\",\"grant_type\":\"authorization_code\",\"refresh_token_type\":\"Refresh\",\"scope\":\"openid profile email\",\"refresh_token_id\":\"7104e058-108f-4e1a-a36b-a230ce1ef0c4\",\"code_id\":\"5a652b51-84f0-4d2c-8630-e79aa88c1725\",\"client_auth_method\":\"client-secret\"}',NULL,'10.10.2.198','Hi','5a652b51-84f0-4d2c-8630-e79aa88c1725',1604571947536,'CODE_TO_TOKEN','519652bc-24a1-4b7a-a65a-7003d745e6f5',NULL),('da8725fa-e276-4019-9a75-71d4b98b9977','sts_frontend','{\"auth_method\":\"openid-connect\",\"auth_type\":\"code\",\"redirect_uri\":\"http://localhost:3000/\",\"code_id\":\"b91bc866-e6ff-40b5-984e-826d99e05e1d\",\"username\":\"phearoth\"}','user_not_found','10.10.2.198','sts',NULL,1604570094629,'LOGIN_ERROR',NULL,NULL),('e2b398ba-42b3-4ad0-8b13-295351eae01a','hiv_frontend','{\"token_id\":\"3b786c64-7524-48a5-b0e5-1c85ae82fd2a\",\"grant_type\":\"authorization_code\",\"refresh_token_type\":\"Refresh\",\"scope\":\"openid profile email\",\"refresh_token_id\":\"213ca366-2f10-4da3-831c-908175993a8b\",\"code_id\":\"84a72804-1d6b-42e5-ac75-b61c5647f301\",\"client_auth_method\":\"client-secret\"}',NULL,'10.10.2.198','Hi','84a72804-1d6b-42e5-ac75-b61c5647f301',1604571565121,'CODE_TO_TOKEN','519652bc-24a1-4b7a-a65a-7003d745e6f5',NULL),('e3997c37-d8ce-4a97-8752-1d74c4348a92','sts_frontend','{\"auth_method\":\"openid-connect\",\"auth_type\":\"code\",\"response_type\":\"code\",\"redirect_uri\":\"http://localhost:3000/\",\"consent\":\"no_consent_required\",\"code_id\":\"b91bc866-e6ff-40b5-984e-826d99e05e1d\",\"response_mode\":\"fragment\",\"username\":\"phearoth\"}',NULL,'10.10.2.198','sts','b91bc866-e6ff-40b5-984e-826d99e05e1d',1604570573295,'LOGIN','1c225af7-8324-4dfb-9495-0cf032fb0cf0',NULL),('e8bc572c-b3f7-4e42-8929-08506f1e895b','sts_frontend','{\"token_id\":\"37dd8135-e5df-4153-afc6-852280a49270\",\"grant_type\":\"authorization_code\",\"refresh_token_type\":\"Refresh\",\"scope\":\"openid profile email\",\"refresh_token_id\":\"ac4f566b-0ed1-4059-ada6-50e3572b745f\",\"code_id\":\"b91bc866-e6ff-40b5-984e-826d99e05e1d\",\"client_auth_method\":\"client-secret\"}',NULL,'10.10.2.198','sts','b91bc866-e6ff-40b5-984e-826d99e05e1d',1604570216022,'CODE_TO_TOKEN','1c225af7-8324-4dfb-9495-0cf032fb0cf0',NULL),('ecf25391-17ef-4ee4-9e2d-ce4e3312956a','hiv_frontend','{\"auth_method\":\"openid-connect\",\"auth_type\":\"code\",\"redirect_uri\":\"http://localhost:3004/\",\"code_id\":\"bd61ad81-f4f2-4576-8f9e-41e9079f3a6d\",\"username\":\"chanthorn@web-essentials.co\"}','invalid_user_credentials','10.10.2.136','Hi',NULL,1604572969731,'LOGIN_ERROR','5a3b4694-3690-4bcd-8f39-9b1fecff1dd1',NULL),('ee91bae3-201a-4935-9309-b54b1878b9bd','sts_frontend','{\"auth_method\":\"openid-connect\",\"auth_type\":\"code\",\"response_type\":\"code\",\"redirect_uri\":\"http://localhost:3000/therapist\",\"consent\":\"no_consent_required\",\"code_id\":\"b91bc866-e6ff-40b5-984e-826d99e05e1d\",\"response_mode\":\"fragment\",\"username\":\"phearoth\"}',NULL,'10.10.2.198','sts','b91bc866-e6ff-40b5-984e-826d99e05e1d',1604570138216,'LOGIN','1c225af7-8324-4dfb-9495-0cf032fb0cf0',NULL);
/*!40000 ALTER TABLE `EVENT_ENTITY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FEDERATED_IDENTITY`
--

DROP TABLE IF EXISTS `FEDERATED_IDENTITY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FEDERATED_IDENTITY` (
  `IDENTITY_PROVIDER` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `REALM_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `FEDERATED_USER_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `FEDERATED_USERNAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TOKEN` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `USER_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`IDENTITY_PROVIDER`,`USER_ID`),
  KEY `IDX_FEDIDENTITY_USER` (`USER_ID`),
  KEY `IDX_FEDIDENTITY_FEDUSER` (`FEDERATED_USER_ID`),
  CONSTRAINT `FK404288B92EF007A6` FOREIGN KEY (`USER_ID`) REFERENCES `USER_ENTITY` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FEDERATED_IDENTITY`
--

LOCK TABLES `FEDERATED_IDENTITY` WRITE;
/*!40000 ALTER TABLE `FEDERATED_IDENTITY` DISABLE KEYS */;
/*!40000 ALTER TABLE `FEDERATED_IDENTITY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FEDERATED_USER`
--

DROP TABLE IF EXISTS `FEDERATED_USER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FEDERATED_USER` (
  `ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `STORAGE_PROVIDER_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REALM_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FEDERATED_USER`
--

LOCK TABLES `FEDERATED_USER` WRITE;
/*!40000 ALTER TABLE `FEDERATED_USER` DISABLE KEYS */;
/*!40000 ALTER TABLE `FEDERATED_USER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FED_USER_ATTRIBUTE`
--

DROP TABLE IF EXISTS `FED_USER_ATTRIBUTE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FED_USER_ATTRIBUTE` (
  `ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `USER_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `REALM_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `STORAGE_PROVIDER_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `VALUE` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `LONG_VALUE_HASH` binary(64) DEFAULT NULL,
  `LONG_VALUE_HASH_LOWER_CASE` binary(64) DEFAULT NULL,
  `LONG_VALUE` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  PRIMARY KEY (`ID`),
  KEY `IDX_FU_ATTRIBUTE` (`USER_ID`,`REALM_ID`,`NAME`),
  KEY `FED_USER_ATTR_LONG_VALUES` (`LONG_VALUE_HASH`,`NAME`),
  KEY `FED_USER_ATTR_LONG_VALUES_LOWER_CASE` (`LONG_VALUE_HASH_LOWER_CASE`,`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FED_USER_ATTRIBUTE`
--

LOCK TABLES `FED_USER_ATTRIBUTE` WRITE;
/*!40000 ALTER TABLE `FED_USER_ATTRIBUTE` DISABLE KEYS */;
/*!40000 ALTER TABLE `FED_USER_ATTRIBUTE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FED_USER_CONSENT`
--

DROP TABLE IF EXISTS `FED_USER_CONSENT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FED_USER_CONSENT` (
  `ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `CLIENT_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `USER_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `REALM_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `STORAGE_PROVIDER_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CREATED_DATE` bigint DEFAULT NULL,
  `LAST_UPDATED_DATE` bigint DEFAULT NULL,
  `CLIENT_STORAGE_PROVIDER` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `EXTERNAL_CLIENT_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IDX_FU_CONSENT` (`USER_ID`,`CLIENT_ID`),
  KEY `IDX_FU_CONSENT_RU` (`REALM_ID`,`USER_ID`),
  KEY `IDX_FU_CNSNT_EXT` (`USER_ID`,`CLIENT_STORAGE_PROVIDER`,`EXTERNAL_CLIENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FED_USER_CONSENT`
--

LOCK TABLES `FED_USER_CONSENT` WRITE;
/*!40000 ALTER TABLE `FED_USER_CONSENT` DISABLE KEYS */;
/*!40000 ALTER TABLE `FED_USER_CONSENT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FED_USER_CONSENT_CL_SCOPE`
--

DROP TABLE IF EXISTS `FED_USER_CONSENT_CL_SCOPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FED_USER_CONSENT_CL_SCOPE` (
  `USER_CONSENT_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `SCOPE_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`USER_CONSENT_ID`,`SCOPE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FED_USER_CONSENT_CL_SCOPE`
--

LOCK TABLES `FED_USER_CONSENT_CL_SCOPE` WRITE;
/*!40000 ALTER TABLE `FED_USER_CONSENT_CL_SCOPE` DISABLE KEYS */;
/*!40000 ALTER TABLE `FED_USER_CONSENT_CL_SCOPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FED_USER_CREDENTIAL`
--

DROP TABLE IF EXISTS `FED_USER_CREDENTIAL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FED_USER_CREDENTIAL` (
  `ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `SALT` tinyblob,
  `TYPE` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CREATED_DATE` bigint DEFAULT NULL,
  `USER_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `REALM_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `STORAGE_PROVIDER_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `USER_LABEL` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SECRET_DATA` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `CREDENTIAL_DATA` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `PRIORITY` int DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IDX_FU_CREDENTIAL` (`USER_ID`,`TYPE`),
  KEY `IDX_FU_CREDENTIAL_RU` (`REALM_ID`,`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FED_USER_CREDENTIAL`
--

LOCK TABLES `FED_USER_CREDENTIAL` WRITE;
/*!40000 ALTER TABLE `FED_USER_CREDENTIAL` DISABLE KEYS */;
/*!40000 ALTER TABLE `FED_USER_CREDENTIAL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FED_USER_GROUP_MEMBERSHIP`
--

DROP TABLE IF EXISTS `FED_USER_GROUP_MEMBERSHIP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FED_USER_GROUP_MEMBERSHIP` (
  `GROUP_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `USER_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `REALM_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `STORAGE_PROVIDER_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`GROUP_ID`,`USER_ID`),
  KEY `IDX_FU_GROUP_MEMBERSHIP` (`USER_ID`,`GROUP_ID`),
  KEY `IDX_FU_GROUP_MEMBERSHIP_RU` (`REALM_ID`,`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FED_USER_GROUP_MEMBERSHIP`
--

LOCK TABLES `FED_USER_GROUP_MEMBERSHIP` WRITE;
/*!40000 ALTER TABLE `FED_USER_GROUP_MEMBERSHIP` DISABLE KEYS */;
/*!40000 ALTER TABLE `FED_USER_GROUP_MEMBERSHIP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FED_USER_REQUIRED_ACTION`
--

DROP TABLE IF EXISTS `FED_USER_REQUIRED_ACTION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FED_USER_REQUIRED_ACTION` (
  `REQUIRED_ACTION` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ' ',
  `USER_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `REALM_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `STORAGE_PROVIDER_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`REQUIRED_ACTION`,`USER_ID`),
  KEY `IDX_FU_REQUIRED_ACTION` (`USER_ID`,`REQUIRED_ACTION`),
  KEY `IDX_FU_REQUIRED_ACTION_RU` (`REALM_ID`,`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FED_USER_REQUIRED_ACTION`
--

LOCK TABLES `FED_USER_REQUIRED_ACTION` WRITE;
/*!40000 ALTER TABLE `FED_USER_REQUIRED_ACTION` DISABLE KEYS */;
/*!40000 ALTER TABLE `FED_USER_REQUIRED_ACTION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FED_USER_ROLE_MAPPING`
--

DROP TABLE IF EXISTS `FED_USER_ROLE_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FED_USER_ROLE_MAPPING` (
  `ROLE_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `USER_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `REALM_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `STORAGE_PROVIDER_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ROLE_ID`,`USER_ID`),
  KEY `IDX_FU_ROLE_MAPPING` (`USER_ID`,`ROLE_ID`),
  KEY `IDX_FU_ROLE_MAPPING_RU` (`REALM_ID`,`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FED_USER_ROLE_MAPPING`
--

LOCK TABLES `FED_USER_ROLE_MAPPING` WRITE;
/*!40000 ALTER TABLE `FED_USER_ROLE_MAPPING` DISABLE KEYS */;
/*!40000 ALTER TABLE `FED_USER_ROLE_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GROUP_ATTRIBUTE`
--

DROP TABLE IF EXISTS `GROUP_ATTRIBUTE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GROUP_ATTRIBUTE` (
  `ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'sybase-needs-something-here',
  `NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `GROUP_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IDX_GROUP_ATTR_GROUP` (`GROUP_ID`),
  KEY `IDX_GROUP_ATT_BY_NAME_VALUE` (`NAME`,`VALUE`),
  CONSTRAINT `FK_GROUP_ATTRIBUTE_GROUP` FOREIGN KEY (`GROUP_ID`) REFERENCES `KEYCLOAK_GROUP` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GROUP_ATTRIBUTE`
--

LOCK TABLES `GROUP_ATTRIBUTE` WRITE;
/*!40000 ALTER TABLE `GROUP_ATTRIBUTE` DISABLE KEYS */;
/*!40000 ALTER TABLE `GROUP_ATTRIBUTE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GROUP_ROLE_MAPPING`
--

DROP TABLE IF EXISTS `GROUP_ROLE_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GROUP_ROLE_MAPPING` (
  `ROLE_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `GROUP_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`ROLE_ID`,`GROUP_ID`),
  KEY `IDX_GROUP_ROLE_MAPP_GROUP` (`GROUP_ID`),
  CONSTRAINT `FK_GROUP_ROLE_GROUP` FOREIGN KEY (`GROUP_ID`) REFERENCES `KEYCLOAK_GROUP` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GROUP_ROLE_MAPPING`
--

LOCK TABLES `GROUP_ROLE_MAPPING` WRITE;
/*!40000 ALTER TABLE `GROUP_ROLE_MAPPING` DISABLE KEYS */;
INSERT INTO `GROUP_ROLE_MAPPING` VALUES ('1842460e-8b69-4c32-9ac6-8243dfe49639','43644117-0a68-4f54-9d9d-a79bc788da6d'),('1ccfecb5-77d3-4481-b925-5789f09a98b7','43644117-0a68-4f54-9d9d-a79bc788da6d'),('3403b29b-e3b6-4ddb-b28e-cde0092e9a7b','43644117-0a68-4f54-9d9d-a79bc788da6d'),('3ba06e2e-8369-4329-99c5-f48c8c7a2c39','43644117-0a68-4f54-9d9d-a79bc788da6d'),('781d96e7-76e4-405e-a5d3-dde6a26bdb12','43644117-0a68-4f54-9d9d-a79bc788da6d'),('8d4c4127-a801-4654-83a1-4ac23c6da4b3','43644117-0a68-4f54-9d9d-a79bc788da6d'),('a0e43a7c-29f7-4e91-804d-08d094de488b','43644117-0a68-4f54-9d9d-a79bc788da6d'),('bcbc6ae1-2e22-494d-b760-0e8583355525','43644117-0a68-4f54-9d9d-a79bc788da6d'),('bea852e4-dc8c-4fa9-ab23-9e025bad558c','43644117-0a68-4f54-9d9d-a79bc788da6d'),('37b4a72a-ca7e-43bc-9d11-27fa7b625185','4a12dce5-7432-4a69-bc53-924bb8e14763'),('3af4e50d-5229-4db2-8514-bd654206469c','4a12dce5-7432-4a69-bc53-924bb8e14763'),('bb7e3087-8ad5-46fb-a66f-f201749b77dd','4a12dce5-7432-4a69-bc53-924bb8e14763'),('22ffa567-5b11-4982-afc8-f3116f592f31','5464c1af-8480-4c16-8300-3b63853b191b'),('58e44ab5-ff5a-49d1-87a5-004b50d7bc4d','5464c1af-8480-4c16-8300-3b63853b191b'),('889edec8-6fd2-40ca-ab3a-4a640e0312c3','5464c1af-8480-4c16-8300-3b63853b191b'),('8cfa4596-c794-4a7d-81b7-9be60295cddc','5464c1af-8480-4c16-8300-3b63853b191b'),('a929749a-7c30-4cf2-9d55-34294c77b091','5464c1af-8480-4c16-8300-3b63853b191b'),('cc4ba29a-6d5f-4a44-8708-f04fa4685152','5464c1af-8480-4c16-8300-3b63853b191b'),('ccd1d72a-1899-4330-959a-dcd53fdf08f3','5464c1af-8480-4c16-8300-3b63853b191b'),('d804beeb-4b12-42b9-ab6f-8fc8e14d8d1d','5464c1af-8480-4c16-8300-3b63853b191b'),('eb01e416-d8d8-48cb-96d4-a5a526fbf81a','5464c1af-8480-4c16-8300-3b63853b191b'),('f5dbedbe-8f75-4d1d-8cef-888c8c59bf54','5464c1af-8480-4c16-8300-3b63853b191b'),('f885a621-175f-4a11-88ac-9d3f778b4920','5464c1af-8480-4c16-8300-3b63853b191b'),('12d42716-ddf9-4a1c-ae19-509770c173fc','566021f0-f4e8-4ea0-b6ba-72a3c5b35599'),('2480e19a-9b3d-457e-b01c-31d5a8c71d21','566021f0-f4e8-4ea0-b6ba-72a3c5b35599'),('2c421755-e3f0-44bb-9dc9-23664ba75999','566021f0-f4e8-4ea0-b6ba-72a3c5b35599'),('72e02da3-38f0-44af-b047-334e0575c99b','566021f0-f4e8-4ea0-b6ba-72a3c5b35599'),('77b1f911-ab47-423f-b7c7-59dde8e6ddc1','566021f0-f4e8-4ea0-b6ba-72a3c5b35599'),('a2ba492e-1b3f-4e0a-a2c9-b8cb97bea491','566021f0-f4e8-4ea0-b6ba-72a3c5b35599'),('b115f8b3-9300-49e9-962d-3094c4c9d2a3','566021f0-f4e8-4ea0-b6ba-72a3c5b35599'),('bbc5975f-d084-4af5-bc84-e3434c57ea21','566021f0-f4e8-4ea0-b6ba-72a3c5b35599'),('de9e3906-1f7d-46fc-b1e0-c7479b359373','566021f0-f4e8-4ea0-b6ba-72a3c5b35599'),('e7f4c7bb-c736-44ad-a932-fa9ff147e6d7','566021f0-f4e8-4ea0-b6ba-72a3c5b35599'),('2346b050-3bf2-4dcf-93f4-bc6079ceba05','628a4475-dc04-4f04-8232-82952becec7d'),('37b4a72a-ca7e-43bc-9d11-27fa7b625185','628a4475-dc04-4f04-8232-82952becec7d'),('48d39a36-0001-4b24-8ff4-713fce6ee144','628a4475-dc04-4f04-8232-82952becec7d'),('a07756dd-2e41-414c-9017-b93afd3bb522','628a4475-dc04-4f04-8232-82952becec7d'),('a9a48d94-076e-4dd8-902b-fa5b4cc92561','628a4475-dc04-4f04-8232-82952becec7d'),('bb7e3087-8ad5-46fb-a66f-f201749b77dd','628a4475-dc04-4f04-8232-82952becec7d'),('bf97ff26-b23e-498d-8d8b-536773b9d834','628a4475-dc04-4f04-8232-82952becec7d'),('d4462f7a-1c48-4ba1-b24f-3e0f8c82e550','628a4475-dc04-4f04-8232-82952becec7d'),('10726d7c-b18f-4cee-86ed-85b47f0cf37e','73327fb8-7eba-416c-b98a-eacbf51d1137'),('1e93736d-f776-45b2-a96b-d25eea66709b','73327fb8-7eba-416c-b98a-eacbf51d1137'),('22443081-8011-43ff-b0db-7c73d25c8539','73327fb8-7eba-416c-b98a-eacbf51d1137'),('22ffa567-5b11-4982-afc8-f3116f592f31','73327fb8-7eba-416c-b98a-eacbf51d1137'),('23eaffa9-c12b-4f4c-93b2-6c4ac04ada97','73327fb8-7eba-416c-b98a-eacbf51d1137'),('2aec1f96-5ff5-4c69-8762-e27ccf92b0aa','73327fb8-7eba-416c-b98a-eacbf51d1137'),('35326eab-a0bd-41ec-a152-be9086d25489','73327fb8-7eba-416c-b98a-eacbf51d1137'),('402f483e-b25a-4ef6-a7b5-edd149476a66','73327fb8-7eba-416c-b98a-eacbf51d1137'),('70c3353e-289e-4686-b254-6a8475f53402','73327fb8-7eba-416c-b98a-eacbf51d1137'),('7fcb25fc-35c6-4ad3-8519-d4bc40635022','73327fb8-7eba-416c-b98a-eacbf51d1137'),('9df676e9-1d82-416a-b64e-342b628b22fd','73327fb8-7eba-416c-b98a-eacbf51d1137'),('a00df050-5498-4548-89e5-a8e0d746b586','73327fb8-7eba-416c-b98a-eacbf51d1137'),('c632a80d-e13b-4858-96a1-98211e7835a7','73327fb8-7eba-416c-b98a-eacbf51d1137'),('efba8528-db6b-44f6-a982-8b9e095d3927','73327fb8-7eba-416c-b98a-eacbf51d1137'),('054bebcf-01e1-4372-bde4-ff06daa0d164','a874c900-56b5-43c9-84cc-e2232d01accf'),('120ca44d-f527-4bb3-9583-d8161284cbde','a874c900-56b5-43c9-84cc-e2232d01accf'),('14981c9f-810f-446c-a117-cc854b2b7835','a874c900-56b5-43c9-84cc-e2232d01accf'),('14ac522d-5f9f-495c-8481-87e42bb08980','a874c900-56b5-43c9-84cc-e2232d01accf'),('14f729d2-c548-4e43-bb0c-d974bc6af896','a874c900-56b5-43c9-84cc-e2232d01accf'),('1ccfecb5-77d3-4481-b925-5789f09a98b7','a874c900-56b5-43c9-84cc-e2232d01accf'),('2ecf43c0-432d-42d6-9dfc-cc1445361baf','a874c900-56b5-43c9-84cc-e2232d01accf'),('308a36be-0b75-42e8-8917-b711d045134d','a874c900-56b5-43c9-84cc-e2232d01accf'),('3403b29b-e3b6-4ddb-b28e-cde0092e9a7b','a874c900-56b5-43c9-84cc-e2232d01accf'),('3bc6bb6e-0c42-420c-9484-ba27cad08e7f','a874c900-56b5-43c9-84cc-e2232d01accf'),('4b6e58bc-31ce-4f87-ba54-d537ca2592cd','a874c900-56b5-43c9-84cc-e2232d01accf'),('52aac4f5-6406-4895-9c5f-7f8ffdd8413a','a874c900-56b5-43c9-84cc-e2232d01accf'),('8d4c4127-a801-4654-83a1-4ac23c6da4b3','a874c900-56b5-43c9-84cc-e2232d01accf'),('a0e43a7c-29f7-4e91-804d-08d094de488b','a874c900-56b5-43c9-84cc-e2232d01accf'),('afaee320-f76a-48ad-a700-b106d05813d9','a874c900-56b5-43c9-84cc-e2232d01accf'),('b6f16505-bdbe-4ee0-af77-06ddb84cb62c','a874c900-56b5-43c9-84cc-e2232d01accf'),('b82479b2-0770-4d20-b015-ffeb651b6fe1','a874c900-56b5-43c9-84cc-e2232d01accf'),('b8d4e191-773f-4142-a859-8314a7fb5926','a874c900-56b5-43c9-84cc-e2232d01accf'),('bea852e4-dc8c-4fa9-ab23-9e025bad558c','a874c900-56b5-43c9-84cc-e2232d01accf'),('c0e4d349-85f5-47fd-8f93-aa8cdaf816bf','a874c900-56b5-43c9-84cc-e2232d01accf'),('c181012a-31a5-4a76-acf7-75d7a6e0bb59','a874c900-56b5-43c9-84cc-e2232d01accf'),('c1fab73c-9b32-4931-b49a-0e25ada0f0b6','a874c900-56b5-43c9-84cc-e2232d01accf'),('cd22ea20-4224-4b01-a4d3-29d97a306861','a874c900-56b5-43c9-84cc-e2232d01accf'),('ce03ff53-dd1f-4a70-96f9-fee461bdfe4b','a874c900-56b5-43c9-84cc-e2232d01accf'),('ce4d96ba-0759-4405-b77c-9ac5ec5ca368','a874c900-56b5-43c9-84cc-e2232d01accf'),('ce545cba-3739-491a-a4b0-2178a6a9ec45','a874c900-56b5-43c9-84cc-e2232d01accf'),('d373fd80-c342-49d9-8c2e-ab0a7b0e7a37','a874c900-56b5-43c9-84cc-e2232d01accf'),('d98a0753-50e2-45e1-b0c9-e98d41bd64ce','a874c900-56b5-43c9-84cc-e2232d01accf'),('dc509253-74e0-43b0-8d0c-6f9895dffae4','a874c900-56b5-43c9-84cc-e2232d01accf'),('de71c678-fba9-42bc-a16c-a0a339d0c820','a874c900-56b5-43c9-84cc-e2232d01accf'),('e6320424-9682-466c-bc33-131ffeb0c062','a874c900-56b5-43c9-84cc-e2232d01accf'),('2ecf43c0-432d-42d6-9dfc-cc1445361baf','bbeb9671-7a62-4333-a809-b4138e11a4ed'),('3403b29b-e3b6-4ddb-b28e-cde0092e9a7b','bbeb9671-7a62-4333-a809-b4138e11a4ed'),('3bc6bb6e-0c42-420c-9484-ba27cad08e7f','bbeb9671-7a62-4333-a809-b4138e11a4ed'),('45220250-6002-4f8a-bb49-f3dbe07fd3fc','bbeb9671-7a62-4333-a809-b4138e11a4ed'),('46ac402d-f653-4c27-887f-685a697f46e9','bbeb9671-7a62-4333-a809-b4138e11a4ed'),('46f7a006-c3b2-4fcb-9265-6b7715daeeb5','bbeb9671-7a62-4333-a809-b4138e11a4ed'),('5e3951fd-7594-4bd3-8a12-84dbc1552d13','bbeb9671-7a62-4333-a809-b4138e11a4ed'),('66ee0cf6-ed60-42b7-8bd8-ee497863d25f','bbeb9671-7a62-4333-a809-b4138e11a4ed'),('8d4c4127-a801-4654-83a1-4ac23c6da4b3','bbeb9671-7a62-4333-a809-b4138e11a4ed'),('93d8d4e2-303c-47d4-9eb9-4a599f4bd9b1','bbeb9671-7a62-4333-a809-b4138e11a4ed'),('9f71496a-1d21-4282-8032-cc93fdac806d','bbeb9671-7a62-4333-a809-b4138e11a4ed'),('a0e43a7c-29f7-4e91-804d-08d094de488b','bbeb9671-7a62-4333-a809-b4138e11a4ed'),('bea852e4-dc8c-4fa9-ab23-9e025bad558c','bbeb9671-7a62-4333-a809-b4138e11a4ed'),('c0e4d349-85f5-47fd-8f93-aa8cdaf816bf','bbeb9671-7a62-4333-a809-b4138e11a4ed'),('c1fab73c-9b32-4931-b49a-0e25ada0f0b6','bbeb9671-7a62-4333-a809-b4138e11a4ed'),('cd22ea20-4224-4b01-a4d3-29d97a306861','bbeb9671-7a62-4333-a809-b4138e11a4ed'),('ce03ff53-dd1f-4a70-96f9-fee461bdfe4b','bbeb9671-7a62-4333-a809-b4138e11a4ed'),('d373fd80-c342-49d9-8c2e-ab0a7b0e7a37','bbeb9671-7a62-4333-a809-b4138e11a4ed'),('d85332df-5cd4-4bd2-aecd-e53fc4db8ef0','bbeb9671-7a62-4333-a809-b4138e11a4ed'),('dc509253-74e0-43b0-8d0c-6f9895dffae4','bbeb9671-7a62-4333-a809-b4138e11a4ed'),('e2e3689c-e30f-40f8-90af-cc7b3376724e','bbeb9671-7a62-4333-a809-b4138e11a4ed'),('f067a7b5-0166-4344-8365-0c28dd53e023','bbeb9671-7a62-4333-a809-b4138e11a4ed'),('1ccfecb5-77d3-4481-b925-5789f09a98b7','c262046d-3b62-41ca-89f5-747cdbcf472a'),('2d956fc3-dca7-4ccc-b390-6226598a9fb9','c262046d-3b62-41ca-89f5-747cdbcf472a'),('3403b29b-e3b6-4ddb-b28e-cde0092e9a7b','c262046d-3b62-41ca-89f5-747cdbcf472a'),('75fd73bb-ffba-45bc-9115-f326a69abd9e','c262046d-3b62-41ca-89f5-747cdbcf472a'),('8d4c4127-a801-4654-83a1-4ac23c6da4b3','c262046d-3b62-41ca-89f5-747cdbcf472a'),('a0e43a7c-29f7-4e91-804d-08d094de488b','c262046d-3b62-41ca-89f5-747cdbcf472a'),('bea852e4-dc8c-4fa9-ab23-9e025bad558c','c262046d-3b62-41ca-89f5-747cdbcf472a');
/*!40000 ALTER TABLE `GROUP_ROLE_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IDENTITY_PROVIDER`
--

DROP TABLE IF EXISTS `IDENTITY_PROVIDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `IDENTITY_PROVIDER` (
  `INTERNAL_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ENABLED` bit(1) NOT NULL DEFAULT b'0',
  `PROVIDER_ALIAS` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PROVIDER_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `STORE_TOKEN` bit(1) NOT NULL DEFAULT b'0',
  `AUTHENTICATE_BY_DEFAULT` bit(1) NOT NULL DEFAULT b'0',
  `REALM_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ADD_TOKEN_ROLE` bit(1) NOT NULL DEFAULT b'1',
  `TRUST_EMAIL` bit(1) NOT NULL DEFAULT b'0',
  `FIRST_BROKER_LOGIN_FLOW_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `POST_BROKER_LOGIN_FLOW_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PROVIDER_DISPLAY_NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `LINK_ONLY` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`INTERNAL_ID`),
  UNIQUE KEY `UK_2DAELWNIBJI49AVXSRTUF6XJ33` (`PROVIDER_ALIAS`,`REALM_ID`),
  KEY `IDX_IDENT_PROV_REALM` (`REALM_ID`),
  CONSTRAINT `FK2B4EBC52AE5C3B34` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IDENTITY_PROVIDER`
--

LOCK TABLES `IDENTITY_PROVIDER` WRITE;
/*!40000 ALTER TABLE `IDENTITY_PROVIDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `IDENTITY_PROVIDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IDENTITY_PROVIDER_CONFIG`
--

DROP TABLE IF EXISTS `IDENTITY_PROVIDER_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `IDENTITY_PROVIDER_CONFIG` (
  `IDENTITY_PROVIDER_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`IDENTITY_PROVIDER_ID`,`NAME`),
  CONSTRAINT `FKDC4897CF864C4E43` FOREIGN KEY (`IDENTITY_PROVIDER_ID`) REFERENCES `IDENTITY_PROVIDER` (`INTERNAL_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IDENTITY_PROVIDER_CONFIG`
--

LOCK TABLES `IDENTITY_PROVIDER_CONFIG` WRITE;
/*!40000 ALTER TABLE `IDENTITY_PROVIDER_CONFIG` DISABLE KEYS */;
/*!40000 ALTER TABLE `IDENTITY_PROVIDER_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IDENTITY_PROVIDER_MAPPER`
--

DROP TABLE IF EXISTS `IDENTITY_PROVIDER_MAPPER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `IDENTITY_PROVIDER_MAPPER` (
  `ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `IDP_ALIAS` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `IDP_MAPPER_NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `REALM_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IDX_ID_PROV_MAPP_REALM` (`REALM_ID`),
  CONSTRAINT `FK_IDPM_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IDENTITY_PROVIDER_MAPPER`
--

LOCK TABLES `IDENTITY_PROVIDER_MAPPER` WRITE;
/*!40000 ALTER TABLE `IDENTITY_PROVIDER_MAPPER` DISABLE KEYS */;
/*!40000 ALTER TABLE `IDENTITY_PROVIDER_MAPPER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IDP_MAPPER_CONFIG`
--

DROP TABLE IF EXISTS `IDP_MAPPER_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `IDP_MAPPER_CONFIG` (
  `IDP_MAPPER_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`IDP_MAPPER_ID`,`NAME`),
  CONSTRAINT `FK_IDPMCONFIG` FOREIGN KEY (`IDP_MAPPER_ID`) REFERENCES `IDENTITY_PROVIDER_MAPPER` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IDP_MAPPER_CONFIG`
--

LOCK TABLES `IDP_MAPPER_CONFIG` WRITE;
/*!40000 ALTER TABLE `IDP_MAPPER_CONFIG` DISABLE KEYS */;
/*!40000 ALTER TABLE `IDP_MAPPER_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `KEYCLOAK_GROUP`
--

DROP TABLE IF EXISTS `KEYCLOAK_GROUP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `KEYCLOAK_GROUP` (
  `ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `NAME` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `PARENT_GROUP` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `REALM_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `SIBLING_NAMES` (`REALM_ID`,`PARENT_GROUP`,`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `KEYCLOAK_GROUP`
--

LOCK TABLES `KEYCLOAK_GROUP` WRITE;
/*!40000 ALTER TABLE `KEYCLOAK_GROUP` DISABLE KEYS */;
INSERT INTO `KEYCLOAK_GROUP` VALUES ('c262046d-3b62-41ca-89f5-747cdbcf472a','clinic_admin',' ','hi'),('43644117-0a68-4f54-9d9d-a79bc788da6d','country_admin',' ','hi'),('a874c900-56b5-43c9-84cc-e2232d01accf','organization_admin',' ','hi'),('bbeb9671-7a62-4333-a809-b4138e11a4ed','super_admin',' ','hi'),('566021f0-f4e8-4ea0-b6ba-72a3c5b35599','translator',' ','hi'),('628a4475-dc04-4f04-8232-82952becec7d','admin',' ','hi-library'),('4a12dce5-7432-4a69-bc53-924bb8e14763','moderator',' ','hi-library'),('5464c1af-8480-4c16-8300-3b63853b191b','patient',' ','hi-therapist'),('73327fb8-7eba-416c-b98a-eacbf51d1137','therapist',' ','hi-therapist');
/*!40000 ALTER TABLE `KEYCLOAK_GROUP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `KEYCLOAK_ROLE`
--

DROP TABLE IF EXISTS `KEYCLOAK_ROLE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `KEYCLOAK_ROLE` (
  `ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `CLIENT_REALM_CONSTRAINT` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CLIENT_ROLE` bit(1) DEFAULT NULL,
  `DESCRIPTION` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `NAME` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `REALM_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CLIENT` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REALM` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_J3RWUVD56ONTGSUHOGM184WW2-2` (`NAME`,`CLIENT_REALM_CONSTRAINT`),
  KEY `IDX_KEYCLOAK_ROLE_CLIENT` (`CLIENT`),
  KEY `IDX_KEYCLOAK_ROLE_REALM` (`REALM`),
  CONSTRAINT `FK_6VYQFE4CN4WLQ8R6KT5VDSJ5C` FOREIGN KEY (`REALM`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `KEYCLOAK_ROLE`
--

LOCK TABLES `KEYCLOAK_ROLE` WRITE;
/*!40000 ALTER TABLE `KEYCLOAK_ROLE` DISABLE KEYS */;
INSERT INTO `KEYCLOAK_ROLE` VALUES ('00ae66f6-1cf0-44be-936b-9e45bd50c9ab','2410b91c-be58-4f3c-a4ae-83cd998c8f6c',_binary '','${role_view-realm}','view-realm','master','2410b91c-be58-4f3c-a4ae-83cd998c8f6c',NULL),('01373fa2-c341-4881-8b0e-942183911915','cea71342-d5fb-4873-b97d-21ac890e6c72',_binary '','${role_query-clients}','query-clients','master','cea71342-d5fb-4873-b97d-21ac890e6c72',NULL),('032f3007-2de0-4d68-a1f2-2bcb362c49e4','hi-therapist',_binary '\0','${role_default-roles-hi-therapist}','default-roles-hi-therapist','hi-therapist',NULL,'hi-therapist'),('054bebcf-01e1-4372-bde4-ff06daa0d164','eec28897-b54a-4d82-9488-f454e28d01ea',_binary '','${role_manage-realm}','manage-realm','hi','eec28897-b54a-4d82-9488-f454e28d01ea',NULL),('059bac13-47e5-4328-87b6-91d719adb748','hi',_binary '\0','${role_default-roles-hi}','default-roles-hi','hi',NULL,'hi'),('07caf862-aa71-42e2-8e1b-72636efc39ed','hi',_binary '\0',NULL,'view_educational_material','hi',NULL,'hi'),('0bd1e972-359f-4451-a62d-d219f1d3e1f5','hi',_binary '\0',NULL,'view_questionnaire','hi',NULL,'hi'),('0dba3061-2a7f-4419-a9e1-e79a52a1e0d9','b3fea689-45c7-4c2b-96ef-b389a0355159',_binary '','${role_read-token}','read-token','hi-library','b3fea689-45c7-4c2b-96ef-b389a0355159',NULL),('0ee3a335-cb19-472e-84d5-57498e202144','e7c18adf-18b9-48fc-92a0-698f43736bcd',_binary '','${role_view-users}','view-users','master','e7c18adf-18b9-48fc-92a0-698f43736bcd',NULL),('10726d7c-b18f-4cee-86ed-85b47f0cf37e','ead46d75-3ebd-458d-8d9a-8df75b027507',_binary '','${role_manage-users}','manage-users','hi-therapist','ead46d75-3ebd-458d-8d9a-8df75b027507',NULL),('120ca44d-f527-4bb3-9583-d8161284cbde','eec28897-b54a-4d82-9488-f454e28d01ea',_binary '','${role_create-client}','create-client','hi','eec28897-b54a-4d82-9488-f454e28d01ea',NULL),('1211a063-da3c-4820-b606-6fd4f291bc9e','a70bea3e-e035-439e-a52a-b15206b54b29',_binary '','${role_manage-account-links}','manage-account-links','master','a70bea3e-e035-439e-a52a-b15206b54b29',NULL),('12d42716-ddf9-4a1c-ae19-509770c173fc','hi',_binary '\0',NULL,'translate_exercise','hi',NULL,'hi'),('14981c9f-810f-446c-a117-cc854b2b7835','hi',_binary '\0','Able to manage the color scheme','manage_color_scheme','hi',NULL,'hi'),('14ac522d-5f9f-495c-8481-87e42bb08980','eec28897-b54a-4d82-9488-f454e28d01ea',_binary '','${role_impersonation}','impersonation','hi','eec28897-b54a-4d82-9488-f454e28d01ea',NULL),('14f729d2-c548-4e43-bb0c-d974bc6af896','eec28897-b54a-4d82-9488-f454e28d01ea',_binary '','${role_query-groups}','query-groups','hi','eec28897-b54a-4d82-9488-f454e28d01ea',NULL),('16f34db3-a6ac-4df5-b516-16890e1201a5','59b01532-686c-41a7-a818-8cd64adb99f5',_binary '','${role_manage-authorization}','manage-authorization','master','59b01532-686c-41a7-a818-8cd64adb99f5',NULL),('1842460e-8b69-4c32-9ac6-8243dfe49639','hi',_binary '\0','','country_admin','hi',NULL,NULL),('18ad43de-71c2-4a8b-ad73-f07085acdf31','89d22c6b-7a3a-406a-8635-049ea85abb55',_binary '','${role_manage-account}','manage-account','hi-therapist','89d22c6b-7a3a-406a-8635-049ea85abb55',NULL),('1a46e084-3c0f-47a6-a387-8a6a81704c2f','2410b91c-be58-4f3c-a4ae-83cd998c8f6c',_binary '','${role_query-groups}','query-groups','master','2410b91c-be58-4f3c-a4ae-83cd998c8f6c',NULL),('1b4216cf-f78b-4be9-96b1-fd005cf0e73b','hi',_binary '\0',NULL,'translator','hi',NULL,'hi'),('1c1676e8-93d6-4468-a1ed-ef29a45da551','ac8a7f4f-fefc-4a43-bc0f-b42078184dc5',_binary '','${role_read-token}','read-token','hi','ac8a7f4f-fefc-4a43-bc0f-b42078184dc5',NULL),('1cb16ce1-3a7f-43b9-bacf-10c1ad9a49bc','55c52d92-7f2e-40b2-8cef-35e558d2c72b',_binary '','${role_manage-account-links}','manage-account-links','hi','55c52d92-7f2e-40b2-8cef-35e558d2c72b',NULL),('1ccfecb5-77d3-4481-b925-5789f09a98b7','hi',_binary '\0',NULL,'view_dashboard','hi',NULL,'hi'),('1d33e369-a70f-4178-aafe-6907f30eb041','hi-therapist',_binary '\0',NULL,'setup_category','hi-therapist',NULL,'hi-therapist'),('1dc40da9-ce99-4be0-a632-9765bf897854','hi-therapist',_binary '\0','Able to CRUD the therapist user','manage_therapist','hi-therapist',NULL,'hi-therapist'),('1e93736d-f776-45b2-a96b-d25eea66709b','ead46d75-3ebd-458d-8d9a-8df75b027507',_binary '','${role_query-groups}','query-groups','hi-therapist','ead46d75-3ebd-458d-8d9a-8df75b027507',NULL),('21b3d453-d39d-4fd8-84a0-bf6ee4f2d404','59b01532-686c-41a7-a818-8cd64adb99f5',_binary '','${role_manage-users}','manage-users','master','59b01532-686c-41a7-a818-8cd64adb99f5',NULL),('22443081-8011-43ff-b0db-7c73d25c8539','ead46d75-3ebd-458d-8d9a-8df75b027507',_binary '','${role_query-clients}','query-clients','hi-therapist','ead46d75-3ebd-458d-8d9a-8df75b027507',NULL),('22d81b87-2705-4b8a-9f17-d8c73bbb8ada','0ae8de67-23f4-49b2-8672-75bb2dedc900',_binary '','${role_query-groups}','query-groups','hi-library','0ae8de67-23f4-49b2-8672-75bb2dedc900',NULL),('22ffa567-5b11-4982-afc8-f3116f592f31','89d22c6b-7a3a-406a-8635-049ea85abb55',_binary '','${role_view-profile}','view-profile','hi-therapist','89d22c6b-7a3a-406a-8635-049ea85abb55',NULL),('2346b050-3bf2-4dcf-93f4-bc6079ceba05','hi-library',_binary '\0','Manage translation','manage_translation','hi-library',NULL,'hi-library'),('23eaffa9-c12b-4f4c-93b2-6c4ac04ada97','ead46d75-3ebd-458d-8d9a-8df75b027507',_binary '','${role_manage-identity-providers}','manage-identity-providers','hi-therapist','ead46d75-3ebd-458d-8d9a-8df75b027507',NULL),('242285dd-bda3-4f01-a8c5-8edf054b9c00','ead46d75-3ebd-458d-8d9a-8df75b027507',_binary '','${role_view-clients}','view-clients','hi-therapist','ead46d75-3ebd-458d-8d9a-8df75b027507',NULL),('2480e19a-9b3d-457e-b01c-31d5a8c71d21','hi',_binary '\0',NULL,'translate_guidance_page','hi',NULL,'hi'),('25a749a3-7053-4ec9-b2d3-345ffb0b9cf5','dd77b2d7-5ee9-4a5d-a25a-eb152157fb4c',_binary '','${role_delete-account}','delete-account','hi-library','dd77b2d7-5ee9-4a5d-a25a-eb152157fb4c',NULL),('26ffdef8-ad2b-4982-b273-13a8613a8fae','59b01532-686c-41a7-a818-8cd64adb99f5',_binary '','${role_view-events}','view-events','master','59b01532-686c-41a7-a818-8cd64adb99f5',NULL),('2830fd54-4c44-4201-bd85-d52bbfc5ee31','cea71342-d5fb-4873-b97d-21ac890e6c72',_binary '','${role_manage-events}','manage-events','master','cea71342-d5fb-4873-b97d-21ac890e6c72',NULL),('28a570b2-8bd0-49f5-a9d3-ab2cafefb639','master',_binary '\0','${role_offline-access}','offline_access','master',NULL,'master'),('298e3fa8-5bb9-43f6-8859-f09da0d5c99b','a70bea3e-e035-439e-a52a-b15206b54b29',_binary '','${role_manage-account}','manage-account','master','a70bea3e-e035-439e-a52a-b15206b54b29',NULL),('29a39de2-caac-47cc-bcce-18f040c746dc','2410b91c-be58-4f3c-a4ae-83cd998c8f6c',_binary '','${role_view-users}','view-users','master','2410b91c-be58-4f3c-a4ae-83cd998c8f6c',NULL),('2ae4040e-08ea-4c17-ac2f-6bbf064c4342','59b01532-686c-41a7-a818-8cd64adb99f5',_binary '','${role_view-authorization}','view-authorization','master','59b01532-686c-41a7-a818-8cd64adb99f5',NULL),('2aec1f96-5ff5-4c69-8762-e27ccf92b0aa','ead46d75-3ebd-458d-8d9a-8df75b027507',_binary '','${role_manage-events}','manage-events','hi-therapist','ead46d75-3ebd-458d-8d9a-8df75b027507',NULL),('2b3dc8b2-ff69-4268-9b64-d2f7f79f4c2c','e7c18adf-18b9-48fc-92a0-698f43736bcd',_binary '','${role_query-groups}','query-groups','master','e7c18adf-18b9-48fc-92a0-698f43736bcd',NULL),('2c421755-e3f0-44bb-9dc9-23664ba75999','hi',_binary '\0',NULL,'translate_category','hi',NULL,'hi'),('2d7c0c3c-74d3-464c-8949-5955fb9ebaaa','hi',_binary '\0',NULL,'view_exercise','hi',NULL,'hi'),('2d956fc3-dca7-4ccc-b390-6226598a9fb9','hi',_binary '\0','','clinic_admin','hi',NULL,NULL),('2e12ca9a-83f4-4aed-98a7-7fa6ea1ba299','0ae8de67-23f4-49b2-8672-75bb2dedc900',_binary '','${role_manage-users}','manage-users','hi-library','0ae8de67-23f4-49b2-8672-75bb2dedc900',NULL),('2ecf43c0-432d-42d6-9dfc-cc1445361baf','hi',_binary '\0',NULL,'setup_category','hi',NULL,'hi'),('308a36be-0b75-42e8-8917-b711d045134d','eec28897-b54a-4d82-9488-f454e28d01ea',_binary '','${role_manage-authorization}','manage-authorization','hi','eec28897-b54a-4d82-9488-f454e28d01ea',NULL),('31dd067f-5aa5-4ac2-896c-8a42efb5062e','89d22c6b-7a3a-406a-8635-049ea85abb55',_binary '','${role_manage-account-links}','manage-account-links','hi-therapist','89d22c6b-7a3a-406a-8635-049ea85abb55',NULL),('3403b29b-e3b6-4ddb-b28e-cde0092e9a7b','hi',_binary '\0',NULL,'manage_survey','hi',NULL,'hi'),('34b02a3d-8a87-46f2-87c5-f909eed28d33','2410b91c-be58-4f3c-a4ae-83cd998c8f6c',_binary '','${role_view-identity-providers}','view-identity-providers','master','2410b91c-be58-4f3c-a4ae-83cd998c8f6c',NULL),('35326eab-a0bd-41ec-a152-be9086d25489','ead46d75-3ebd-458d-8d9a-8df75b027507',_binary '','${role_manage-realm}','manage-realm','hi-therapist','ead46d75-3ebd-458d-8d9a-8df75b027507',NULL),('368e1c70-6301-46e4-ae40-067ebe468d7c','a70bea3e-e035-439e-a52a-b15206b54b29',_binary '','${role_view-profile}','view-profile','master','a70bea3e-e035-439e-a52a-b15206b54b29',NULL),('37b4a72a-ca7e-43bc-9d11-27fa7b625185','hi-library',_binary '\0','Able to CRUD the the resource, and can them','manage_resource','hi-library',NULL,'hi-library'),('38270fed-0ae0-4300-ac04-f8f0f69285af','dd77b2d7-5ee9-4a5d-a25a-eb152157fb4c',_binary '','${role_view-applications}','view-applications','hi-library','dd77b2d7-5ee9-4a5d-a25a-eb152157fb4c',NULL),('38f80631-917d-4413-9562-7cb836e89858','hi',_binary '\0','${role_offline-access}','offline_access','hi',NULL,'hi'),('3992601b-152d-4c5e-bcff-7007b41923e3','0ae8de67-23f4-49b2-8672-75bb2dedc900',_binary '','${role_view-clients}','view-clients','hi-library','0ae8de67-23f4-49b2-8672-75bb2dedc900',NULL),('3af4e50d-5229-4db2-8514-bd654206469c','hi-library',_binary '\0','Able to approve/decline resource and translation','review_resource','hi-library',NULL,'hi-library'),('3ba06e2e-8369-4329-99c5-f48c8c7a2c39','hi',_binary '\0','Able to CRUD the clinic admin user','manage_clinic_admin','hi',NULL,'hi'),('3bc6bb6e-0c42-420c-9484-ba27cad08e7f','hi',_binary '\0',NULL,'manage_static_page','hi',NULL,'hi'),('3cccce94-b48e-4c33-8958-4f7657fc314b','0ae8de67-23f4-49b2-8672-75bb2dedc900',_binary '','${role_impersonation}','impersonation','hi-library','0ae8de67-23f4-49b2-8672-75bb2dedc900',NULL),('3eaec993-a4f3-42e1-ba9a-8aaadd1df12a','hi-therapist',_binary '\0','Able to CRUD the exercise','setup_exercise','hi-therapist',NULL,'hi-therapist'),('402f483e-b25a-4ef6-a7b5-edd149476a66','ead46d75-3ebd-458d-8d9a-8df75b027507',_binary '','${role_query-users}','query-users','hi-therapist','ead46d75-3ebd-458d-8d9a-8df75b027507',NULL),('41ad038d-890e-4170-82bf-a29bb6490b65','e7c18adf-18b9-48fc-92a0-698f43736bcd',_binary '','${role_manage-clients}','manage-clients','master','e7c18adf-18b9-48fc-92a0-698f43736bcd',NULL),('425151dd-871a-4a94-80a8-8a211b216b55','59b01532-686c-41a7-a818-8cd64adb99f5',_binary '','${role_view-users}','view-users','master','59b01532-686c-41a7-a818-8cd64adb99f5',NULL),('44be220f-b334-4263-9cf7-f8f561e78cd8','eec28897-b54a-4d82-9488-f454e28d01ea',_binary '','${role_view-realm}','view-realm','hi','eec28897-b54a-4d82-9488-f454e28d01ea',NULL),('44f11c4f-11de-4930-a9bb-66f1504833af','hi-library',_binary '\0','${role_offline-access}','offline_access','hi-library',NULL,'hi-library'),('45220250-6002-4f8a-bb49-f3dbe07fd3fc','hi',_binary '\0',NULL,'manage_organization','hi',NULL,'hi'),('46ac402d-f653-4c27-887f-685a697f46e9','hi',_binary '\0',NULL,'manage_term_condition','hi',NULL,'hi'),('46f7a006-c3b2-4fcb-9265-6b7715daeeb5','hi',_binary '\0',NULL,'manage_disease','hi',NULL,'hi'),('47ae232f-75b7-4988-9298-7bdaa6765b46','hi',_binary '\0',NULL,'submit_questionnaire_answer','hi',NULL,'hi'),('48d39a36-0001-4b24-8ff4-713fce6ee144','hi-library',_binary '\0','Able to CRUD the static page','manage_static_page','hi-library',NULL,'hi-library'),('48dfb461-04ca-48a5-95e3-1371514e7f0a','0ae8de67-23f4-49b2-8672-75bb2dedc900',_binary '','${role_view-events}','view-events','hi-library','0ae8de67-23f4-49b2-8672-75bb2dedc900',NULL),('4932c89c-41ac-4345-be94-39117f2c07fd','e7c18adf-18b9-48fc-92a0-698f43736bcd',_binary '','${role_query-realms}','query-realms','master','e7c18adf-18b9-48fc-92a0-698f43736bcd',NULL),('49e18c09-e656-430c-b553-e6ecc1021764','eec28897-b54a-4d82-9488-f454e28d01ea',_binary '','${role_view-authorization}','view-authorization','hi','eec28897-b54a-4d82-9488-f454e28d01ea',NULL),('4a38d073-c8b2-4d2f-a41b-309828b871c8','dd77b2d7-5ee9-4a5d-a25a-eb152157fb4c',_binary '','${role_manage-account}','manage-account','hi-library','dd77b2d7-5ee9-4a5d-a25a-eb152157fb4c',NULL),('4a627f10-a570-4e66-8c08-563e2471582b','cea71342-d5fb-4873-b97d-21ac890e6c72',_binary '','${role_view-realm}','view-realm','master','cea71342-d5fb-4873-b97d-21ac890e6c72',NULL),('4b6e58bc-31ce-4f87-ba54-d537ca2592cd','eec28897-b54a-4d82-9488-f454e28d01ea',_binary '','${role_manage-clients}','manage-clients','hi','eec28897-b54a-4d82-9488-f454e28d01ea',NULL),('4cb97d48-2f20-4146-9b3f-2317233e53c5','hi-therapist',_binary '\0','Able to CRUD the patient','manage_patient','hi-therapist',NULL,'hi-therapist'),('4dd0c0cd-e03b-45f9-98e0-132d7209a096','55c52d92-7f2e-40b2-8cef-35e558d2c72b',_binary '','${role_view-groups}','view-groups','hi','55c52d92-7f2e-40b2-8cef-35e558d2c72b',NULL),('4e3e0eef-4bbe-4828-a15f-e121afe02340','e7c18adf-18b9-48fc-92a0-698f43736bcd',_binary '','${role_impersonation}','impersonation','master','e7c18adf-18b9-48fc-92a0-698f43736bcd',NULL),('4fa64c47-26ef-475a-9e44-28af07a418e9','2410b91c-be58-4f3c-a4ae-83cd998c8f6c',_binary '','${role_query-clients}','query-clients','master','2410b91c-be58-4f3c-a4ae-83cd998c8f6c',NULL),('52aac4f5-6406-4895-9c5f-7f8ffdd8413a','hi',_binary '\0','Able to view the term condition','view_term_condition','hi',NULL,'hi'),('52e3937a-614a-4d35-94df-cbb332b995ec','eec28897-b54a-4d82-9488-f454e28d01ea',_binary '','${role_view-identity-providers}','view-identity-providers','hi','eec28897-b54a-4d82-9488-f454e28d01ea',NULL),('53629c47-2fee-4562-a4dc-a540c93bb3e4','59b01532-686c-41a7-a818-8cd64adb99f5',_binary '','${role_view-realm}','view-realm','master','59b01532-686c-41a7-a818-8cd64adb99f5',NULL),('53d64e50-e2eb-4a7d-be80-0b8d67ec33f5','e7c18adf-18b9-48fc-92a0-698f43736bcd',_binary '','${role_view-authorization}','view-authorization','master','e7c18adf-18b9-48fc-92a0-698f43736bcd',NULL),('5460ad86-a19a-467f-ba48-9c1ad3377b1c','0ae8de67-23f4-49b2-8672-75bb2dedc900',_binary '','${role_manage-identity-providers}','manage-identity-providers','hi-library','0ae8de67-23f4-49b2-8672-75bb2dedc900',NULL),('54f3ba9c-339a-47f1-9c90-7adb0dc81720','0ae8de67-23f4-49b2-8672-75bb2dedc900',_binary '','${role_query-clients}','query-clients','hi-library','0ae8de67-23f4-49b2-8672-75bb2dedc900',NULL),('561aa322-24db-4b3e-837e-95566a8010a1','0ae8de67-23f4-49b2-8672-75bb2dedc900',_binary '','${role_view-users}','view-users','hi-library','0ae8de67-23f4-49b2-8672-75bb2dedc900',NULL),('566678c5-562a-45b4-8471-7337910500a3','cea71342-d5fb-4873-b97d-21ac890e6c72',_binary '','${role_query-users}','query-users','master','cea71342-d5fb-4873-b97d-21ac890e6c72',NULL),('56fbb983-3bbf-434a-9142-553aef29cd68','2410b91c-be58-4f3c-a4ae-83cd998c8f6c',_binary '','${role_query-users}','query-users','master','2410b91c-be58-4f3c-a4ae-83cd998c8f6c',NULL),('56fceb4c-8177-42bb-ae99-b408c919532e','0ae8de67-23f4-49b2-8672-75bb2dedc900',_binary '','${role_query-users}','query-users','hi-library','0ae8de67-23f4-49b2-8672-75bb2dedc900',NULL),('56fd0f57-bed4-4e96-a04e-7209aaa2d04e','a70bea3e-e035-439e-a52a-b15206b54b29',_binary '','${role_view-applications}','view-applications','master','a70bea3e-e035-439e-a52a-b15206b54b29',NULL),('573c17a8-7fb7-4771-a70e-9fd0582447d6','cea71342-d5fb-4873-b97d-21ac890e6c72',_binary '','${role_view-clients}','view-clients','master','cea71342-d5fb-4873-b97d-21ac890e6c72',NULL),('57f8de0b-ed99-4fa1-b2c3-9349f52799a2','hi-therapist',_binary '\0','${role_offline-access}','offline_access','hi-therapist',NULL,'hi-therapist'),('58e44ab5-ff5a-49d1-87a5-004b50d7bc4d','hi-therapist',_binary '\0',NULL,'view_goal_progress','hi-therapist',NULL,'hi-therapist'),('5902a4b5-396b-4eea-905a-c118fa71b163','89d22c6b-7a3a-406a-8635-049ea85abb55',_binary '','${role_view-applications}','view-applications','hi-therapist','89d22c6b-7a3a-406a-8635-049ea85abb55',NULL),('5a889eca-bf6b-4de9-bcdb-c4aa9bf25af7','e7c18adf-18b9-48fc-92a0-698f43736bcd',_binary '','${role_manage-users}','manage-users','master','e7c18adf-18b9-48fc-92a0-698f43736bcd',NULL),('5bd24075-4f1a-4f31-9646-d152685192a8','dd77b2d7-5ee9-4a5d-a25a-eb152157fb4c',_binary '','${role_manage-account-links}','manage-account-links','hi-library','dd77b2d7-5ee9-4a5d-a25a-eb152157fb4c',NULL),('5ddd5c4c-e4d8-45d0-a399-d240e8a434c3','0ae8de67-23f4-49b2-8672-75bb2dedc900',_binary '','${role_create-client}','create-client','hi-library','0ae8de67-23f4-49b2-8672-75bb2dedc900',NULL),('5de95d05-8d26-4af8-ba68-e403183dcd49','hi',_binary '\0',NULL,'view_appointment','hi',NULL,'hi'),('5e3951fd-7594-4bd3-8a12-84dbc1552d13','hi',_binary '\0',NULL,'manage_translation','hi',NULL,'hi'),('5eeae865-ed74-4f5b-8901-8ef7f397fb18','0ae8de67-23f4-49b2-8672-75bb2dedc900',_binary '','${role_view-authorization}','view-authorization','hi-library','0ae8de67-23f4-49b2-8672-75bb2dedc900',NULL),('619042b1-f9e2-46fc-a4cf-25d191e5412b','hi',_binary '\0','${role_uma_authorization}','uma_authorization','hi',NULL,'hi'),('62301597-66eb-4d5a-ac39-9979524c2010','cea71342-d5fb-4873-b97d-21ac890e6c72',_binary '','${role_manage-users}','manage-users','master','cea71342-d5fb-4873-b97d-21ac890e6c72',NULL),('66ee0cf6-ed60-42b7-8bd8-ee497863d25f','hi',_binary '\0',NULL,'manage_privacy_policy','hi',NULL,'hi'),('68058e8a-9155-4286-8c47-2009a9e63b39','55c52d92-7f2e-40b2-8cef-35e558d2c72b',_binary '','${role_view-consent}','view-consent','hi','55c52d92-7f2e-40b2-8cef-35e558d2c72b',NULL),('684b9754-6a4e-496d-887b-6c5a9e9b38b8','0ae8de67-23f4-49b2-8672-75bb2dedc900',_binary '','${role_manage-events}','manage-events','hi-library','0ae8de67-23f4-49b2-8672-75bb2dedc900',NULL),('68c7aa64-39d7-4257-ae05-d44e82880078','dd77b2d7-5ee9-4a5d-a25a-eb152157fb4c',_binary '','${role_view-groups}','view-groups','hi-library','dd77b2d7-5ee9-4a5d-a25a-eb152157fb4c',NULL),('6a3356b5-86ba-4956-ad4b-84cc8d51aafb','hi-therapist',_binary '\0','Able to CRUD the educational material','setup_educational_material','hi-therapist',NULL,'hi-therapist'),('6cffa52e-4534-4267-a398-63e94eef7516','59b01532-686c-41a7-a818-8cd64adb99f5',_binary '','${role_view-clients}','view-clients','master','59b01532-686c-41a7-a818-8cd64adb99f5',NULL),('6e394702-4f6a-4b94-9470-519fd14eead7','eec28897-b54a-4d82-9488-f454e28d01ea',_binary '','${role_view-users}','view-users','hi','eec28897-b54a-4d82-9488-f454e28d01ea',NULL),('70c3353e-289e-4686-b254-6a8475f53402','ead46d75-3ebd-458d-8d9a-8df75b027507',_binary '','${role_query-realms}','query-realms','hi-therapist','ead46d75-3ebd-458d-8d9a-8df75b027507',NULL),('70f1aa72-6a63-4f4b-8cbc-7e2ad035de51','e7c18adf-18b9-48fc-92a0-698f43736bcd',_binary '','${role_view-events}','view-events','master','e7c18adf-18b9-48fc-92a0-698f43736bcd',NULL),('72e02da3-38f0-44af-b047-334e0575c99b','hi',_binary '\0',NULL,'translate_educational_material','hi',NULL,'hi'),('74f0f19f-af21-4bd0-a1cb-4be5ad4f1f42','2410b91c-be58-4f3c-a4ae-83cd998c8f6c',_binary '','${role_manage-clients}','manage-clients','master','2410b91c-be58-4f3c-a4ae-83cd998c8f6c',NULL),('75fd73bb-ffba-45bc-9115-f326a69abd9e','hi',_binary '\0','Able to CRUD the therapist user','manage_therapist','hi',NULL,'hi'),('7647bb87-9809-490e-990c-48a28db22b0a','2410b91c-be58-4f3c-a4ae-83cd998c8f6c',_binary '','${role_impersonation}','impersonation','master','2410b91c-be58-4f3c-a4ae-83cd998c8f6c',NULL),('7719c68c-30ab-4a8b-a515-575e45a69aa5','434a5435-9f56-4ed6-9649-1946ac15cbfc',_binary '','${role_read-token}','read-token','master','434a5435-9f56-4ed6-9649-1946ac15cbfc',NULL),('77456bd3-b257-4094-8591-c79eab57a465','hi',_binary '\0','view, select and arrange content','create_treatment_plan_for_patient','hi',NULL,'hi'),('77b1f911-ab47-423f-b7c7-59dde8e6ddc1','hi',_binary '\0',NULL,'translate_term_condition','hi',NULL,'hi'),('77ed6c0f-1fa1-4634-8e79-4d65333ca865','master',_binary '\0','${role_default-roles-master}','default-roles-master','master',NULL,'master'),('781d96e7-76e4-405e-a5d3-dde6a26bdb12','hi',_binary '\0',NULL,'manage_clinic','hi',NULL,'hi'),('79379a0d-8564-4c5a-9281-80e6e8f9c259','89d22c6b-7a3a-406a-8635-049ea85abb55',_binary '','${role_view-consent}','view-consent','hi-therapist','89d22c6b-7a3a-406a-8635-049ea85abb55',NULL),('7a77eaa4-ec6d-4364-9d61-113997360274','0ae8de67-23f4-49b2-8672-75bb2dedc900',_binary '','${role_realm-admin}','realm-admin','hi-library','0ae8de67-23f4-49b2-8672-75bb2dedc900',NULL),('7caf6225-3ccd-4ddb-95f3-8d409c318f94','cea71342-d5fb-4873-b97d-21ac890e6c72',_binary '','${role_impersonation}','impersonation','master','cea71342-d5fb-4873-b97d-21ac890e6c72',NULL),('7d5e9c61-db23-4e8e-9ba8-bbe670180da7','59b01532-686c-41a7-a818-8cd64adb99f5',_binary '','${role_view-identity-providers}','view-identity-providers','master','59b01532-686c-41a7-a818-8cd64adb99f5',NULL),('7dd12a22-6e02-4c0d-a98a-e610c52b8678','hi-therapist',_binary '\0','Able to CRUD the country admin user','manage_country_admin','hi-therapist',NULL,'hi-therapist'),('7f932738-c306-46fb-8bb1-48b9226d467b','e7c18adf-18b9-48fc-92a0-698f43736bcd',_binary '','${role_create-client}','create-client','master','e7c18adf-18b9-48fc-92a0-698f43736bcd',NULL),('7fa3b186-7572-4edf-b1a7-c35927506483','cea71342-d5fb-4873-b97d-21ac890e6c72',_binary '','${role_query-groups}','query-groups','master','cea71342-d5fb-4873-b97d-21ac890e6c72',NULL),('7fcb25fc-35c6-4ad3-8519-d4bc40635022','ead46d75-3ebd-458d-8d9a-8df75b027507',_binary '','${role_impersonation}','impersonation','hi-therapist','ead46d75-3ebd-458d-8d9a-8df75b027507',NULL),('8010acf7-3276-4985-b12f-3cbc1a26dd3b','master',_binary '\0','${role_create-realm}','create-realm','master',NULL,'master'),('82d73cb9-7046-4cbf-acc6-176f67419ee5','hi',_binary '\0',NULL,'view_treatment_detail','hi',NULL,'hi'),('82f84986-dadb-4762-8eb8-b641d562a6e4','55c52d92-7f2e-40b2-8cef-35e558d2c72b',_binary '','${role_delete-account}','delete-account','hi','55c52d92-7f2e-40b2-8cef-35e558d2c72b',NULL),('8427a229-708a-47d2-8372-2c304119dfa7','89d22c6b-7a3a-406a-8635-049ea85abb55',_binary '','${role_delete-account}','delete-account','hi-therapist','89d22c6b-7a3a-406a-8635-049ea85abb55',NULL),('85ac723d-87f6-4438-8ff1-d2e4007bb8c4','59b01532-686c-41a7-a818-8cd64adb99f5',_binary '','${role_create-client}','create-client','master','59b01532-686c-41a7-a818-8cd64adb99f5',NULL),('864c5a94-0990-484f-be31-2a78ed815e00','0ae8de67-23f4-49b2-8672-75bb2dedc900',_binary '','${role_query-realms}','query-realms','hi-library','0ae8de67-23f4-49b2-8672-75bb2dedc900',NULL),('86cc53c6-7921-4f3a-9d08-d84718c5046f','hi',_binary '\0',NULL,'arrange_appointment','hi',NULL,'hi'),('872aaf1b-421f-4bfe-8fdb-cb90327c55e3','e7c18adf-18b9-48fc-92a0-698f43736bcd',_binary '','${role_manage-realm}','manage-realm','master','e7c18adf-18b9-48fc-92a0-698f43736bcd',NULL),('889edec8-6fd2-40ca-ab3a-4a640e0312c3','hi-therapist',_binary '\0',NULL,'view_appointment','hi-therapist',NULL,'hi-therapist'),('88c0020d-dce6-4262-9d23-beb583ea89d0','2410b91c-be58-4f3c-a4ae-83cd998c8f6c',_binary '','${role_query-realms}','query-realms','master','2410b91c-be58-4f3c-a4ae-83cd998c8f6c',NULL),('89ad497a-d027-48df-96ae-ad8810931dff','e7c18adf-18b9-48fc-92a0-698f43736bcd',_binary '','${role_view-identity-providers}','view-identity-providers','master','e7c18adf-18b9-48fc-92a0-698f43736bcd',NULL),('8cfa4596-c794-4a7d-81b7-9be60295cddc','hi-therapist',_binary '\0',NULL,'submit_exercise_result','hi-therapist',NULL,'hi-therapist'),('8d4c4127-a801-4654-83a1-4ac23c6da4b3','55c52d92-7f2e-40b2-8cef-35e558d2c72b',_binary '','${role_view-profile}','view-profile','hi','55c52d92-7f2e-40b2-8cef-35e558d2c72b',NULL),('909d09c1-22eb-4144-b5ec-30b8de651dd2','dd77b2d7-5ee9-4a5d-a25a-eb152157fb4c',_binary '','${role_manage-consent}','manage-consent','hi-library','dd77b2d7-5ee9-4a5d-a25a-eb152157fb4c',NULL),('9243fa25-7798-487d-9ce4-34e255394c7b','cea71342-d5fb-4873-b97d-21ac890e6c72',_binary '','${role_create-client}','create-client','master','cea71342-d5fb-4873-b97d-21ac890e6c72',NULL),('93d8d4e2-303c-47d4-9eb9-4a599f4bd9b1','hi',_binary '\0',NULL,'manage_translator','hi',NULL,'hi'),('9477a00f-8934-4e15-b988-08202d1975d7','ead46d75-3ebd-458d-8d9a-8df75b027507',_binary '','${role_view-users}','view-users','hi-therapist','ead46d75-3ebd-458d-8d9a-8df75b027507',NULL),('996b8b32-cfb2-4912-b250-83ed166bad34','hi-therapist',_binary '\0','Able to CRUD the clinic admin user','manage_clinic_admin','hi-therapist',NULL,'hi-therapist'),('9ac3098d-e17e-4f43-acd8-efcefdbe37c8','89d22c6b-7a3a-406a-8635-049ea85abb55',_binary '','${role_manage-consent}','manage-consent','hi-therapist','89d22c6b-7a3a-406a-8635-049ea85abb55',NULL),('9b3bf72d-8c6a-4dd2-b676-adaf85286bae','hi-therapist',_binary '\0',NULL,'arrange_appointment','hi-therapist',NULL,'hi-therapist'),('9bb9ff1d-b7b5-465b-a062-ce5008ff6cf3','0ae8de67-23f4-49b2-8672-75bb2dedc900',_binary '','${role_manage-clients}','manage-clients','hi-library','0ae8de67-23f4-49b2-8672-75bb2dedc900',NULL),('9df01365-d95e-4866-af36-e9001bf2d534','master',_binary '\0','${role_admin}','admin','master',NULL,'master'),('9df676e9-1d82-416a-b64e-342b628b22fd','ead46d75-3ebd-458d-8d9a-8df75b027507',_binary '','${role_manage-clients}','manage-clients','hi-therapist','ead46d75-3ebd-458d-8d9a-8df75b027507',NULL),('9e73d30d-39bd-4b9e-a0a4-b5acc01c762f','hi-therapist',_binary '\0','view, select and arrange content','create_treatment_plan_for_patient','hi-therapist',NULL,'hi-therapist'),('9f71496a-1d21-4282-8032-cc93fdac806d','hi',_binary '\0',NULL,'manage_guidance_page','hi',NULL,'hi'),('9fb9f866-c307-41c7-94e5-a1513edd5c68','59b01532-686c-41a7-a818-8cd64adb99f5',_binary '','${role_impersonation}','impersonation','master','59b01532-686c-41a7-a818-8cd64adb99f5',NULL),('a00df050-5498-4548-89e5-a8e0d746b586','ead46d75-3ebd-458d-8d9a-8df75b027507',_binary '','${role_create-client}','create-client','hi-therapist','ead46d75-3ebd-458d-8d9a-8df75b027507',NULL),('a07756dd-2e41-414c-9017-b93afd3bb522','hi-library',_binary '\0',NULL,'manage_language','hi-library',NULL,'hi-library'),('a082dd05-6586-48aa-aedb-4651ac05c757','a70bea3e-e035-439e-a52a-b15206b54b29',_binary '','${role_delete-account}','delete-account','master','a70bea3e-e035-439e-a52a-b15206b54b29',NULL),('a089e73e-1f72-47e1-9e6b-678d471ca446','2410b91c-be58-4f3c-a4ae-83cd998c8f6c',_binary '','${role_manage-users}','manage-users','master','2410b91c-be58-4f3c-a4ae-83cd998c8f6c',NULL),('a0e43a7c-29f7-4e91-804d-08d094de488b','hi',_binary '\0',NULL,'view_edit_own_profile','hi',NULL,'hi'),('a0ed7511-4e73-496b-8381-4830ea6c8a86','ead46d75-3ebd-458d-8d9a-8df75b027507',_binary '','${role_view-authorization}','view-authorization','hi-therapist','ead46d75-3ebd-458d-8d9a-8df75b027507',NULL),('a101ab45-c2cd-49c1-9f29-858b1cbfcd1c','0ae8de67-23f4-49b2-8672-75bb2dedc900',_binary '','${role_manage-authorization}','manage-authorization','hi-library','0ae8de67-23f4-49b2-8672-75bb2dedc900',NULL),('a1536262-08cb-4b79-b0db-c676eb890b2e','0ae8de67-23f4-49b2-8672-75bb2dedc900',_binary '','${role_view-identity-providers}','view-identity-providers','hi-library','0ae8de67-23f4-49b2-8672-75bb2dedc900',NULL),('a2ba492e-1b3f-4e0a-a2c9-b8cb97bea491','hi',_binary '\0',NULL,'translate_static_page','hi',NULL,'hi'),('a43df422-48c0-4a17-bf2a-d628deb44d5f','eec28897-b54a-4d82-9488-f454e28d01ea',_binary '','${role_view-events}','view-events','hi','eec28897-b54a-4d82-9488-f454e28d01ea',NULL),('a53af599-a6dc-44bf-a6ff-71171b218c7a','a70bea3e-e035-439e-a52a-b15206b54b29',_binary '','${role_manage-consent}','manage-consent','master','a70bea3e-e035-439e-a52a-b15206b54b29',NULL),('a929749a-7c30-4cf2-9d55-34294c77b091','hi-therapist',_binary '\0',NULL,'view_edit_own_profile','hi-therapist',NULL,'hi-therapist'),('a9a48d94-076e-4dd8-902b-fa5b4cc92561','dd77b2d7-5ee9-4a5d-a25a-eb152157fb4c',_binary '','${role_view-profile}','view-profile','hi-library','dd77b2d7-5ee9-4a5d-a25a-eb152157fb4c',NULL),('aa08b7ec-5382-4d15-bf0d-b2a3b0c34552','hi',_binary '\0','Able to CRUD the patient','manage_patient','hi',NULL,'hi'),('aade3d9c-31da-4d1b-92b6-a0fdd5e65e7d','a70bea3e-e035-439e-a52a-b15206b54b29',_binary '','${role_view-groups}','view-groups','master','a70bea3e-e035-439e-a52a-b15206b54b29',NULL),('ab85019a-b17f-4c23-afad-13cdf037c695','cea71342-d5fb-4873-b97d-21ac890e6c72',_binary '','${role_manage-authorization}','manage-authorization','master','cea71342-d5fb-4873-b97d-21ac890e6c72',NULL),('aeac672f-dc8f-450e-b2e3-ab866af60ae0','55c52d92-7f2e-40b2-8cef-35e558d2c72b',_binary '','${role_manage-consent}','manage-consent','hi','55c52d92-7f2e-40b2-8cef-35e558d2c72b',NULL),('afaee320-f76a-48ad-a700-b106d05813d9','eec28897-b54a-4d82-9488-f454e28d01ea',_binary '','${role_manage-identity-providers}','manage-identity-providers','hi','eec28897-b54a-4d82-9488-f454e28d01ea',NULL),('b115f8b3-9300-49e9-962d-3094c4c9d2a3','hi',_binary '\0',NULL,'translate_assistive_technology','hi',NULL,'hi'),('b30da0e7-4091-4583-8472-419ccb8f9de0','55c52d92-7f2e-40b2-8cef-35e558d2c72b',_binary '','${role_manage-account}','manage-account','hi','55c52d92-7f2e-40b2-8cef-35e558d2c72b',NULL),('b3cb606d-891e-4952-bb8c-f0980ec78d72','hi-therapist',_binary '\0','Able to CRUD the educational questionnaire','setup_questionnaire','hi-therapist',NULL,'hi-therapist'),('b43dda3f-f119-4549-910c-5d9765845ccd','cea71342-d5fb-4873-b97d-21ac890e6c72',_binary '','${role_view-authorization}','view-authorization','master','cea71342-d5fb-4873-b97d-21ac890e6c72',NULL),('b44f6419-b97e-4055-acfe-075336cb910c','e7c18adf-18b9-48fc-92a0-698f43736bcd',_binary '','${role_manage-identity-providers}','manage-identity-providers','master','e7c18adf-18b9-48fc-92a0-698f43736bcd',NULL),('b57b0da5-ac8d-48a2-be41-2e12f5e6dcda','78044321-1410-42bf-9489-f89303e77e5a',_binary '','${role_read-token}','read-token','hi-therapist','78044321-1410-42bf-9489-f89303e77e5a',NULL),('b6416210-c646-43a2-976a-bb5f0a58e8f6','cea71342-d5fb-4873-b97d-21ac890e6c72',_binary '','${role_view-events}','view-events','master','cea71342-d5fb-4873-b97d-21ac890e6c72',NULL),('b6f16505-bdbe-4ee0-af77-06ddb84cb62c','eec28897-b54a-4d82-9488-f454e28d01ea',_binary '','${role_manage-users}','manage-users','hi','eec28897-b54a-4d82-9488-f454e28d01ea',NULL),('b82479b2-0770-4d20-b015-ffeb651b6fe1','eec28897-b54a-4d82-9488-f454e28d01ea',_binary '','${role_query-realms}','query-realms','hi','eec28897-b54a-4d82-9488-f454e28d01ea',NULL),('b8d4e191-773f-4142-a859-8314a7fb5926','eec28897-b54a-4d82-9488-f454e28d01ea',_binary '','${role_query-clients}','query-clients','hi','eec28897-b54a-4d82-9488-f454e28d01ea',NULL),('b8f8da75-9378-4e8a-a9a7-11c07d8639f4','2410b91c-be58-4f3c-a4ae-83cd998c8f6c',_binary '','${role_manage-events}','manage-events','master','2410b91c-be58-4f3c-a4ae-83cd998c8f6c',NULL),('ba425f7d-8d3c-42df-99cc-a36efe9adfbd','59b01532-686c-41a7-a818-8cd64adb99f5',_binary '','${role_manage-realm}','manage-realm','master','59b01532-686c-41a7-a818-8cd64adb99f5',NULL),('bb4fa995-fd79-481b-86bd-a36badee6ddd','59b01532-686c-41a7-a818-8cd64adb99f5',_binary '','${role_query-clients}','query-clients','master','59b01532-686c-41a7-a818-8cd64adb99f5',NULL),('bb7e3087-8ad5-46fb-a66f-f201749b77dd','hi-library',_binary '\0','Able to update its own user profile','view_edit_own_profile','hi-library',NULL,'hi-library'),('bbc5975f-d084-4af5-bc84-e3434c57ea21','hi',_binary '\0',NULL,'translate_privacy_policy','hi',NULL,'hi'),('bcbc6ae1-2e22-494d-b760-0e8583355525','hi',_binary '\0',NULL,'manage_profession','hi',NULL,'hi'),('bceb2071-33b4-4cd8-995f-5c1a6ed83998','e7c18adf-18b9-48fc-92a0-698f43736bcd',_binary '','${role_view-clients}','view-clients','master','e7c18adf-18b9-48fc-92a0-698f43736bcd',NULL),('bda0f1b4-9b28-42c3-b2eb-65688de4c3a9','cea71342-d5fb-4873-b97d-21ac890e6c72',_binary '','${role_manage-clients}','manage-clients','master','cea71342-d5fb-4873-b97d-21ac890e6c72',NULL),('bea852e4-dc8c-4fa9-ab23-9e025bad558c','hi',_binary '\0',NULL,'view_report','hi',NULL,'hi'),('bf291eac-9e88-488a-8b9c-3eecd827accf','2410b91c-be58-4f3c-a4ae-83cd998c8f6c',_binary '','${role_view-authorization}','view-authorization','master','2410b91c-be58-4f3c-a4ae-83cd998c8f6c',NULL),('bf97ff26-b23e-498d-8d8b-536773b9d834','hi-library',_binary '\0','Able to CRUD the user','manage_user','hi-library',NULL,'hi-library'),('c0e4d349-85f5-47fd-8f93-aa8cdaf816bf','hi',_binary '\0','Able to CRUD the global admin user','manage_global_admin','hi',NULL,'hi'),('c181012a-31a5-4a76-acf7-75d7a6e0bb59','eec28897-b54a-4d82-9488-f454e28d01ea',_binary '','${role_query-users}','query-users','hi','eec28897-b54a-4d82-9488-f454e28d01ea',NULL),('c1fab73c-9b32-4931-b49a-0e25ada0f0b6','hi',_binary '\0','Able to CRUD the exercise','setup_exercise','hi',NULL,'hi'),('c3e3d308-4e19-4295-b474-83446e85ef8b','cea71342-d5fb-4873-b97d-21ac890e6c72',_binary '','${role_manage-realm}','manage-realm','master','cea71342-d5fb-4873-b97d-21ac890e6c72',NULL),('c3fb18d5-1fa5-48e6-bb25-013fa16accb5','59b01532-686c-41a7-a818-8cd64adb99f5',_binary '','${role_manage-events}','manage-events','master','59b01532-686c-41a7-a818-8cd64adb99f5',NULL),('c4258163-6732-4619-8858-60447dbaa16c','2410b91c-be58-4f3c-a4ae-83cd998c8f6c',_binary '','${role_manage-authorization}','manage-authorization','master','2410b91c-be58-4f3c-a4ae-83cd998c8f6c',NULL),('c43fba40-8523-428c-b2ce-793efe0fa6de','0ae8de67-23f4-49b2-8672-75bb2dedc900',_binary '','${role_manage-realm}','manage-realm','hi-library','0ae8de67-23f4-49b2-8672-75bb2dedc900',NULL),('c488a6e4-2fb7-4ede-b36e-ac876cb23470','hi',_binary '\0',NULL,'submit_exercise_result','hi',NULL,'hi'),('c632a80d-e13b-4858-96a1-98211e7835a7','ead46d75-3ebd-458d-8d9a-8df75b027507',_binary '','${role_manage-authorization}','manage-authorization','hi-therapist','ead46d75-3ebd-458d-8d9a-8df75b027507',NULL),('c9f8b913-eb44-4e53-85ab-6314111968cb','2410b91c-be58-4f3c-a4ae-83cd998c8f6c',_binary '','${role_manage-identity-providers}','manage-identity-providers','master','2410b91c-be58-4f3c-a4ae-83cd998c8f6c',NULL),('cc4ba29a-6d5f-4a44-8708-f04fa4685152','hi-therapist',_binary '\0',NULL,'view_questionnaire','hi-therapist',NULL,'hi-therapist'),('ccd1d72a-1899-4330-959a-dcd53fdf08f3','hi-therapist',_binary '\0',NULL,'view_educational_material','hi-therapist',NULL,'hi-therapist'),('cd22ea20-4224-4b01-a4d3-29d97a306861','hi',_binary '\0','Able to CRUD the educational questionnaire','setup_questionnaire','hi',NULL,'hi'),('cd45236d-bff4-4b6e-9d29-f50a2bdb710b','hi-therapist',_binary '\0','${role_uma_authorization}','uma_authorization','hi-therapist',NULL,'hi-therapist'),('cdf78286-af3f-4934-8a79-1a93399bc6e7','master',_binary '\0','${role_uma_authorization}','uma_authorization','master',NULL,'master'),('ce03ff53-dd1f-4a70-96f9-fee461bdfe4b','hi',_binary '\0',NULL,'manage_organization_admin','hi',NULL,'hi'),('ce4d96ba-0759-4405-b77c-9ac5ec5ca368','hi',_binary '\0',NULL,'manage_country','hi',NULL,'hi'),('ce545cba-3739-491a-a4b0-2178a6a9ec45','hi',_binary '\0','Able to CRUD the country admin user','manage_country_admin','hi',NULL,'hi'),('ce5b976f-2769-4571-bfb2-a5bcccc988cc','59b01532-686c-41a7-a818-8cd64adb99f5',_binary '','${role_manage-identity-providers}','manage-identity-providers','master','59b01532-686c-41a7-a818-8cd64adb99f5',NULL),('ce78b116-0146-4168-9e0c-dd6abc7989ea','hi',_binary '\0',NULL,'view_goal_progress','hi',NULL,'hi'),('ce81cff5-3cce-40f2-86b2-e1e75d00ab76','hi',_binary '\0',NULL,'message_call_between_therapist_patient','hi',NULL,'hi'),('cee3835d-f183-4802-9539-ef0eb64edd76','e7c18adf-18b9-48fc-92a0-698f43736bcd',_binary '','${role_query-clients}','query-clients','master','e7c18adf-18b9-48fc-92a0-698f43736bcd',NULL),('cf361d06-de87-4e7b-af50-15543e801331','cea71342-d5fb-4873-b97d-21ac890e6c72',_binary '','${role_manage-identity-providers}','manage-identity-providers','master','cea71342-d5fb-4873-b97d-21ac890e6c72',NULL),('d10021f4-b42f-4d36-86d6-472063f00e1f','hi',_binary '\0',NULL,'input_goal_progress','hi',NULL,'hi'),('d373fd80-c342-49d9-8c2e-ab0a7b0e7a37','hi',_binary '\0','Able to CRUD the educational material','setup_educational_material','hi',NULL,'hi'),('d4462f7a-1c48-4ba1-b24f-3e0f8c82e550','hi-library',_binary '\0','Able to CRUD the category','setup_category','hi-library',NULL,'hi-library'),('d4aa5643-4212-404c-8d33-dfc4d4800a43','59b01532-686c-41a7-a818-8cd64adb99f5',_binary '','${role_query-users}','query-users','master','59b01532-686c-41a7-a818-8cd64adb99f5',NULL),('d655fcec-fa9b-4a04-8760-9e31934fba58','89d22c6b-7a3a-406a-8635-049ea85abb55',_binary '','${role_view-groups}','view-groups','hi-therapist','89d22c6b-7a3a-406a-8635-049ea85abb55',NULL),('d686ff30-9ce6-4d21-b40e-954cf53da12d','hi-library',_binary '\0','${role_uma_authorization}','uma_authorization','hi-library',NULL,'hi-library'),('d804beeb-4b12-42b9-ab6f-8fc8e14d8d1d','hi-therapist',_binary '\0',NULL,'view_exercise','hi-therapist',NULL,'hi-therapist'),('d85332df-5cd4-4bd2-aecd-e53fc4db8ef0','hi',_binary '\0',NULL,'super_admin','hi',NULL,'hi'),('d8978dbe-2f95-407f-bc7c-c5425b8bfaaa','ead46d75-3ebd-458d-8d9a-8df75b027507',_binary '','${role_view-identity-providers}','view-identity-providers','hi-therapist','ead46d75-3ebd-458d-8d9a-8df75b027507',NULL),('d98a0753-50e2-45e1-b0c9-e98d41bd64ce','hi',_binary '\0','Able to view the privacy policy','view_privacy_policy','hi',NULL,'hi'),('db105e10-4cb3-42dd-9859-d2bafd0ee380','59b01532-686c-41a7-a818-8cd64adb99f5',_binary '','${role_manage-clients}','manage-clients','master','59b01532-686c-41a7-a818-8cd64adb99f5',NULL),('dc2548b0-a639-46fa-b100-d9e79403159a','eec28897-b54a-4d82-9488-f454e28d01ea',_binary '','${role_view-clients}','view-clients','hi','eec28897-b54a-4d82-9488-f454e28d01ea',NULL),('dc509253-74e0-43b0-8d0c-6f9895dffae4','hi',_binary '\0',NULL,'manage_system_limit','hi',NULL,'hi'),('dcca5cfc-246c-4b86-8e90-21626faf6844','e7c18adf-18b9-48fc-92a0-698f43736bcd',_binary '','${role_manage-authorization}','manage-authorization','master','e7c18adf-18b9-48fc-92a0-698f43736bcd',NULL),('dd09bc4c-82ce-4c7f-a199-74d18141777a','hi-therapist',_binary '\0',NULL,'view_treatment_detail','hi-therapist',NULL,'hi-therapist'),('de71c678-fba9-42bc-a16c-a0a339d0c820','eec28897-b54a-4d82-9488-f454e28d01ea',_binary '','${role_manage-events}','manage-events','hi','eec28897-b54a-4d82-9488-f454e28d01ea',NULL),('de9e3906-1f7d-46fc-b1e0-c7479b359373','hi',_binary '\0',NULL,'translate_questionnaire','hi',NULL,'hi'),('e2e3689c-e30f-40f8-90af-cc7b3376724e','hi',_binary '\0',NULL,'manage_language','hi',NULL,'hi'),('e55c716f-3837-46a3-bc18-f7edd296ef69','59b01532-686c-41a7-a818-8cd64adb99f5',_binary '','${role_query-groups}','query-groups','master','59b01532-686c-41a7-a818-8cd64adb99f5',NULL),('e601c120-4492-43f9-905d-79ae0944e1b2','cea71342-d5fb-4873-b97d-21ac890e6c72',_binary '','${role_query-realms}','query-realms','master','cea71342-d5fb-4873-b97d-21ac890e6c72',NULL),('e6320424-9682-466c-bc33-131ffeb0c062','eec28897-b54a-4d82-9488-f454e28d01ea',_binary '','${role_realm-admin}','realm-admin','hi','eec28897-b54a-4d82-9488-f454e28d01ea',NULL),('e6bc4d2e-62c3-4ca8-b5fe-3dd02e0b6e55','ead46d75-3ebd-458d-8d9a-8df75b027507',_binary '','${role_view-realm}','view-realm','hi-therapist','ead46d75-3ebd-458d-8d9a-8df75b027507',NULL),('e71ff6bd-cc83-4652-a644-5d3308854fdd','hi-library',_binary '\0','${role_default-roles-hi-library}','default-roles-hi-library','hi-library',NULL,'hi-library'),('e768d5af-dcba-471f-a394-ddb396e944b1','2410b91c-be58-4f3c-a4ae-83cd998c8f6c',_binary '','${role_create-client}','create-client','master','2410b91c-be58-4f3c-a4ae-83cd998c8f6c',NULL),('e7f4c7bb-c736-44ad-a932-fa9ff147e6d7','hi',_binary '\0',NULL,'translate_translation','hi',NULL,'hi'),('eb01e416-d8d8-48cb-96d4-a5a526fbf81a','hi-therapist',_binary '\0',NULL,'submit_questionnaire_answer','hi-therapist',NULL,'hi-therapist'),('ebdb7e9c-5c47-4c4e-8a34-4c1f48cbf3dd','ead46d75-3ebd-458d-8d9a-8df75b027507',_binary '','${role_view-events}','view-events','hi-therapist','ead46d75-3ebd-458d-8d9a-8df75b027507',NULL),('ec491403-06e6-422f-8ddf-a7d8fe4ccb2e','cea71342-d5fb-4873-b97d-21ac890e6c72',_binary '','${role_view-identity-providers}','view-identity-providers','master','cea71342-d5fb-4873-b97d-21ac890e6c72',NULL),('ecc92669-d6ea-4e37-9fae-d2668999ad98','e7c18adf-18b9-48fc-92a0-698f43736bcd',_binary '','${role_view-realm}','view-realm','master','e7c18adf-18b9-48fc-92a0-698f43736bcd',NULL),('ed10bdfe-d49f-40ac-8eb3-88281e25b79e','hi-therapist',_binary '\0',NULL,'view_report','hi-therapist',NULL,'hi-therapist'),('efba8528-db6b-44f6-a982-8b9e095d3927','ead46d75-3ebd-458d-8d9a-8df75b027507',_binary '','${role_realm-admin}','realm-admin','hi-therapist','ead46d75-3ebd-458d-8d9a-8df75b027507',NULL),('f067a7b5-0166-4344-8365-0c28dd53e023','hi',_binary '\0',NULL,'manage_assistive_technology','hi',NULL,'hi'),('f0d9e002-07dc-496f-baa9-3e933bda4afd','2410b91c-be58-4f3c-a4ae-83cd998c8f6c',_binary '','${role_view-clients}','view-clients','master','2410b91c-be58-4f3c-a4ae-83cd998c8f6c',NULL),('f20b2e08-0240-4cf4-b36a-a878c5318b2b','55c52d92-7f2e-40b2-8cef-35e558d2c72b',_binary '','${role_view-applications}','view-applications','hi','55c52d92-7f2e-40b2-8cef-35e558d2c72b',NULL),('f34f5ab1-6e50-40a2-9867-027a204cc7e9','59b01532-686c-41a7-a818-8cd64adb99f5',_binary '','${role_query-realms}','query-realms','master','59b01532-686c-41a7-a818-8cd64adb99f5',NULL),('f5dbedbe-8f75-4d1d-8cef-888c8c59bf54','hi-therapist',_binary '\0',NULL,'input_goal_progress','hi-therapist',NULL,'hi-therapist'),('f6d665b3-80d6-4129-8b48-feeb881164b8','a70bea3e-e035-439e-a52a-b15206b54b29',_binary '','${role_view-consent}','view-consent','master','a70bea3e-e035-439e-a52a-b15206b54b29',NULL),('f885a621-175f-4a11-88ac-9d3f778b4920','hi-therapist',_binary '\0',NULL,'message_call_between_therapist_patient','hi-therapist',NULL,'hi-therapist'),('f967e712-b9c7-4c96-b2f2-23e91316a3a8','cea71342-d5fb-4873-b97d-21ac890e6c72',_binary '','${role_view-users}','view-users','master','cea71342-d5fb-4873-b97d-21ac890e6c72',NULL),('f984b833-991e-461c-b01b-e57ba9da2903','2410b91c-be58-4f3c-a4ae-83cd998c8f6c',_binary '','${role_manage-realm}','manage-realm','master','2410b91c-be58-4f3c-a4ae-83cd998c8f6c',NULL),('fac4ad96-b1f9-45c2-96cf-c5701f048f9d','2410b91c-be58-4f3c-a4ae-83cd998c8f6c',_binary '','${role_view-events}','view-events','master','2410b91c-be58-4f3c-a4ae-83cd998c8f6c',NULL),('fb4125e3-a3e4-4078-a7d4-1e45370023c1','dd77b2d7-5ee9-4a5d-a25a-eb152157fb4c',_binary '','${role_view-consent}','view-consent','hi-library','dd77b2d7-5ee9-4a5d-a25a-eb152157fb4c',NULL),('fb46403d-6bd8-43ef-8a34-d4b177c7134d','0ae8de67-23f4-49b2-8672-75bb2dedc900',_binary '','${role_view-realm}','view-realm','hi-library','0ae8de67-23f4-49b2-8672-75bb2dedc900',NULL),('fb76d28f-756e-4bee-aa0d-e3101875df75','hi-therapist',_binary '\0','Able to CRUD the global admin user','manage_global_admin','hi-therapist',NULL,'hi-therapist'),('fd58fb2c-7a94-49fc-bc74-1de11d3fe33c','e7c18adf-18b9-48fc-92a0-698f43736bcd',_binary '','${role_query-users}','query-users','master','e7c18adf-18b9-48fc-92a0-698f43736bcd',NULL),('ff169916-d575-4626-84f8-d41b7aa2a907','e7c18adf-18b9-48fc-92a0-698f43736bcd',_binary '','${role_manage-events}','manage-events','master','e7c18adf-18b9-48fc-92a0-698f43736bcd',NULL);
/*!40000 ALTER TABLE `KEYCLOAK_ROLE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MIGRATION_MODEL`
--

DROP TABLE IF EXISTS `MIGRATION_MODEL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MIGRATION_MODEL` (
  `ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `VERSION` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `UPDATE_TIME` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `IDX_UPDATE_TIME` (`UPDATE_TIME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MIGRATION_MODEL`
--

LOCK TABLES `MIGRATION_MODEL` WRITE;
/*!40000 ALTER TABLE `MIGRATION_MODEL` DISABLE KEYS */;
INSERT INTO `MIGRATION_MODEL` VALUES ('2zhzo','24.0.5',1740016729),('4xmsc','11.0.2',1604463933),('64f4r','15.1.1',1740015543),('86qbq','25.0.6',1740020094),('c0dh5','13.0.1',1740014935),('epglr','20.0.5',1740016023),('kdw76','23.0.7',1740016594),('l8drw','22.0.5',1740016470),('l8f0b','21.1.2',1740016324),('nkrbh','11.0.3',1632306148),('q0u9v','14.0.0',1740015039),('wu06f','12.0.4',1740014794),('xtvnh','16.1.1',1740015677);
/*!40000 ALTER TABLE `MIGRATION_MODEL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OFFLINE_CLIENT_SESSION`
--

DROP TABLE IF EXISTS `OFFLINE_CLIENT_SESSION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OFFLINE_CLIENT_SESSION` (
  `USER_SESSION_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `CLIENT_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `OFFLINE_FLAG` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `TIMESTAMP` int DEFAULT NULL,
  `DATA` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `CLIENT_STORAGE_PROVIDER` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'local',
  `EXTERNAL_CLIENT_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'local',
  `VERSION` int DEFAULT '0',
  PRIMARY KEY (`USER_SESSION_ID`,`CLIENT_ID`,`CLIENT_STORAGE_PROVIDER`,`EXTERNAL_CLIENT_ID`,`OFFLINE_FLAG`),
  KEY `IDX_US_SESS_ID_ON_CL_SESS` (`USER_SESSION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OFFLINE_CLIENT_SESSION`
--

LOCK TABLES `OFFLINE_CLIENT_SESSION` WRITE;
/*!40000 ALTER TABLE `OFFLINE_CLIENT_SESSION` DISABLE KEYS */;
/*!40000 ALTER TABLE `OFFLINE_CLIENT_SESSION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OFFLINE_USER_SESSION`
--

DROP TABLE IF EXISTS `OFFLINE_USER_SESSION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OFFLINE_USER_SESSION` (
  `USER_SESSION_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `USER_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REALM_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `CREATED_ON` int NOT NULL,
  `OFFLINE_FLAG` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `DATA` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `LAST_SESSION_REFRESH` int NOT NULL DEFAULT '0',
  `BROKER_SESSION_ID` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `VERSION` int DEFAULT '0',
  PRIMARY KEY (`USER_SESSION_ID`,`OFFLINE_FLAG`),
  KEY `IDX_OFFLINE_USS_BY_USER` (`USER_ID`,`REALM_ID`,`OFFLINE_FLAG`),
  KEY `IDX_OFFLINE_USS_BY_LAST_SESSION_REFRESH` (`REALM_ID`,`OFFLINE_FLAG`,`LAST_SESSION_REFRESH`),
  KEY `IDX_OFFLINE_USS_BY_BROKER_SESSION_ID` (`BROKER_SESSION_ID`(255),`REALM_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OFFLINE_USER_SESSION`
--

LOCK TABLES `OFFLINE_USER_SESSION` WRITE;
/*!40000 ALTER TABLE `OFFLINE_USER_SESSION` DISABLE KEYS */;
/*!40000 ALTER TABLE `OFFLINE_USER_SESSION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ORG`
--

DROP TABLE IF EXISTS `ORG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ORG` (
  `ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ENABLED` tinyint NOT NULL,
  `REALM_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `GROUP_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `DESCRIPTION` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_ORG_NAME` (`REALM_ID`,`NAME`),
  UNIQUE KEY `UK_ORG_GROUP` (`GROUP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ORG`
--

LOCK TABLES `ORG` WRITE;
/*!40000 ALTER TABLE `ORG` DISABLE KEYS */;
/*!40000 ALTER TABLE `ORG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ORG_DOMAIN`
--

DROP TABLE IF EXISTS `ORG_DOMAIN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ORG_DOMAIN` (
  `ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `VERIFIED` tinyint NOT NULL,
  `ORG_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`,`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ORG_DOMAIN`
--

LOCK TABLES `ORG_DOMAIN` WRITE;
/*!40000 ALTER TABLE `ORG_DOMAIN` DISABLE KEYS */;
/*!40000 ALTER TABLE `ORG_DOMAIN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `POLICY_CONFIG`
--

DROP TABLE IF EXISTS `POLICY_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `POLICY_CONFIG` (
  `POLICY_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`POLICY_ID`,`NAME`),
  CONSTRAINT `FKDC34197CF864C4E43` FOREIGN KEY (`POLICY_ID`) REFERENCES `RESOURCE_SERVER_POLICY` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `POLICY_CONFIG`
--

LOCK TABLES `POLICY_CONFIG` WRITE;
/*!40000 ALTER TABLE `POLICY_CONFIG` DISABLE KEYS */;
/*!40000 ALTER TABLE `POLICY_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROTOCOL_MAPPER`
--

DROP TABLE IF EXISTS `PROTOCOL_MAPPER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PROTOCOL_MAPPER` (
  `ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `PROTOCOL` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `PROTOCOL_MAPPER_NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `CLIENT_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CLIENT_SCOPE_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IDX_PROTOCOL_MAPPER_CLIENT` (`CLIENT_ID`),
  KEY `IDX_CLSCOPE_PROTMAP` (`CLIENT_SCOPE_ID`),
  CONSTRAINT `FK_CLI_SCOPE_MAPPER` FOREIGN KEY (`CLIENT_SCOPE_ID`) REFERENCES `CLIENT_SCOPE` (`ID`),
  CONSTRAINT `FK_PCM_REALM` FOREIGN KEY (`CLIENT_ID`) REFERENCES `CLIENT` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROTOCOL_MAPPER`
--

LOCK TABLES `PROTOCOL_MAPPER` WRITE;
/*!40000 ALTER TABLE `PROTOCOL_MAPPER` DISABLE KEYS */;
INSERT INTO `PROTOCOL_MAPPER` VALUES ('006df7f3-db14-4b30-bbb2-de147bde0122','upn','openid-connect','oidc-usermodel-property-mapper',NULL,'f8b8a1e5-c804-4695-b5b1-35c66ddbabee'),('037b7484-2d7a-4965-9f11-e9df8f2196a3','family name','openid-connect','oidc-usermodel-property-mapper',NULL,'3617b695-9239-4d20-9271-32aa00a4825a'),('096ca0ed-f271-47b3-84a6-18d924575aa7','phone number','openid-connect','oidc-usermodel-attribute-mapper',NULL,'8c3bdc03-95db-4a61-833f-d816bc6d702c'),('0c6ee8a3-f557-485c-85a2-9cd4758c86ec','auth_time','openid-connect','oidc-usersessionmodel-note-mapper',NULL,'8cf5052c-143d-4034-a453-71443d4c683c'),('0cee8338-8563-4b0b-8ce3-28142780cf4e','auth_time','openid-connect','oidc-usersessionmodel-note-mapper',NULL,'20d24c08-4287-49c0-9e96-23b74cb9dde4'),('0fab5b8a-16c6-4ace-ba0c-80c5b724989a','locale','openid-connect','oidc-usermodel-attribute-mapper','5ac1fbef-dc0d-437e-bdfb-6d0c0d467dc0',NULL),('11bd8bfe-e13b-429e-b5f5-ddb816e82372','audience resolve','openid-connect','oidc-audience-resolve-mapper',NULL,'f72905ec-d315-4c68-89dd-14d42907cf3e'),('1314331a-5621-47b8-8082-96a8f1f802a6','updated at','openid-connect','oidc-usermodel-attribute-mapper',NULL,'275e4568-19f1-4016-8db4-c60a6daa0ab4'),('131bd228-0aa8-4f4f-a803-dae8934e4430','username','openid-connect','oidc-usermodel-property-mapper',NULL,'2a8bc487-583c-43dc-8d29-1ad0950d438b'),('13479da2-7a14-49a5-a36c-9fe1b1f49559','gender','openid-connect','oidc-usermodel-attribute-mapper',NULL,'2a8bc487-583c-43dc-8d29-1ad0950d438b'),('1593fa24-8a33-4eeb-acbb-2b8b97abd004','audience resolve','openid-connect','oidc-audience-resolve-mapper',NULL,'41cca0ba-533b-45a7-99c1-8b4ecf149f06'),('198063ba-d18a-483e-8c5c-06361e4b61ae','picture','openid-connect','oidc-usermodel-attribute-mapper',NULL,'3617b695-9239-4d20-9271-32aa00a4825a'),('19d50c57-f8ea-4609-8af2-b7cbe9c166a2','allowed web origins','openid-connect','oidc-allowed-origins-mapper',NULL,'176332ca-d883-4329-a9d4-68884a7c275e'),('1aa58698-76dd-4113-8161-cae0fe90cb1a','profile','openid-connect','oidc-usermodel-attribute-mapper',NULL,'3617b695-9239-4d20-9271-32aa00a4825a'),('1f88e620-e06c-4b8c-90ca-80b3d4c4e946','full name','openid-connect','oidc-full-name-mapper',NULL,'63210a8a-0008-4908-a26e-c374667cf2ea'),('21d400d1-75ad-4e66-95e5-206ea1d2a49f','nickname','openid-connect','oidc-usermodel-attribute-mapper',NULL,'3617b695-9239-4d20-9271-32aa00a4825a'),('2324eae2-7402-4ad4-ad51-bb469eb3982e','given name','openid-connect','oidc-usermodel-property-mapper',NULL,'3617b695-9239-4d20-9271-32aa00a4825a'),('235604a1-f400-4ad5-846c-fe6488996e95','audience resolve','openid-connect','oidc-audience-resolve-mapper','af07419a-9fdd-48f8-bb86-98deababeb5d',NULL),('25a9adb4-390e-4db3-8179-a437cc15bb9d','birthdate','openid-connect','oidc-usermodel-attribute-mapper',NULL,'275e4568-19f1-4016-8db4-c60a6daa0ab4'),('2767f0f8-c8e0-4aba-99bd-683d158c9a35','zoneinfo','openid-connect','oidc-usermodel-attribute-mapper',NULL,'63210a8a-0008-4908-a26e-c374667cf2ea'),('29f6f61d-61cf-4ace-9278-dd69d1b73112','nickname','openid-connect','oidc-usermodel-attribute-mapper',NULL,'2a8bc487-583c-43dc-8d29-1ad0950d438b'),('2edc67a4-d6ca-40c1-ab1d-9755cbfc964e','full name','openid-connect','oidc-full-name-mapper',NULL,'2a8bc487-583c-43dc-8d29-1ad0950d438b'),('2fccc0e1-960f-4a02-b324-26730253693f','updated at','openid-connect','oidc-usermodel-attribute-mapper',NULL,'2a8bc487-583c-43dc-8d29-1ad0950d438b'),('30b414b5-01ed-4cd0-866f-c3edc937bb9a','email','openid-connect','oidc-usermodel-property-mapper',NULL,'77249e04-e2d2-4031-9667-8786a866947c'),('31a4b671-cda0-43b3-bb40-dd49af57e755','family name','openid-connect','oidc-usermodel-property-mapper',NULL,'2a8bc487-583c-43dc-8d29-1ad0950d438b'),('330b1fd6-41da-4693-9a5c-f60a5a76d055','email verified','openid-connect','oidc-usermodel-property-mapper',NULL,'77249e04-e2d2-4031-9667-8786a866947c'),('340c09f2-d529-4f0a-9ba9-d43989e121d5','nickname','openid-connect','oidc-usermodel-attribute-mapper',NULL,'63210a8a-0008-4908-a26e-c374667cf2ea'),('36f43a1f-7960-4b1e-9fad-cb0a9b958015','phone number verified','openid-connect','oidc-usermodel-attribute-mapper',NULL,'8c3bdc03-95db-4a61-833f-d816bc6d702c'),('3a823928-d589-4b70-b9ff-dedac139acc7','email verified','openid-connect','oidc-usermodel-property-mapper',NULL,'5753f684-aa1d-4cc0-88aa-98a2f0cab3af'),('3b165070-481a-4bfd-a16e-acb2a7987ed9','groups','openid-connect','oidc-usermodel-realm-role-mapper',NULL,'ee7ace46-13d6-42c2-9718-1c0cbd9418a8'),('3d119ee6-8d34-49f4-833c-a6aa36964b56','locale','openid-connect','oidc-usermodel-attribute-mapper','d3bacc5c-ac4e-41ab-abb9-3d79878ddcdc',NULL),('3d75c537-ed38-4fa3-aafc-b84f3647c4e9','realm roles','openid-connect','oidc-usermodel-realm-role-mapper',NULL,'f72905ec-d315-4c68-89dd-14d42907cf3e'),('3fc458c5-2cea-45ea-8900-3530eaab9307','groups','openid-connect','oidc-usermodel-realm-role-mapper',NULL,'c32f9638-55d0-4d5a-a3fb-feb682bc420c'),('4182c471-c41f-4d0b-ae8a-4135ebb175cb','given name','openid-connect','oidc-usermodel-property-mapper',NULL,'2a8bc487-583c-43dc-8d29-1ad0950d438b'),('43a8499d-f72b-43a0-ba0d-c36f976df92d','auth_time','openid-connect','oidc-usersessionmodel-note-mapper',NULL,'80525d8c-f22c-4adc-a0de-adf5ebf8a6bb'),('44197f4e-2f1b-46c9-aab1-417cf632acba','address','openid-connect','oidc-address-mapper',NULL,'04f47a6c-8d2b-415f-be78-80d855e614a8'),('44b10a86-9368-427f-a595-a308956637f4','role list','saml','saml-role-list-mapper',NULL,'c860f1d3-2172-40b1-9ce2-84911e6a17a9'),('46a11a2f-8fd2-4186-a4f9-9d0238fd4a2c','website','openid-connect','oidc-usermodel-attribute-mapper',NULL,'275e4568-19f1-4016-8db4-c60a6daa0ab4'),('47e11601-6ddd-4294-9718-11ad2de3f79a','phone number verified','openid-connect','oidc-usermodel-attribute-mapper',NULL,'4072c001-f7e7-4fa4-9f9f-0f099a308dfe'),('48f1f00f-b3a6-451c-b258-0e1661e745ea','audience resolve','openid-connect','oidc-audience-resolve-mapper',NULL,'91926bc4-0204-43c3-a034-67e94de06f80'),('4bbd70f2-774a-456f-85bc-cd75b0e64d42','given name','openid-connect','oidc-usermodel-property-mapper',NULL,'63210a8a-0008-4908-a26e-c374667cf2ea'),('4d4d94aa-4430-434a-96d4-c8ae520987e2','acr loa level','openid-connect','oidc-acr-mapper',NULL,'46172ddf-6ae6-4156-8d29-27e64cc13377'),('4eaa91b9-91e9-4964-a65b-2a85ffe0919d','sub','openid-connect','oidc-sub-mapper',NULL,'20d24c08-4287-49c0-9e96-23b74cb9dde4'),('4fa4652e-e530-458a-8419-f08e1d48c283','role list','saml','saml-role-list-mapper',NULL,'fedf7ec0-e80f-4336-a9b1-17e8bf4c7b71'),('5710c814-8c1b-4aa6-9082-4d9364c67951','upn','openid-connect','oidc-usermodel-property-mapper',NULL,'ee7ace46-13d6-42c2-9718-1c0cbd9418a8'),('571fa7da-4f61-4c58-84a2-ee8bba9320bc','middle name','openid-connect','oidc-usermodel-attribute-mapper',NULL,'3617b695-9239-4d20-9271-32aa00a4825a'),('59dadbbf-7c5e-4a63-8b45-6a071b3fc1f9','sub','openid-connect','oidc-sub-mapper',NULL,'80525d8c-f22c-4adc-a0de-adf5ebf8a6bb'),('5a3e40aa-5988-4a7c-b03f-1ea561d30ec1','username','openid-connect','oidc-usermodel-property-mapper',NULL,'3617b695-9239-4d20-9271-32aa00a4825a'),('5e8c918b-8b17-4015-8139-5808f99e44c1','picture','openid-connect','oidc-usermodel-attribute-mapper',NULL,'275e4568-19f1-4016-8db4-c60a6daa0ab4'),('6442409e-8d0b-4ece-90b8-dc5b60a84062','gender','openid-connect','oidc-usermodel-attribute-mapper',NULL,'275e4568-19f1-4016-8db4-c60a6daa0ab4'),('68bc5ecd-9b4c-44e0-aafa-cbed318f3a89','realm roles','openid-connect','oidc-usermodel-realm-role-mapper',NULL,'0d783cca-c3a4-4d95-ab32-82551105367e'),('6b278229-0181-4fc4-b4c9-a80f5218a124','phone number verified','openid-connect','oidc-usermodel-attribute-mapper',NULL,'90332860-b400-4df0-b3a0-5ddee0d59319'),('6b301df0-831e-4aec-ae1e-e12d055d5b81','website','openid-connect','oidc-usermodel-attribute-mapper',NULL,'63210a8a-0008-4908-a26e-c374667cf2ea'),('6b69c55c-b041-425e-b771-15990ccaef1f','picture','openid-connect','oidc-usermodel-attribute-mapper',NULL,'63210a8a-0008-4908-a26e-c374667cf2ea'),('6d4467b4-3bf6-40b6-9fce-d82f2863c74e','client roles','openid-connect','oidc-usermodel-client-role-mapper',NULL,'0d783cca-c3a4-4d95-ab32-82551105367e'),('6d6d50b8-cd32-40a4-b07b-0eb7c5a0a8c7','gender','openid-connect','oidc-usermodel-attribute-mapper',NULL,'63210a8a-0008-4908-a26e-c374667cf2ea'),('73167b77-9d4b-45e8-9eeb-61ba4e1560a3','full name','openid-connect','oidc-full-name-mapper',NULL,'275e4568-19f1-4016-8db4-c60a6daa0ab4'),('76383b8f-1a73-4948-afd4-62e04c8581e1','middle name','openid-connect','oidc-usermodel-attribute-mapper',NULL,'63210a8a-0008-4908-a26e-c374667cf2ea'),('7cb38b1d-07fd-4463-a7e7-64f67375f20a','phone number','openid-connect','oidc-usermodel-attribute-mapper',NULL,'5331ff23-6ff5-4b10-9ac9-0c413fe89907'),('80c245ea-7a32-48da-a1b7-5c0ab5663c7a','locale','openid-connect','oidc-usermodel-attribute-mapper',NULL,'2a8bc487-583c-43dc-8d29-1ad0950d438b'),('81719cf9-dcb4-4804-9427-c0d34073a261','updated at','openid-connect','oidc-usermodel-attribute-mapper',NULL,'3617b695-9239-4d20-9271-32aa00a4825a'),('82d96572-c3fe-4f6a-aea2-efa45c566fe5','locale','openid-connect','oidc-usermodel-attribute-mapper',NULL,'3617b695-9239-4d20-9271-32aa00a4825a'),('85fea67a-1bc0-4958-b78f-69f103c3b80d','profile','openid-connect','oidc-usermodel-attribute-mapper',NULL,'2a8bc487-583c-43dc-8d29-1ad0950d438b'),('86cf90a9-9880-4bc1-9a13-79f73b8e975a','zoneinfo','openid-connect','oidc-usermodel-attribute-mapper',NULL,'275e4568-19f1-4016-8db4-c60a6daa0ab4'),('86dc21e6-cbcf-4a20-8465-51221dd5d891','phone number verified','openid-connect','oidc-usermodel-attribute-mapper',NULL,'5331ff23-6ff5-4b10-9ac9-0c413fe89907'),('894279b9-16aa-4ebe-b40f-c338bf2a7d92','birthdate','openid-connect','oidc-usermodel-attribute-mapper',NULL,'3617b695-9239-4d20-9271-32aa00a4825a'),('8b0f11c1-b665-4298-9828-87ec1111df26','locale','openid-connect','oidc-usermodel-attribute-mapper',NULL,'275e4568-19f1-4016-8db4-c60a6daa0ab4'),('8f3b5ec0-34c9-4d6a-b4a0-d15e05b8b9cc','audience resolve','openid-connect','oidc-audience-resolve-mapper','a3a37b6f-21f9-49da-8561-1b850d20cba5',NULL),('8faf4278-9adf-4ea6-ba06-74792a73ed54','groups','openid-connect','oidc-usermodel-realm-role-mapper',NULL,'f8b8a1e5-c804-4695-b5b1-35c66ddbabee'),('9077b7ef-ecb9-49f9-a70e-c4f901a0a6df','audience resolve','openid-connect','oidc-audience-resolve-mapper','1d1424ea-24c6-4434-b5e5-8e96e26f3255',NULL),('95898375-85c2-4f64-9e07-9c0167f1abba','allowed web origins','openid-connect','oidc-allowed-origins-mapper',NULL,'356d3968-262b-4bee-8d44-0d93e880b01a'),('958ba9e1-0bd0-4495-9e17-3bbd61c8e970','role list','saml','saml-role-list-mapper',NULL,'76bd20ff-2540-4fb2-b91f-f1b9ec78c9d0'),('96211100-9f9c-4d9a-8749-1d248f69d421','phone number','openid-connect','oidc-usermodel-attribute-mapper',NULL,'4072c001-f7e7-4fa4-9f9f-0f099a308dfe'),('96eadbc7-0864-40ca-9243-f3deeb6615c4','realm roles','openid-connect','oidc-usermodel-realm-role-mapper',NULL,'91926bc4-0204-43c3-a034-67e94de06f80'),('9840695c-9722-4694-ae41-0826ae555a9a','profile','openid-connect','oidc-usermodel-attribute-mapper',NULL,'275e4568-19f1-4016-8db4-c60a6daa0ab4'),('9a098d90-5d0a-40ac-9a85-6d05b376a943','allowed web origins','openid-connect','oidc-allowed-origins-mapper',NULL,'9ecc4599-6324-4ab5-a7a2-67e68b1af5f2'),('9a84beae-9dab-4a04-ba5c-e4f5117e07f1','email verified','openid-connect','oidc-usermodel-property-mapper',NULL,'f070e008-1bf3-4354-9566-af729276ee3e'),('9c4bbdd6-ce3e-4db0-8a4a-9cab43631399','address','openid-connect','oidc-address-mapper',NULL,'4d7db1a2-1bb6-4104-801b-ea18bd31d25e'),('9d3d082f-0f51-44a8-a828-7e51381a12cd','email','openid-connect','oidc-usermodel-property-mapper',NULL,'5753f684-aa1d-4cc0-88aa-98a2f0cab3af'),('9e0b38ce-963b-48ca-ac53-7a12fea2ea8d','email','openid-connect','oidc-usermodel-property-mapper',NULL,'0ea1d4c1-d78e-433a-9a43-d31c1c298deb'),('9eaea907-8ea0-46c7-b495-921d82af2c8d','family name','openid-connect','oidc-usermodel-property-mapper',NULL,'63210a8a-0008-4908-a26e-c374667cf2ea'),('9f8e25ef-c1d9-4d9b-87b4-b33d61987fe6','email','openid-connect','oidc-usermodel-property-mapper',NULL,'f070e008-1bf3-4354-9566-af729276ee3e'),('a2d37426-f561-4caf-8a73-6cdd8d6f3942','nickname','openid-connect','oidc-usermodel-attribute-mapper',NULL,'275e4568-19f1-4016-8db4-c60a6daa0ab4'),('a3967c9d-64b7-4eaa-98a2-f8ae0cf2ddfc','birthdate','openid-connect','oidc-usermodel-attribute-mapper',NULL,'63210a8a-0008-4908-a26e-c374667cf2ea'),('a5bb2b95-0c4a-44a1-88de-dfbfff6af5d4','audience resolve','openid-connect','oidc-audience-resolve-mapper','63f568e6-51bc-4bbe-9fb4-1dcf570d09a4',NULL),('a7af676a-3789-448d-856d-e05f9e8da7ac','middle name','openid-connect','oidc-usermodel-attribute-mapper',NULL,'2a8bc487-583c-43dc-8d29-1ad0950d438b'),('a9f03f70-1836-4ffb-ad00-124c7d1a7bad','phone number','openid-connect','oidc-usermodel-attribute-mapper',NULL,'90332860-b400-4df0-b3a0-5ddee0d59319'),('aaa2c4c0-f764-454e-be7d-1a12804ca02d','acr loa level','openid-connect','oidc-acr-mapper',NULL,'32a3853a-b88f-4676-a8ff-36e7f9b1ec44'),('b11141a7-cae8-4dc1-8e0a-d105dd1d3716','realm roles','openid-connect','oidc-usermodel-realm-role-mapper',NULL,'41cca0ba-533b-45a7-99c1-8b4ecf149f06'),('b142fa95-0973-4476-b530-c8d13a9e8951','auth_time','openid-connect','oidc-usersessionmodel-note-mapper',NULL,'6ec5000c-e317-4360-8f97-2f3545494994'),('b67a3949-d542-4d03-9066-f3893047c15b','acr loa level','openid-connect','oidc-acr-mapper',NULL,'6c42b94b-4d9d-47e4-b334-74526eba766b'),('b97ea8a6-c8cb-42f8-9c81-24ec8ca6a490','upn','openid-connect','oidc-usermodel-property-mapper',NULL,'c32f9638-55d0-4d5a-a3fb-feb682bc420c'),('bb7b61e4-3f08-404d-93b7-eea0011a7b43','sub','openid-connect','oidc-sub-mapper',NULL,'8cf5052c-143d-4034-a453-71443d4c683c'),('bd321e4c-74d3-4028-a5c0-10dcc7157cc1','client roles','openid-connect','oidc-usermodel-client-role-mapper',NULL,'91926bc4-0204-43c3-a034-67e94de06f80'),('bd3e6f70-09ca-439a-8fd4-0b5cf8cd4a1a','locale','openid-connect','oidc-usermodel-attribute-mapper',NULL,'63210a8a-0008-4908-a26e-c374667cf2ea'),('be118bec-e679-4e70-aee1-7703b4050dd8','full name','openid-connect','oidc-full-name-mapper',NULL,'3617b695-9239-4d20-9271-32aa00a4825a'),('bea4f679-e702-4c9b-8eec-ba5677017bf7','email verified','openid-connect','oidc-usermodel-property-mapper',NULL,'0ea1d4c1-d78e-433a-9a43-d31c1c298deb'),('c4276f3e-996e-45ae-9235-17887a9e475d','address','openid-connect','oidc-address-mapper',NULL,'414975ff-f904-4ab5-b84c-ce90b092c83a'),('c4902038-0eb0-4811-bac2-7eb6a2b767b3','sub','openid-connect','oidc-sub-mapper',NULL,'6ec5000c-e317-4360-8f97-2f3545494994'),('c90bed19-1881-4989-9a2b-6e2606372e4f','role list','saml','saml-role-list-mapper',NULL,'bcb19857-2acf-43ed-9480-b1975fa5f33c'),('c95950fe-4907-418e-a3fc-d5e78f2dacb7','middle name','openid-connect','oidc-usermodel-attribute-mapper',NULL,'275e4568-19f1-4016-8db4-c60a6daa0ab4'),('cb9469bd-60fb-42a0-b938-1a3d544a1f4e','client roles','openid-connect','oidc-usermodel-client-role-mapper',NULL,'f72905ec-d315-4c68-89dd-14d42907cf3e'),('cc5b8a35-d901-4796-aa54-aa293be0928d','audience resolve','openid-connect','oidc-audience-resolve-mapper',NULL,'0d783cca-c3a4-4d95-ab32-82551105367e'),('cd38c808-7bae-4540-a1fc-b7935ee728ee','acr loa level','openid-connect','oidc-acr-mapper',NULL,'01bd005a-2d2b-4826-9f76-953fcaf6d1bd'),('cda7a2f1-ab17-4e79-8af7-51a719c2ee4f','address','openid-connect','oidc-address-mapper',NULL,'467375c3-0f8a-490f-b105-0bb44c15a518'),('d20b83ec-e517-4932-bfae-985c548799c3','family name','openid-connect','oidc-usermodel-property-mapper',NULL,'275e4568-19f1-4016-8db4-c60a6daa0ab4'),('d216a194-89f0-49b6-90a4-84f23c24f2d5','locale','openid-connect','oidc-usermodel-attribute-mapper','d84f18c2-b355-4a93-893b-a886e0b8fcf2',NULL),('d6160b92-64a3-46fa-be76-4a14ae3b5107','website','openid-connect','oidc-usermodel-attribute-mapper',NULL,'3617b695-9239-4d20-9271-32aa00a4825a'),('d62b6e6b-99b5-412e-a53b-b496d9059733','gender','openid-connect','oidc-usermodel-attribute-mapper',NULL,'3617b695-9239-4d20-9271-32aa00a4825a'),('de094ef6-4cb2-4341-ba33-0a5da4b18cc6','birthdate','openid-connect','oidc-usermodel-attribute-mapper',NULL,'2a8bc487-583c-43dc-8d29-1ad0950d438b'),('de7cae8a-0085-488b-bafd-df92884f3a06','allowed web origins','openid-connect','oidc-allowed-origins-mapper',NULL,'433a8036-5c4d-4675-a59e-2ac046db7713'),('dfd01dfc-b19c-4643-bd57-209d003f4980','locale','openid-connect','oidc-usermodel-attribute-mapper','cb884845-e614-4c6e-9508-6fd6ae87fd60',NULL),('e044230a-2483-42fd-ad8c-6072864398a7','upn','openid-connect','oidc-usermodel-property-mapper',NULL,'db8690d5-98eb-4b33-8165-cb295c69b3d2'),('e149ff65-9268-4d44-8d6d-fd850788b1f8','username','openid-connect','oidc-usermodel-property-mapper',NULL,'63210a8a-0008-4908-a26e-c374667cf2ea'),('e224daa6-a8b8-43f3-9d05-073bac90abaf','picture','openid-connect','oidc-usermodel-attribute-mapper',NULL,'2a8bc487-583c-43dc-8d29-1ad0950d438b'),('e3dada28-c2ac-4413-a52b-62e55e41d800','client roles','openid-connect','oidc-usermodel-client-role-mapper',NULL,'41cca0ba-533b-45a7-99c1-8b4ecf149f06'),('eda86f46-b870-4411-88e2-02cfb092a1f4','username','openid-connect','oidc-usermodel-property-mapper',NULL,'275e4568-19f1-4016-8db4-c60a6daa0ab4'),('eeb735b0-b090-4ed3-8b7e-928fba3192d5','zoneinfo','openid-connect','oidc-usermodel-attribute-mapper',NULL,'3617b695-9239-4d20-9271-32aa00a4825a'),('ef0f0a8b-8ba8-4d32-98c5-cb8dc496514f','zoneinfo','openid-connect','oidc-usermodel-attribute-mapper',NULL,'2a8bc487-583c-43dc-8d29-1ad0950d438b'),('f0a40ed6-1df2-4037-bd94-f8d13b638fef','profile','openid-connect','oidc-usermodel-attribute-mapper',NULL,'63210a8a-0008-4908-a26e-c374667cf2ea'),('f38320de-d931-4596-9b43-e8aeb5cd2bd5','given name','openid-connect','oidc-usermodel-property-mapper',NULL,'275e4568-19f1-4016-8db4-c60a6daa0ab4'),('fae5b917-0f41-4c07-a1a0-c717a9d8c4ce','website','openid-connect','oidc-usermodel-attribute-mapper',NULL,'2a8bc487-583c-43dc-8d29-1ad0950d438b'),('fdbc37ba-f5d2-445d-8316-7094f279200f','updated at','openid-connect','oidc-usermodel-attribute-mapper',NULL,'63210a8a-0008-4908-a26e-c374667cf2ea'),('ffcd07dc-1501-46ce-a38c-643af2d72d7d','groups','openid-connect','oidc-usermodel-realm-role-mapper',NULL,'db8690d5-98eb-4b33-8165-cb295c69b3d2');
/*!40000 ALTER TABLE `PROTOCOL_MAPPER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROTOCOL_MAPPER_CONFIG`
--

DROP TABLE IF EXISTS `PROTOCOL_MAPPER_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PROTOCOL_MAPPER_CONFIG` (
  `PROTOCOL_MAPPER_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`PROTOCOL_MAPPER_ID`,`NAME`),
  CONSTRAINT `FK_PMCONFIG` FOREIGN KEY (`PROTOCOL_MAPPER_ID`) REFERENCES `PROTOCOL_MAPPER` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROTOCOL_MAPPER_CONFIG`
--

LOCK TABLES `PROTOCOL_MAPPER_CONFIG` WRITE;
/*!40000 ALTER TABLE `PROTOCOL_MAPPER_CONFIG` DISABLE KEYS */;
INSERT INTO `PROTOCOL_MAPPER_CONFIG` VALUES ('006df7f3-db14-4b30-bbb2-de147bde0122','true','access.token.claim'),('006df7f3-db14-4b30-bbb2-de147bde0122','upn','claim.name'),('006df7f3-db14-4b30-bbb2-de147bde0122','true','id.token.claim'),('006df7f3-db14-4b30-bbb2-de147bde0122','String','jsonType.label'),('006df7f3-db14-4b30-bbb2-de147bde0122','username','user.attribute'),('006df7f3-db14-4b30-bbb2-de147bde0122','true','userinfo.token.claim'),('037b7484-2d7a-4965-9f11-e9df8f2196a3','true','access.token.claim'),('037b7484-2d7a-4965-9f11-e9df8f2196a3','family_name','claim.name'),('037b7484-2d7a-4965-9f11-e9df8f2196a3','true','id.token.claim'),('037b7484-2d7a-4965-9f11-e9df8f2196a3','String','jsonType.label'),('037b7484-2d7a-4965-9f11-e9df8f2196a3','lastName','user.attribute'),('037b7484-2d7a-4965-9f11-e9df8f2196a3','true','userinfo.token.claim'),('096ca0ed-f271-47b3-84a6-18d924575aa7','true','access.token.claim'),('096ca0ed-f271-47b3-84a6-18d924575aa7','phone_number','claim.name'),('096ca0ed-f271-47b3-84a6-18d924575aa7','true','id.token.claim'),('096ca0ed-f271-47b3-84a6-18d924575aa7','String','jsonType.label'),('096ca0ed-f271-47b3-84a6-18d924575aa7','phoneNumber','user.attribute'),('096ca0ed-f271-47b3-84a6-18d924575aa7','true','userinfo.token.claim'),('0c6ee8a3-f557-485c-85a2-9cd4758c86ec','true','access.token.claim'),('0c6ee8a3-f557-485c-85a2-9cd4758c86ec','auth_time','claim.name'),('0c6ee8a3-f557-485c-85a2-9cd4758c86ec','true','id.token.claim'),('0c6ee8a3-f557-485c-85a2-9cd4758c86ec','true','introspection.token.claim'),('0c6ee8a3-f557-485c-85a2-9cd4758c86ec','long','jsonType.label'),('0c6ee8a3-f557-485c-85a2-9cd4758c86ec','AUTH_TIME','user.session.note'),('0cee8338-8563-4b0b-8ce3-28142780cf4e','true','access.token.claim'),('0cee8338-8563-4b0b-8ce3-28142780cf4e','auth_time','claim.name'),('0cee8338-8563-4b0b-8ce3-28142780cf4e','true','id.token.claim'),('0cee8338-8563-4b0b-8ce3-28142780cf4e','true','introspection.token.claim'),('0cee8338-8563-4b0b-8ce3-28142780cf4e','long','jsonType.label'),('0cee8338-8563-4b0b-8ce3-28142780cf4e','AUTH_TIME','user.session.note'),('0fab5b8a-16c6-4ace-ba0c-80c5b724989a','true','access.token.claim'),('0fab5b8a-16c6-4ace-ba0c-80c5b724989a','locale','claim.name'),('0fab5b8a-16c6-4ace-ba0c-80c5b724989a','true','id.token.claim'),('0fab5b8a-16c6-4ace-ba0c-80c5b724989a','String','jsonType.label'),('0fab5b8a-16c6-4ace-ba0c-80c5b724989a','locale','user.attribute'),('0fab5b8a-16c6-4ace-ba0c-80c5b724989a','true','userinfo.token.claim'),('1314331a-5621-47b8-8082-96a8f1f802a6','true','access.token.claim'),('1314331a-5621-47b8-8082-96a8f1f802a6','updated_at','claim.name'),('1314331a-5621-47b8-8082-96a8f1f802a6','true','id.token.claim'),('1314331a-5621-47b8-8082-96a8f1f802a6','String','jsonType.label'),('1314331a-5621-47b8-8082-96a8f1f802a6','updatedAt','user.attribute'),('1314331a-5621-47b8-8082-96a8f1f802a6','true','userinfo.token.claim'),('131bd228-0aa8-4f4f-a803-dae8934e4430','true','access.token.claim'),('131bd228-0aa8-4f4f-a803-dae8934e4430','preferred_username','claim.name'),('131bd228-0aa8-4f4f-a803-dae8934e4430','true','id.token.claim'),('131bd228-0aa8-4f4f-a803-dae8934e4430','String','jsonType.label'),('131bd228-0aa8-4f4f-a803-dae8934e4430','username','user.attribute'),('131bd228-0aa8-4f4f-a803-dae8934e4430','true','userinfo.token.claim'),('13479da2-7a14-49a5-a36c-9fe1b1f49559','true','access.token.claim'),('13479da2-7a14-49a5-a36c-9fe1b1f49559','gender','claim.name'),('13479da2-7a14-49a5-a36c-9fe1b1f49559','true','id.token.claim'),('13479da2-7a14-49a5-a36c-9fe1b1f49559','String','jsonType.label'),('13479da2-7a14-49a5-a36c-9fe1b1f49559','gender','user.attribute'),('13479da2-7a14-49a5-a36c-9fe1b1f49559','true','userinfo.token.claim'),('198063ba-d18a-483e-8c5c-06361e4b61ae','true','access.token.claim'),('198063ba-d18a-483e-8c5c-06361e4b61ae','picture','claim.name'),('198063ba-d18a-483e-8c5c-06361e4b61ae','true','id.token.claim'),('198063ba-d18a-483e-8c5c-06361e4b61ae','String','jsonType.label'),('198063ba-d18a-483e-8c5c-06361e4b61ae','picture','user.attribute'),('198063ba-d18a-483e-8c5c-06361e4b61ae','true','userinfo.token.claim'),('1aa58698-76dd-4113-8161-cae0fe90cb1a','true','access.token.claim'),('1aa58698-76dd-4113-8161-cae0fe90cb1a','profile','claim.name'),('1aa58698-76dd-4113-8161-cae0fe90cb1a','true','id.token.claim'),('1aa58698-76dd-4113-8161-cae0fe90cb1a','String','jsonType.label'),('1aa58698-76dd-4113-8161-cae0fe90cb1a','profile','user.attribute'),('1aa58698-76dd-4113-8161-cae0fe90cb1a','true','userinfo.token.claim'),('1f88e620-e06c-4b8c-90ca-80b3d4c4e946','true','access.token.claim'),('1f88e620-e06c-4b8c-90ca-80b3d4c4e946','true','id.token.claim'),('1f88e620-e06c-4b8c-90ca-80b3d4c4e946','true','userinfo.token.claim'),('21d400d1-75ad-4e66-95e5-206ea1d2a49f','true','access.token.claim'),('21d400d1-75ad-4e66-95e5-206ea1d2a49f','nickname','claim.name'),('21d400d1-75ad-4e66-95e5-206ea1d2a49f','true','id.token.claim'),('21d400d1-75ad-4e66-95e5-206ea1d2a49f','String','jsonType.label'),('21d400d1-75ad-4e66-95e5-206ea1d2a49f','nickname','user.attribute'),('21d400d1-75ad-4e66-95e5-206ea1d2a49f','true','userinfo.token.claim'),('2324eae2-7402-4ad4-ad51-bb469eb3982e','true','access.token.claim'),('2324eae2-7402-4ad4-ad51-bb469eb3982e','given_name','claim.name'),('2324eae2-7402-4ad4-ad51-bb469eb3982e','true','id.token.claim'),('2324eae2-7402-4ad4-ad51-bb469eb3982e','String','jsonType.label'),('2324eae2-7402-4ad4-ad51-bb469eb3982e','firstName','user.attribute'),('2324eae2-7402-4ad4-ad51-bb469eb3982e','true','userinfo.token.claim'),('25a9adb4-390e-4db3-8179-a437cc15bb9d','true','access.token.claim'),('25a9adb4-390e-4db3-8179-a437cc15bb9d','birthdate','claim.name'),('25a9adb4-390e-4db3-8179-a437cc15bb9d','true','id.token.claim'),('25a9adb4-390e-4db3-8179-a437cc15bb9d','String','jsonType.label'),('25a9adb4-390e-4db3-8179-a437cc15bb9d','birthdate','user.attribute'),('25a9adb4-390e-4db3-8179-a437cc15bb9d','true','userinfo.token.claim'),('2767f0f8-c8e0-4aba-99bd-683d158c9a35','true','access.token.claim'),('2767f0f8-c8e0-4aba-99bd-683d158c9a35','zoneinfo','claim.name'),('2767f0f8-c8e0-4aba-99bd-683d158c9a35','true','id.token.claim'),('2767f0f8-c8e0-4aba-99bd-683d158c9a35','String','jsonType.label'),('2767f0f8-c8e0-4aba-99bd-683d158c9a35','zoneinfo','user.attribute'),('2767f0f8-c8e0-4aba-99bd-683d158c9a35','true','userinfo.token.claim'),('29f6f61d-61cf-4ace-9278-dd69d1b73112','true','access.token.claim'),('29f6f61d-61cf-4ace-9278-dd69d1b73112','nickname','claim.name'),('29f6f61d-61cf-4ace-9278-dd69d1b73112','true','id.token.claim'),('29f6f61d-61cf-4ace-9278-dd69d1b73112','String','jsonType.label'),('29f6f61d-61cf-4ace-9278-dd69d1b73112','nickname','user.attribute'),('29f6f61d-61cf-4ace-9278-dd69d1b73112','true','userinfo.token.claim'),('2edc67a4-d6ca-40c1-ab1d-9755cbfc964e','true','access.token.claim'),('2edc67a4-d6ca-40c1-ab1d-9755cbfc964e','true','id.token.claim'),('2edc67a4-d6ca-40c1-ab1d-9755cbfc964e','true','userinfo.token.claim'),('2fccc0e1-960f-4a02-b324-26730253693f','true','access.token.claim'),('2fccc0e1-960f-4a02-b324-26730253693f','updated_at','claim.name'),('2fccc0e1-960f-4a02-b324-26730253693f','true','id.token.claim'),('2fccc0e1-960f-4a02-b324-26730253693f','String','jsonType.label'),('2fccc0e1-960f-4a02-b324-26730253693f','updatedAt','user.attribute'),('2fccc0e1-960f-4a02-b324-26730253693f','true','userinfo.token.claim'),('30b414b5-01ed-4cd0-866f-c3edc937bb9a','true','access.token.claim'),('30b414b5-01ed-4cd0-866f-c3edc937bb9a','email','claim.name'),('30b414b5-01ed-4cd0-866f-c3edc937bb9a','true','id.token.claim'),('30b414b5-01ed-4cd0-866f-c3edc937bb9a','String','jsonType.label'),('30b414b5-01ed-4cd0-866f-c3edc937bb9a','email','user.attribute'),('30b414b5-01ed-4cd0-866f-c3edc937bb9a','true','userinfo.token.claim'),('31a4b671-cda0-43b3-bb40-dd49af57e755','true','access.token.claim'),('31a4b671-cda0-43b3-bb40-dd49af57e755','family_name','claim.name'),('31a4b671-cda0-43b3-bb40-dd49af57e755','true','id.token.claim'),('31a4b671-cda0-43b3-bb40-dd49af57e755','String','jsonType.label'),('31a4b671-cda0-43b3-bb40-dd49af57e755','lastName','user.attribute'),('31a4b671-cda0-43b3-bb40-dd49af57e755','true','userinfo.token.claim'),('330b1fd6-41da-4693-9a5c-f60a5a76d055','true','access.token.claim'),('330b1fd6-41da-4693-9a5c-f60a5a76d055','email_verified','claim.name'),('330b1fd6-41da-4693-9a5c-f60a5a76d055','true','id.token.claim'),('330b1fd6-41da-4693-9a5c-f60a5a76d055','boolean','jsonType.label'),('330b1fd6-41da-4693-9a5c-f60a5a76d055','emailVerified','user.attribute'),('330b1fd6-41da-4693-9a5c-f60a5a76d055','true','userinfo.token.claim'),('340c09f2-d529-4f0a-9ba9-d43989e121d5','true','access.token.claim'),('340c09f2-d529-4f0a-9ba9-d43989e121d5','nickname','claim.name'),('340c09f2-d529-4f0a-9ba9-d43989e121d5','true','id.token.claim'),('340c09f2-d529-4f0a-9ba9-d43989e121d5','String','jsonType.label'),('340c09f2-d529-4f0a-9ba9-d43989e121d5','nickname','user.attribute'),('340c09f2-d529-4f0a-9ba9-d43989e121d5','true','userinfo.token.claim'),('36f43a1f-7960-4b1e-9fad-cb0a9b958015','true','access.token.claim'),('36f43a1f-7960-4b1e-9fad-cb0a9b958015','phone_number_verified','claim.name'),('36f43a1f-7960-4b1e-9fad-cb0a9b958015','true','id.token.claim'),('36f43a1f-7960-4b1e-9fad-cb0a9b958015','boolean','jsonType.label'),('36f43a1f-7960-4b1e-9fad-cb0a9b958015','phoneNumberVerified','user.attribute'),('36f43a1f-7960-4b1e-9fad-cb0a9b958015','true','userinfo.token.claim'),('3a823928-d589-4b70-b9ff-dedac139acc7','true','access.token.claim'),('3a823928-d589-4b70-b9ff-dedac139acc7','email_verified','claim.name'),('3a823928-d589-4b70-b9ff-dedac139acc7','true','id.token.claim'),('3a823928-d589-4b70-b9ff-dedac139acc7','boolean','jsonType.label'),('3a823928-d589-4b70-b9ff-dedac139acc7','emailVerified','user.attribute'),('3a823928-d589-4b70-b9ff-dedac139acc7','true','userinfo.token.claim'),('3b165070-481a-4bfd-a16e-acb2a7987ed9','true','access.token.claim'),('3b165070-481a-4bfd-a16e-acb2a7987ed9','groups','claim.name'),('3b165070-481a-4bfd-a16e-acb2a7987ed9','true','id.token.claim'),('3b165070-481a-4bfd-a16e-acb2a7987ed9','String','jsonType.label'),('3b165070-481a-4bfd-a16e-acb2a7987ed9','true','multivalued'),('3b165070-481a-4bfd-a16e-acb2a7987ed9','foo','user.attribute'),('3d119ee6-8d34-49f4-833c-a6aa36964b56','true','access.token.claim'),('3d119ee6-8d34-49f4-833c-a6aa36964b56','locale','claim.name'),('3d119ee6-8d34-49f4-833c-a6aa36964b56','true','id.token.claim'),('3d119ee6-8d34-49f4-833c-a6aa36964b56','String','jsonType.label'),('3d119ee6-8d34-49f4-833c-a6aa36964b56','locale','user.attribute'),('3d119ee6-8d34-49f4-833c-a6aa36964b56','true','userinfo.token.claim'),('3d75c537-ed38-4fa3-aafc-b84f3647c4e9','true','access.token.claim'),('3d75c537-ed38-4fa3-aafc-b84f3647c4e9','realm_access.roles','claim.name'),('3d75c537-ed38-4fa3-aafc-b84f3647c4e9','String','jsonType.label'),('3d75c537-ed38-4fa3-aafc-b84f3647c4e9','true','multivalued'),('3d75c537-ed38-4fa3-aafc-b84f3647c4e9','foo','user.attribute'),('3fc458c5-2cea-45ea-8900-3530eaab9307','true','access.token.claim'),('3fc458c5-2cea-45ea-8900-3530eaab9307','groups','claim.name'),('3fc458c5-2cea-45ea-8900-3530eaab9307','true','id.token.claim'),('3fc458c5-2cea-45ea-8900-3530eaab9307','String','jsonType.label'),('3fc458c5-2cea-45ea-8900-3530eaab9307','true','multivalued'),('3fc458c5-2cea-45ea-8900-3530eaab9307','foo','user.attribute'),('4182c471-c41f-4d0b-ae8a-4135ebb175cb','true','access.token.claim'),('4182c471-c41f-4d0b-ae8a-4135ebb175cb','given_name','claim.name'),('4182c471-c41f-4d0b-ae8a-4135ebb175cb','true','id.token.claim'),('4182c471-c41f-4d0b-ae8a-4135ebb175cb','String','jsonType.label'),('4182c471-c41f-4d0b-ae8a-4135ebb175cb','firstName','user.attribute'),('4182c471-c41f-4d0b-ae8a-4135ebb175cb','true','userinfo.token.claim'),('43a8499d-f72b-43a0-ba0d-c36f976df92d','true','access.token.claim'),('43a8499d-f72b-43a0-ba0d-c36f976df92d','auth_time','claim.name'),('43a8499d-f72b-43a0-ba0d-c36f976df92d','true','id.token.claim'),('43a8499d-f72b-43a0-ba0d-c36f976df92d','true','introspection.token.claim'),('43a8499d-f72b-43a0-ba0d-c36f976df92d','long','jsonType.label'),('43a8499d-f72b-43a0-ba0d-c36f976df92d','AUTH_TIME','user.session.note'),('44197f4e-2f1b-46c9-aab1-417cf632acba','true','access.token.claim'),('44197f4e-2f1b-46c9-aab1-417cf632acba','true','id.token.claim'),('44197f4e-2f1b-46c9-aab1-417cf632acba','country','user.attribute.country'),('44197f4e-2f1b-46c9-aab1-417cf632acba','formatted','user.attribute.formatted'),('44197f4e-2f1b-46c9-aab1-417cf632acba','locality','user.attribute.locality'),('44197f4e-2f1b-46c9-aab1-417cf632acba','postal_code','user.attribute.postal_code'),('44197f4e-2f1b-46c9-aab1-417cf632acba','region','user.attribute.region'),('44197f4e-2f1b-46c9-aab1-417cf632acba','street','user.attribute.street'),('44197f4e-2f1b-46c9-aab1-417cf632acba','true','userinfo.token.claim'),('44b10a86-9368-427f-a595-a308956637f4','Role','attribute.name'),('44b10a86-9368-427f-a595-a308956637f4','Basic','attribute.nameformat'),('44b10a86-9368-427f-a595-a308956637f4','false','single'),('46a11a2f-8fd2-4186-a4f9-9d0238fd4a2c','true','access.token.claim'),('46a11a2f-8fd2-4186-a4f9-9d0238fd4a2c','website','claim.name'),('46a11a2f-8fd2-4186-a4f9-9d0238fd4a2c','true','id.token.claim'),('46a11a2f-8fd2-4186-a4f9-9d0238fd4a2c','String','jsonType.label'),('46a11a2f-8fd2-4186-a4f9-9d0238fd4a2c','website','user.attribute'),('46a11a2f-8fd2-4186-a4f9-9d0238fd4a2c','true','userinfo.token.claim'),('47e11601-6ddd-4294-9718-11ad2de3f79a','true','access.token.claim'),('47e11601-6ddd-4294-9718-11ad2de3f79a','phone_number_verified','claim.name'),('47e11601-6ddd-4294-9718-11ad2de3f79a','true','id.token.claim'),('47e11601-6ddd-4294-9718-11ad2de3f79a','boolean','jsonType.label'),('47e11601-6ddd-4294-9718-11ad2de3f79a','phoneNumberVerified','user.attribute'),('47e11601-6ddd-4294-9718-11ad2de3f79a','true','userinfo.token.claim'),('4bbd70f2-774a-456f-85bc-cd75b0e64d42','true','access.token.claim'),('4bbd70f2-774a-456f-85bc-cd75b0e64d42','given_name','claim.name'),('4bbd70f2-774a-456f-85bc-cd75b0e64d42','true','id.token.claim'),('4bbd70f2-774a-456f-85bc-cd75b0e64d42','String','jsonType.label'),('4bbd70f2-774a-456f-85bc-cd75b0e64d42','firstName','user.attribute'),('4bbd70f2-774a-456f-85bc-cd75b0e64d42','true','userinfo.token.claim'),('4d4d94aa-4430-434a-96d4-c8ae520987e2','true','access.token.claim'),('4d4d94aa-4430-434a-96d4-c8ae520987e2','true','id.token.claim'),('4eaa91b9-91e9-4964-a65b-2a85ffe0919d','true','access.token.claim'),('4eaa91b9-91e9-4964-a65b-2a85ffe0919d','true','introspection.token.claim'),('4fa4652e-e530-458a-8419-f08e1d48c283','Role','attribute.name'),('4fa4652e-e530-458a-8419-f08e1d48c283','Basic','attribute.nameformat'),('4fa4652e-e530-458a-8419-f08e1d48c283','false','single'),('5710c814-8c1b-4aa6-9082-4d9364c67951','true','access.token.claim'),('5710c814-8c1b-4aa6-9082-4d9364c67951','upn','claim.name'),('5710c814-8c1b-4aa6-9082-4d9364c67951','true','id.token.claim'),('5710c814-8c1b-4aa6-9082-4d9364c67951','String','jsonType.label'),('5710c814-8c1b-4aa6-9082-4d9364c67951','username','user.attribute'),('5710c814-8c1b-4aa6-9082-4d9364c67951','true','userinfo.token.claim'),('571fa7da-4f61-4c58-84a2-ee8bba9320bc','true','access.token.claim'),('571fa7da-4f61-4c58-84a2-ee8bba9320bc','middle_name','claim.name'),('571fa7da-4f61-4c58-84a2-ee8bba9320bc','true','id.token.claim'),('571fa7da-4f61-4c58-84a2-ee8bba9320bc','String','jsonType.label'),('571fa7da-4f61-4c58-84a2-ee8bba9320bc','middleName','user.attribute'),('571fa7da-4f61-4c58-84a2-ee8bba9320bc','true','userinfo.token.claim'),('59dadbbf-7c5e-4a63-8b45-6a071b3fc1f9','true','access.token.claim'),('59dadbbf-7c5e-4a63-8b45-6a071b3fc1f9','true','introspection.token.claim'),('5a3e40aa-5988-4a7c-b03f-1ea561d30ec1','true','access.token.claim'),('5a3e40aa-5988-4a7c-b03f-1ea561d30ec1','preferred_username','claim.name'),('5a3e40aa-5988-4a7c-b03f-1ea561d30ec1','true','id.token.claim'),('5a3e40aa-5988-4a7c-b03f-1ea561d30ec1','String','jsonType.label'),('5a3e40aa-5988-4a7c-b03f-1ea561d30ec1','username','user.attribute'),('5a3e40aa-5988-4a7c-b03f-1ea561d30ec1','true','userinfo.token.claim'),('5e8c918b-8b17-4015-8139-5808f99e44c1','true','access.token.claim'),('5e8c918b-8b17-4015-8139-5808f99e44c1','picture','claim.name'),('5e8c918b-8b17-4015-8139-5808f99e44c1','true','id.token.claim'),('5e8c918b-8b17-4015-8139-5808f99e44c1','String','jsonType.label'),('5e8c918b-8b17-4015-8139-5808f99e44c1','picture','user.attribute'),('5e8c918b-8b17-4015-8139-5808f99e44c1','true','userinfo.token.claim'),('6442409e-8d0b-4ece-90b8-dc5b60a84062','true','access.token.claim'),('6442409e-8d0b-4ece-90b8-dc5b60a84062','gender','claim.name'),('6442409e-8d0b-4ece-90b8-dc5b60a84062','true','id.token.claim'),('6442409e-8d0b-4ece-90b8-dc5b60a84062','String','jsonType.label'),('6442409e-8d0b-4ece-90b8-dc5b60a84062','gender','user.attribute'),('6442409e-8d0b-4ece-90b8-dc5b60a84062','true','userinfo.token.claim'),('68bc5ecd-9b4c-44e0-aafa-cbed318f3a89','true','access.token.claim'),('68bc5ecd-9b4c-44e0-aafa-cbed318f3a89','realm_access.roles','claim.name'),('68bc5ecd-9b4c-44e0-aafa-cbed318f3a89','String','jsonType.label'),('68bc5ecd-9b4c-44e0-aafa-cbed318f3a89','true','multivalued'),('68bc5ecd-9b4c-44e0-aafa-cbed318f3a89','foo','user.attribute'),('6b278229-0181-4fc4-b4c9-a80f5218a124','true','access.token.claim'),('6b278229-0181-4fc4-b4c9-a80f5218a124','phone_number_verified','claim.name'),('6b278229-0181-4fc4-b4c9-a80f5218a124','true','id.token.claim'),('6b278229-0181-4fc4-b4c9-a80f5218a124','boolean','jsonType.label'),('6b278229-0181-4fc4-b4c9-a80f5218a124','phoneNumberVerified','user.attribute'),('6b278229-0181-4fc4-b4c9-a80f5218a124','true','userinfo.token.claim'),('6b301df0-831e-4aec-ae1e-e12d055d5b81','true','access.token.claim'),('6b301df0-831e-4aec-ae1e-e12d055d5b81','website','claim.name'),('6b301df0-831e-4aec-ae1e-e12d055d5b81','true','id.token.claim'),('6b301df0-831e-4aec-ae1e-e12d055d5b81','String','jsonType.label'),('6b301df0-831e-4aec-ae1e-e12d055d5b81','website','user.attribute'),('6b301df0-831e-4aec-ae1e-e12d055d5b81','true','userinfo.token.claim'),('6b69c55c-b041-425e-b771-15990ccaef1f','true','access.token.claim'),('6b69c55c-b041-425e-b771-15990ccaef1f','picture','claim.name'),('6b69c55c-b041-425e-b771-15990ccaef1f','true','id.token.claim'),('6b69c55c-b041-425e-b771-15990ccaef1f','String','jsonType.label'),('6b69c55c-b041-425e-b771-15990ccaef1f','picture','user.attribute'),('6b69c55c-b041-425e-b771-15990ccaef1f','true','userinfo.token.claim'),('6d4467b4-3bf6-40b6-9fce-d82f2863c74e','true','access.token.claim'),('6d4467b4-3bf6-40b6-9fce-d82f2863c74e','resource_access.${client_id}.roles','claim.name'),('6d4467b4-3bf6-40b6-9fce-d82f2863c74e','String','jsonType.label'),('6d4467b4-3bf6-40b6-9fce-d82f2863c74e','true','multivalued'),('6d4467b4-3bf6-40b6-9fce-d82f2863c74e','foo','user.attribute'),('6d6d50b8-cd32-40a4-b07b-0eb7c5a0a8c7','true','access.token.claim'),('6d6d50b8-cd32-40a4-b07b-0eb7c5a0a8c7','gender','claim.name'),('6d6d50b8-cd32-40a4-b07b-0eb7c5a0a8c7','true','id.token.claim'),('6d6d50b8-cd32-40a4-b07b-0eb7c5a0a8c7','String','jsonType.label'),('6d6d50b8-cd32-40a4-b07b-0eb7c5a0a8c7','gender','user.attribute'),('6d6d50b8-cd32-40a4-b07b-0eb7c5a0a8c7','true','userinfo.token.claim'),('73167b77-9d4b-45e8-9eeb-61ba4e1560a3','true','access.token.claim'),('73167b77-9d4b-45e8-9eeb-61ba4e1560a3','true','id.token.claim'),('73167b77-9d4b-45e8-9eeb-61ba4e1560a3','true','userinfo.token.claim'),('76383b8f-1a73-4948-afd4-62e04c8581e1','true','access.token.claim'),('76383b8f-1a73-4948-afd4-62e04c8581e1','middle_name','claim.name'),('76383b8f-1a73-4948-afd4-62e04c8581e1','true','id.token.claim'),('76383b8f-1a73-4948-afd4-62e04c8581e1','String','jsonType.label'),('76383b8f-1a73-4948-afd4-62e04c8581e1','middleName','user.attribute'),('76383b8f-1a73-4948-afd4-62e04c8581e1','true','userinfo.token.claim'),('7cb38b1d-07fd-4463-a7e7-64f67375f20a','true','access.token.claim'),('7cb38b1d-07fd-4463-a7e7-64f67375f20a','phone_number','claim.name'),('7cb38b1d-07fd-4463-a7e7-64f67375f20a','true','id.token.claim'),('7cb38b1d-07fd-4463-a7e7-64f67375f20a','String','jsonType.label'),('7cb38b1d-07fd-4463-a7e7-64f67375f20a','phoneNumber','user.attribute'),('7cb38b1d-07fd-4463-a7e7-64f67375f20a','true','userinfo.token.claim'),('80c245ea-7a32-48da-a1b7-5c0ab5663c7a','true','access.token.claim'),('80c245ea-7a32-48da-a1b7-5c0ab5663c7a','locale','claim.name'),('80c245ea-7a32-48da-a1b7-5c0ab5663c7a','true','id.token.claim'),('80c245ea-7a32-48da-a1b7-5c0ab5663c7a','String','jsonType.label'),('80c245ea-7a32-48da-a1b7-5c0ab5663c7a','locale','user.attribute'),('80c245ea-7a32-48da-a1b7-5c0ab5663c7a','true','userinfo.token.claim'),('81719cf9-dcb4-4804-9427-c0d34073a261','true','access.token.claim'),('81719cf9-dcb4-4804-9427-c0d34073a261','updated_at','claim.name'),('81719cf9-dcb4-4804-9427-c0d34073a261','true','id.token.claim'),('81719cf9-dcb4-4804-9427-c0d34073a261','String','jsonType.label'),('81719cf9-dcb4-4804-9427-c0d34073a261','updatedAt','user.attribute'),('81719cf9-dcb4-4804-9427-c0d34073a261','true','userinfo.token.claim'),('82d96572-c3fe-4f6a-aea2-efa45c566fe5','true','access.token.claim'),('82d96572-c3fe-4f6a-aea2-efa45c566fe5','locale','claim.name'),('82d96572-c3fe-4f6a-aea2-efa45c566fe5','true','id.token.claim'),('82d96572-c3fe-4f6a-aea2-efa45c566fe5','String','jsonType.label'),('82d96572-c3fe-4f6a-aea2-efa45c566fe5','locale','user.attribute'),('82d96572-c3fe-4f6a-aea2-efa45c566fe5','true','userinfo.token.claim'),('85fea67a-1bc0-4958-b78f-69f103c3b80d','true','access.token.claim'),('85fea67a-1bc0-4958-b78f-69f103c3b80d','profile','claim.name'),('85fea67a-1bc0-4958-b78f-69f103c3b80d','true','id.token.claim'),('85fea67a-1bc0-4958-b78f-69f103c3b80d','String','jsonType.label'),('85fea67a-1bc0-4958-b78f-69f103c3b80d','profile','user.attribute'),('85fea67a-1bc0-4958-b78f-69f103c3b80d','true','userinfo.token.claim'),('86cf90a9-9880-4bc1-9a13-79f73b8e975a','true','access.token.claim'),('86cf90a9-9880-4bc1-9a13-79f73b8e975a','zoneinfo','claim.name'),('86cf90a9-9880-4bc1-9a13-79f73b8e975a','true','id.token.claim'),('86cf90a9-9880-4bc1-9a13-79f73b8e975a','String','jsonType.label'),('86cf90a9-9880-4bc1-9a13-79f73b8e975a','zoneinfo','user.attribute'),('86cf90a9-9880-4bc1-9a13-79f73b8e975a','true','userinfo.token.claim'),('86dc21e6-cbcf-4a20-8465-51221dd5d891','true','access.token.claim'),('86dc21e6-cbcf-4a20-8465-51221dd5d891','phone_number_verified','claim.name'),('86dc21e6-cbcf-4a20-8465-51221dd5d891','true','id.token.claim'),('86dc21e6-cbcf-4a20-8465-51221dd5d891','boolean','jsonType.label'),('86dc21e6-cbcf-4a20-8465-51221dd5d891','phoneNumberVerified','user.attribute'),('86dc21e6-cbcf-4a20-8465-51221dd5d891','true','userinfo.token.claim'),('894279b9-16aa-4ebe-b40f-c338bf2a7d92','true','access.token.claim'),('894279b9-16aa-4ebe-b40f-c338bf2a7d92','birthdate','claim.name'),('894279b9-16aa-4ebe-b40f-c338bf2a7d92','true','id.token.claim'),('894279b9-16aa-4ebe-b40f-c338bf2a7d92','String','jsonType.label'),('894279b9-16aa-4ebe-b40f-c338bf2a7d92','birthdate','user.attribute'),('894279b9-16aa-4ebe-b40f-c338bf2a7d92','true','userinfo.token.claim'),('8b0f11c1-b665-4298-9828-87ec1111df26','true','access.token.claim'),('8b0f11c1-b665-4298-9828-87ec1111df26','locale','claim.name'),('8b0f11c1-b665-4298-9828-87ec1111df26','true','id.token.claim'),('8b0f11c1-b665-4298-9828-87ec1111df26','String','jsonType.label'),('8b0f11c1-b665-4298-9828-87ec1111df26','locale','user.attribute'),('8b0f11c1-b665-4298-9828-87ec1111df26','true','userinfo.token.claim'),('8faf4278-9adf-4ea6-ba06-74792a73ed54','true','access.token.claim'),('8faf4278-9adf-4ea6-ba06-74792a73ed54','groups','claim.name'),('8faf4278-9adf-4ea6-ba06-74792a73ed54','true','id.token.claim'),('8faf4278-9adf-4ea6-ba06-74792a73ed54','String','jsonType.label'),('8faf4278-9adf-4ea6-ba06-74792a73ed54','true','multivalued'),('8faf4278-9adf-4ea6-ba06-74792a73ed54','foo','user.attribute'),('958ba9e1-0bd0-4495-9e17-3bbd61c8e970','Role','attribute.name'),('958ba9e1-0bd0-4495-9e17-3bbd61c8e970','Basic','attribute.nameformat'),('958ba9e1-0bd0-4495-9e17-3bbd61c8e970','false','single'),('96211100-9f9c-4d9a-8749-1d248f69d421','true','access.token.claim'),('96211100-9f9c-4d9a-8749-1d248f69d421','phone_number','claim.name'),('96211100-9f9c-4d9a-8749-1d248f69d421','true','id.token.claim'),('96211100-9f9c-4d9a-8749-1d248f69d421','String','jsonType.label'),('96211100-9f9c-4d9a-8749-1d248f69d421','phoneNumber','user.attribute'),('96211100-9f9c-4d9a-8749-1d248f69d421','true','userinfo.token.claim'),('96eadbc7-0864-40ca-9243-f3deeb6615c4','true','access.token.claim'),('96eadbc7-0864-40ca-9243-f3deeb6615c4','realm_access.roles','claim.name'),('96eadbc7-0864-40ca-9243-f3deeb6615c4','String','jsonType.label'),('96eadbc7-0864-40ca-9243-f3deeb6615c4','true','multivalued'),('96eadbc7-0864-40ca-9243-f3deeb6615c4','foo','user.attribute'),('9840695c-9722-4694-ae41-0826ae555a9a','true','access.token.claim'),('9840695c-9722-4694-ae41-0826ae555a9a','profile','claim.name'),('9840695c-9722-4694-ae41-0826ae555a9a','true','id.token.claim'),('9840695c-9722-4694-ae41-0826ae555a9a','String','jsonType.label'),('9840695c-9722-4694-ae41-0826ae555a9a','profile','user.attribute'),('9840695c-9722-4694-ae41-0826ae555a9a','true','userinfo.token.claim'),('9a84beae-9dab-4a04-ba5c-e4f5117e07f1','true','access.token.claim'),('9a84beae-9dab-4a04-ba5c-e4f5117e07f1','email_verified','claim.name'),('9a84beae-9dab-4a04-ba5c-e4f5117e07f1','true','id.token.claim'),('9a84beae-9dab-4a04-ba5c-e4f5117e07f1','boolean','jsonType.label'),('9a84beae-9dab-4a04-ba5c-e4f5117e07f1','emailVerified','user.attribute'),('9a84beae-9dab-4a04-ba5c-e4f5117e07f1','true','userinfo.token.claim'),('9c4bbdd6-ce3e-4db0-8a4a-9cab43631399','true','access.token.claim'),('9c4bbdd6-ce3e-4db0-8a4a-9cab43631399','true','id.token.claim'),('9c4bbdd6-ce3e-4db0-8a4a-9cab43631399','country','user.attribute.country'),('9c4bbdd6-ce3e-4db0-8a4a-9cab43631399','formatted','user.attribute.formatted'),('9c4bbdd6-ce3e-4db0-8a4a-9cab43631399','locality','user.attribute.locality'),('9c4bbdd6-ce3e-4db0-8a4a-9cab43631399','postal_code','user.attribute.postal_code'),('9c4bbdd6-ce3e-4db0-8a4a-9cab43631399','region','user.attribute.region'),('9c4bbdd6-ce3e-4db0-8a4a-9cab43631399','street','user.attribute.street'),('9c4bbdd6-ce3e-4db0-8a4a-9cab43631399','true','userinfo.token.claim'),('9d3d082f-0f51-44a8-a828-7e51381a12cd','true','access.token.claim'),('9d3d082f-0f51-44a8-a828-7e51381a12cd','email','claim.name'),('9d3d082f-0f51-44a8-a828-7e51381a12cd','true','id.token.claim'),('9d3d082f-0f51-44a8-a828-7e51381a12cd','String','jsonType.label'),('9d3d082f-0f51-44a8-a828-7e51381a12cd','email','user.attribute'),('9d3d082f-0f51-44a8-a828-7e51381a12cd','true','userinfo.token.claim'),('9e0b38ce-963b-48ca-ac53-7a12fea2ea8d','true','access.token.claim'),('9e0b38ce-963b-48ca-ac53-7a12fea2ea8d','email','claim.name'),('9e0b38ce-963b-48ca-ac53-7a12fea2ea8d','true','id.token.claim'),('9e0b38ce-963b-48ca-ac53-7a12fea2ea8d','String','jsonType.label'),('9e0b38ce-963b-48ca-ac53-7a12fea2ea8d','email','user.attribute'),('9e0b38ce-963b-48ca-ac53-7a12fea2ea8d','true','userinfo.token.claim'),('9eaea907-8ea0-46c7-b495-921d82af2c8d','true','access.token.claim'),('9eaea907-8ea0-46c7-b495-921d82af2c8d','family_name','claim.name'),('9eaea907-8ea0-46c7-b495-921d82af2c8d','true','id.token.claim'),('9eaea907-8ea0-46c7-b495-921d82af2c8d','String','jsonType.label'),('9eaea907-8ea0-46c7-b495-921d82af2c8d','lastName','user.attribute'),('9eaea907-8ea0-46c7-b495-921d82af2c8d','true','userinfo.token.claim'),('9f8e25ef-c1d9-4d9b-87b4-b33d61987fe6','true','access.token.claim'),('9f8e25ef-c1d9-4d9b-87b4-b33d61987fe6','email','claim.name'),('9f8e25ef-c1d9-4d9b-87b4-b33d61987fe6','true','id.token.claim'),('9f8e25ef-c1d9-4d9b-87b4-b33d61987fe6','String','jsonType.label'),('9f8e25ef-c1d9-4d9b-87b4-b33d61987fe6','email','user.attribute'),('9f8e25ef-c1d9-4d9b-87b4-b33d61987fe6','true','userinfo.token.claim'),('a2d37426-f561-4caf-8a73-6cdd8d6f3942','true','access.token.claim'),('a2d37426-f561-4caf-8a73-6cdd8d6f3942','nickname','claim.name'),('a2d37426-f561-4caf-8a73-6cdd8d6f3942','true','id.token.claim'),('a2d37426-f561-4caf-8a73-6cdd8d6f3942','String','jsonType.label'),('a2d37426-f561-4caf-8a73-6cdd8d6f3942','nickname','user.attribute'),('a2d37426-f561-4caf-8a73-6cdd8d6f3942','true','userinfo.token.claim'),('a3967c9d-64b7-4eaa-98a2-f8ae0cf2ddfc','true','access.token.claim'),('a3967c9d-64b7-4eaa-98a2-f8ae0cf2ddfc','birthdate','claim.name'),('a3967c9d-64b7-4eaa-98a2-f8ae0cf2ddfc','true','id.token.claim'),('a3967c9d-64b7-4eaa-98a2-f8ae0cf2ddfc','String','jsonType.label'),('a3967c9d-64b7-4eaa-98a2-f8ae0cf2ddfc','birthdate','user.attribute'),('a3967c9d-64b7-4eaa-98a2-f8ae0cf2ddfc','true','userinfo.token.claim'),('a7af676a-3789-448d-856d-e05f9e8da7ac','true','access.token.claim'),('a7af676a-3789-448d-856d-e05f9e8da7ac','middle_name','claim.name'),('a7af676a-3789-448d-856d-e05f9e8da7ac','true','id.token.claim'),('a7af676a-3789-448d-856d-e05f9e8da7ac','String','jsonType.label'),('a7af676a-3789-448d-856d-e05f9e8da7ac','middleName','user.attribute'),('a7af676a-3789-448d-856d-e05f9e8da7ac','true','userinfo.token.claim'),('a9f03f70-1836-4ffb-ad00-124c7d1a7bad','true','access.token.claim'),('a9f03f70-1836-4ffb-ad00-124c7d1a7bad','phone_number','claim.name'),('a9f03f70-1836-4ffb-ad00-124c7d1a7bad','true','id.token.claim'),('a9f03f70-1836-4ffb-ad00-124c7d1a7bad','String','jsonType.label'),('a9f03f70-1836-4ffb-ad00-124c7d1a7bad','phoneNumber','user.attribute'),('a9f03f70-1836-4ffb-ad00-124c7d1a7bad','true','userinfo.token.claim'),('aaa2c4c0-f764-454e-be7d-1a12804ca02d','true','access.token.claim'),('aaa2c4c0-f764-454e-be7d-1a12804ca02d','true','id.token.claim'),('b11141a7-cae8-4dc1-8e0a-d105dd1d3716','true','access.token.claim'),('b11141a7-cae8-4dc1-8e0a-d105dd1d3716','realm_access.roles','claim.name'),('b11141a7-cae8-4dc1-8e0a-d105dd1d3716','String','jsonType.label'),('b11141a7-cae8-4dc1-8e0a-d105dd1d3716','true','multivalued'),('b11141a7-cae8-4dc1-8e0a-d105dd1d3716','foo','user.attribute'),('b142fa95-0973-4476-b530-c8d13a9e8951','true','access.token.claim'),('b142fa95-0973-4476-b530-c8d13a9e8951','auth_time','claim.name'),('b142fa95-0973-4476-b530-c8d13a9e8951','true','id.token.claim'),('b142fa95-0973-4476-b530-c8d13a9e8951','true','introspection.token.claim'),('b142fa95-0973-4476-b530-c8d13a9e8951','long','jsonType.label'),('b142fa95-0973-4476-b530-c8d13a9e8951','AUTH_TIME','user.session.note'),('b67a3949-d542-4d03-9066-f3893047c15b','true','access.token.claim'),('b67a3949-d542-4d03-9066-f3893047c15b','true','id.token.claim'),('b97ea8a6-c8cb-42f8-9c81-24ec8ca6a490','true','access.token.claim'),('b97ea8a6-c8cb-42f8-9c81-24ec8ca6a490','upn','claim.name'),('b97ea8a6-c8cb-42f8-9c81-24ec8ca6a490','true','id.token.claim'),('b97ea8a6-c8cb-42f8-9c81-24ec8ca6a490','String','jsonType.label'),('b97ea8a6-c8cb-42f8-9c81-24ec8ca6a490','username','user.attribute'),('b97ea8a6-c8cb-42f8-9c81-24ec8ca6a490','true','userinfo.token.claim'),('bb7b61e4-3f08-404d-93b7-eea0011a7b43','true','access.token.claim'),('bb7b61e4-3f08-404d-93b7-eea0011a7b43','true','introspection.token.claim'),('bd321e4c-74d3-4028-a5c0-10dcc7157cc1','true','access.token.claim'),('bd321e4c-74d3-4028-a5c0-10dcc7157cc1','resource_access.${client_id}.roles','claim.name'),('bd321e4c-74d3-4028-a5c0-10dcc7157cc1','String','jsonType.label'),('bd321e4c-74d3-4028-a5c0-10dcc7157cc1','true','multivalued'),('bd321e4c-74d3-4028-a5c0-10dcc7157cc1','foo','user.attribute'),('bd3e6f70-09ca-439a-8fd4-0b5cf8cd4a1a','true','access.token.claim'),('bd3e6f70-09ca-439a-8fd4-0b5cf8cd4a1a','locale','claim.name'),('bd3e6f70-09ca-439a-8fd4-0b5cf8cd4a1a','true','id.token.claim'),('bd3e6f70-09ca-439a-8fd4-0b5cf8cd4a1a','String','jsonType.label'),('bd3e6f70-09ca-439a-8fd4-0b5cf8cd4a1a','locale','user.attribute'),('bd3e6f70-09ca-439a-8fd4-0b5cf8cd4a1a','true','userinfo.token.claim'),('be118bec-e679-4e70-aee1-7703b4050dd8','true','access.token.claim'),('be118bec-e679-4e70-aee1-7703b4050dd8','true','id.token.claim'),('be118bec-e679-4e70-aee1-7703b4050dd8','true','userinfo.token.claim'),('bea4f679-e702-4c9b-8eec-ba5677017bf7','true','access.token.claim'),('bea4f679-e702-4c9b-8eec-ba5677017bf7','email_verified','claim.name'),('bea4f679-e702-4c9b-8eec-ba5677017bf7','true','id.token.claim'),('bea4f679-e702-4c9b-8eec-ba5677017bf7','boolean','jsonType.label'),('bea4f679-e702-4c9b-8eec-ba5677017bf7','emailVerified','user.attribute'),('bea4f679-e702-4c9b-8eec-ba5677017bf7','true','userinfo.token.claim'),('c4276f3e-996e-45ae-9235-17887a9e475d','true','access.token.claim'),('c4276f3e-996e-45ae-9235-17887a9e475d','true','id.token.claim'),('c4276f3e-996e-45ae-9235-17887a9e475d','country','user.attribute.country'),('c4276f3e-996e-45ae-9235-17887a9e475d','formatted','user.attribute.formatted'),('c4276f3e-996e-45ae-9235-17887a9e475d','locality','user.attribute.locality'),('c4276f3e-996e-45ae-9235-17887a9e475d','postal_code','user.attribute.postal_code'),('c4276f3e-996e-45ae-9235-17887a9e475d','region','user.attribute.region'),('c4276f3e-996e-45ae-9235-17887a9e475d','street','user.attribute.street'),('c4276f3e-996e-45ae-9235-17887a9e475d','true','userinfo.token.claim'),('c4902038-0eb0-4811-bac2-7eb6a2b767b3','true','access.token.claim'),('c4902038-0eb0-4811-bac2-7eb6a2b767b3','true','introspection.token.claim'),('c90bed19-1881-4989-9a2b-6e2606372e4f','Role','attribute.name'),('c90bed19-1881-4989-9a2b-6e2606372e4f','Basic','attribute.nameformat'),('c90bed19-1881-4989-9a2b-6e2606372e4f','false','single'),('c95950fe-4907-418e-a3fc-d5e78f2dacb7','true','access.token.claim'),('c95950fe-4907-418e-a3fc-d5e78f2dacb7','middle_name','claim.name'),('c95950fe-4907-418e-a3fc-d5e78f2dacb7','true','id.token.claim'),('c95950fe-4907-418e-a3fc-d5e78f2dacb7','String','jsonType.label'),('c95950fe-4907-418e-a3fc-d5e78f2dacb7','middleName','user.attribute'),('c95950fe-4907-418e-a3fc-d5e78f2dacb7','true','userinfo.token.claim'),('cb9469bd-60fb-42a0-b938-1a3d544a1f4e','true','access.token.claim'),('cb9469bd-60fb-42a0-b938-1a3d544a1f4e','resource_access.${client_id}.roles','claim.name'),('cb9469bd-60fb-42a0-b938-1a3d544a1f4e','String','jsonType.label'),('cb9469bd-60fb-42a0-b938-1a3d544a1f4e','true','multivalued'),('cb9469bd-60fb-42a0-b938-1a3d544a1f4e','foo','user.attribute'),('cd38c808-7bae-4540-a1fc-b7935ee728ee','true','access.token.claim'),('cd38c808-7bae-4540-a1fc-b7935ee728ee','true','id.token.claim'),('cda7a2f1-ab17-4e79-8af7-51a719c2ee4f','true','access.token.claim'),('cda7a2f1-ab17-4e79-8af7-51a719c2ee4f','true','id.token.claim'),('cda7a2f1-ab17-4e79-8af7-51a719c2ee4f','country','user.attribute.country'),('cda7a2f1-ab17-4e79-8af7-51a719c2ee4f','formatted','user.attribute.formatted'),('cda7a2f1-ab17-4e79-8af7-51a719c2ee4f','locality','user.attribute.locality'),('cda7a2f1-ab17-4e79-8af7-51a719c2ee4f','postal_code','user.attribute.postal_code'),('cda7a2f1-ab17-4e79-8af7-51a719c2ee4f','region','user.attribute.region'),('cda7a2f1-ab17-4e79-8af7-51a719c2ee4f','street','user.attribute.street'),('cda7a2f1-ab17-4e79-8af7-51a719c2ee4f','true','userinfo.token.claim'),('d20b83ec-e517-4932-bfae-985c548799c3','true','access.token.claim'),('d20b83ec-e517-4932-bfae-985c548799c3','family_name','claim.name'),('d20b83ec-e517-4932-bfae-985c548799c3','true','id.token.claim'),('d20b83ec-e517-4932-bfae-985c548799c3','String','jsonType.label'),('d20b83ec-e517-4932-bfae-985c548799c3','lastName','user.attribute'),('d20b83ec-e517-4932-bfae-985c548799c3','true','userinfo.token.claim'),('d216a194-89f0-49b6-90a4-84f23c24f2d5','true','access.token.claim'),('d216a194-89f0-49b6-90a4-84f23c24f2d5','locale','claim.name'),('d216a194-89f0-49b6-90a4-84f23c24f2d5','true','id.token.claim'),('d216a194-89f0-49b6-90a4-84f23c24f2d5','String','jsonType.label'),('d216a194-89f0-49b6-90a4-84f23c24f2d5','locale','user.attribute'),('d216a194-89f0-49b6-90a4-84f23c24f2d5','true','userinfo.token.claim'),('d6160b92-64a3-46fa-be76-4a14ae3b5107','true','access.token.claim'),('d6160b92-64a3-46fa-be76-4a14ae3b5107','website','claim.name'),('d6160b92-64a3-46fa-be76-4a14ae3b5107','true','id.token.claim'),('d6160b92-64a3-46fa-be76-4a14ae3b5107','String','jsonType.label'),('d6160b92-64a3-46fa-be76-4a14ae3b5107','website','user.attribute'),('d6160b92-64a3-46fa-be76-4a14ae3b5107','true','userinfo.token.claim'),('d62b6e6b-99b5-412e-a53b-b496d9059733','true','access.token.claim'),('d62b6e6b-99b5-412e-a53b-b496d9059733','gender','claim.name'),('d62b6e6b-99b5-412e-a53b-b496d9059733','true','id.token.claim'),('d62b6e6b-99b5-412e-a53b-b496d9059733','String','jsonType.label'),('d62b6e6b-99b5-412e-a53b-b496d9059733','gender','user.attribute'),('d62b6e6b-99b5-412e-a53b-b496d9059733','true','userinfo.token.claim'),('de094ef6-4cb2-4341-ba33-0a5da4b18cc6','true','access.token.claim'),('de094ef6-4cb2-4341-ba33-0a5da4b18cc6','birthdate','claim.name'),('de094ef6-4cb2-4341-ba33-0a5da4b18cc6','true','id.token.claim'),('de094ef6-4cb2-4341-ba33-0a5da4b18cc6','String','jsonType.label'),('de094ef6-4cb2-4341-ba33-0a5da4b18cc6','birthdate','user.attribute'),('de094ef6-4cb2-4341-ba33-0a5da4b18cc6','true','userinfo.token.claim'),('dfd01dfc-b19c-4643-bd57-209d003f4980','true','access.token.claim'),('dfd01dfc-b19c-4643-bd57-209d003f4980','locale','claim.name'),('dfd01dfc-b19c-4643-bd57-209d003f4980','true','id.token.claim'),('dfd01dfc-b19c-4643-bd57-209d003f4980','String','jsonType.label'),('dfd01dfc-b19c-4643-bd57-209d003f4980','locale','user.attribute'),('dfd01dfc-b19c-4643-bd57-209d003f4980','true','userinfo.token.claim'),('e044230a-2483-42fd-ad8c-6072864398a7','true','access.token.claim'),('e044230a-2483-42fd-ad8c-6072864398a7','upn','claim.name'),('e044230a-2483-42fd-ad8c-6072864398a7','true','id.token.claim'),('e044230a-2483-42fd-ad8c-6072864398a7','String','jsonType.label'),('e044230a-2483-42fd-ad8c-6072864398a7','username','user.attribute'),('e044230a-2483-42fd-ad8c-6072864398a7','true','userinfo.token.claim'),('e149ff65-9268-4d44-8d6d-fd850788b1f8','true','access.token.claim'),('e149ff65-9268-4d44-8d6d-fd850788b1f8','preferred_username','claim.name'),('e149ff65-9268-4d44-8d6d-fd850788b1f8','true','id.token.claim'),('e149ff65-9268-4d44-8d6d-fd850788b1f8','String','jsonType.label'),('e149ff65-9268-4d44-8d6d-fd850788b1f8','username','user.attribute'),('e149ff65-9268-4d44-8d6d-fd850788b1f8','true','userinfo.token.claim'),('e224daa6-a8b8-43f3-9d05-073bac90abaf','true','access.token.claim'),('e224daa6-a8b8-43f3-9d05-073bac90abaf','picture','claim.name'),('e224daa6-a8b8-43f3-9d05-073bac90abaf','true','id.token.claim'),('e224daa6-a8b8-43f3-9d05-073bac90abaf','String','jsonType.label'),('e224daa6-a8b8-43f3-9d05-073bac90abaf','picture','user.attribute'),('e224daa6-a8b8-43f3-9d05-073bac90abaf','true','userinfo.token.claim'),('e3dada28-c2ac-4413-a52b-62e55e41d800','true','access.token.claim'),('e3dada28-c2ac-4413-a52b-62e55e41d800','resource_access.${client_id}.roles','claim.name'),('e3dada28-c2ac-4413-a52b-62e55e41d800','String','jsonType.label'),('e3dada28-c2ac-4413-a52b-62e55e41d800','true','multivalued'),('e3dada28-c2ac-4413-a52b-62e55e41d800','foo','user.attribute'),('eda86f46-b870-4411-88e2-02cfb092a1f4','true','access.token.claim'),('eda86f46-b870-4411-88e2-02cfb092a1f4','preferred_username','claim.name'),('eda86f46-b870-4411-88e2-02cfb092a1f4','true','id.token.claim'),('eda86f46-b870-4411-88e2-02cfb092a1f4','String','jsonType.label'),('eda86f46-b870-4411-88e2-02cfb092a1f4','username','user.attribute'),('eda86f46-b870-4411-88e2-02cfb092a1f4','true','userinfo.token.claim'),('eeb735b0-b090-4ed3-8b7e-928fba3192d5','true','access.token.claim'),('eeb735b0-b090-4ed3-8b7e-928fba3192d5','zoneinfo','claim.name'),('eeb735b0-b090-4ed3-8b7e-928fba3192d5','true','id.token.claim'),('eeb735b0-b090-4ed3-8b7e-928fba3192d5','String','jsonType.label'),('eeb735b0-b090-4ed3-8b7e-928fba3192d5','zoneinfo','user.attribute'),('eeb735b0-b090-4ed3-8b7e-928fba3192d5','true','userinfo.token.claim'),('ef0f0a8b-8ba8-4d32-98c5-cb8dc496514f','true','access.token.claim'),('ef0f0a8b-8ba8-4d32-98c5-cb8dc496514f','zoneinfo','claim.name'),('ef0f0a8b-8ba8-4d32-98c5-cb8dc496514f','true','id.token.claim'),('ef0f0a8b-8ba8-4d32-98c5-cb8dc496514f','String','jsonType.label'),('ef0f0a8b-8ba8-4d32-98c5-cb8dc496514f','zoneinfo','user.attribute'),('ef0f0a8b-8ba8-4d32-98c5-cb8dc496514f','true','userinfo.token.claim'),('f0a40ed6-1df2-4037-bd94-f8d13b638fef','true','access.token.claim'),('f0a40ed6-1df2-4037-bd94-f8d13b638fef','profile','claim.name'),('f0a40ed6-1df2-4037-bd94-f8d13b638fef','true','id.token.claim'),('f0a40ed6-1df2-4037-bd94-f8d13b638fef','String','jsonType.label'),('f0a40ed6-1df2-4037-bd94-f8d13b638fef','profile','user.attribute'),('f0a40ed6-1df2-4037-bd94-f8d13b638fef','true','userinfo.token.claim'),('f38320de-d931-4596-9b43-e8aeb5cd2bd5','true','access.token.claim'),('f38320de-d931-4596-9b43-e8aeb5cd2bd5','given_name','claim.name'),('f38320de-d931-4596-9b43-e8aeb5cd2bd5','true','id.token.claim'),('f38320de-d931-4596-9b43-e8aeb5cd2bd5','String','jsonType.label'),('f38320de-d931-4596-9b43-e8aeb5cd2bd5','firstName','user.attribute'),('f38320de-d931-4596-9b43-e8aeb5cd2bd5','true','userinfo.token.claim'),('fae5b917-0f41-4c07-a1a0-c717a9d8c4ce','true','access.token.claim'),('fae5b917-0f41-4c07-a1a0-c717a9d8c4ce','website','claim.name'),('fae5b917-0f41-4c07-a1a0-c717a9d8c4ce','true','id.token.claim'),('fae5b917-0f41-4c07-a1a0-c717a9d8c4ce','String','jsonType.label'),('fae5b917-0f41-4c07-a1a0-c717a9d8c4ce','website','user.attribute'),('fae5b917-0f41-4c07-a1a0-c717a9d8c4ce','true','userinfo.token.claim'),('fdbc37ba-f5d2-445d-8316-7094f279200f','true','access.token.claim'),('fdbc37ba-f5d2-445d-8316-7094f279200f','updated_at','claim.name'),('fdbc37ba-f5d2-445d-8316-7094f279200f','true','id.token.claim'),('fdbc37ba-f5d2-445d-8316-7094f279200f','String','jsonType.label'),('fdbc37ba-f5d2-445d-8316-7094f279200f','updatedAt','user.attribute'),('fdbc37ba-f5d2-445d-8316-7094f279200f','true','userinfo.token.claim'),('ffcd07dc-1501-46ce-a38c-643af2d72d7d','true','access.token.claim'),('ffcd07dc-1501-46ce-a38c-643af2d72d7d','groups','claim.name'),('ffcd07dc-1501-46ce-a38c-643af2d72d7d','true','id.token.claim'),('ffcd07dc-1501-46ce-a38c-643af2d72d7d','String','jsonType.label'),('ffcd07dc-1501-46ce-a38c-643af2d72d7d','true','multivalued'),('ffcd07dc-1501-46ce-a38c-643af2d72d7d','foo','user.attribute');
/*!40000 ALTER TABLE `PROTOCOL_MAPPER_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REALM`
--

DROP TABLE IF EXISTS `REALM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REALM` (
  `ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ACCESS_CODE_LIFESPAN` int DEFAULT NULL,
  `USER_ACTION_LIFESPAN` int DEFAULT NULL,
  `ACCESS_TOKEN_LIFESPAN` int DEFAULT NULL,
  `ACCOUNT_THEME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ADMIN_THEME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `EMAIL_THEME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ENABLED` bit(1) NOT NULL DEFAULT b'0',
  `EVENTS_ENABLED` bit(1) NOT NULL DEFAULT b'0',
  `EVENTS_EXPIRATION` bigint DEFAULT NULL,
  `LOGIN_THEME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `NOT_BEFORE` int DEFAULT NULL,
  `PASSWORD_POLICY` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `REGISTRATION_ALLOWED` bit(1) NOT NULL DEFAULT b'0',
  `REMEMBER_ME` bit(1) NOT NULL DEFAULT b'0',
  `RESET_PASSWORD_ALLOWED` bit(1) NOT NULL DEFAULT b'0',
  `SOCIAL` bit(1) NOT NULL DEFAULT b'0',
  `SSL_REQUIRED` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SSO_IDLE_TIMEOUT` int DEFAULT NULL,
  `SSO_MAX_LIFESPAN` int DEFAULT NULL,
  `UPDATE_PROFILE_ON_SOC_LOGIN` bit(1) NOT NULL DEFAULT b'0',
  `VERIFY_EMAIL` bit(1) NOT NULL DEFAULT b'0',
  `MASTER_ADMIN_CLIENT` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `LOGIN_LIFESPAN` int DEFAULT NULL,
  `INTERNATIONALIZATION_ENABLED` bit(1) NOT NULL DEFAULT b'0',
  `DEFAULT_LOCALE` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REG_EMAIL_AS_USERNAME` bit(1) NOT NULL DEFAULT b'0',
  `ADMIN_EVENTS_ENABLED` bit(1) NOT NULL DEFAULT b'0',
  `ADMIN_EVENTS_DETAILS_ENABLED` bit(1) NOT NULL DEFAULT b'0',
  `EDIT_USERNAME_ALLOWED` bit(1) NOT NULL DEFAULT b'0',
  `OTP_POLICY_COUNTER` int DEFAULT '0',
  `OTP_POLICY_WINDOW` int DEFAULT '1',
  `OTP_POLICY_PERIOD` int DEFAULT '30',
  `OTP_POLICY_DIGITS` int DEFAULT '6',
  `OTP_POLICY_ALG` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'HmacSHA1',
  `OTP_POLICY_TYPE` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'totp',
  `BROWSER_FLOW` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REGISTRATION_FLOW` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DIRECT_GRANT_FLOW` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `RESET_CREDENTIALS_FLOW` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CLIENT_AUTH_FLOW` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `OFFLINE_SESSION_IDLE_TIMEOUT` int DEFAULT '0',
  `REVOKE_REFRESH_TOKEN` bit(1) NOT NULL DEFAULT b'0',
  `ACCESS_TOKEN_LIFE_IMPLICIT` int DEFAULT '0',
  `LOGIN_WITH_EMAIL_ALLOWED` bit(1) NOT NULL DEFAULT b'1',
  `DUPLICATE_EMAILS_ALLOWED` bit(1) NOT NULL DEFAULT b'0',
  `DOCKER_AUTH_FLOW` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REFRESH_TOKEN_MAX_REUSE` int DEFAULT '0',
  `ALLOW_USER_MANAGED_ACCESS` bit(1) NOT NULL DEFAULT b'0',
  `SSO_MAX_LIFESPAN_REMEMBER_ME` int NOT NULL,
  `SSO_IDLE_TIMEOUT_REMEMBER_ME` int NOT NULL,
  `DEFAULT_ROLE` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_ORVSDMLA56612EAEFIQ6WL5OI` (`NAME`),
  KEY `IDX_REALM_MASTER_ADM_CLI` (`MASTER_ADMIN_CLIENT`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REALM`
--

LOCK TABLES `REALM` WRITE;
/*!40000 ALTER TABLE `REALM` DISABLE KEYS */;
INSERT INTO `REALM` VALUES ('hi',60,300,3600,NULL,NULL,NULL,_binary '',_binary '\0',0,'hi','hi',1608625292,'specialChars(1) and upperCase(1) and lowerCase(1) and length(8) and digits(1)',_binary '\0',_binary '\0',_binary '',_binary '\0','EXTERNAL',1800,36000,_binary '\0',_binary '\0','2410b91c-be58-4f3c-a4ae-83cd998c8f6c',1800,_binary '','en',_binary '\0',_binary '\0',_binary '\0',_binary '\0',0,1,30,6,'HmacSHA1','totp','34b5d5d8-d3ef-4e9b-a253-df8b4115a21a','22a7a6b6-61a2-4ef0-944d-0e00c5ce4c21','9ec99d3d-749a-454b-bac4-423b2a7d105f','8384ed04-ad56-46db-a2d5-1975c859d74e','ca153fff-2c91-4dcd-9ffc-88d44bc1973f',2592000,_binary '\0',900,_binary '',_binary '\0','e5a56b25-198b-4b22-8ef5-1b0e26727f69',0,_binary '\0',0,0,'059bac13-47e5-4328-87b6-91d719adb748'),('hi-library',60,300,300,NULL,NULL,'keycloak',_binary '',_binary '\0',0,'open-library','hi-library',0,NULL,_binary '\0',_binary '\0',_binary '',_binary '\0','EXTERNAL',1800,36000,_binary '\0',_binary '\0','cea71342-d5fb-4873-b97d-21ac890e6c72',1800,_binary '\0',NULL,_binary '\0',_binary '\0',_binary '\0',_binary '\0',0,1,30,6,'HmacSHA1','totp','e6130d4d-117d-4a54-b478-ec24dfbc929a','718d46e1-350c-4c81-ad21-9164565e4128','3ea3ddb8-d400-4492-9336-af24f413ea93','7458dff4-fe52-4c2e-9ef5-4f7e10e9784b','5bcee621-2824-45ef-83b0-33ce018959d4',2592000,_binary '\0',900,_binary '',_binary '\0','1cce3557-13cf-4bb4-a39d-0548fdf71394',0,_binary '\0',0,0,'e71ff6bd-cc83-4652-a644-5d3308854fdd'),('hi-therapist',60,300,1800,NULL,NULL,'keycloak',_binary '',_binary '\0',0,'hi','hi-therapist',1619517373,'specialChars(1) and upperCase(1) and lowerCase(1) and length(8) and digits(1)',_binary '\0',_binary '\0',_binary '',_binary '\0','EXTERNAL',1800,36000,_binary '\0',_binary '\0','e7c18adf-18b9-48fc-92a0-698f43736bcd',1800,_binary '','en',_binary '\0',_binary '\0',_binary '\0',_binary '\0',0,1,30,6,'HmacSHA1','totp','e9a9c744-015c-437b-b1c7-68677d4e9bda','ee6e3d97-68b0-4771-a840-ad02eb747500','84461f65-53f7-4dd0-b2fc-a22189b67668','ed3234cf-40bd-408b-a242-109a6009389c','90d64ec7-2b2a-4a6b-8127-27c35439bd01',2592000,_binary '\0',900,_binary '',_binary '\0','4ca37c19-ca79-40ab-b914-e458b06637f7',0,_binary '\0',0,0,'032f3007-2de0-4d68-a1f2-2bcb362c49e4'),('master',60,300,60,NULL,NULL,NULL,_binary '',_binary '\0',0,NULL,'master',0,NULL,_binary '\0',_binary '\0',_binary '\0',_binary '\0','EXTERNAL',1800,36000,_binary '\0',_binary '\0','59b01532-686c-41a7-a818-8cd64adb99f5',1800,_binary '\0',NULL,_binary '\0',_binary '\0',_binary '\0',_binary '\0',0,1,30,6,'HmacSHA1','totp','ee278adf-b54d-43a7-9f7b-6d371cb01118','4029cddf-3047-4fce-b502-9e705e02b175','7413e1f5-671c-4f99-a8ec-9a3df8f83b1b','876af1ff-ec2a-4357-ad20-b097e1a30b66','762d0690-3bea-4566-8e75-9e97d6b30cbf',2592000,_binary '\0',900,_binary '',_binary '\0','4e530eef-6f34-4750-8712-8460b81579f5',0,_binary '\0',0,0,'77ed6c0f-1fa1-4634-8e79-4d65333ca865');
/*!40000 ALTER TABLE `REALM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REALM_ATTRIBUTE`
--

DROP TABLE IF EXISTS `REALM_ATTRIBUTE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REALM_ATTRIBUTE` (
  `NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `REALM_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  PRIMARY KEY (`NAME`,`REALM_ID`),
  KEY `IDX_REALM_ATTR_REALM` (`REALM_ID`),
  CONSTRAINT `FK_8SHXD6L3E9ATQUKACXGPFFPTW` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REALM_ATTRIBUTE`
--

LOCK TABLES `REALM_ATTRIBUTE` WRITE;
/*!40000 ALTER TABLE `REALM_ATTRIBUTE` DISABLE KEYS */;
INSERT INTO `REALM_ATTRIBUTE` VALUES ('_browser_header.contentSecurityPolicy','hi','frame-src \'self\'; frame-ancestors \'self\'; object-src \'none\';'),('_browser_header.contentSecurityPolicy','hi-library','frame-src \'self\'; frame-ancestors \'self\'; object-src \'none\';'),('_browser_header.contentSecurityPolicy','hi-therapist','frame-src \'self\'; frame-ancestors \'self\'; object-src \'none\';'),('_browser_header.contentSecurityPolicy','master','frame-src \'self\'; frame-ancestors \'self\'; object-src \'none\';'),('_browser_header.contentSecurityPolicyReportOnly','hi',''),('_browser_header.contentSecurityPolicyReportOnly','hi-library',''),('_browser_header.contentSecurityPolicyReportOnly','hi-therapist',''),('_browser_header.contentSecurityPolicyReportOnly','master',''),('_browser_header.strictTransportSecurity','hi','max-age=31536000; includeSubDomains'),('_browser_header.strictTransportSecurity','hi-library','max-age=31536000; includeSubDomains'),('_browser_header.strictTransportSecurity','hi-therapist','max-age=31536000; includeSubDomains'),('_browser_header.strictTransportSecurity','master','max-age=31536000; includeSubDomains'),('_browser_header.xContentTypeOptions','hi','nosniff'),('_browser_header.xContentTypeOptions','hi-library','nosniff'),('_browser_header.xContentTypeOptions','hi-therapist','nosniff'),('_browser_header.xContentTypeOptions','master','nosniff'),('_browser_header.xFrameOptions','hi','SAMEORIGIN'),('_browser_header.xFrameOptions','hi-library','SAMEORIGIN'),('_browser_header.xFrameOptions','hi-therapist','SAMEORIGIN'),('_browser_header.xFrameOptions','master','SAMEORIGIN'),('_browser_header.xRobotsTag','hi','none'),('_browser_header.xRobotsTag','hi-library','none'),('_browser_header.xRobotsTag','hi-therapist','none'),('_browser_header.xRobotsTag','master','none'),('_browser_header.xXSSProtection','hi','1; mode=block'),('_browser_header.xXSSProtection','hi-library','1; mode=block'),('_browser_header.xXSSProtection','hi-therapist','1; mode=block'),('_browser_header.xXSSProtection','master','1; mode=block'),('acr.loa.map','hi','{}'),('acr.loa.map','hi-library','{}'),('acr.loa.map','hi-therapist','{}'),('actionTokenGeneratedByAdminLifespan','hi','172800'),('actionTokenGeneratedByAdminLifespan','hi-library','43200'),('actionTokenGeneratedByAdminLifespan','hi-therapist','172800'),('actionTokenGeneratedByAdminLifespan','master','43200'),('actionTokenGeneratedByUserLifespan','hi','300'),('actionTokenGeneratedByUserLifespan','hi-library','300'),('actionTokenGeneratedByUserLifespan','hi-therapist','300'),('actionTokenGeneratedByUserLifespan','master','300'),('bruteForceProtected','hi','false'),('bruteForceProtected','hi-library','false'),('bruteForceProtected','hi-therapist','false'),('bruteForceProtected','master','false'),('cibaAuthRequestedUserHint','hi','login_hint'),('cibaAuthRequestedUserHint','hi-library','login_hint'),('cibaAuthRequestedUserHint','hi-therapist','login_hint'),('cibaBackchannelTokenDeliveryMode','hi','poll'),('cibaBackchannelTokenDeliveryMode','hi-library','poll'),('cibaBackchannelTokenDeliveryMode','hi-therapist','poll'),('cibaExpiresIn','hi','120'),('cibaExpiresIn','hi-library','120'),('cibaExpiresIn','hi-therapist','120'),('cibaInterval','hi','5'),('cibaInterval','hi-library','5'),('cibaInterval','hi-therapist','5'),('client-policies.policies','hi','{\"policies\":[]}'),('client-policies.policies','hi-library','{\"policies\":[]}'),('client-policies.policies','hi-therapist','{\"policies\":[]}'),('client-policies.policies','master','{\"policies\":[]}'),('client-policies.profiles','hi','{\"profiles\":[]}'),('client-policies.profiles','hi-library','{\"profiles\":[]}'),('client-policies.profiles','hi-therapist','{\"profiles\":[]}'),('client-policies.profiles','master','{\"profiles\":[]}'),('clientOfflineSessionIdleTimeout','hi','0'),('clientOfflineSessionIdleTimeout','hi-library','0'),('clientOfflineSessionIdleTimeout','hi-therapist','0'),('clientOfflineSessionIdleTimeout','master','0'),('clientOfflineSessionMaxLifespan','hi','0'),('clientOfflineSessionMaxLifespan','hi-library','0'),('clientOfflineSessionMaxLifespan','hi-therapist','0'),('clientOfflineSessionMaxLifespan','master','0'),('clientSessionIdleTimeout','hi','0'),('clientSessionIdleTimeout','hi-library','0'),('clientSessionIdleTimeout','hi-therapist','0'),('clientSessionIdleTimeout','master','0'),('clientSessionMaxLifespan','hi','0'),('clientSessionMaxLifespan','hi-library','0'),('clientSessionMaxLifespan','hi-therapist','0'),('clientSessionMaxLifespan','master','0'),('displayName','hi',''),('displayName','hi-library',''),('displayName','hi-therapist',''),('displayName','master','Keycloak'),('displayNameHtml','hi',''),('displayNameHtml','hi-library',''),('displayNameHtml','hi-therapist',''),('displayNameHtml','master','<div class=\"kc-logo-text\"><span>Keycloak</span></div>'),('failureFactor','hi','30'),('failureFactor','hi-library','30'),('failureFactor','hi-therapist','30'),('failureFactor','master','30'),('firstBrokerLoginFlowId','hi','c72ed562-95ad-48fe-98ef-b1110fea119c'),('firstBrokerLoginFlowId','hi-library','a2b67129-6c56-46ed-bca6-55279c9d9de0'),('firstBrokerLoginFlowId','hi-therapist','1d21a5a6-c602-41c1-8a61-c21360530fc6'),('firstBrokerLoginFlowId','master','6a73c2d6-c611-4bf4-a014-3d9b1b1b31e6'),('frontendUrl','hi','https://local-hi-admin.wehost.asia/auth/'),('frontendUrl','hi-library','https://local-hi-library.wehost.asia/auth/'),('frontendUrl','hi-therapist','https://local-hi-therapist.wehost.asia/auth/'),('maxDeltaTimeSeconds','hi','43200'),('maxDeltaTimeSeconds','hi-library','43200'),('maxDeltaTimeSeconds','hi-therapist','43200'),('maxDeltaTimeSeconds','master','43200'),('maxFailureWaitSeconds','hi','900'),('maxFailureWaitSeconds','hi-library','900'),('maxFailureWaitSeconds','hi-therapist','900'),('maxFailureWaitSeconds','master','900'),('maxTemporaryLockouts','hi','0'),('maxTemporaryLockouts','hi-library','0'),('maxTemporaryLockouts','hi-therapist','0'),('minimumQuickLoginWaitSeconds','hi','60'),('minimumQuickLoginWaitSeconds','hi-library','60'),('minimumQuickLoginWaitSeconds','hi-therapist','60'),('minimumQuickLoginWaitSeconds','master','60'),('oauth2DeviceCodeLifespan','hi','600'),('oauth2DeviceCodeLifespan','hi-library','600'),('oauth2DeviceCodeLifespan','hi-therapist','600'),('oauth2DevicePollingInterval','hi','5'),('oauth2DevicePollingInterval','hi-library','5'),('oauth2DevicePollingInterval','hi-therapist','5'),('offlineSessionMaxLifespan','hi','5184000'),('offlineSessionMaxLifespan','hi-library','5184000'),('offlineSessionMaxLifespan','hi-therapist','5184000'),('offlineSessionMaxLifespan','master','5184000'),('offlineSessionMaxLifespanEnabled','hi','false'),('offlineSessionMaxLifespanEnabled','hi-library','false'),('offlineSessionMaxLifespanEnabled','hi-therapist','false'),('offlineSessionMaxLifespanEnabled','master','false'),('organizationsEnabled','hi','false'),('organizationsEnabled','hi-library','false'),('organizationsEnabled','hi-therapist','false'),('parRequestUriLifespan','hi','60'),('parRequestUriLifespan','hi-library','60'),('parRequestUriLifespan','hi-therapist','60'),('permanentLockout','hi','false'),('permanentLockout','hi-library','false'),('permanentLockout','hi-therapist','false'),('permanentLockout','master','false'),('quickLoginCheckMilliSeconds','hi','1000'),('quickLoginCheckMilliSeconds','hi-library','1000'),('quickLoginCheckMilliSeconds','hi-therapist','1000'),('quickLoginCheckMilliSeconds','master','1000'),('realmReusableOtpCode','hi','false'),('realmReusableOtpCode','hi-library','false'),('realmReusableOtpCode','hi-therapist','false'),('waitIncrementSeconds','hi','60'),('waitIncrementSeconds','hi-library','60'),('waitIncrementSeconds','hi-therapist','60'),('waitIncrementSeconds','master','60'),('webAuthnPolicyAttestationConveyancePreference','hi','not specified'),('webAuthnPolicyAttestationConveyancePreference','hi-library','not specified'),('webAuthnPolicyAttestationConveyancePreference','hi-therapist','not specified'),('webAuthnPolicyAttestationConveyancePreference','master','not specified'),('webAuthnPolicyAttestationConveyancePreferencePasswordless','hi','not specified'),('webAuthnPolicyAttestationConveyancePreferencePasswordless','hi-library','not specified'),('webAuthnPolicyAttestationConveyancePreferencePasswordless','hi-therapist','not specified'),('webAuthnPolicyAttestationConveyancePreferencePasswordless','master','not specified'),('webAuthnPolicyAuthenticatorAttachment','hi','not specified'),('webAuthnPolicyAuthenticatorAttachment','hi-library','not specified'),('webAuthnPolicyAuthenticatorAttachment','hi-therapist','not specified'),('webAuthnPolicyAuthenticatorAttachment','master','not specified'),('webAuthnPolicyAuthenticatorAttachmentPasswordless','hi','not specified'),('webAuthnPolicyAuthenticatorAttachmentPasswordless','hi-library','not specified'),('webAuthnPolicyAuthenticatorAttachmentPasswordless','hi-therapist','not specified'),('webAuthnPolicyAuthenticatorAttachmentPasswordless','master','not specified'),('webAuthnPolicyAvoidSameAuthenticatorRegister','hi','false'),('webAuthnPolicyAvoidSameAuthenticatorRegister','hi-library','false'),('webAuthnPolicyAvoidSameAuthenticatorRegister','hi-therapist','false'),('webAuthnPolicyAvoidSameAuthenticatorRegister','master','false'),('webAuthnPolicyAvoidSameAuthenticatorRegisterPasswordless','hi','false'),('webAuthnPolicyAvoidSameAuthenticatorRegisterPasswordless','hi-library','false'),('webAuthnPolicyAvoidSameAuthenticatorRegisterPasswordless','hi-therapist','false'),('webAuthnPolicyAvoidSameAuthenticatorRegisterPasswordless','master','false'),('webAuthnPolicyCreateTimeout','hi','0'),('webAuthnPolicyCreateTimeout','hi-library','0'),('webAuthnPolicyCreateTimeout','hi-therapist','0'),('webAuthnPolicyCreateTimeout','master','0'),('webAuthnPolicyCreateTimeoutPasswordless','hi','0'),('webAuthnPolicyCreateTimeoutPasswordless','hi-library','0'),('webAuthnPolicyCreateTimeoutPasswordless','hi-therapist','0'),('webAuthnPolicyCreateTimeoutPasswordless','master','0'),('webAuthnPolicyRequireResidentKey','hi','not specified'),('webAuthnPolicyRequireResidentKey','hi-library','not specified'),('webAuthnPolicyRequireResidentKey','hi-therapist','not specified'),('webAuthnPolicyRequireResidentKey','master','not specified'),('webAuthnPolicyRequireResidentKeyPasswordless','hi','not specified'),('webAuthnPolicyRequireResidentKeyPasswordless','hi-library','not specified'),('webAuthnPolicyRequireResidentKeyPasswordless','hi-therapist','not specified'),('webAuthnPolicyRequireResidentKeyPasswordless','master','not specified'),('webAuthnPolicyRpEntityName','hi','keycloak'),('webAuthnPolicyRpEntityName','hi-library','keycloak'),('webAuthnPolicyRpEntityName','hi-therapist','keycloak'),('webAuthnPolicyRpEntityName','master','keycloak'),('webAuthnPolicyRpEntityNamePasswordless','hi','keycloak'),('webAuthnPolicyRpEntityNamePasswordless','hi-library','keycloak'),('webAuthnPolicyRpEntityNamePasswordless','hi-therapist','keycloak'),('webAuthnPolicyRpEntityNamePasswordless','master','keycloak'),('webAuthnPolicyRpId','hi',''),('webAuthnPolicyRpId','hi-library',''),('webAuthnPolicyRpId','hi-therapist',''),('webAuthnPolicyRpId','master',''),('webAuthnPolicyRpIdPasswordless','hi',''),('webAuthnPolicyRpIdPasswordless','hi-library',''),('webAuthnPolicyRpIdPasswordless','hi-therapist',''),('webAuthnPolicyRpIdPasswordless','master',''),('webAuthnPolicySignatureAlgorithms','hi','ES256'),('webAuthnPolicySignatureAlgorithms','hi-library','ES256'),('webAuthnPolicySignatureAlgorithms','hi-therapist','ES256'),('webAuthnPolicySignatureAlgorithms','master','ES256'),('webAuthnPolicySignatureAlgorithmsPasswordless','hi','ES256'),('webAuthnPolicySignatureAlgorithmsPasswordless','hi-library','ES256'),('webAuthnPolicySignatureAlgorithmsPasswordless','hi-therapist','ES256'),('webAuthnPolicySignatureAlgorithmsPasswordless','master','ES256'),('webAuthnPolicyUserVerificationRequirement','hi','not specified'),('webAuthnPolicyUserVerificationRequirement','hi-library','not specified'),('webAuthnPolicyUserVerificationRequirement','hi-therapist','not specified'),('webAuthnPolicyUserVerificationRequirement','master','not specified'),('webAuthnPolicyUserVerificationRequirementPasswordless','hi','not specified'),('webAuthnPolicyUserVerificationRequirementPasswordless','hi-library','not specified'),('webAuthnPolicyUserVerificationRequirementPasswordless','hi-therapist','not specified'),('webAuthnPolicyUserVerificationRequirementPasswordless','master','not specified');
/*!40000 ALTER TABLE `REALM_ATTRIBUTE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REALM_DEFAULT_GROUPS`
--

DROP TABLE IF EXISTS `REALM_DEFAULT_GROUPS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REALM_DEFAULT_GROUPS` (
  `REALM_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `GROUP_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`REALM_ID`,`GROUP_ID`),
  UNIQUE KEY `CON_GROUP_ID_DEF_GROUPS` (`GROUP_ID`),
  KEY `IDX_REALM_DEF_GRP_REALM` (`REALM_ID`),
  CONSTRAINT `FK_DEF_GROUPS_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REALM_DEFAULT_GROUPS`
--

LOCK TABLES `REALM_DEFAULT_GROUPS` WRITE;
/*!40000 ALTER TABLE `REALM_DEFAULT_GROUPS` DISABLE KEYS */;
/*!40000 ALTER TABLE `REALM_DEFAULT_GROUPS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REALM_ENABLED_EVENT_TYPES`
--

DROP TABLE IF EXISTS `REALM_ENABLED_EVENT_TYPES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REALM_ENABLED_EVENT_TYPES` (
  `REALM_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`REALM_ID`,`VALUE`),
  KEY `IDX_REALM_EVT_TYPES_REALM` (`REALM_ID`),
  CONSTRAINT `FK_H846O4H0W8EPX5NWEDRF5Y69J` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REALM_ENABLED_EVENT_TYPES`
--

LOCK TABLES `REALM_ENABLED_EVENT_TYPES` WRITE;
/*!40000 ALTER TABLE `REALM_ENABLED_EVENT_TYPES` DISABLE KEYS */;
/*!40000 ALTER TABLE `REALM_ENABLED_EVENT_TYPES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REALM_EVENTS_LISTENERS`
--

DROP TABLE IF EXISTS `REALM_EVENTS_LISTENERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REALM_EVENTS_LISTENERS` (
  `REALM_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`REALM_ID`,`VALUE`),
  KEY `IDX_REALM_EVT_LIST_REALM` (`REALM_ID`),
  CONSTRAINT `FK_H846O4H0W8EPX5NXEV9F5Y69J` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REALM_EVENTS_LISTENERS`
--

LOCK TABLES `REALM_EVENTS_LISTENERS` WRITE;
/*!40000 ALTER TABLE `REALM_EVENTS_LISTENERS` DISABLE KEYS */;
INSERT INTO `REALM_EVENTS_LISTENERS` VALUES ('hi','jboss-logging'),('hi-library','jboss-logging'),('hi-therapist','jboss-logging'),('master','jboss-logging');
/*!40000 ALTER TABLE `REALM_EVENTS_LISTENERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REALM_LOCALIZATIONS`
--

DROP TABLE IF EXISTS `REALM_LOCALIZATIONS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REALM_LOCALIZATIONS` (
  `REALM_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `LOCALE` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `TEXTS` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  PRIMARY KEY (`REALM_ID`,`LOCALE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REALM_LOCALIZATIONS`
--

LOCK TABLES `REALM_LOCALIZATIONS` WRITE;
/*!40000 ALTER TABLE `REALM_LOCALIZATIONS` DISABLE KEYS */;
/*!40000 ALTER TABLE `REALM_LOCALIZATIONS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REALM_REQUIRED_CREDENTIAL`
--

DROP TABLE IF EXISTS `REALM_REQUIRED_CREDENTIAL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REALM_REQUIRED_CREDENTIAL` (
  `TYPE` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `FORM_LABEL` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `INPUT` bit(1) NOT NULL DEFAULT b'0',
  `SECRET` bit(1) NOT NULL DEFAULT b'0',
  `REALM_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`REALM_ID`,`TYPE`),
  CONSTRAINT `FK_5HG65LYBEVAVKQFKI3KPONH9V` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REALM_REQUIRED_CREDENTIAL`
--

LOCK TABLES `REALM_REQUIRED_CREDENTIAL` WRITE;
/*!40000 ALTER TABLE `REALM_REQUIRED_CREDENTIAL` DISABLE KEYS */;
INSERT INTO `REALM_REQUIRED_CREDENTIAL` VALUES ('password','password',_binary '',_binary '','hi'),('password','password',_binary '',_binary '','hi-library'),('password','password',_binary '',_binary '','hi-therapist'),('password','password',_binary '',_binary '','master');
/*!40000 ALTER TABLE `REALM_REQUIRED_CREDENTIAL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REALM_SMTP_CONFIG`
--

DROP TABLE IF EXISTS `REALM_SMTP_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REALM_SMTP_CONFIG` (
  `REALM_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`REALM_ID`,`NAME`),
  CONSTRAINT `FK_70EJ8XDXGXD0B9HH6180IRR0O` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REALM_SMTP_CONFIG`
--

LOCK TABLES `REALM_SMTP_CONFIG` WRITE;
/*!40000 ALTER TABLE `REALM_SMTP_CONFIG` DISABLE KEYS */;
INSERT INTO `REALM_SMTP_CONFIG` VALUES ('hi','true','auth'),('hi','noreply@web-essentials.asia','from'),('hi','10.10.10.37','host'),('hi','aeudthyqepcfndex','password'),('hi','1025','port'),('hi','','replyTo'),('hi','false','ssl'),('hi','true','starttls'),('hi','noreply@web-essentials.asia','user'),('hi-library','true','auth'),('hi-library','noreply@opentelerehab.com','from'),('hi-library','email-smtp.us-east-1.amazonaws.com','host'),('hi-library','BB2s0ie8mv2EhLEnApyZEmL4YpbqC2KQeSWQFqbKEzEJ','password'),('hi-library','587','port'),('hi-library','false','ssl'),('hi-library','true','starttls'),('hi-library','AKIA2T6OTQKX64H4UR76','user'),('hi-therapist','false','auth'),('hi-therapist','noreply@web-essentials.asia','from'),('hi-therapist','10.10.10.37','host'),('hi-therapist','aeudthyqepcfndex','password'),('hi-therapist','1025','port'),('hi-therapist','','ssl'),('hi-therapist','false','starttls'),('hi-therapist','noreply@web-essentials.asia','user'),('master','true','auth'),('master','noreply@web-essentials.asia','from'),('master','smtp.gmail.com','host'),('master','aeudthyqepcfndex','password'),('master','587','port'),('master','','ssl'),('master','true','starttls'),('master','noreply@web-essentials.asia','user');
/*!40000 ALTER TABLE `REALM_SMTP_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REALM_SUPPORTED_LOCALES`
--

DROP TABLE IF EXISTS `REALM_SUPPORTED_LOCALES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REALM_SUPPORTED_LOCALES` (
  `REALM_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`REALM_ID`,`VALUE`),
  KEY `IDX_REALM_SUPP_LOCAL_REALM` (`REALM_ID`),
  CONSTRAINT `FK_SUPPORTED_LOCALES_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REALM_SUPPORTED_LOCALES`
--

LOCK TABLES `REALM_SUPPORTED_LOCALES` WRITE;
/*!40000 ALTER TABLE `REALM_SUPPORTED_LOCALES` DISABLE KEYS */;
INSERT INTO `REALM_SUPPORTED_LOCALES` VALUES ('hi','ar'),('hi','ca'),('hi','cs'),('hi','de'),('hi','en'),('hi','es'),('hi','fr'),('hi','it'),('hi','ja'),('hi','lt'),('hi','nl'),('hi','no'),('hi','pl'),('hi','pt-BR'),('hi','ru'),('hi','sk'),('hi','sv'),('hi','tr'),('hi','vi'),('hi','zh-CN'),('hi-library',''),('hi-therapist','ar'),('hi-therapist','ca'),('hi-therapist','cs'),('hi-therapist','de'),('hi-therapist','en'),('hi-therapist','es'),('hi-therapist','fr'),('hi-therapist','it'),('hi-therapist','ja'),('hi-therapist','lt'),('hi-therapist','nl'),('hi-therapist','no'),('hi-therapist','pl'),('hi-therapist','pt-BR'),('hi-therapist','ru'),('hi-therapist','sk'),('hi-therapist','sv'),('hi-therapist','tr'),('hi-therapist','vi'),('hi-therapist','zh-CN');
/*!40000 ALTER TABLE `REALM_SUPPORTED_LOCALES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REDIRECT_URIS`
--

DROP TABLE IF EXISTS `REDIRECT_URIS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REDIRECT_URIS` (
  `CLIENT_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`CLIENT_ID`,`VALUE`),
  KEY `IDX_REDIR_URI_CLIENT` (`CLIENT_ID`),
  CONSTRAINT `FK_1BURS8PB4OUJ97H5WUPPAHV9F` FOREIGN KEY (`CLIENT_ID`) REFERENCES `CLIENT` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REDIRECT_URIS`
--

LOCK TABLES `REDIRECT_URIS` WRITE;
/*!40000 ALTER TABLE `REDIRECT_URIS` DISABLE KEYS */;
INSERT INTO `REDIRECT_URIS` VALUES ('1472daaa-5420-4b1f-bfb2-f184f16a8320','/*'),('1d1424ea-24c6-4434-b5e5-8e96e26f3255','/realms/hi-library/account/*'),('30febc11-32fa-4349-a4db-a46a33775ab2','/*'),('558bc5ae-068f-4e0b-b70a-170b730aa137','/*'),('55c52d92-7f2e-40b2-8cef-35e558d2c72b',''),('55c52d92-7f2e-40b2-8cef-35e558d2c72b','/realms/hi/account/*'),('5ac1fbef-dc0d-437e-bdfb-6d0c0d467dc0','/admin/hi-library/console/*'),('620c09d1-5d44-4bda-959f-82ff964b0f98','/*'),('63f568e6-51bc-4bbe-9fb4-1dcf570d09a4','/realms/Hi/account/*'),('89d22c6b-7a3a-406a-8635-049ea85abb55','/realms/hi-therapist/account/*'),('a3a37b6f-21f9-49da-8561-1b850d20cba5','/realms/master/account/*'),('a70bea3e-e035-439e-a52a-b15206b54b29','/realms/master/account/*'),('af07419a-9fdd-48f8-bb86-98deababeb5d','/realms/Hi/account/*'),('cb884845-e614-4c6e-9508-6fd6ae87fd60','/admin/hi-therapist/console/*'),('d3bacc5c-ac4e-41ab-abb9-3d79878ddcdc','/admin/master/console/*'),('d84f18c2-b355-4a93-893b-a886e0b8fcf2','/admin/hi/console/*'),('da8a1c0e-1290-4e3d-988f-7ff967de07d8','/*'),('dd77b2d7-5ee9-4a5d-a25a-eb152157fb4c','/realms/hi-library/account/*'),('e233b1cf-3455-4e60-9488-ec12dfa884d2','/*');
/*!40000 ALTER TABLE `REDIRECT_URIS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REQUIRED_ACTION_CONFIG`
--

DROP TABLE IF EXISTS `REQUIRED_ACTION_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REQUIRED_ACTION_CONFIG` (
  `REQUIRED_ACTION_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`REQUIRED_ACTION_ID`,`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REQUIRED_ACTION_CONFIG`
--

LOCK TABLES `REQUIRED_ACTION_CONFIG` WRITE;
/*!40000 ALTER TABLE `REQUIRED_ACTION_CONFIG` DISABLE KEYS */;
/*!40000 ALTER TABLE `REQUIRED_ACTION_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REQUIRED_ACTION_PROVIDER`
--

DROP TABLE IF EXISTS `REQUIRED_ACTION_PROVIDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REQUIRED_ACTION_PROVIDER` (
  `ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ALIAS` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REALM_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ENABLED` bit(1) NOT NULL DEFAULT b'0',
  `DEFAULT_ACTION` bit(1) NOT NULL DEFAULT b'0',
  `PROVIDER_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PRIORITY` int DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IDX_REQ_ACT_PROV_REALM` (`REALM_ID`),
  CONSTRAINT `FK_REQ_ACT_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REQUIRED_ACTION_PROVIDER`
--

LOCK TABLES `REQUIRED_ACTION_PROVIDER` WRITE;
/*!40000 ALTER TABLE `REQUIRED_ACTION_PROVIDER` DISABLE KEYS */;
INSERT INTO `REQUIRED_ACTION_PROVIDER` VALUES ('016c2bf4-eac2-46ef-a3c3-ef653d467294','TERMS_AND_CONDITIONS','Terms and Conditions','master',_binary '\0',_binary '\0','TERMS_AND_CONDITIONS',20),('086c9301-7137-4fca-b080-2e473c9e24d6','delete_credential','Delete Credential','hi-therapist',_binary '',_binary '\0','delete_credential',100),('19c959e5-986b-4669-a1e0-6f86a0a8c23c','delete_account','Delete Account','hi',_binary '\0',_binary '\0','delete_account',60),('1db9aea1-13ef-499c-92d2-b133f106858d','UPDATE_PROFILE','Update Profile','hi-library',_binary '',_binary '\0','UPDATE_PROFILE',40),('23661360-bbe6-4f35-bf79-d054db9586ad','UPDATE_PROFILE','Update Profile','hi-therapist',_binary '',_binary '\0','UPDATE_PROFILE',40),('2710ed35-7f7c-4446-91c6-2f02f7880cd2','VERIFY_EMAIL','Verify Email','hi',_binary '',_binary '\0','VERIFY_EMAIL',50),('287f30f3-e555-4307-8832-197f134c9fcc','VERIFY_EMAIL','Verify Email','master',_binary '',_binary '\0','VERIFY_EMAIL',50),('28cf349b-8ab7-455b-8126-7375ca4c2dc5','UPDATE_PASSWORD','Update Password','hi-therapist',_binary '',_binary '\0','UPDATE_PASSWORD',30),('2d299709-160a-4b77-9142-ea645025f189','update_user_locale','Update User Locale','master',_binary '',_binary '\0','update_user_locale',1000),('385b9b08-154a-4625-b050-c8318b9bff2c','UPDATE_PROFILE','Update Profile','master',_binary '',_binary '\0','UPDATE_PROFILE',40),('3d3427db-3be5-4027-bfb8-c8cb82ddff8e','delete_credential','Delete Credential','master',_binary '',_binary '\0','delete_credential',100),('46891415-98e1-4ad7-ac33-2556ead02669','CONFIGURE_TOTP','Configure OTP','master',_binary '',_binary '\0','CONFIGURE_TOTP',10),('49bbbe93-d5b9-4928-8507-a74d1b2db32b','CONFIGURE_TOTP','Configure OTP','hi',_binary '',_binary '\0','CONFIGURE_TOTP',10),('4a386ca8-cf16-4970-b566-38c4ed921b6e','UPDATE_PASSWORD','Update Password','hi-library',_binary '',_binary '\0','UPDATE_PASSWORD',30),('56338295-32af-4353-aa8c-73f9aecf7c48','update_user_locale','Update User Locale','hi',_binary '',_binary '\0','update_user_locale',1000),('5b663b53-f3f2-4210-b8cc-4ca5b220705c','CONFIGURE_TOTP','Configure OTP','hi-library',_binary '',_binary '\0','CONFIGURE_TOTP',10),('61519a1b-7a74-477d-a8b8-b5e97dfe5574','update_user_locale','Update User Locale','hi-library',_binary '',_binary '\0','update_user_locale',1000),('6227edcd-058f-4da3-a36d-101e83aa270c','TERMS_AND_CONDITIONS','Terms and Conditions','hi-library',_binary '\0',_binary '\0','TERMS_AND_CONDITIONS',20),('6598f1bf-e5e1-4713-b4ba-293168b03dc6','UPDATE_PASSWORD','Update Password','master',_binary '',_binary '\0','UPDATE_PASSWORD',30),('670f35d4-6349-4109-a768-148e9ea41c50','delete_credential','Delete Credential','hi',_binary '',_binary '\0','delete_credential',100),('6c0d98c7-e8c6-4083-8deb-89934b92209f','delete_account','Delete Account','master',_binary '\0',_binary '\0','delete_account',60),('7ba0d5d0-2cd2-4ae1-98a8-0f7e4fe4d9d2','CONFIGURE_TOTP','Configure OTP','hi-therapist',_binary '',_binary '\0','CONFIGURE_TOTP',10),('8a79f45b-7781-4f63-addb-08f10eb1cc01','VERIFY_EMAIL','Verify Email','hi-therapist',_binary '',_binary '\0','VERIFY_EMAIL',50),('8fb6ddb3-3daa-4ef8-bb57-df2b61fb49a1','UPDATE_PROFILE','Update Profile','hi',_binary '',_binary '\0','UPDATE_PROFILE',40),('a0401677-6fe5-485c-8dbe-b76d2f2dfe37','delete_account','Delete Account','hi-therapist',_binary '\0',_binary '\0','delete_account',60),('af2a02d1-baec-47cf-94f2-1c9a70a46ed0','UPDATE_PASSWORD','Update Password','hi',_binary '',_binary '\0','UPDATE_PASSWORD',30),('b4eaad31-af61-42ca-946d-d01a0fb4d7eb','TERMS_AND_CONDITIONS','Terms and Conditions','hi-therapist',_binary '',_binary '','TERMS_AND_CONDITIONS',20),('bbd37eca-6464-4deb-abcc-6be0190bd291','TERMS_AND_CONDITIONS','Terms and Conditions','hi',_binary '',_binary '','TERMS_AND_CONDITIONS',20),('ccf1fc33-9af8-406e-9f06-98a1ddb36ecb','VERIFY_EMAIL','Verify Email','hi-library',_binary '',_binary '\0','VERIFY_EMAIL',50),('e1acb59e-5df3-4427-8c5c-491f0ac21dca','update_user_locale','Update User Locale','hi-therapist',_binary '',_binary '\0','update_user_locale',1000),('ecf466f8-a59e-4775-a682-ab461dc2e1c3','delete_account','Delete Account','hi-library',_binary '\0',_binary '\0','delete_account',60),('fc8bb445-3f6d-4f17-8e6a-2f3b378e5e69','delete_credential','Delete Credential','hi-library',_binary '',_binary '\0','delete_credential',100);
/*!40000 ALTER TABLE `REQUIRED_ACTION_PROVIDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RESOURCE_ATTRIBUTE`
--

DROP TABLE IF EXISTS `RESOURCE_ATTRIBUTE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RESOURCE_ATTRIBUTE` (
  `ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'sybase-needs-something-here',
  `NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `RESOURCE_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_5HRM2VLF9QL5FU022KQEPOVBR` (`RESOURCE_ID`),
  CONSTRAINT `FK_5HRM2VLF9QL5FU022KQEPOVBR` FOREIGN KEY (`RESOURCE_ID`) REFERENCES `RESOURCE_SERVER_RESOURCE` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RESOURCE_ATTRIBUTE`
--

LOCK TABLES `RESOURCE_ATTRIBUTE` WRITE;
/*!40000 ALTER TABLE `RESOURCE_ATTRIBUTE` DISABLE KEYS */;
/*!40000 ALTER TABLE `RESOURCE_ATTRIBUTE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RESOURCE_POLICY`
--

DROP TABLE IF EXISTS `RESOURCE_POLICY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RESOURCE_POLICY` (
  `RESOURCE_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `POLICY_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`RESOURCE_ID`,`POLICY_ID`),
  KEY `IDX_RES_POLICY_POLICY` (`POLICY_ID`),
  CONSTRAINT `FK_FRSRPOS53XCX4WNKOG82SSRFY` FOREIGN KEY (`RESOURCE_ID`) REFERENCES `RESOURCE_SERVER_RESOURCE` (`ID`),
  CONSTRAINT `FK_FRSRPP213XCX4WNKOG82SSRFY` FOREIGN KEY (`POLICY_ID`) REFERENCES `RESOURCE_SERVER_POLICY` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RESOURCE_POLICY`
--

LOCK TABLES `RESOURCE_POLICY` WRITE;
/*!40000 ALTER TABLE `RESOURCE_POLICY` DISABLE KEYS */;
/*!40000 ALTER TABLE `RESOURCE_POLICY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RESOURCE_SCOPE`
--

DROP TABLE IF EXISTS `RESOURCE_SCOPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RESOURCE_SCOPE` (
  `RESOURCE_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `SCOPE_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`RESOURCE_ID`,`SCOPE_ID`),
  KEY `IDX_RES_SCOPE_SCOPE` (`SCOPE_ID`),
  CONSTRAINT `FK_FRSRPOS13XCX4WNKOG82SSRFY` FOREIGN KEY (`RESOURCE_ID`) REFERENCES `RESOURCE_SERVER_RESOURCE` (`ID`),
  CONSTRAINT `FK_FRSRPS213XCX4WNKOG82SSRFY` FOREIGN KEY (`SCOPE_ID`) REFERENCES `RESOURCE_SERVER_SCOPE` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RESOURCE_SCOPE`
--

LOCK TABLES `RESOURCE_SCOPE` WRITE;
/*!40000 ALTER TABLE `RESOURCE_SCOPE` DISABLE KEYS */;
/*!40000 ALTER TABLE `RESOURCE_SCOPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RESOURCE_SERVER`
--

DROP TABLE IF EXISTS `RESOURCE_SERVER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RESOURCE_SERVER` (
  `ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ALLOW_RS_REMOTE_MGMT` bit(1) NOT NULL DEFAULT b'0',
  `POLICY_ENFORCE_MODE` tinyint DEFAULT NULL,
  `DECISION_STRATEGY` tinyint NOT NULL DEFAULT '1',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RESOURCE_SERVER`
--

LOCK TABLES `RESOURCE_SERVER` WRITE;
/*!40000 ALTER TABLE `RESOURCE_SERVER` DISABLE KEYS */;
/*!40000 ALTER TABLE `RESOURCE_SERVER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RESOURCE_SERVER_PERM_TICKET`
--

DROP TABLE IF EXISTS `RESOURCE_SERVER_PERM_TICKET`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RESOURCE_SERVER_PERM_TICKET` (
  `ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `OWNER` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REQUESTER` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CREATED_TIMESTAMP` bigint NOT NULL,
  `GRANTED_TIMESTAMP` bigint DEFAULT NULL,
  `RESOURCE_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `SCOPE_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `RESOURCE_SERVER_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `POLICY_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_FRSR6T700S9V50BU18WS5PMT` (`OWNER`,`REQUESTER`,`RESOURCE_SERVER_ID`,`RESOURCE_ID`,`SCOPE_ID`),
  KEY `FK_FRSRHO213XCX4WNKOG82SSPMT` (`RESOURCE_SERVER_ID`),
  KEY `FK_FRSRHO213XCX4WNKOG83SSPMT` (`RESOURCE_ID`),
  KEY `FK_FRSRHO213XCX4WNKOG84SSPMT` (`SCOPE_ID`),
  KEY `FK_FRSRPO2128CX4WNKOG82SSRFY` (`POLICY_ID`),
  KEY `IDX_PERM_TICKET_REQUESTER` (`REQUESTER`),
  KEY `IDX_PERM_TICKET_OWNER` (`OWNER`),
  CONSTRAINT `FK_FRSRHO213XCX4WNKOG82SSPMT` FOREIGN KEY (`RESOURCE_SERVER_ID`) REFERENCES `RESOURCE_SERVER` (`ID`),
  CONSTRAINT `FK_FRSRHO213XCX4WNKOG83SSPMT` FOREIGN KEY (`RESOURCE_ID`) REFERENCES `RESOURCE_SERVER_RESOURCE` (`ID`),
  CONSTRAINT `FK_FRSRHO213XCX4WNKOG84SSPMT` FOREIGN KEY (`SCOPE_ID`) REFERENCES `RESOURCE_SERVER_SCOPE` (`ID`),
  CONSTRAINT `FK_FRSRPO2128CX4WNKOG82SSRFY` FOREIGN KEY (`POLICY_ID`) REFERENCES `RESOURCE_SERVER_POLICY` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RESOURCE_SERVER_PERM_TICKET`
--

LOCK TABLES `RESOURCE_SERVER_PERM_TICKET` WRITE;
/*!40000 ALTER TABLE `RESOURCE_SERVER_PERM_TICKET` DISABLE KEYS */;
/*!40000 ALTER TABLE `RESOURCE_SERVER_PERM_TICKET` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RESOURCE_SERVER_POLICY`
--

DROP TABLE IF EXISTS `RESOURCE_SERVER_POLICY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RESOURCE_SERVER_POLICY` (
  `ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `DESCRIPTION` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `TYPE` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `DECISION_STRATEGY` tinyint DEFAULT NULL,
  `LOGIC` tinyint DEFAULT NULL,
  `RESOURCE_SERVER_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `OWNER` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_FRSRPT700S9V50BU18WS5HA6` (`NAME`,`RESOURCE_SERVER_ID`),
  KEY `IDX_RES_SERV_POL_RES_SERV` (`RESOURCE_SERVER_ID`),
  CONSTRAINT `FK_FRSRPO213XCX4WNKOG82SSRFY` FOREIGN KEY (`RESOURCE_SERVER_ID`) REFERENCES `RESOURCE_SERVER` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RESOURCE_SERVER_POLICY`
--

LOCK TABLES `RESOURCE_SERVER_POLICY` WRITE;
/*!40000 ALTER TABLE `RESOURCE_SERVER_POLICY` DISABLE KEYS */;
/*!40000 ALTER TABLE `RESOURCE_SERVER_POLICY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RESOURCE_SERVER_RESOURCE`
--

DROP TABLE IF EXISTS `RESOURCE_SERVER_RESOURCE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RESOURCE_SERVER_RESOURCE` (
  `ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `TYPE` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ICON_URI` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `OWNER` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `RESOURCE_SERVER_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `OWNER_MANAGED_ACCESS` bit(1) NOT NULL DEFAULT b'0',
  `DISPLAY_NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_FRSR6T700S9V50BU18WS5HA6` (`NAME`,`OWNER`,`RESOURCE_SERVER_ID`),
  KEY `IDX_RES_SRV_RES_RES_SRV` (`RESOURCE_SERVER_ID`),
  CONSTRAINT `FK_FRSRHO213XCX4WNKOG82SSRFY` FOREIGN KEY (`RESOURCE_SERVER_ID`) REFERENCES `RESOURCE_SERVER` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RESOURCE_SERVER_RESOURCE`
--

LOCK TABLES `RESOURCE_SERVER_RESOURCE` WRITE;
/*!40000 ALTER TABLE `RESOURCE_SERVER_RESOURCE` DISABLE KEYS */;
/*!40000 ALTER TABLE `RESOURCE_SERVER_RESOURCE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RESOURCE_SERVER_SCOPE`
--

DROP TABLE IF EXISTS `RESOURCE_SERVER_SCOPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RESOURCE_SERVER_SCOPE` (
  `ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ICON_URI` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `RESOURCE_SERVER_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DISPLAY_NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_FRSRST700S9V50BU18WS5HA6` (`NAME`,`RESOURCE_SERVER_ID`),
  KEY `IDX_RES_SRV_SCOPE_RES_SRV` (`RESOURCE_SERVER_ID`),
  CONSTRAINT `FK_FRSRSO213XCX4WNKOG82SSRFY` FOREIGN KEY (`RESOURCE_SERVER_ID`) REFERENCES `RESOURCE_SERVER` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RESOURCE_SERVER_SCOPE`
--

LOCK TABLES `RESOURCE_SERVER_SCOPE` WRITE;
/*!40000 ALTER TABLE `RESOURCE_SERVER_SCOPE` DISABLE KEYS */;
/*!40000 ALTER TABLE `RESOURCE_SERVER_SCOPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RESOURCE_URIS`
--

DROP TABLE IF EXISTS `RESOURCE_URIS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RESOURCE_URIS` (
  `RESOURCE_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`RESOURCE_ID`,`VALUE`),
  CONSTRAINT `FK_RESOURCE_SERVER_URIS` FOREIGN KEY (`RESOURCE_ID`) REFERENCES `RESOURCE_SERVER_RESOURCE` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RESOURCE_URIS`
--

LOCK TABLES `RESOURCE_URIS` WRITE;
/*!40000 ALTER TABLE `RESOURCE_URIS` DISABLE KEYS */;
/*!40000 ALTER TABLE `RESOURCE_URIS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ROLE_ATTRIBUTE`
--

DROP TABLE IF EXISTS `ROLE_ATTRIBUTE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ROLE_ATTRIBUTE` (
  `ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ROLE_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IDX_ROLE_ATTRIBUTE` (`ROLE_ID`),
  CONSTRAINT `FK_ROLE_ATTRIBUTE_ID` FOREIGN KEY (`ROLE_ID`) REFERENCES `KEYCLOAK_ROLE` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ROLE_ATTRIBUTE`
--

LOCK TABLES `ROLE_ATTRIBUTE` WRITE;
/*!40000 ALTER TABLE `ROLE_ATTRIBUTE` DISABLE KEYS */;
/*!40000 ALTER TABLE `ROLE_ATTRIBUTE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SCOPE_MAPPING`
--

DROP TABLE IF EXISTS `SCOPE_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SCOPE_MAPPING` (
  `CLIENT_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ROLE_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`CLIENT_ID`,`ROLE_ID`),
  KEY `IDX_SCOPE_MAPPING_ROLE` (`ROLE_ID`),
  CONSTRAINT `FK_OUSE064PLMLR732LXJCN1Q5F1` FOREIGN KEY (`CLIENT_ID`) REFERENCES `CLIENT` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SCOPE_MAPPING`
--

LOCK TABLES `SCOPE_MAPPING` WRITE;
/*!40000 ALTER TABLE `SCOPE_MAPPING` DISABLE KEYS */;
INSERT INTO `SCOPE_MAPPING` VALUES ('a3a37b6f-21f9-49da-8561-1b850d20cba5','298e3fa8-5bb9-43f6-8859-f09da0d5c99b'),('1d1424ea-24c6-4434-b5e5-8e96e26f3255','4a38d073-c8b2-4d2f-a41b-309828b871c8'),('af07419a-9fdd-48f8-bb86-98deababeb5d','4dd0c0cd-e03b-45f9-98e0-132d7209a096'),('1d1424ea-24c6-4434-b5e5-8e96e26f3255','68c7aa64-39d7-4257-ae05-d44e82880078'),('a3a37b6f-21f9-49da-8561-1b850d20cba5','aade3d9c-31da-4d1b-92b6-a0fdd5e65e7d'),('63f568e6-51bc-4bbe-9fb4-1dcf570d09a4','d655fcec-fa9b-4a04-8760-9e31934fba58');
/*!40000 ALTER TABLE `SCOPE_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SCOPE_POLICY`
--

DROP TABLE IF EXISTS `SCOPE_POLICY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SCOPE_POLICY` (
  `SCOPE_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `POLICY_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`SCOPE_ID`,`POLICY_ID`),
  KEY `IDX_SCOPE_POLICY_POLICY` (`POLICY_ID`),
  CONSTRAINT `FK_FRSRASP13XCX4WNKOG82SSRFY` FOREIGN KEY (`POLICY_ID`) REFERENCES `RESOURCE_SERVER_POLICY` (`ID`),
  CONSTRAINT `FK_FRSRPASS3XCX4WNKOG82SSRFY` FOREIGN KEY (`SCOPE_ID`) REFERENCES `RESOURCE_SERVER_SCOPE` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SCOPE_POLICY`
--

LOCK TABLES `SCOPE_POLICY` WRITE;
/*!40000 ALTER TABLE `SCOPE_POLICY` DISABLE KEYS */;
/*!40000 ALTER TABLE `SCOPE_POLICY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USERNAME_LOGIN_FAILURE`
--

DROP TABLE IF EXISTS `USERNAME_LOGIN_FAILURE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `USERNAME_LOGIN_FAILURE` (
  `REALM_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `USERNAME` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `FAILED_LOGIN_NOT_BEFORE` int DEFAULT NULL,
  `LAST_FAILURE` bigint DEFAULT NULL,
  `LAST_IP_FAILURE` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `NUM_FAILURES` int DEFAULT NULL,
  PRIMARY KEY (`REALM_ID`,`USERNAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USERNAME_LOGIN_FAILURE`
--

LOCK TABLES `USERNAME_LOGIN_FAILURE` WRITE;
/*!40000 ALTER TABLE `USERNAME_LOGIN_FAILURE` DISABLE KEYS */;
/*!40000 ALTER TABLE `USERNAME_LOGIN_FAILURE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_ATTRIBUTE`
--

DROP TABLE IF EXISTS `USER_ATTRIBUTE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `USER_ATTRIBUTE` (
  `NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `USER_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'sybase-needs-something-here',
  `LONG_VALUE_HASH` binary(64) DEFAULT NULL,
  `LONG_VALUE_HASH_LOWER_CASE` binary(64) DEFAULT NULL,
  `LONG_VALUE` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  PRIMARY KEY (`ID`),
  KEY `IDX_USER_ATTRIBUTE` (`USER_ID`),
  KEY `IDX_USER_ATTRIBUTE_NAME` (`NAME`,`VALUE`),
  KEY `USER_ATTR_LONG_VALUES` (`LONG_VALUE_HASH`,`NAME`),
  KEY `USER_ATTR_LONG_VALUES_LOWER_CASE` (`LONG_VALUE_HASH_LOWER_CASE`,`NAME`),
  CONSTRAINT `FK_5HRM2VLF9QL5FU043KQEPOVBR` FOREIGN KEY (`USER_ID`) REFERENCES `USER_ENTITY` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_ATTRIBUTE`
--

LOCK TABLES `USER_ATTRIBUTE` WRITE;
/*!40000 ALTER TABLE `USER_ATTRIBUTE` DISABLE KEYS */;
INSERT INTO `USER_ATTRIBUTE` VALUES ('locale','en','4688d9ef-f6e2-4d2e-8eef-b394fc6d6b76','1b8d7ac2-59da-43d6-85a1-26f00f864970',NULL,NULL,NULL),('locale','en','6f6845e2-f1b4-4a00-aae6-f8cf1a69479d','3db45cb1-1caf-423c-8145-62a3da6f4c3b',NULL,NULL,NULL),('locale','en','ff717361-63cd-4068-9a80-5f7be827009f','a1ce7dc0-7f20-4efd-9a13-9fa3f90fb5d2',NULL,NULL,NULL),('locale','en','e5a40a06-e7f9-47e4-b817-acd16c665e68','bd3086de-e761-4daa-96f9-e8fb87a603c1',NULL,NULL,NULL),('terms_and_conditions','1743759003','4688d9ef-f6e2-4d2e-8eef-b394fc6d6b76','e57b8976-dd8f-4f82-85f1-021e81a6b09c',NULL,NULL,NULL);
/*!40000 ALTER TABLE `USER_ATTRIBUTE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_CONSENT`
--

DROP TABLE IF EXISTS `USER_CONSENT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `USER_CONSENT` (
  `ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `CLIENT_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `USER_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `CREATED_DATE` bigint DEFAULT NULL,
  `LAST_UPDATED_DATE` bigint DEFAULT NULL,
  `CLIENT_STORAGE_PROVIDER` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `EXTERNAL_CLIENT_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_LOCAL_CONSENT` (`CLIENT_ID`,`USER_ID`),
  UNIQUE KEY `UK_EXTERNAL_CONSENT` (`CLIENT_STORAGE_PROVIDER`,`EXTERNAL_CLIENT_ID`,`USER_ID`),
  KEY `IDX_USER_CONSENT` (`USER_ID`),
  CONSTRAINT `FK_GRNTCSNT_USER` FOREIGN KEY (`USER_ID`) REFERENCES `USER_ENTITY` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_CONSENT`
--

LOCK TABLES `USER_CONSENT` WRITE;
/*!40000 ALTER TABLE `USER_CONSENT` DISABLE KEYS */;
/*!40000 ALTER TABLE `USER_CONSENT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_CONSENT_CLIENT_SCOPE`
--

DROP TABLE IF EXISTS `USER_CONSENT_CLIENT_SCOPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `USER_CONSENT_CLIENT_SCOPE` (
  `USER_CONSENT_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `SCOPE_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`USER_CONSENT_ID`,`SCOPE_ID`),
  KEY `IDX_USCONSENT_CLSCOPE` (`USER_CONSENT_ID`),
  KEY `IDX_USCONSENT_SCOPE_ID` (`SCOPE_ID`),
  CONSTRAINT `FK_GRNTCSNT_CLSC_USC` FOREIGN KEY (`USER_CONSENT_ID`) REFERENCES `USER_CONSENT` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_CONSENT_CLIENT_SCOPE`
--

LOCK TABLES `USER_CONSENT_CLIENT_SCOPE` WRITE;
/*!40000 ALTER TABLE `USER_CONSENT_CLIENT_SCOPE` DISABLE KEYS */;
/*!40000 ALTER TABLE `USER_CONSENT_CLIENT_SCOPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_ENTITY`
--

DROP TABLE IF EXISTS `USER_ENTITY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `USER_ENTITY` (
  `ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `EMAIL` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `EMAIL_CONSTRAINT` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `EMAIL_VERIFIED` bit(1) NOT NULL DEFAULT b'0',
  `ENABLED` bit(1) NOT NULL DEFAULT b'0',
  `FEDERATION_LINK` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `FIRST_NAME` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `LAST_NAME` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `REALM_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `USERNAME` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `CREATED_TIMESTAMP` bigint DEFAULT NULL,
  `SERVICE_ACCOUNT_CLIENT_LINK` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `NOT_BEFORE` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_DYKN684SL8UP1CRFEI6ECKHD7` (`REALM_ID`,`EMAIL_CONSTRAINT`),
  UNIQUE KEY `UK_RU8TT6T700S9V50BU18WS5HA6` (`REALM_ID`,`USERNAME`),
  KEY `IDX_USER_EMAIL` (`EMAIL`),
  KEY `IDX_USER_SERVICE_ACCOUNT` (`REALM_ID`,`SERVICE_ACCOUNT_CLIENT_LINK`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_ENTITY`
--

LOCK TABLES `USER_ENTITY` WRITE;
/*!40000 ALTER TABLE `USER_ENTITY` DISABLE KEYS */;
INSERT INTO `USER_ENTITY` VALUES ('07cfcdaa-d117-4f30-8b94-1d0e30196515',NULL,'6a0f7444-b9a5-46d5-9bb6-a6f77526442f',_binary '\0',_binary '',NULL,'DO NOT DELETE!','DO NOT DELETE!','hi-therapist','hi_backend',1606207907844,NULL,0),('1d46a5b9-3e17-42ab-a8bd-c2d1c4700e84','production@wehost.asia','production@wehost.asia',_binary '\0',_binary '',NULL,'Web','Essentials','master','admin',1604463938141,NULL,0),('4688d9ef-f6e2-4d2e-8eef-b394fc6d6b76',NULL,'27c85b91-cf53-4abf-a121-dc831d8ca984',_binary '\0',_binary '',NULL,NULL,NULL,'hi-therapist','therapist@we.co',1743754665388,NULL,0),('6f6845e2-f1b4-4a00-aae6-f8cf1a69479d','organization-admin@we.co','organization-admin@we.co',_binary '',_binary '',NULL,'Organization','Admin','hi','organization-admin@we.co',1646363590862,NULL,0),('730d393a-7ffc-47d2-9d9e-f7747ef74ced','clinic-admin@we.co','clinic-admin@we.co',_binary '',_binary '',NULL,'Clinic','Admin','hi','clinic-admin@we.co',1607487861439,NULL,0),('aea2b548-e5aa-4663-85d0-966d96c2da47',NULL,'298f7b6f-f8a4-4f76-a417-acffd8809a48',_binary '\0',_binary '',NULL,'DO NOT DELETE!','DO NOT DELETE!','hi-library','hi_backend',1627528950776,NULL,0),('e5a40a06-e7f9-47e4-b817-acd16c665e68','super-admin@we.co','super-admin@we.co',_binary '',_binary '',NULL,'Admin','Super','hi','super-admin@we.co',1646211347084,NULL,0),('f2041bb8-59ef-4663-8142-8c8c8223f851',NULL,'ed96b71d-fa39-456a-bb93-597ca4087d7d',_binary '\0',_binary '',NULL,'DO NOT DELETE!','DO NOT DELETE!','hi','hi_backend',1604895823718,NULL,1739960058),('ff717361-63cd-4068-9a80-5f7be827009f','country-admin@we.co','country-admin@we.co',_binary '',_binary '',NULL,'Country','Admin','hi','country-admin@we.co',1646367796137,NULL,0);
/*!40000 ALTER TABLE `USER_ENTITY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_FEDERATION_CONFIG`
--

DROP TABLE IF EXISTS `USER_FEDERATION_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `USER_FEDERATION_CONFIG` (
  `USER_FEDERATION_PROVIDER_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`USER_FEDERATION_PROVIDER_ID`,`NAME`),
  CONSTRAINT `FK_T13HPU1J94R2EBPEKR39X5EU5` FOREIGN KEY (`USER_FEDERATION_PROVIDER_ID`) REFERENCES `USER_FEDERATION_PROVIDER` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_FEDERATION_CONFIG`
--

LOCK TABLES `USER_FEDERATION_CONFIG` WRITE;
/*!40000 ALTER TABLE `USER_FEDERATION_CONFIG` DISABLE KEYS */;
/*!40000 ALTER TABLE `USER_FEDERATION_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_FEDERATION_MAPPER`
--

DROP TABLE IF EXISTS `USER_FEDERATION_MAPPER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `USER_FEDERATION_MAPPER` (
  `ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `FEDERATION_PROVIDER_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `FEDERATION_MAPPER_TYPE` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `REALM_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IDX_USR_FED_MAP_FED_PRV` (`FEDERATION_PROVIDER_ID`),
  KEY `IDX_USR_FED_MAP_REALM` (`REALM_ID`),
  CONSTRAINT `FK_FEDMAPPERPM_FEDPRV` FOREIGN KEY (`FEDERATION_PROVIDER_ID`) REFERENCES `USER_FEDERATION_PROVIDER` (`ID`),
  CONSTRAINT `FK_FEDMAPPERPM_REALM` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_FEDERATION_MAPPER`
--

LOCK TABLES `USER_FEDERATION_MAPPER` WRITE;
/*!40000 ALTER TABLE `USER_FEDERATION_MAPPER` DISABLE KEYS */;
/*!40000 ALTER TABLE `USER_FEDERATION_MAPPER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_FEDERATION_MAPPER_CONFIG`
--

DROP TABLE IF EXISTS `USER_FEDERATION_MAPPER_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `USER_FEDERATION_MAPPER_CONFIG` (
  `USER_FEDERATION_MAPPER_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`USER_FEDERATION_MAPPER_ID`,`NAME`),
  CONSTRAINT `FK_FEDMAPPER_CFG` FOREIGN KEY (`USER_FEDERATION_MAPPER_ID`) REFERENCES `USER_FEDERATION_MAPPER` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_FEDERATION_MAPPER_CONFIG`
--

LOCK TABLES `USER_FEDERATION_MAPPER_CONFIG` WRITE;
/*!40000 ALTER TABLE `USER_FEDERATION_MAPPER_CONFIG` DISABLE KEYS */;
/*!40000 ALTER TABLE `USER_FEDERATION_MAPPER_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_FEDERATION_PROVIDER`
--

DROP TABLE IF EXISTS `USER_FEDERATION_PROVIDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `USER_FEDERATION_PROVIDER` (
  `ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `CHANGED_SYNC_PERIOD` int DEFAULT NULL,
  `DISPLAY_NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `FULL_SYNC_PERIOD` int DEFAULT NULL,
  `LAST_SYNC` int DEFAULT NULL,
  `PRIORITY` int DEFAULT NULL,
  `PROVIDER_NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REALM_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IDX_USR_FED_PRV_REALM` (`REALM_ID`),
  CONSTRAINT `FK_1FJ32F6PTOLW2QY60CD8N01E8` FOREIGN KEY (`REALM_ID`) REFERENCES `REALM` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_FEDERATION_PROVIDER`
--

LOCK TABLES `USER_FEDERATION_PROVIDER` WRITE;
/*!40000 ALTER TABLE `USER_FEDERATION_PROVIDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `USER_FEDERATION_PROVIDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_GROUP_MEMBERSHIP`
--

DROP TABLE IF EXISTS `USER_GROUP_MEMBERSHIP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `USER_GROUP_MEMBERSHIP` (
  `GROUP_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `USER_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`GROUP_ID`,`USER_ID`),
  KEY `IDX_USER_GROUP_MAPPING` (`USER_ID`),
  CONSTRAINT `FK_USER_GROUP_USER` FOREIGN KEY (`USER_ID`) REFERENCES `USER_ENTITY` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_GROUP_MEMBERSHIP`
--

LOCK TABLES `USER_GROUP_MEMBERSHIP` WRITE;
/*!40000 ALTER TABLE `USER_GROUP_MEMBERSHIP` DISABLE KEYS */;
INSERT INTO `USER_GROUP_MEMBERSHIP` VALUES ('a874c900-56b5-43c9-84cc-e2232d01accf','6f6845e2-f1b4-4a00-aae6-f8cf1a69479d'),('c262046d-3b62-41ca-89f5-747cdbcf472a','730d393a-7ffc-47d2-9d9e-f7747ef74ced'),('bbeb9671-7a62-4333-a809-b4138e11a4ed','e5a40a06-e7f9-47e4-b817-acd16c665e68'),('43644117-0a68-4f54-9d9d-a79bc788da6d','ff717361-63cd-4068-9a80-5f7be827009f');
/*!40000 ALTER TABLE `USER_GROUP_MEMBERSHIP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_REQUIRED_ACTION`
--

DROP TABLE IF EXISTS `USER_REQUIRED_ACTION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `USER_REQUIRED_ACTION` (
  `USER_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `REQUIRED_ACTION` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ' ',
  PRIMARY KEY (`REQUIRED_ACTION`,`USER_ID`),
  KEY `IDX_USER_REQACTIONS` (`USER_ID`),
  CONSTRAINT `FK_6QJ3W1JW9CVAFHE19BWSIUVMD` FOREIGN KEY (`USER_ID`) REFERENCES `USER_ENTITY` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_REQUIRED_ACTION`
--

LOCK TABLES `USER_REQUIRED_ACTION` WRITE;
/*!40000 ALTER TABLE `USER_REQUIRED_ACTION` DISABLE KEYS */;
/*!40000 ALTER TABLE `USER_REQUIRED_ACTION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_ROLE_MAPPING`
--

DROP TABLE IF EXISTS `USER_ROLE_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `USER_ROLE_MAPPING` (
  `ROLE_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `USER_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`ROLE_ID`,`USER_ID`),
  KEY `IDX_USER_ROLE_MAPPING` (`USER_ID`),
  CONSTRAINT `FK_C4FQV34P1MBYLLOXANG7B1Q3L` FOREIGN KEY (`USER_ID`) REFERENCES `USER_ENTITY` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_ROLE_MAPPING`
--

LOCK TABLES `USER_ROLE_MAPPING` WRITE;
/*!40000 ALTER TABLE `USER_ROLE_MAPPING` DISABLE KEYS */;
INSERT INTO `USER_ROLE_MAPPING` VALUES ('10726d7c-b18f-4cee-86ed-85b47f0cf37e','07cfcdaa-d117-4f30-8b94-1d0e30196515'),('18ad43de-71c2-4a8b-ad73-f07085acdf31','07cfcdaa-d117-4f30-8b94-1d0e30196515'),('1e93736d-f776-45b2-a96b-d25eea66709b','07cfcdaa-d117-4f30-8b94-1d0e30196515'),('22ffa567-5b11-4982-afc8-f3116f592f31','07cfcdaa-d117-4f30-8b94-1d0e30196515'),('28a570b2-8bd0-49f5-a9d3-ab2cafefb639','1d46a5b9-3e17-42ab-a8bd-c2d1c4700e84'),('298e3fa8-5bb9-43f6-8859-f09da0d5c99b','1d46a5b9-3e17-42ab-a8bd-c2d1c4700e84'),('368e1c70-6301-46e4-ae40-067ebe468d7c','1d46a5b9-3e17-42ab-a8bd-c2d1c4700e84'),('9df01365-d95e-4866-af36-e9001bf2d534','1d46a5b9-3e17-42ab-a8bd-c2d1c4700e84'),('cdf78286-af3f-4934-8a79-1a93399bc6e7','1d46a5b9-3e17-42ab-a8bd-c2d1c4700e84'),('032f3007-2de0-4d68-a1f2-2bcb362c49e4','4688d9ef-f6e2-4d2e-8eef-b394fc6d6b76'),('8d4c4127-a801-4654-83a1-4ac23c6da4b3','6f6845e2-f1b4-4a00-aae6-f8cf1a69479d'),('2e12ca9a-83f4-4aed-98a7-7fa6ea1ba299','aea2b548-e5aa-4663-85d0-966d96c2da47'),('3cccce94-b48e-4c33-8958-4f7657fc314b','aea2b548-e5aa-4663-85d0-966d96c2da47'),('44f11c4f-11de-4930-a9bb-66f1504833af','aea2b548-e5aa-4663-85d0-966d96c2da47'),('4a38d073-c8b2-4d2f-a41b-309828b871c8','aea2b548-e5aa-4663-85d0-966d96c2da47'),('5460ad86-a19a-467f-ba48-9c1ad3377b1c','aea2b548-e5aa-4663-85d0-966d96c2da47'),('54f3ba9c-339a-47f1-9c90-7adb0dc81720','aea2b548-e5aa-4663-85d0-966d96c2da47'),('561aa322-24db-4b3e-837e-95566a8010a1','aea2b548-e5aa-4663-85d0-966d96c2da47'),('5ddd5c4c-e4d8-45d0-a399-d240e8a434c3','aea2b548-e5aa-4663-85d0-966d96c2da47'),('684b9754-6a4e-496d-887b-6c5a9e9b38b8','aea2b548-e5aa-4663-85d0-966d96c2da47'),('7a77eaa4-ec6d-4364-9d61-113997360274','aea2b548-e5aa-4663-85d0-966d96c2da47'),('864c5a94-0990-484f-be31-2a78ed815e00','aea2b548-e5aa-4663-85d0-966d96c2da47'),('9bb9ff1d-b7b5-465b-a062-ce5008ff6cf3','aea2b548-e5aa-4663-85d0-966d96c2da47'),('a101ab45-c2cd-49c1-9f29-858b1cbfcd1c','aea2b548-e5aa-4663-85d0-966d96c2da47'),('a9a48d94-076e-4dd8-902b-fa5b4cc92561','aea2b548-e5aa-4663-85d0-966d96c2da47'),('c43fba40-8523-428c-b2ce-793efe0fa6de','aea2b548-e5aa-4663-85d0-966d96c2da47'),('d686ff30-9ce6-4d21-b40e-954cf53da12d','aea2b548-e5aa-4663-85d0-966d96c2da47'),('8d4c4127-a801-4654-83a1-4ac23c6da4b3','e5a40a06-e7f9-47e4-b817-acd16c665e68'),('054bebcf-01e1-4372-bde4-ff06daa0d164','f2041bb8-59ef-4663-8142-8c8c8223f851'),('120ca44d-f527-4bb3-9583-d8161284cbde','f2041bb8-59ef-4663-8142-8c8c8223f851'),('14ac522d-5f9f-495c-8481-87e42bb08980','f2041bb8-59ef-4663-8142-8c8c8223f851'),('308a36be-0b75-42e8-8917-b711d045134d','f2041bb8-59ef-4663-8142-8c8c8223f851'),('4b6e58bc-31ce-4f87-ba54-d537ca2592cd','f2041bb8-59ef-4663-8142-8c8c8223f851'),('6e394702-4f6a-4b94-9470-519fd14eead7','f2041bb8-59ef-4663-8142-8c8c8223f851'),('8d4c4127-a801-4654-83a1-4ac23c6da4b3','f2041bb8-59ef-4663-8142-8c8c8223f851'),('afaee320-f76a-48ad-a700-b106d05813d9','f2041bb8-59ef-4663-8142-8c8c8223f851'),('b30da0e7-4091-4583-8472-419ccb8f9de0','f2041bb8-59ef-4663-8142-8c8c8223f851'),('b6f16505-bdbe-4ee0-af77-06ddb84cb62c','f2041bb8-59ef-4663-8142-8c8c8223f851'),('b82479b2-0770-4d20-b015-ffeb651b6fe1','f2041bb8-59ef-4663-8142-8c8c8223f851'),('b8d4e191-773f-4142-a859-8314a7fb5926','f2041bb8-59ef-4663-8142-8c8c8223f851'),('de71c678-fba9-42bc-a16c-a0a339d0c820','f2041bb8-59ef-4663-8142-8c8c8223f851'),('e6320424-9682-466c-bc33-131ffeb0c062','f2041bb8-59ef-4663-8142-8c8c8223f851'),('8d4c4127-a801-4654-83a1-4ac23c6da4b3','ff717361-63cd-4068-9a80-5f7be827009f');
/*!40000 ALTER TABLE `USER_ROLE_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_SESSION`
--

DROP TABLE IF EXISTS `USER_SESSION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `USER_SESSION` (
  `ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `AUTH_METHOD` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `IP_ADDRESS` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `LAST_SESSION_REFRESH` int DEFAULT NULL,
  `LOGIN_USERNAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REALM_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REMEMBER_ME` bit(1) NOT NULL DEFAULT b'0',
  `STARTED` int DEFAULT NULL,
  `USER_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `USER_SESSION_STATE` int DEFAULT NULL,
  `BROKER_SESSION_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `BROKER_USER_ID` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_SESSION`
--

LOCK TABLES `USER_SESSION` WRITE;
/*!40000 ALTER TABLE `USER_SESSION` DISABLE KEYS */;
/*!40000 ALTER TABLE `USER_SESSION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_SESSION_NOTE`
--

DROP TABLE IF EXISTS `USER_SESSION_NOTE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `USER_SESSION_NOTE` (
  `USER_SESSION` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`USER_SESSION`,`NAME`),
  CONSTRAINT `FK5EDFB00FF51D3472` FOREIGN KEY (`USER_SESSION`) REFERENCES `USER_SESSION` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_SESSION_NOTE`
--

LOCK TABLES `USER_SESSION_NOTE` WRITE;
/*!40000 ALTER TABLE `USER_SESSION_NOTE` DISABLE KEYS */;
/*!40000 ALTER TABLE `USER_SESSION_NOTE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WEB_ORIGINS`
--

DROP TABLE IF EXISTS `WEB_ORIGINS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WEB_ORIGINS` (
  `CLIENT_ID` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `VALUE` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`CLIENT_ID`,`VALUE`),
  KEY `IDX_WEB_ORIG_CLIENT` (`CLIENT_ID`),
  CONSTRAINT `FK_LOJPHO213XCX4WNKOG82SSRFY` FOREIGN KEY (`CLIENT_ID`) REFERENCES `CLIENT` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WEB_ORIGINS`
--

LOCK TABLES `WEB_ORIGINS` WRITE;
/*!40000 ALTER TABLE `WEB_ORIGINS` DISABLE KEYS */;
INSERT INTO `WEB_ORIGINS` VALUES ('1472daaa-5420-4b1f-bfb2-f184f16a8320','/*'),('30febc11-32fa-4349-a4db-a46a33775ab2','/*'),('558bc5ae-068f-4e0b-b70a-170b730aa137','/*'),('5ac1fbef-dc0d-437e-bdfb-6d0c0d467dc0','+'),('620c09d1-5d44-4bda-959f-82ff964b0f98','/*'),('cb884845-e614-4c6e-9508-6fd6ae87fd60','+'),('d3bacc5c-ac4e-41ab-abb9-3d79878ddcdc','+'),('d84f18c2-b355-4a93-893b-a886e0b8fcf2','+'),('da8a1c0e-1290-4e3d-988f-7ff967de07d8','/*'),('e233b1cf-3455-4e60-9488-ec12dfa884d2','/*');
/*!40000 ALTER TABLE `WEB_ORIGINS` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-07  7:23:18
